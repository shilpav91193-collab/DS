<?php

namespace App\Traits;

use App\Models\ContentRolesMap;
use Auth;
use Illuminate\Database\Eloquent\Builder;

trait HasUserRole
{
    // public function getUserRoleAttribute()
    // {
    //     return $this->getRoles()->pluck('user_roles.name');
    // }

    protected $append = ['user_type'];

    private static $content_type = '';

    public function getUserTypeAttribute()
    {
        self::$content_type = $this->post_type;

        return $this->userTypeValue()->value('user_type');
    }

    public function userTypeValue()
    {
        $modal = strtolower(str_replace('App\Models\\', '', get_class($this)));
        if ($modal == 'posts') {
            $modal = self::$content_type ?? 'posts';
        }

        return $this->hasOne(ContentRolesMap::class, 'content_id', 'id')->where('content_type', $modal);
    }

    public static function whereHasUserTypeValue($content_type = false)
    {
        if (Auth::guard('api')->check()) {
            $user = Auth::guard('api')->user();
        } else {
            $user = Auth::user();
        }

        $modal = strtolower(str_replace('App\Models\\', '', static::class));

        if ($modal == 'posts') {
            $content_type = $content_type ?? $modal;
            self::$content_type = $content_type;

            return static::whereHas('userTypeValue', function (Builder $query) use ($content_type, $user) {
                $query->where('content_type', '=', $content_type)
                ->where(function ($q) use ($user) {
                    $q->where('user_type', '=', $user->type)
                    ->orWhere('user_type', '=', 'public');
                });
            });
        } elseif ($modal != 'policy') {
            return static::whereHas('userTypeValue', function (Builder $query) use ($modal, $user) {
                $query->where('content_type', '=', $modal)
                ->where(function ($q) use ($user) {
                    $q->where('user_type', '=', $user->type)
                    ->orWhere('user_type', '=', 'public');
                });
            });
        } else {
            return static::whereHas('userTypeValue', function (Builder $query) use ($modal, $user) {
                $query->where('content_type', '=', $modal)
                ->where(function ($q) use ($user) {
                    if ($user->type == 'student') {
                        $q->where('user_type', '=', $user->type)
                        ->orWhere('user_type', '=', 'public');
                    } elseif ($user->type == 'staff') {
                        $q->where('user_type', '=', 'student')
                        ->orWhere('user_type', '=', 'staff')
                        ->orWhere('user_type', '=', 'public');
                    }
                });
            });
        }
    }

    public static function whereHasPublicValue($content_type = null)
    {
        $modal = strtolower(str_replace('App\Models\\', '', static::class));

        $content_type = $content_type ?? $modal;
        self::$content_type = $content_type;

        return static::whereHas('userTypeValue', function (Builder $query) use ($content_type) {
            $query->where('content_type', '=', $content_type)
            ->where('user_type', '=', 'public');
        });
    }

    public function syncUserTypes($array, $content_type = null)
    {
        $array = array_filter($array);
        $modal = strtolower(str_replace('App\Models\\', '', get_class($this)));
        $content_type = $content_type ?? $modal;
        self::$content_type = $content_type;
        if (empty($array)) {
            $this->userTypeValue()->delete();
        } else {
            $this->userTypeValue()->updateOrCreate(['content_type' => $content_type], ['user_type' => $array[0]]);
        }
    }

    // public function getRoles()
    // {
    //     return $this->belongsToMany(UserRole::class, 'content_roles_map', 'content_id', 'user_type')
    //                                 ->where([
    //                                     'content_type' => strtolower(str_replace('App\Models\\', '', get_class($this))),
    //                                     'user_type' => 'user'
    //                                 ]);
    // }

    // public function getUserRoleAttribute()
    // {
    //     return $this->hasMany(ContentRolesMap::class, 'content_id')
    //                 ->where('content_type', '=', strtolower(str_replace('App\Models\\', '', get_class($this))))
    //                 ->pluck('role_id')->toArray();
    // }
}
