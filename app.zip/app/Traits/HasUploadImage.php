<?php

namespace App\Traits;

use App\Models\Medias;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

trait HasUploadImage
{
    // upload an image using ajax
    public function uploadImage(Request $request)
    {
        $file = $request->file('image');
        $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048',
        ]);

        $name = $file->store('public/media');
        $url = '/storage/'.str_replace('public/', '', $name);
        $media = new Medias;
        $media->is_default = 'N';
        $media->file_title = $request->input('file_name', '');
        $media->file_name = $url;
        $media->file_url = $url;
        $media->created_by = Auth::id();
        $media->save();
        $media->file_url = asset($url);

        return response()->json([
            'status' => 'success',
            'image' => $media,
        ], 201);
    }

    public function addVideo(Request $request)
    {
        $request->validate([
            'video_url' => 'required|url',
        ]);
        $media = new Medias;
        $media->is_default = 'N';
        $media->file_title = $request->input('file_name', '');
        $media->file_name = $request->input('video_url');
        $media->file_url = $request->input('video_url');
        $media->content_type = 'video';
        $media->created_by = Auth::id();
        $media->save();
        $media->file_url = $request->input('video_url');

        return response()->json([
            'status' => 'success',
            'video' => $media,
        ], 201);
    }

    public function removeImage(Request $request)
    {
        $id = $request->input('id');
        $media = Medias::findOrFail($id);
        $media->delete();
        if ($media->content_type != 'video') {
            try {
                unlink(storage_path('app/public/'.str_replace('/storage/', '', $media->file_url)));
            } catch (\Exception $e) {
                // do nothing
            }
        }

        return response()->json([
            'status' => 'success',
        ], 200);
    }
}
