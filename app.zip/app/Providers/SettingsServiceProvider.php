<?php

namespace App\Providers;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class SettingsServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        if (Schema::hasTable('settings')) {
            Cache::flush();

            //Config values

            //Site confiuration values
            $settings = Cache::remember('settings', 60, function () {
                // Laravel >= 5.2, use 'lists' instead of 'pluck' for Laravel <= 5.1
                return \App\Models\Setting::pluck('value', 'name')->all();
            });
            config()->set('settings', $settings);

            //Config values
            $config = Cache::remember('config', 60, function () {
                $admin_roles = config('settings.admin_access_roles') ? array_map('trim', explode(',', config('settings.admin_access_roles'))) : [1, 2];

                return ['admin_roles' => $admin_roles];
            });
            config()->set('config', $config);

            //Content types
            $content_type = Cache::remember('content_type', 60, function () {
                $posts = [
                    'page' => (object) [
                        'singular' => 'Page',
                        'plural' => 'Pages',
                        'add' => 'Page',
                        'edit' => 'Page',
                        'list' => 'Pages',
                        'menu' => 'Pages',
                        'slug' => 'page',
                        'image' => true,
                        'image_size' => '',
                        'enable_fotos' => false,
                        'enable_icon_class' => false,
                        'enable_foto_url' => false,
                        'enable_video' => false,
                        'enable_author' => false,
                        'enable_excerpt' => true,
                        'enable_subtitle' => false,
                        'enable_short_description' => false,
                        'enable_featured' => false,
                        'featured_posts' => '',
                        'enable_seo' => true,
                        'date' => false,
                        'enable_banner' => true,
                        'enable_note' => false,
                        'url' => true,
                        'pagebuilder' => false,
                        'enable_location' => false,

                    ],
                    'news' => (object) [
                        'singular' => 'News',
                        'plural' => 'News',
                        'add' => 'News',
                        'edit' => 'News',
                        'list' => 'News',
                        'menu' => 'News',
                        'slug' => 'news',
                        'image' => true,
                        'image_size' => '',
                        'enable_fotos' => false,
                        'enable_foto_url' => false,
                        'enable_icon_class' => false,
                        'enable_video' => false,
                        'enable_author' => false,
                        'enable_excerpt' => true,
                        'enable_subtitle' => false,
                        'enable_short_description' => false,
                        'enable_featured' => false,
                        'enable_location' => false,
                        'featured_posts' => '',
                        'enable_seo' => true,
                        'date' => true,
                        'enable_banner' => true,
                        'enable_note' => false,
                        'url' => true,
                        'pagebuilder' => false,
                        'terms' => ['news'],
                    ],
                    'sectors' => (object) [
                        'singular' => 'Sector',
                        'plural' => 'Sectors',
                        'add' => 'Sectors',
                        'edit' => 'Sectors',
                        'list' => 'Sectors',
                        'menu' => 'Sectors',
                        'slug' => 'sectors',
                        'image' => true,
                        'image_size' => '',
                        'enable_fotos' => false,
                        'enable_foto_url' => false,
                        'enable_video' => false,
                        'enable_icon_class' => true,
                        'enable_author' => false,
                        'enable_excerpt' => true,
                        'enable_subtitle' => true,
                        'enable_short_description' => false,
                        'enable_featured' => false,
                        'enable_location' => false,
                        'featured_posts' => '',
                        'enable_seo' => true,
                        'date' => true,
                        'enable_banner' => true,
                        'enable_note' => false,
                        'url' => true,
                        'pagebuilder' => false,
                        'terms' => ['sectors'],
                    ],
                    'districts' => (object) [
                        'singular' => 'District',
                        'plural' => 'Districts',
                        'add' => 'Districts',
                        'edit' => 'Districts',
                        'list' => 'Districts',
                        'menu' => 'Districts',
                        'slug' => 'districts',
                        'image' => true,
                        'image_size' => '',
                        'enable_fotos' => false,
                        'enable_foto_url' => false,
                        'enable_video' => false,
                        'enable_icon_class' => true,
                        'enable_author' => false,
                        'enable_excerpt' => false,
                        'enable_subtitle' => false,
                        'enable_short_description' => true,
                        'enable_featured' => false,
                        'enable_location' => false,
                        'featured_posts' => '',
                        'enable_seo' => true,
                        'date' => false,
                        'enable_banner' => true,
                        'enable_note' => true,
                        'enable_disctrict_note' => true,
                        'url' => true,
                        'pagebuilder' => false,
                        'terms' => ['districts'],
                    ],
                    'airports' => (object) [
                        'singular' => 'Airport',
                        'plural' => 'Airports',
                        'add' => 'Airport',
                        'edit' => 'Airport',
                        'list' => 'Airports',
                        'menu' => 'Airports',
                        'slug' => 'airports',
                        'image' => true,
                        'image_size' => '',
                        'enable_fotos' => false,
                        'enable_foto_url' => false,
                        'enable_video' => false,
                        'enable_icon_class' => true,
                        'enable_author' => false,
                        'enable_excerpt' => false,
                        'enable_subtitle' => false,
                        'enable_short_description' => false,
                        'enable_featured' => false,
                        'enable_location' => false,
                        'featured_posts' => '',
                        'enable_seo' => true,
                        'date' => false,
                        'enable_banner' => true,
                        'enable_note' => true,
                        'enable_disctrict_note' => false,
                        'url' => true,
                        'pagebuilder' => false,
                        'terms' => ['airports'],
                    ],
                    'article' => (object) [
                        'singular' => 'Article',
                        'plural' => 'Articles',
                        'add' => 'Article',
                        'edit' => 'Article',
                        'list' => 'Article',
                        'menu' => 'Article',
                        'slug' => 'article',
                        'image' => true,
                        'image_size' => '',
                        'enable_fotos' => false,
                        'enable_foto_url' => false,
                        'enable_icon_class' => false,
                        'enable_video' => false,
                        'enable_author' => true,
                        'enable_excerpt' => true,
                        'enable_subtitle' => false,
                        'enable_short_description' => false,
                        'enable_featured' => false,
                        'featured_posts' => '',
                        'enable_seo' => true,
                        'date' => true,
                        'enable_banner' => true,
                        'enable_note' => false,
                        'url' => true,
                        'pagebuilder' => false,
                        'terms' => ['article'],
                    ],
                    'contents' => (object) [
                        'singular' => 'Content',
                        'plural' => 'Contents',
                        'add' => 'Content',
                        'edit' => 'Content',
                        'list' => 'Contents',
                        'menu' => 'Content',
                        'slug' => 'contents',
                        'image' => true,
                        'image_size' => '',
                        'enable_fotos' => false,
                        'enable_foto_url' => false,
                        'enable_icon_class' => false,
                        'enable_video' => false,
                        'enable_author' => false,
                        'enable_excerpt' => true,
                        'enable_subtitle' => false,
                        'enable_short_description' => false,
                        'enable_featured' => false,
                        'featured_posts' => '',
                        'enable_seo' => false,
                        'date' => true,
                        'enable_banner' => false,
                        'enable_note' => false,
                        'district_meta' => false,
                        'url' => true,
                        'pagebuilder' => false,
                        'terms' => ['category' => 'Categories'],
                    ],

                ];

                return $posts;
            });
            config()->set('content_type', $content_type);

            //Content types
            $terms = Cache::remember('terms', 60, function () {
                $posts = [
                    'category' => (object) [
                        'singular' => 'Category',
                        'plural' => 'Categories',
                        'add' => 'Category',
                        'edit' => 'Category',
                        'list' => 'Categories',
                        'menu' => 'Categories',
                        'slug' => 'category',
                        'image' => true,
                        'url' => true,
                        'enable_seo' => false,
                    ],
                    'category2' => (object) [
                        'singular' => 'Category',
                        'plural' => 'Categories',
                        'add' => 'Category',
                        'edit' => 'Category',
                        'list' => 'Categories',
                        'menu' => 'Categories',
                        'slug' => 'category',
                        'image' => true,
                        'url' => true,
                        'enable_seo' => false,
                    ],
                ];

                return $posts;
            });
            config()->set('terms', $terms);
        }
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
