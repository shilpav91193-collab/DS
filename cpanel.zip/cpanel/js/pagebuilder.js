/*
 * Author: Asker
 * Date: 31 March 2022
 * Description:
 *      This is custom script
 **/

/* global moment:false, Chart:false, Sparkline:false */
(function ($) {
  'use strict'


    $.fn.pagebuilder = function (options) {
        var $options = {};
        var opts = $.extend({}, $.fn.pagebuilder.defaults, options);
        var $loaderHtml = '<div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>';

        //$( ".sort-items" ).sortable();
        $('.sort-blocks').sortable({
            dragoverBubble: true
        }).bind('sortupdate', function($this,ui) {
            var sectionids = $(this).closest('.sort-blocks').find('div.block').map(function(){  return $(this).data("id"); }).get().join(",");

              $.ajax({
                   url: opts.url+"ajax",
                   method: 'POST',
                   dataType: 'json',
                   data:{ sectionids:sectionids, action: 'block-order-update' },
                   error: function(){
                       console.log('block order not updated!!');
                   },
                   success: function (data) {
                       if(data.status == 'success'){
                            console.log(data.body);
                            return true;
                       }
                       else{
                            alert(data.message);
                       }

                   }

           });
       });

       /*
        $('.sort-sections').sortable({ handle: '.handle' }).bind('sortupdate', function($this,ui) {
            var sectionids = $('.sort-items div.section').map(function(){  return $(this).data("id"); }).get().join(",");

              $.ajax({
                   url: opts.url+"ajax",
                   method: 'POST',
                   dataType: 'json',
                   data:{ sectionids:sectionids, action: 'section-order-update' },
                   error: function(){
                       console.log('section order not updated!!');
                   },
                   success: function (data) {
                       if(data.status == 'success'){
                            console.log(data.body);
                            return true;
                       }
                       else{
                            alert(data.message);
                       }

                   }

           });
       });
       */


        $('.pagebuilder').click(function(e) {
            var $this = $(this);
            var content_type = $(this).attr('data-value');
            var id = $(this).attr('data-id');
            var url = window.location.href;

            $.getJSON(opts.url + "ajax",{ action: 'load-pagebuilder' ,content_type:content_type,id:id},function(data){
                if(data.status == 'success'){
                    if(content_type == 'builder'){
                        $('.content_type').val('builder');
                        $this.attr('data-value','normal');
                        $this.html('Switch to page normal');
                    }
                    else{
                        $('.content_type').val('normal');
                        $this.attr('data-value','builder');
                        $this.html('Switch to page builder');


                    }
                        $('#conten_sections').html(data.body);
                }
            });
        });


        /*
        $(document).on("click", "#pagebuilder_add_section", function(e) {
            var id = $(this).attr('data-id');
            $('.select-section-popup').modal('show');
            $('.select-section-popup').find('.modal-title').html('Select Section')
            $('.select-section-popup').find('.modal-body').html($loaderHtml)
            $.getJSON(opts.url + "ajax",{ action: 'list-section-type',id:id},function(data){
                if(data.status == 'success'){
                    $('.select-section-popup').find('.modal-body').html(data.body);
                }
            });
        });
        $(document).on("change", "#column_selection", function(e) {
            var blocks = $(this).val();
            var post_id = $(this).attr('data-id');
            $.getJSON(opts.url + "ajax",{ action: 'add-section-wrap',blocks:blocks,post_id:post_id},function(data){
                if(data.status == 'success'){
                    $('.sections-list').append(data.body);
                }
                $('.select-section-popup').modal('hide');
            });
        });
        */
        //New code
        $(document).on("click", "#pagebuilder_add_section", function(e) {
            var post_id = $(this).attr('data-id');
            var blocks = 0;
            $.getJSON(opts.url + "ajax",{ action: 'add-section-wrap',blocks:blocks,post_id:post_id},function(data){
                if(data.status == 'success'){
                    $('.sections-list').append(data.body);
                }
            });
        });
        $(document).on("click", ".add_content_block", function(e) {
            $('.select-section-popup').modal('show');
            $('.select-section-popup').find('.modal-title').html('Select Section');
            $('.select-section-popup').find('.modal-body').html($loaderHtml);
            var post_id = $(this).attr('data-id');
            var section = $(this).attr('data-section');
            $.getJSON(opts.url + "ajax",{ action: 'list-section-type',id:post_id},function(data){
                if(data.status == 'success'){
                    $('.select-section-popup').find('.modal-body').html(data.body);
                }
            });
        });

        $(document).on("click", ".edit_content_block, .edit_content_block_dropdown+.dropdown-menu .dropdown-item", function(e) {
            e.preventDefault();
            var finder = $(this).is('.edit_content_block') ? $(this) : $(this).closest('.dropdown-menu').prev('.dropdown-toggle');
            var post_id = finder.attr('data-post_id');
            var block_id = finder.attr('data-id');
            var section = finder.attr('data-section');
            var column = finder.attr('data-column');
            var block_type = $(this).attr('data-block-type');
            $('.select-section-popup').modal('show');
            $('.select-section-popup').find('.modal-title').html('Edit content block');
            $('.select-section-popup').find('.modal-body').html($loaderHtml);
            $.getJSON(opts.url + "ajax",{ action: "edit-content-block",block_id:block_id,post_id:post_id,section:section,column:column,block_type:block_type},function(data){
                if(data.status == 'success'){
                    $('.select-section-popup').find('.modal-body').html(data.body);
                    //setTimeout(function(){
                        $(".textEditor").summernote({
                            height: 200,
                            disableDragAndDrop : false,
                            toolbar: TOOLBAR,
                            styleTags: STYLETAGS,
                        });
                    //}, 1000);
                }
            });

        });

        $(document).on("click", ".section_block_copy", function() {
            if(!confirm('Are you sure you want to create a duplicate of this block?'))
                return false;
            var $this = $(this);
            var prevText = $(this).html();
            $(this).html('<i class="fas fa-spinner fa-pulse"></i>');
            $.ajax({
                url: opts.url + "ajax",
                method: "POST",
                dataType: "json",
                data: {action: "copy-content-block",block_id:$(this).attr('data-id')},
                error: function (e) {
                    console.log(e);
                    alert("Internal Server Error.");
                },
                success: function (data) {
                    $this.html(prevText);
                    if (data.status == "success") {
                        $('.section-'+data.section.id).html(data.body);
                        $('.sort-blocks').sortable('refresh');
                    }
                    else {
                        alert('Something went wrong.');
                    }
                },
            });
        });

        $(document).on("submit", "#section_block_frm", function(e) {
            e.preventDefault();
            var $this = $(this);
            var prevText = $(this).find('button.submit').html();
            $(this).find('button.submit').html('<i class="fas fa-spinner fa-pulse"></i> Please wait..');
            var formdata =$(this).serialize();
            $.ajax({
                url: opts.url + "ajax",
                method: "POST",
                dataType: "json",
                data: formdata,
                error: function (e) {
                    console.log(e);
                    alert("Internal Server Error.");
                },
                success: function (data) {
                    $this.find('button.submit').html(prevText);
                    if (data.status == "success") {
                        $('.select-section-popup').modal('hide');
                        $('.section-'+data.section.id).html(data.body);
                        $('.sort-blocks').sortable('refresh');
                        //$('.column-'+data.block.section_id+'-'+data.block.sort_order).find('em.column-title').html(data.block.title);
                        //$('.column-'+data.block.section_id+'-'+data.block.sort_order).find('a.edit_content_block').attr('data-id',data.block.id);
                    }
                    else {
                        $('.select-section-popup').find('.modal-body').append('');
                    }
                },
            });
        });

    //    $(document).on('change',".mediaType",function(e){
    //        if($(this).val() == 'image'){
    //            $('.image').removeClass('d-none');
    //            $('.video').addClass('d-none');
    //        }
    //        else if($(this).val() == 'video'){
    //            $('.image').addClass('d-none');
    //            $('.video').removeClass('d-none');
    //        }
    //        else{
    //            $('.image').addClass('d-none');
    //            $('.video').addClass('d-none');
    //        }
    //    });
        /*********** IMAGES UPLOAD TEMP *******************/
       $(document).on('change',".image-upload",function(e){

                var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                var $this = $(this);
                var form_data = new FormData();
                var totalfiles = $(this).prop("files").length;
                var $error = [];

                for (var index = 0; index < totalfiles; index++) {
                    var $file = $(this).prop("files")[index]
                    var $size = parseInt($file.size)/(1024*1024);
                    if($size < 5.01){
                        form_data.append("files[]", $file);
                    }
                    else{
                        form_data.append("size_error[]", $file.name) ;
                    }
                }
                form_data.append("action", "temp-upload-image");
                form_data.append("_token", CSRF_TOKEN);
                $('div.imageOutput').html('<i class="fa fa-spinner fa-pulse"></i> please wait..');
                $this.attr('disabled',true);

                $.ajax({
                        type: "POST",
                        url: opts.url+'ajax',
                        dataType:'json',
                        cache: false,
                        contentType: false,
                        processData: false,
                        data: form_data,
                        success: function(result){
                            $this.next('div').html('');
                            $this.removeAttr('disabled');
                            if(result.status == 'success'){
                                $('div.imageOutput').html(result.body);
                            }
                            else{
                                alert(result.message);
                            }
                        },
                        error: function(e){
                           alert("Internal server error occured. May be the uploaded image size is too large. Please try with another image!!" );
                           $this.closest('div').find('#upload-media-button').html('<i class="fa fa-upload"></i>').removeAttr('disabled');
                           $this.removeAttr('disabled');
                        }
                    });

        });

        $(document).on("click", ".delete_tmp_image", function(e) {
            var name = $(this).attr('data-name');
            var $this = $(this);
            $.getJSON(opts.url + "ajax",{ action: 'delete-tmp-image',name:name},function(data){
                if(data.status == 'success'){
                    $this.closest('div').remove();
                }
            });

        });
        $(document).on("click", ".delete_org_image", function(e) {
            var name = $(this).attr('data-name');
            var $this = $(this);
            $.getJSON(opts.url + "ajax",{ action: 'delete-org-image',name:name},function(data){
                if(data.status == 'success'){
                    $this.closest('div').remove();
                    $('.img_input').val('');
                }
            });

        });
        $(document).on("click", ".delete-content-section", function(e) {
            var post_id = $(this).attr('data-post_id');
            var section = $(this).attr('data-section');
            var $this = $(this);

            if(confirm('Are you sure you want to delete this section?') == true){
                $this.html('<i class="fa fa-spinner fa-pulse"></i>');
                $.getJSON(opts.url + "ajax",{ action: 'delete-content-section',section:section,post_id:post_id},function(data){
                     if(data.status == 'success'){
                        $('div.section-'+section).css("background-color","#E5E5E5").fadeOut(500, function(){
                            $(this).remove();
                            $this.html('<i class="far fa-trash-alt"></i>');
                            //location.reload();
                        });
                     }
                 });
            }
            return false;
        });
        $(document).on("click", ".section-status-update", function(e) {
            var id = $(this).attr('data-id');
            var status = $(this).attr('data-status');
            var $this = $(this);
            $this.html('<i class="fa fa-spinner fa-pulse"></i>');
            $.getJSON(opts.url + "ajax",{ action: 'section-status-update',status:status,id:id},function(data){
                 if(data.status == 'success'){
                    $this.html(data.body);
                    $this.attr('data-status',data.status_value);
                 }
             });
            return false;
        });
        $(document).on("click", ".section-settings", function(e) {
            $('.select-section-popup').modal('show');
            $('.select-section-popup').find('.modal-title').html('Section');
            $('.select-section-popup').find('.modal-body').html($loaderHtml);
            var post_id = $(this).attr('data-post_id');
            var section = $(this).attr('data-section');
            $.getJSON(opts.url + "ajax",{ action: 'section-settings',section:section,post_id:post_id},function(data){
                if(data.status == 'success'){
                    $('.select-section-popup').find('.modal-body').html(data.body);
                }
            });
        });
         $(document).on("submit", "#section_settings_frm", function(e) {
            e.preventDefault();
            var $this = $(this);
            var prevText = $(this).find('button.submit').html();
            $(this).find('button.submit').html('<i class="fas fa-spinner fa-pulse"></i> Please wait..');
            var formdata =$(this).serialize();
            $.ajax({
                url: opts.url + "ajax",
                method: "POST",
                dataType: "json",
                data: formdata,
                error: function (e) {
                    alert("Internal Server Error.");
                },
                success: function (data) {
                    $this.find('button.submit').html(prevText);
                    if (data.status == "success") {
                        $('.select-section-popup').modal('hide');
                        $('.section-'+data.section.id).html(data.body);

                    }
                    else {
                        $('.select-section-popup').find('.modal-body').append('');
                    }
                },
            });
        });

        $(document).on("click", ".delete-content-block", function(e) {
            var post_id = $(this).attr('data-post_id');
            var section = $(this).attr('data-section');
            var id = $(this).attr('data-id');
            var $this = $(this);

            if(confirm('Are you sure you want to delete this block?') == true){
                $this.html('<i class="fa fa-spinner fa-pulse"></i>');
                $.getJSON(opts.url + "ajax",{ action: 'delete-content-block',section:section,id:id},function(data){
                     if(data.status == 'success'){
                        $this.closest('div.block').css("background-color","#E5E5E5").fadeOut(500, function(){
                            $(this).remove();
                            $this.html('<i class="far fa-trash-alt"></i>');
                        });
                        $('.sort-blocks').sortable('refresh');
                     }
                 });
            }
            return false;
        });
        $(document).on("change", ".display-change", function(e) {
            var value = $(this).val();
            if(value == 'Full'){
                $('#num_columns').val(1);
                $('.nums-rows').addClass('d-none');
            }
            else{
                $('.nums-rows').removeClass('d-none');
                $('#num_columns').val(3);
            }
        });


        $.fn.pagebuilder.defaults = {
            url: ""
        };
    };
})(jQuery);

