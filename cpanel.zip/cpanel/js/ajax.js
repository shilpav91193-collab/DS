
$(document).ready(function () {
    get_column_data()
       
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
  });
       
       //Get all column
       function get_column_data() {
           
           $.ajax({
               url: root_url,
               type:'GET',
               data: { }
           }).done(function(data){
               table_data_row(data.data,data.rows)
           });
       }
       
       //Column table row
       function table_data_row(data,rowsData) {
       
         
           var	rows = '';
             rows = rows + '<tr>';
           $.each( data, function( key, value ) {
               
                 rows = rows + '<th>'+value+' &nbsp;&nbsp;&nbsp;&nbsp;<a class="mr-2" style="font-size: 0.8em;" id="deleteColumn" data-id="'+key+'" data-table="'+tableId+'"><i class="fa fa-trash"></i><a class="py-0" style="font-size: 0.8em;" id="editColumn" data-id="'+key+'" data-table="'+tableId+'" data-toggle="modal" data-target="#modal-id"><i class="fa fa-edit"></i></a></th>';
                 
           });
   
         
       rows = rows + '<th>Action</th></tr>';
       html = '';
       $.each(rowsData, function( key, row ) {
           
           html = html + '<tr>';
           $.each( data, function( key1, value ) {
               rowName=row[key1];   
               if(rowName)            
                 html = html + '<td>'+rowName+'</td>';
               else
                html = html + '<td></td>';
   
              
          });
          html = html + '<td><a class="mr-2" style="font-size: 0.8em;" id="deleteRow" data-id="'+key+'" data-table="'+tableId+'"><i class="fa fa-trash"></i><a class="ml-2" style="font-size: 0.8em;" id="editRow" data-id="'+key+'" data-table="'+tableId+'" data-toggle="modal" data-target="#modal-id-row"><i class="fa fa-edit"></i></a></td></tr>';
       });
          rows+=html;
           $("tbody").html(rows);
       }
       
       //Insert column data
       $("body").on("click","#cretaeNewColumn",function(e){
       
           e.preventDefault;
           $('#userCrudModal').html("Create Column");
           $('#submit').val("Add Column");
           $('#modal-id').modal('show');          
           $('#key').val(null);
           $('#name').val(null);
           $('#table_id').val($(this).attr("table_id"));
           $('#columndata').trigger("reset");
       
       });
   
        //Insert column data
        $("body").on("click","#cretaeNewRow",function(e){
           e.preventDefault;
           $('#userCrudModalRow').html("Create Row");
           $('#rowSubmit').val("Add Row");
           $('#row_key').val(null);
           
           $.ajax({
               url: root_url,
               type:'GET',
               data: { }
           }).done(function(data){
              
               var	column = '';
               column = column + '<tr>';
             $.each( data.data, function( key, value ) {
                 
               column = column + '<th>'+value+'</th>';
                   
             });
            
     
             column = column + '</tr>';
             column = column + '<tr>';
             $.each( data.data, function( key, value ) {
                 
               column = column + '<td><textarea class="row_name textEditorLongRow" name="column['+key+']" data-key='+key+'></textarea></td>';
                   
             });
            
             column = column + '</tr>';
             $(".column-tbody").html(column);
             var TOOLBAR = [
              ['style', ['bold', 'italic', 'underline', 'clear']],           
              ['para', ['ul', 'ol']],
              ['insert', ['link', 'picture']],
              ['misc', ['codeview']]
            ];
             $(".textEditorLongRow").summernote({
              height: 200,
              disableDragAndDrop : false,
              toolbar: TOOLBAR,
              styleTags: STYLETAGS,
          });
           });
           $('#submit').val("Save");
           $('#modal-id-row').modal('show');
           $('#table_id').val($(this).attr("table_id"));
           $('#columndata').trigger("reset");
       
       });
       
       //Save data into database
       $('body').on('click', '#submit', function (event) {
           event.preventDefault()
           var id = $("#table_id").val();
           var name = $("#name").val();
           var key = $("#key").val();
         
           $.ajax({
             url: store,
             type: "POST",
             data: {
               id: id,
               name: name,
               key:key
             },
             dataType: 'json',
             success: function (data) {
                 
                 $('#columndata').trigger("reset");
                 $('#modal-id').modal('hide');
                 
                 get_column_data()
             },
             error: function (data) {
                 console.log('Error......');
             }
         });
       });
       
       //Edit modal window
       $('body').on('click', '#editColumn', function (event) {
       
           event.preventDefault();
           var id = $(this).data('id');
           
           var table = $(this).data('table');
           $.get(store+'/'+table+'/'+id+'/edit', function (data) {
                
                $('#userCrudModal').html("Edit column");
                $('#submit').val("Edit column");
                $('#modal-id').modal('show');
                $('#table_id').val(data.table);
                $('#name').val(data.data);
                $('#key').val(data.key);
            })
       });


            //Edit modal window
            $('body').on('click', '#editRow', function (event) {
       
                event.preventDefault();
                var id = $(this).data('id');
                
                var table = $(this).data('table');
                $.get(storeRow+'/'+table+'/'+id+'/edit', function (data) {
                     
                   
                     var	column = '';
                     column = column + '<tr>';
                   $.each( data.column, function( key, value ) {
                       
                     column = column + '<th>'+value+'</th>';
                         
                   });
                  
           
                   column = column + '</tr>';
                   column = column + '<tr>';
                   var rowval=data.row;
                   $.each( data.column, function( key, value ) {
                    
                       
                     column = column + '<td><textarea class="row_name textEditorLongRow" name="column['+key+']" data-key='+key+'>'+rowval[key]+'</textarea></td>';
                         
                   });
                  
                   column = column + '</tr>';
                   $(".column-tbody").html(column);
                   var TOOLBAR = [
                    ['style', ['bold', 'italic', 'underline', 'clear']],           
                    ['para', ['ul', 'ol']],
                    ['insert', ['link', 'picture']],
                    ['misc', ['codeview']]
                  ];
                   $(".textEditorLongRow").summernote({
                    height: 200,
                    disableDragAndDrop : false,
                    toolbar: TOOLBAR,
                    styleTags: STYLETAGS,
                });
                   $('#userCrudModalRow').html("Edit Row");
                   $('#rowSubmit').val("Edit Row");
                   $('#modal-id-row').modal('show');
                   $('#table_id').val(data.table);
                 
                  $('#row_key').val(data.key);
                 });
                
                 })
           
       
        //deleteColumn
        $('body').on('click', '#deleteColumn', function (event) {
           if(!confirm("Do you really want to do this?")) {
              return false;
            }
       
            event.preventDefault();
           var id = $(this).attr('data-id');
           var table = $(this).data('table');
           $.ajax(
               {
                 url: store+'/'+table+'/'+id+'/delete',
                 type: 'GET',
                 data: {
                       id: id
               },
               success: function (response){
                
                   get_column_data()
               }
            });
             return false;
          });

           //deleteRow
           $('body').on('click', '#deleteRow', function (event) {
              if(!confirm("Do you really want to do this?")) {
               return false;
             }
        
             event.preventDefault();
            var id = $(this).attr('data-id');
            var table = $(this).data('table');
            $.ajax(
                {
                  url: storeRow+'/'+table+'/'+id+'/delete',
                  type: 'GET',
                  data: {
                        id: id
                },
                success: function (response){
                 
                    get_column_data()
                }
             });
              return false;
           });
          //Save data into database
          $('body').on('submit', '#rowdata', function (event) {
            event.preventDefault(); // prevent default form submission behavior

          // serialize form data
          var formData = $(this).serialize();

          // send Ajax request
          $.ajax({
            url: storeRow, // form action URL
            type: $(this).attr('method'), // form method
            data: formData, // form data
            headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }, // CSRF token
            success: function(response) {
                $('#columndata').trigger("reset");
                $('#modal-id-row').modal('hide');
                
                get_column_data()
            },
            error: function(xhr, status, error) {
              // handle error response
            }
          });
         });
        
       }); 
   
   