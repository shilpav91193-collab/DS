

$(document).ready(function () {

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    
    //
    //  setTimeout(function() {
    //    $('#degreeType').trigger('change');
    //  }, 1000);
    


    // Listen for changes to the degree type dropdown
    $('body').on('change', '#degreeType', function (event) {
        // Get the selected degree type ID
        
        var degreeTypeId = $(this).val();
 
        // Make an AJAX call to fetch the degrees based on the degree type ID
        $.ajax({
            url: $(this).data('url'),
            method: 'POST',
            data: { id: degreeTypeId, action: 'get-degree' },
            success: function (response) {

                $('#degreeList').empty();
                var slc="";
                $.each(response.data, function (key, value) {
                    if ($.inArray(value.id, degree) !== -1) {
                          slc="selected";
                    }
                    var degreeHtml = '<option '+slc+' value="' + value.id + '">' +
                    value.title + '</option>' +'</div>';
                    $('#degreeList').append(degreeHtml);

                });

            },
            error: function (error) {
                console.error(error);
            }
        });
    });
});

