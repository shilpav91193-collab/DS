/*
 * Author:
 * Date:
 * Description:
 *      This is custom script
 **/

/* global moment:false, Chart:false, Sparkline:false */
(function ($) {
  'use strict'


    $.fn.degreebuilder = function (options) {
        var $options = {};
        var opts = $.extend({}, $.fn.degreebuilder.defaults, options);
        var $loaderHtml = '<div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>';

        //$( ".sort-items" ).sortable();
        $('.degree-sort-blocks').sortable({
            dragoverBubble: true
        }).bind('sortupdate', function($this,ui) {
            var sectionids = $(this).closest('.degree-sort-blocks').find('div.block').map(function(){  return $(this).data("id"); }).get().join(",");

              $.ajax({
                   url: opts.url+"ajax",
                   method: 'POST',
                   dataType: 'json',
                   data:{ ids:sectionids, action: 'block-order-update' },
                   error: function(){
                       console.log('block order not updated!!');
                   },
                   success: function (data) {
                       if(data.status == 'success'){
                            console.log(data.body);
                            return true;
                       }
                       else{
                            alert(data.message);
                       }

                   }

           });
       });
        $(document).on("click", ".edit_degree_block, .edit_degree_block_dropdown+.dropdown-menu .dropdown-item", function(e) {
            e.preventDefault();
            var finder = $(this).is('.edit_degree_block') ? $(this) : $(this).closest('.dropdown-menu').prev('.dropdown-toggle');

            var id = finder.attr('data-id');
            var block_type = $(this).attr('data-block-type');
            var degree_id = finder.attr('data-degree-id');
            var sort_order = finder.attr('data-sort-order');
            var section_id = finder.attr('data-section_id');

            $('.select-section-popup').modal('show');
            $('.select-section-popup').find('.modal-title').html('Edit Degree Content block');
            $('.select-section-popup').find('.modal-body').html($loaderHtml);
            $.getJSON(opts.url + "ajax",{ action: "edit-degree-block", id: id, type: block_type, section_id: section_id, degree_id: degree_id},function(data){
                if(data.status == 'success'){
                    $('.select-section-popup').find('.modal-body').html(data.body);
                    //setTimeout(function(){
                        $(".textEditor").summernote({
                            height: 200,
                            disableDragAndDrop : false,
                            toolbar: TOOLBAR,
                            styleTags: STYLETAGS,
                        });
                        $('.select2').select2();
                    //}, 1000);
                }
            });

        });

        $(document).on("click", ".degreebuilder_add_section", function(e) {
            var $this = $(this);
            var degree_id = $(this).attr('data-id');
            var content_type = $(this).attr('data-content-type');
            $.getJSON(opts.url + "ajax",{ action: 'add-section-wrap',degree_id:degree_id, content_type :content_type},function(data){
                if(data.status == 'success'){
                    $this.closest('.sections-list').append(data.body);
                }
            });
        });

        $(document).on("click", ".degree-delete-content-section", function(e) {
            var degree_id = $(this).attr('data-degree_id');
            var section = $(this).attr('data-section');
            var $this = $(this);

            if(confirm('Are you sure you want to delete this section?') == true){
                $this.html('<i class="fa fa-spinner fa-pulse"></i>');
                $.getJSON(opts.url + "ajax",{ action: 'delete-content-section',section:section,degree_id:degree_id},function(data){
                     if(data.status == 'success'){
                        $('div.section-'+section).css("background-color","#E5E5E5").fadeOut(500, function(){
                            $(this).remove();
                            $this.html('<i class="far fa-trash-alt"></i>');
                            //location.reload();
                        });
                     }
                 });
            }
            return false;
        });
        $(document).on("click", ".degree-section-status-update", function(e) {
            var id = $(this).attr('data-id');
            var status = $(this).attr('data-status');
            var $this = $(this);
            $this.html('<i class="fa fa-spinner fa-pulse"></i>');
            $.getJSON(opts.url + "ajax",{ action: 'section-status-update',status:status,id:id},function(data){
                 if(data.status == 'success'){
                    $this.html(data.body);
                    $this.attr('data-status',data.status_value);
                 }
             });
            return false;
        });

        $(document).on("click", ".degree-section-settings", function(e) {
            $('.select-section-popup').modal('show');
            $('.select-section-popup').find('.modal-title').html('Section');
            $('.select-section-popup').find('.modal-body').html($loaderHtml);
            var degree_id = $(this).attr('data-degree_id');
            var section = $(this).attr('data-section');
            $.getJSON(opts.url + "ajax",{ action: 'section-settings',section:section,degree_id:degree_id},function(data){
                if(data.status == 'success'){
                    $('.select-section-popup').find('.modal-body').html(data.body);
                }
            });
        });
         $(document).on("submit", "#degree_section_settings_frm", function(e) {
            e.preventDefault();
            if ($(this).find($('input[name="title"]')).val() == '') {
                alert('Please enter title');
                return false;
            }
            var $this = $(this);
            var prevText = $(this).find('button.submit').html();
            $(this).find('button.submit').html('<i class="fas fa-spinner fa-pulse"></i> Please wait..');
            var formdata =$(this).serialize();
            $.ajax({
                url: opts.url + "ajax",
                method: "POST",
                dataType: "json",
                data: formdata,
                error: function (e) {
                    alert("Internal Server Error.");
                },
                success: function (data) {
                    $this.find('button.submit').html(prevText);
                    if (data.status == "success") {
                        $('.select-section-popup').modal('hide');
                        $('.section-'+data.section.id).html(data.body);
                        var section_id = data.section.id;
                        var template_id = data.section.template_id;
                        var degree_id = data.section.degree_id;
                        var slug = data.section.content_type;
                        var title = data.section.title;
                        var tab_item = $('.degreebuilder_select_template_contents');
                        var exists = tab_item.find(`[data-id="${section_id}"]`).length;
                        if (template_id) {
                            if (!exists) {
                                tab_item.append(`<a class="dropdown-item" href="javascript:void(0)" data-id="${section_id}"
                                data-degree-id="${degree_id}" data-content-type="${slug}">${title}</a>`);
                                tab_item.closest('.degree-copy-template').removeClass('d-none');
                            }
                        } else {
                            if (exists) {
                                tab_item.find(`[data-id="${section_id}"]`).remove();
                                if(!tab_item.find('a').length) {
                                    tab_item.closest('.degree-copy-template').addClass('d-none');
                                }
                            }
                        }
                    }
                    else {
                        $('.select-section-popup').find('.modal-body').append('');
                    }
                },
            });
        });

        $('.degreebuilder_select_template_contents').on('click', 'a', function() {

            var $this = $(this);
            var id = $(this).attr('data-id');
            var content_type = $(this).attr('data-content-type');
            var degree_id = $(this).attr('data-degree-id');
            $.getJSON(opts.url + "ajax",{ action: 'copy-section',degree_id:degree_id, content_type :content_type, id:id},function(data){
                if(data.status == 'success'){
                    $this.closest('.sections-list').append(data.body);
                }
            });

        });

        $(document).on("submit", "#degree_block_frm", function(e) {
            e.preventDefault();
            var $this = $(this);
            var prevText = $(this).find('button.submit').html();
            $(this).find('button.submit').html('<i class="fas fa-spinner fa-pulse"></i> Please wait..');
            var formdata =$(this).serialize();
            $.ajax({
                url: opts.url + "ajax",
                method: "POST",
                dataType: "json",
                data: formdata,
                error: function (e) {
                    console.log(e);
                    alert("Internal Server Error.");
                },
                success: function (data) {
                    $this.find('button.submit').html(prevText);
                    if (data.status == "success") {
                        $('.select-section-popup').modal('hide');
                        $('#custom-tabs-'+data.slug).find('.section-' + data.section_id).html(data.body);
                        $('.degree-sort-blocks').sortable('refresh');
                        //$('.column-'+data.block.section_id+'-'+data.block.sort_order).find('em.column-title').html(data.block.title);
                        //$('.column-'+data.block.section_id+'-'+data.block.sort_order).find('a.edit_content_block').attr('data-id',data.block.id);
                    }
                    else {
                        $('.select-section-popup').find('.modal-body').append('');
                    }
                },
            });
        });

        $(document).on("click", ".degree_block_copy", function() {
            if(!confirm('Are you sure you want to create a duplicate of this block?'))
                return false;
            var $this = $(this);
            var prevText = $(this).html();
            $(this).html('<i class="fas fa-spinner fa-pulse"></i>');
            $.ajax({
                url: opts.url + "ajax",
                method: "POST",
                dataType: "json",
                data: {action: "copy-degree-block",id:$(this).attr('data-id')},
                error: function (e) {
                    console.log(e);
                    alert("Internal Server Error.");
                },
                success: function (data) {
                    $this.html(prevText);
                    if (data.status == "success") {
                        $('#custom-tabs-'+data.slug).find('.section-' + data.section_id).html(data.body);
                        $('.degree-sort-blocks').sortable('refresh');
                    }
                    else {
                        alert('Something went wrong.');
                    }
                },
            });
        });

        $(document).on("click", ".delete-degree-block", function(e) {
            var id = $(this).attr('data-id');
            var $this = $(this);

            if(confirm('Are you sure you want to delete this block?') == true){
                $this.html('<i class="fa fa-spinner fa-pulse"></i>');
                $.getJSON(opts.url + "ajax",{ action: 'delete-degree-block',id:id},function(data){
                     if(data.status == 'success'){
                        $this.closest('div.block').css("background-color","#E5E5E5").fadeOut(500, function(){
                            $(this).remove();
                            $this.html('<i class="far fa-trash-alt"></i>');
                        });
                        $('.degree-sort-blocks').sortable('refresh');
                     }
                 });
            }
            return false;
        });


        $.fn.degreebuilder.defaults = {
            url: ""
        };
    };
})(jQuery);

