/*
 * Author: Asker
 * Date: 31 March 2022
 * Description:
 *      This is custom script
 **/

/* global moment:false, Chart:false, Sparkline:false */
(function ($) {
  'use strict'
    
    
    $.fn.webform = function (options) {
        var $options = {};
        var opts = $.extend({}, $.fn.webform.defaults, options);          
        var $loaderHtml = '<div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>';
        
        $(document).on('submit', '#webFromFrm', function(e) {
                var data = {
                  fields: []
                };
                e.preventDefault();
                var returnFalse = false;
                $('.webforms-choices-wrapper').each(function () {
                    if ((!$(this).find($('[data-meta="select_from_table"]')).val() || $(this).find($('[data-meta="select_from_table"]')).val() == '') && checkValueRequired($(this).find($('.webforms-choices-container')).find($('.webforms-choice')))) {
                        returnFalse = true;
                    }
                });
                if (returnFalse) {
                    return false;
                }
                $(this).find($('[data-meta][data-indep]')).each(function(e) {
                  var name = $(this).attr('data-meta');
                  var val = ($(this).attr('type') == 'checkbox' || $(this).attr('type') == 'radio') ? $(this).prop('checked') : $(this).val();
                  data[name] = val;
                });
                $(this).find($('[data-field]')).each(function(e) {
                  var key = $(this).attr('data-field');
                  var field = {};
                  $(this).find($('[data-meta]')).each(function(ev) {
                    var name = $(this).attr('data-meta');
                    var val = ($(this).attr('type') == 'checkbox' || $(this).attr('type') == 'radio') ? $(this).prop('checked') : $(this).val();
                    var names = name.split('.');

                    if (names.length > 1) {
                        field = createObjectFromDots(field, name, val);
                    }
                    else if (name.slice(-2) == '[]') {
                      field[name] = field[name] ? field[name] : [];
                      field[name].push(val);
                    }
                    else
                      field[name] = val;
                  });

                  if (!field.select_from_table) {
                    $(this).find($('.webforms-choices-container .webforms-choice')).each(function() {
                      field['choices'] = field['choices'] ? field['choices'] : [];

                      var choices = false;
                      $(this).find($('[data-meta-choices]')).each(function() {
                        choices = choices ? choices : {};
                        var name = $(this).attr('data-meta-choices');
                        var val = ($(this).attr('type') == 'checkbox' || $(this).attr('type') == 'radio') ? $(this).prop('checked') : $(this).val();
                        choices[name] = val;
                        console.log(name, val);
                      });
                      choices && field['choices'].push(choices);

                    });
                  }

                  data.fields.push(field);
                });
                if (data.fields.length) {
                  $(this).find('button[type="submit"]').html('<i class="fa fa-spinner fa-pulse"></i> Please wait..');
                  data._token = $('meta[name="csrf-token"]').attr('content');
                  var formData = new FormData();
                  formData.append('data', JSON.stringify(formData));
                  $.ajax({
                      method: "POST",
                      dataType: "json",
                      data: { data: JSON.stringify(data) },
                      error: function (e) {
                          toastr.error("Internal Server Error.");
                      },
                      success: function (data) {
                        console.log('success', data);
                          if (data.status == "success") {
                              self.location = data.redirect;
                          } else {
                              toastr.error(data.message);
                          }
                      },
                  });
                }
              });
        
        $(document).on("click", ".remove-input-field", function(e) {
            if (confirm('Are you sure to remove this field? This action is not reversable!')) {
                $(this).closest('div.card').css("background-color","#E5E5E5").fadeOut(500, function(){ 
                    $(this).remove();
                });
            }
        });
        
        $( ".webform-inputs.sort-sections" ).sortable({ handle: '.handle-section' }).disableSelection();
        //Dragg and Drop Layers	
        $('.button-selector').draggable({
                cancel: "a.ui-icon", 
                //revert: "invalid",
                revert: true, 
                helper: "clone", 
                cursor: "move", 
                revertDuration: 0 
        });
        
        $('.webform-inputs').droppable({
            accept: ".button-selector",
            activeClass: "ui-state-highlight",
            connectToSortable: ".webform-inputs",		
            drop: function( event, ui ) {
                // clone item to retain in original "list"
                //var $item = ui.draggable.clone();
                var type  = ui.draggable.data('type');
                var $this = $(this);
                var field_count = $('.input-field').length ;
                var extracted_counts = [];
                $('[data-meta="field_name"]').each(function(){
                    var new_count = $(this).val().split('_')[2];
                    if (new_count != null && new_count !== 'undefined') {
                        extracted_counts.push(new_count * 1);
                    }
                });
                while(extracted_counts.includes(field_count)) {
                    field_count++;
                }
                $.get( opts.url+"ajax",{action:'add-webform-inputs',type:type,count:field_count}, function( data ) {							

                          if($( ".webform-inputs .input-field" ).length == 0){
                                $this.addClass('has-drop').html( $(data.body) );
                          }
                          else{
                                  var i=0; //used as flag to find out if element added or not

                                        $this.children('.input-field').each(function()
                                        {
                                                if($(this).offset().top>=ui.offset.top)  //compare
                                           {
                                                   $(data.body).insertBefore($(this));

                                                   i=1;   
                                                   return false; //break loop
                                           }
                                        })

                                        if(i!=1) //if element dropped at the end of cart
                                        {
                                                $this.addClass('has-drop').append($(data.body));

                                        }

                          }
                          $this.sortable({ handle: '.handle-section' });
                });
                //console.log(ui.draggable.data('file'));          

            }
        });
        $(document).on("keyup", ".field_label", function(e) {
            var value = $(this).val() ? $(this).val(): 'Untitled';
            $(this).closest('div.card-body').find('.field_label_value').html(value);
        });
        $(document).on("keyup", ".field_name", function(e) {
            var value = $(this).val() ? $(this).val(): '';
            var name = value.toLowerCase()
                        .replace(/ /g, '_')
                        .replace(/[^\w-]+/g, '');
           
            $(this).val(name);
        });
        $('.sort-sections input').click(function() {
            $(this).select();
        });
        
        
         /******* Checkbox  ***********/

        $(document).on('click', '.webforms-choice-adder', function(e) {

            var $container = $(this).closest('.webforms-choices-wrapper').find($('.webforms-choices-container'));

            if (checkValueRequired($container.find($('.webforms-choice')))) {
                return false;
            }

            var $clone = $container.find($('.webforms-choice')).eq(0).clone();
            // $clone = $clone.find($('.custom-control')).prop('checked', false);
            var $checkedIndex = $container.find($('.webforms-choice [type="radio"]:checked')).closest('.webforms-choice').index();
            $clone.appendTo($container);
            // $clone.find($('.custom-control.custom-radio')).prop('checked', false);
            $container.find($('.webforms-choice')).last().find($('input')).each(function() {
                (!$(this).is('[type="checkbox"]') && !$(this).is('[type="radio"]')) && $(this).val('');
                ($(this).is('[type="checkbox"]') || $(this).is('[type="radio"]')) && $(this).prop('checked', false).trigger('change');
            });
            
            var $index = $container.find($('.webforms-choice')).last().index();
            $clone = $(this).closest('.webforms-container').find($('.webforms-choices-preview .webforms-choice-preview')).first().clone();
            $(this).closest('.webforms-container').find($('.webforms-choices-preview')).append($clone);
            var $check = $(this).closest('.webforms-container').find($('.webforms-choices-preview .webforms-choice-preview')).last();
            $check.find($('input')).val('').prop('checked', false).trigger('change');
            $check.find($('label')).text('Option ' + ($index + 1));

            $checkedIndex != -1 && $container.find($('.webforms-choice')).eq($checkedIndex).find($('input[type="radio"]')).prop('checked', true).trigger('change');
        });

        $(document).on('click', '.webforms-choice-remover', function(e) {

            var $container = $(this).closest('.webforms-choices-wrapper').find($('.webforms-choices-container'));
            if ($container.find($('.webforms-choice')).length > 1) {
                var $index = $(this).closest('.webforms-choice').index();
                $(this).closest('.webforms-container').find($('.webforms-choices-preview .webforms-choice-preview')).eq($index).remove();
                $(this).closest('.webforms-choice').remove();
            }
            
        });

        

        $(document).on('change input', '.webforms-choices-container .webforms-choice input', function() {
            var $val = $(this).val().trim() == '' ? 'Option' : $(this).val().trim();
            var $index = $(this).closest('.webforms-choice').index();
            var $check = $(this).closest('.webforms-container').find($('.webforms-choices-preview .webforms-choice-preview')).eq($index);
            if ($(this).is('.checkbox-form-label')) {
                $check.find($('label')).text($val);
            }
            if ($(this).is('.checkbox-form-value')) {
                $check.find($('input')).val($val);
            }
            // if ($(this).is('.custom-control')) {
            //     console.log($(this).prop('checked'));
            //     $check.find($('input')).prop('checked', $(this).prop('checked'));
            //     $(this).closest('.webforms-choice').find($('input[type="hidden"]')).val(($(this).prop('checked') ? 1 : 0));
            // }
        });

        $(document).on('change', '.webforms-choices-container .webforms-choice input[type="radio"], .webforms-choices-container .webforms-choice input[type="checkbox"]', function() {
            var $index = $(this).closest('.webforms-choice').index();
            var $check = $(this).closest('.webforms-container').find($('.webforms-choices-preview .webforms-choice-preview')).eq($index);
            $check.find($('input')).prop('checked', $(this).prop('checked'));
            $(this).closest('.webforms-choices-container').find($('.webforms-choice')).each(function() {
                var $val = $(this).find($('[data-meta-choices="checked"]')).prop('checked') ? 1 : 0;
                $(this).find($('input[type="hidden"]')).val($val);
                console.log($(this).index(), $(this).find($('input[type="hidden"]')).val());
            });
        });

        $(document).on('change', '.webforms-choices-table-selector', function(){
            if($(this).val() && $(this).val() != '') {
                $(this).closest('.webforms-choices-wrapper').find($('.webforms-choices-not-table')).fadeOut();
                $(this).closest('.webforms-container').find($('.webforms-choices-preview')).fadeOut();
            } else {
                $(this).closest('.webforms-choices-wrapper').find($('.webforms-choices-not-table')).fadeIn();
                $(this).closest('.webforms-container').find($('.webforms-choices-preview')).fadeIn();
            }
        });
        
        /*-------------------------------------*/
        
        function createObjectFromDots(obj, key, value) {
            var result = object = JSON.parse(JSON.stringify(obj));
            var arr = key.split('.');                                   
            for(var i = 0; i < arr.length-1; i++) {
              object = object[arr[i]] = object[arr[i]] ? object[arr[i]] : {};
            }
            if (arr[arr.length-1].slice(-2) != '[]') {
              object[arr[arr.length-1]] = value;
            } else {
              arr[arr.length-1] = arr[arr.length-1].replace('[]', '');
              object[arr[arr.length-1]] = object[arr[arr.length-1]] ? object[arr[arr.length-1]] : [];
              object[arr[arr.length-1]].push(value);
            }
            return result;
        }
        
        function checkValueRequired($item) {
            var returnValue = false;
            $item.each(function(){
                $(this).find($('.form-control')).each(function() {
                    $(this).closest('.input-group').addClass('has-validation');
                    $(this).removeClass('is-invalid');
                    if (!$(this).val() || $(this).val() == '') {
                        returnValue = true;
                        $(this).addClass('is-invalid');
                    }
                });
            });
            return returnValue;
        }
        
        
        $.fn.webform.defaults = {
            url: ""
        };
    };
})(jQuery);

