/*
 * Author:
 * Date:
 * Description:
 *      This is custom script
 **/

/* global moment:false, Chart:false, Sparkline:false */
(function ($) {
  'use strict'


    $.fn.eventbuilder = function (options) {
        var $options = {};
        var opts = $.extend({}, $.fn.eventbuilder.defaults, options);
        var $loaderHtml = '<div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>';

        //$( ".sort-items" ).sortable();
        $('.event-sort-blocks').sortable({
            dragoverBubble: true
        }).bind('sortupdate', function($this,ui) {
            var sectionids = $(this).closest('.event-sort-blocks').find('div.block').map(function(){  return $(this).data("id"); }).get().join(",");

              $.ajax({
                   url: opts.url+"ajax",
                   method: 'POST',
                   dataType: 'json',
                   data:{ ids:sectionids, action: 'block-order-update' },
                   error: function(){
                       console.log('block order not updated!!');
                   },
                   success: function (data) {
                       if(data.status == 'success'){
                            console.log(data.body);
                            return true;
                       }
                       else{
                            alert(data.message);
                       }

                   }

           });
       });
        $(document).on("click", ".edit_event_block, .edit_event_block_dropdown+.dropdown-menu .dropdown-item", function(e) {
            e.preventDefault();
            var finder = $(this).is('.edit_event_block') ? $(this) : $(this).closest('.dropdown-menu').prev('.dropdown-toggle');

            var id = finder.attr('data-id');
            var block_type = $(this).attr('data-block-type');
            var event_id = finder.attr('data-event-id');
            var sort_order = finder.attr('data-sort-order');
            var section_id = finder.attr('data-section_id');

            $('.select-section-popup').modal('show');
            $('.select-section-popup').find('.modal-title').html('Edit Degree Content block');
            $('.select-section-popup').find('.modal-body').html($loaderHtml);
            $.getJSON(opts.url + "ajax",{ action: "edit-event-block", id: id, type: block_type, section_id: section_id, event_id: event_id},function(data){
                if(data.status == 'success'){
                    $('.select-section-popup').find('.modal-body').html(data.body);
                    //setTimeout(function(){
                        $(".textEditor").summernote({
                            height: 200,
                            disableDragAndDrop : false,
                            toolbar: TOOLBAR,
                            styleTags: STYLETAGS,
                        });
                        $('.select2').select2();
                    //}, 1000);
                }
            });

        });

        $(document).on("click", ".eventbuilder_add_section", function(e) {
            var $this = $(this);
            var event_id = $(this).attr('data-id');
            var content_type = $(this).attr('data-content-type');
            $.getJSON(opts.url + "ajax",{ action: 'add-section-wrap',event_id:event_id, content_type :content_type},function(data){
                if(data.status == 'success'){
                    $this.closest('.sections-list').append(data.body);
                }
            });
        });

        $(document).on("click", ".event-delete-content-section", function(e) {
            var event_id = $(this).attr('data-event_id');
            var section = $(this).attr('data-section');
            var $this = $(this);

            if(confirm('Are you sure you want to delete this section?') == true){
                $this.html('<i class="fa fa-spinner fa-pulse"></i>');
                $.getJSON(opts.url + "ajax",{ action: 'delete-content-section',section:section,event_id:event_id},function(data){
                     if(data.status == 'success'){
                        $('div.section-'+section).css("background-color","#E5E5E5").fadeOut(500, function(){
                            $(this).remove();
                            $this.html('<i class="far fa-trash-alt"></i>');
                            //location.reload();
                        });
                     }
                 });
            }
            return false;
        });
        $(document).on("click", ".event-section-status-update", function(e) {
            var id = $(this).attr('data-id');
            var status = $(this).attr('data-status');
            var $this = $(this);
            $this.html('<i class="fa fa-spinner fa-pulse"></i>');
            $.getJSON(opts.url + "ajax",{ action: 'section-status-update',status:status,id:id},function(data){
                 if(data.status == 'success'){
                    $this.html(data.body);
                    $this.attr('data-status',data.status_value);
                 }
             });
            return false;
        });

        $(document).on("click", ".event-section-settings", function(e) {
            $('.select-section-popup').modal('show');
            $('.select-section-popup').find('.modal-title').html('Section');
            $('.select-section-popup').find('.modal-body').html($loaderHtml);
            var event_id = $(this).attr('data-event_id');
            var section = $(this).attr('data-section');
            $.getJSON(opts.url + "ajax",{ action: 'section-settings',section:section,event_id:event_id},function(data){
                if(data.status == 'success'){
                    $('.select-section-popup').find('.modal-body').html(data.body);
                }
            });
        });
         $(document).on("submit", "#event_section_settings_frm", function(e) {
            e.preventDefault();
            if ($(this).find($('input[name="title"]')).val() == '') {
                alert('Please enter title');
                return false;
            }
            var $this = $(this);
            var prevText = $(this).find('button.submit').html();
            $(this).find('button.submit').html('<i class="fas fa-spinner fa-pulse"></i> Please wait..');
            var formdata =$(this).serialize();
            $.ajax({
                url: opts.url + "ajax",
                method: "POST",
                dataType: "json",
                data: formdata,
                error: function (e) {
                    alert("Internal Server Error.");
                },
                success: function (data) {
                    $this.find('button.submit').html(prevText);
                    if (data.status == "success") {
                        $('.select-section-popup').modal('hide');
                        $('.section-'+data.section.id).html(data.body);
                        var section_id = data.section.id;
                        var template_id = data.section.template_id;
                        var event_id = data.section.event_id;
                        var slug = data.section.content_type;
                        var title = data.section.title;
                        var tab_item = $('.eventbuilder_select_template_contents');
                        var exists = tab_item.find(`[data-id="${section_id}"]`).length;
                        if (template_id) {
                            if (!exists) {
                                tab_item.append(`<a class="dropdown-item" href="javascript:void(0)" data-id="${section_id}"
                                data-event-id="${event_id}" data-content-type="${slug}">${title}</a>`);
                                tab_item.closest('.event-copy-template').removeClass('d-none');
                            }
                        } else {
                            if (exists) {
                                tab_item.find(`[data-id="${section_id}"]`).remove();
                                if(!tab_item.find('a').length) {
                                    tab_item.closest('.event-copy-template').addClass('d-none');
                                }
                            }
                        }
                    }
                    else {
                        $('.select-section-popup').find('.modal-body').append('');
                    }
                },
            });
        });

        $('.eventbuilder_select_template_contents').on('click', 'a', function() {

            var $this = $(this);
            var id = $(this).attr('data-id');
            var content_type = $(this).attr('data-content-type');
            var event_id = $(this).attr('data-event-id');
            $.getJSON(opts.url + "ajax",{ action: 'copy-section',event_id:event_id, content_type :content_type, id:id},function(data){
                if(data.status == 'success'){
                    $this.closest('.sections-list').append(data.body);
                }
            });

        });

        $(document).on("submit", "#event_block_frm", function(e) {
            e.preventDefault();
            var $this = $(this);
            var prevText = $(this).find('button.submit').html();
            $(this).find('button.submit').html('<i class="fas fa-spinner fa-pulse"></i> Please wait..');
            var formdata =$(this).serialize();
            $.ajax({
                url: opts.url + "ajax",
                method: "POST",
                dataType: "json",
                data: formdata,
                error: function (e) {
                    console.log(e);
                    alert("Internal Server Error.");
                },
                success: function (data) {
                    $this.find('button.submit').html(prevText);
                    if (data.status == "success") {
                        $('.select-section-popup').modal('hide');
                        $('.section-' + data.section_id).html(data.body);
                        $('.event-sort-blocks').sortable('refresh');
                        //$('.column-'+data.block.section_id+'-'+data.block.sort_order).find('em.column-title').html(data.block.title);
                        //$('.column-'+data.block.section_id+'-'+data.block.sort_order).find('a.edit_content_block').attr('data-id',data.block.id);
                    }
                    else {
                        $('.select-section-popup').find('.modal-body').append('');
                    }
                },
            });
        });

        $(document).on("click", ".event_block_copy", function() {
            if(!confirm('Are you sure you want to create a duplicate of this block?'))
                return false;
            var $this = $(this);
            var prevText = $(this).html();
            $(this).html('<i class="fas fa-spinner fa-pulse"></i>');
            $.ajax({
                url: opts.url + "ajax",
                method: "POST",
                dataType: "json",
                data: {action: "copy-event-block",id:$(this).attr('data-id')},
                error: function (e) {
                    console.log(e);
                    alert("Internal Server Error.");
                },
                success: function (data) {
                    $this.html(prevText);
                    if (data.status == "success") {
                        $('#custom-tabs-'+data.slug).find('.section-' + data.section_id).html(data.body);
                        $('.event-sort-blocks').sortable('refresh');
                    }
                    else {
                        alert('Something went wrong.');
                    }
                },
            });
        });

        $(document).on("click", ".delete-event-block", function(e) {
            var id = $(this).attr('data-id');
            var $this = $(this);

            if(confirm('Are you sure you want to delete this block?') == true){
                $this.html('<i class="fa fa-spinner fa-pulse"></i>');
                $.getJSON(opts.url + "ajax",{ action: 'delete-event-block',id:id},function(data){
                     if(data.status == 'success'){
                        $this.closest('div.block').css("background-color","#E5E5E5").fadeOut(500, function(){
                            $(this).remove();
                            $this.html('<i class="far fa-trash-alt"></i>');
                        });
                        $('.event-sort-blocks').sortable('refresh');
                     }
                 });
            }
            return false;
        });


        $.fn.eventbuilder.defaults = {
            url: ""
        };
    };
})(jQuery);

