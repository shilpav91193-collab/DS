/*
 * Author: Asker
 * Date: 12 Jan 2022
 * Description:
 *      This is custom script
 **/

/* global moment:false, Chart:false, Sparkline:false */

function linkifyYouTubeURLs(text) {
    var re = /https?:\/\/(?:[0-9A-Z-]+\.)?(?:youtu\.be\/|youtube(?:-nocookie)?\.com\S*?[^\w\s-])([\w-]{11})(?=[^\w-]|$)(?![?=&+%\w.-]*(?:['"][^<>]*>|<\/a>))[?=&+%\w.-]*/ig;
    return text.replace(re,
        '$1');
}
function validVideoId(id, video) {
    video.removeClass('is-invalid');
    $('video_adder_btn').attr('disabled', 'disabled');
    window.yt_video_checking = true;
    if (!id || id == '') {
        window.yt_video_checking = false;
        return false;
    }
    var img = new Image();
    img.src = "http://img.youtube.com/vi/" + id + "/mqdefault.jpg";
    img.onload = function () {
        $('video_adder_btn').removeAttr('disabled');
        checkThumbnail(this.width, video);
        window.yt_video_checking = false;
    }
    img.onerror = function () {
        $('video_adder_btn').removeAttr('disabled');
        video.addClass('is-invalid');
        window.yt_video_checking = false;
    }
}

function checkThumbnail(width, video) {
    //HACK a mq thumbnail has width of 320.
    //if the video does not exist(therefore thumbnail don't exist), a default thumbnail of 120 width is returned.
    if (width === 120) {
        video.addClass('is-invalid');
    }
}

(function ($) {
  'use strict'


    $.fn.customScript = function (options) {
        var $options = {};
        var opts = $.extend({}, $.fn.customScript.defaults, options);


        $('[data-toggle="tooltip"]').tooltip();

        $('.timepicker').datetimepicker({
            format: 'LT'
          });

        $('.select2').select2({
          theme: 'bootstrap4'
        });

        $('.textEditorLong').summernote({
            height: 500,
            disableDragAndDrop : false,
            toolbar: TOOLBAR,
            styleTags: STYLETAGS,
        });
        $('.textEditor').summernote({
            height: 200,
            disableDragAndDrop : false,
            toolbar: TOOLBAR,
            styleTags: STYLETAGS,
        });

        $.ajaxSetup({
            headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        //FORM SLUG
        $('#save_formname').click(function(e) {

            var id = $('#id').val();
            var $this = $(this);
            $this.html('<i class="fa fa-spinner fa-pulse"></i>');
            $.getJSON(opts.baseUrl + "forms/ajax",{id : id, name:$('#slug').val(), action: 'check_name' },function(data){
                    $this.html('Ok');
                    $('#slug').val(data.value).attr('type','hidden');
                    $('#event_url').removeClass('d-none').html($('#slug').val());
                    $('#edit_formname').removeClass('d-none');
                    $this.addClass('d-none');
            });
        });
        $('#edit_formname').click(function(e) {
            $('#event_url').addClass('d-none');
            $('#slug').attr('type','text');
            $(this).addClass('d-none');
            $('#save_formname').removeClass('d-none');
        });

        //EVENT SLUG
        $('#save_eventname').click(function(e) {

            var id = $('#id').val();
            var $this = $(this);
            $this.html('<i class="fa fa-spinner fa-pulse"></i>');
            $.getJSON(opts.baseUrl + "events/ajax",{id : id, name:$('#slug').val(), action: 'check_name' },function(data){
                    $this.html('Ok');
                    $('#slug').val(data.value).attr('type','hidden');
                    $('#event_url').removeClass('d-none').html($('#slug').val());
                    $('#edit_eventname').removeClass('d-none');
                    $this.addClass('d-none');
            });
        });
        $('#edit_eventname').click(function(e) {
            $('#event_url').addClass('d-none');
            $('#slug').attr('type','text');
            $(this).addClass('d-none');
            $('#save_eventname').removeClass('d-none');
        });
         $('.event-title').keyup(function(e) {
            if($('#id').val() == ''){
                 if($(this).val() != '' ){
                  $('#slug_area').removeClass('hide');
                 }

                 var Text  = $('.event-title').val();
                 var name  =  Text.toLowerCase().replace(/ /g,'-').replace(/[^\w-]+/g,'');
                     name  = name.replace('---', '-');
                     name  = name.replace('--', '-');

                 $('#event_url').html(name);
                 $('#slug').val(name);
             }
             return ;

         });

         // SERVICE BLOCK TYPE EDITOR
         $('.service-block-type-editor').on('change', function(){
            if ($(this).find('[name="content_type"]').val() == 'title') {
                $('#slug_area').addClass('d-none');
            } else {
                $('#slug_area').removeClass('d-none');
            }
         });

        //POST SLUG
        $('#save_postname').click(function(e) {

            var id = $('#post_id').val();
            var $this = $(this);
            $this.html('<i class="fa fa-spinner fa-pulse"></i>');
            $.getJSON(opts.baseUrl + "posts/ajax",{id : id, name:$('#slug').val(), action: 'check_name' },function(data){
                    $this.html('Ok');
                    $('#slug').val(data.value).attr('type','hidden');
                    $('#post_url').removeClass('d-none').html($('#slug').val());
                    $('#edit_postname').removeClass('d-none');
                    $this.addClass('d-none');
            });
        });
        $('#edit_postname').click(function(e) {
            $('#post_url').addClass('d-none');
            $('#slug').attr('type','text');
            $(this).addClass('d-none');
            $('#save_postname').removeClass('d-none');
        });
         $('.post-title').keyup(function(e) {
            if($('#post_id').val() == ''){
                 if($(this).val() != '' ){
                  $('#slug_area').removeClass('hide');
                 }

                 var Text  = $('.post-title').val();
                 var name  =  Text.toLowerCase().replace(/ /g,'-').replace(/[^\w-]+/g,'');
                     name  = name.replace('---', '-');
                     name  = name.replace('--', '-');

                 $('#post_url').html(name);
                 $('#slug').val(name);
             }
             return ;

         });
         $('.remove-image-post').click(function(e) {
		var id = $(this).data('id');
		var $this 	= $(this);
		if(confirm("Are you sure to remove this image?")){
			$(this).html('<i class="fa fa-spinner fa-pulse"></i> Please wait..');
			$.getJSON(opts.baseUrl + "posts/ajax",{id : id, action: 'remove_image' },function(data){
				$this.html('<i class="fa fa-trash"></i> Remove image');
				if(data.status == 'success'){
					$('img.image-image').remove();
					$this.closest('div').html('<div class="custom-file"><input id="image" type="file" name="image" class="custom-file-input" /><label class="custom-file-label" for="image">Choose file</label></div>');
				}
			});
		}

        });
        $('.remove-image-service').click(function(e) {
		var id = $(this).data('id');
		var $this 	= $(this);
		if(confirm("Are you sure to remove this image?")){
			$(this).html('<i class="fa fa-spinner fa-pulse"></i> Please wait..');
			$.getJSON(opts.baseUrl + "contents/ajax",{id : id, action: 'remove_image' },function(data){
				$this.html('<i class="fa fa-trash"></i> Remove image');
				if(data.status == 'success'){
					$('img.image-image').remove();
					$this.closest('div').html('<div class="custom-file"><input id="image" type="file" name="image" class="custom-file-input" /><label class="custom-file-label" for="image">Choose file</label></div>');
				}
			});
		}

        });

        // activity log previous content
        $('#previous_data_section').on('show.bs.modal', function(e){
            var gid = $(e.relatedTarget).data('guid');
            var $this = $(this).find('.modal-body');
            $this.html('<i class="fa fa-spinner fa-pulse"></i> please wait..');
            $.getJSON(opts.baseUrl + "posts/ajax",{guid : gid, action: 'previous-data' },function(data){
				if(data.status == 'success' && data.data){
                    $this.html(`<pre>${JSON.stringify(data.data, null, 4)}</pre>`);
				} else {
                    $this.html('No data!');
                }
			});
        });

         //-------------------------------------------------
         //TAXONOMY
         $('#save_taxonomyname').click(function(e) {
            var id = $('#post_id').val();
            var $this = $(this);
            $this.html('<i class="fa fa-spinner fa-pulse"></i>');
            $.getJSON(opts.baseUrl + "taxonomies/ajax",{id : id, name:$('#slug').val(), action: 'check_name' },function(data){
                    $this.html('Ok');
                    $('#slug').val(data.value).attr('type','hidden');
                    $('#taxonomy_url').removeClass('d-none').html($('#slug').val());
                    $('#edit_taxonomyname').removeClass('d-none');
                    $this.addClass('d-none');
            });
        });
         $('#edit_taxonomyname').click(function(e) {
            $('#post_url').addClass('d-none');
            $('#slug').attr('type','text');
            $(this).addClass('d-none');
            $('#save_taxonomyname').removeClass('d-none');
        });
         $('.taxonomy-title').keyup(function(e) {
            if($('#taxonomy_id').val() == ''){
                 if($(this).val() != '' ){
                  $('#slug_area').removeClass('hide');
                 }

                 var Text  = $('.taxonomy-title').val();
                 var name  =  Text.toLowerCase().replace(/ /g,'-').replace(/[^\w-]+/g,'');
                     name  = name.replace('---', '-');
                     name  = name.replace('--', '-');

                 $('#taxonomy_url').html(name);
                 $('#slug').val(name);
             }
             return ;

         });
         $('.remove-image-taxonomy').click(function(e) {
		var id = $(this).data('id');
		var $this 	= $(this);
		if(confirm("Are you sure to remove this image?")){
			$(this).html('<i class="fa fa-spinner fa-pulse"></i> Please wait..');
			$.getJSON(opts.baseUrl + "taxonomies/ajax",{id : id, action: 'remove_image' },function(data){
				$this.html('<i class="fa fa-trash"></i> Remove image');
				if(data.status == 'success'){
					$('img.image-image').remove();
					$this.closest('div').html('<div class="custom-file"><input id="image" type="file" name="image" class="custom-file-input" /><label class="custom-file-label" for="image">Choose file</label></div>');
				}
			});
		}

        });

        /*CHANGING OF STATUS*/
        $(document).on("click", ".changeStatus", function () {
            if (confirm("Are you sure you want to change the status of this item?")) {
              var id = $(this).data("id");
              var statusType = $(this).data("status-type");
              var status = $(this).attr("data-status");
              var $this = $(this);

              $.ajax({
                url: opts.baseUrl + "ajax/changeStatus",
                method: "POST",
                dataType: "json",
                data: { id: id, status: status, statusType: statusType },
                error: function (e) {
                  toastr.error("Internal Server Error.");
                },
                success: function (data) {
                  if (data.status == "success") {
                    var newStatus = status == "Y" ? "N" : "Y";
                    $this.attr("data-status", newStatus); // Use $this instead of $(this)
                  } else {
                    toastr.error(data.message);
                  }
                },
              });
            } else {
              return false;
            }
          });

        /*User Roles*/
        $(".check_module").click(function () {
            var class_name = $(this).attr("id");
            var status = $("#" + class_name).attr("data-status");

            if (status == "off") {
                $("#" + class_name).attr("data-status", "on");
            } else {
                $("#" + class_name).attr("data-status", "off");
            }

            $("." + class_name).each(function () {
                if (status == "off") {
                    $(this).attr("checked", "checked");
                } else {
                    $(this).removeAttr("checked");
                }
            });
        });
        //GENERATE PASSWORD
        $(document).on("click", ".generate_password", function () {
            $.ajax({
                url: opts.baseUrl + "ajax/generatePassword",
                method: "POST",
                dataType: "json",
                error: function (e) {
                    toastr.error("Internal Server Error.");
                },
                success: function (data) {
                    if (data.status == "success") {
                        $("#password").val(data.password);
                        $("#confirm_password").val(data.password);
                    }
                },
            });
        });
        /*********** IMAGES UPLOAD TEMP *******************/
        $(document).on('change',".doc-upload",function(e){

                var $this = $(this);
                var form_data = new FormData();
                var totalfiles = $(this).prop("files").length;
                var $error = [];

                for (var index = 0; index < totalfiles; index++) {
                    var $file = $(this).prop("files")[index]
                    var $size = parseInt($file.size)/(1024*1024);
                    if($size < 5.01){
                        form_data.append("files[]", $file);
                    }
                    else{
                        form_data.append("size_error[]", $file.name) ;
                    }
                }
                form_data.append("action", "temp-upload-media");
                $('div.imageOutput').html('<i class="fa fa-spinner fa-pulse"></i> please wait..');
                $this.attr('disabled',true);

                $.ajax({
                        type: "POST",
                        url: opts.baseUrl+'files/ajax',
                        dataType:'json',
                        type: 'POST',
                        data: form_data,
                        async: false,
                        cache: false,
                        contentType: false,
                        enctype: 'multipart/form-data',
                        processData: false,
                        success: function(result){
                            $this.next('div').html('');
                            $this.removeAttr('disabled');
                            if(result.status == 'success'){
                                $('div.imageOutput').html(result.body);
                            }
                            else{
                                alert(result.message);
                            }
                        },
                        error: function(e){
                           alert("Internal server error occured. May be the uploaded image size is too large. Please try with another image!!" );
                           $this.closest('div').find('#upload-media-button').html('<i class="fa fa-upload"></i>').removeAttr('disabled');
                           $this.removeAttr('disabled');
                        }
                    });

        });



        $(document).on('change', '.forms-form-type-input', function(){
            if ($(this).val() == 'webform') {
                $('.forms-webforms-section').fadeIn();
                $('.forms-external-url').fadeOut();
                $('.forms-document-section').fadeOut();
            }
            else if ($(this).val() == 'url') {
                $('.forms-webforms-section').fadeOut();
                $('.forms-external-url').fadeIn();
                $('.forms-document-section').fadeOut();
            }
            else {
                $('.forms-webforms-section').fadeOut();
                $('.forms-external-url').fadeOut();
                $('.forms-document-section').fadeIn();
            }
        });


        $(document).on('change',".is_external",function(e){
          if($(this).is(":checked") == true){
              $('.external_url').removeAttr('disabled');
          }
          else{
             $('.external_url').attr('disabled',true);
          }
        });

        /******* Forms List  ***********/

        /*--------------------------------------------------------------------*/
        $(".nav-link.active").closest("li.has-treeview").addClass("menu-open");
        $(".nav-link.active").closest("li.has-treeview").find(">a.nav-link").addClass("active");
        $.fn.customScript.defaults = {
            apiUrl: "",
            baseUrl: ""
        };

        $('.youtube_id_area').on('paste', function (e) {
            var $this = $(this);
            var paste = e.originalEvent.clipboardData.getData('text');
            var id = linkifyYouTubeURLs(paste);
            validVideoId(id, $this);
            e.preventDefault();
            $('.youtube_id_area').val(id);
            return false;
        });

        $('.youtube_id_area').on('input', function (e) {
            var $this = $(this);
            var paste = $this.val();
            var id = linkifyYouTubeURLs(paste);
            $('.youtube_id_area').val(id);
            validVideoId(id, $this);
        });

        $('.youtube_id_area').trigger('input');

    };
})(jQuery);
