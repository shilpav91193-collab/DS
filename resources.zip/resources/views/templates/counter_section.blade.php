@if(count($datas) > 0)
    <div class="row">
        <div class="col-12">
            <div class="counter-section text-center" id="counter">
                <ul class="m-0">
                    @foreach($datas as $key => $data)
                        <li>
                            <div class="counter-box">
                                <p>{!! $key !!}</p>
                                <h3 class="counter plus">{{$data}}</h3>
                            </div>
                        </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>

@endif
