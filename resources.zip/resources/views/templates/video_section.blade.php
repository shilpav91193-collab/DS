<div class="col-12 my-5">
    <div class="row justify-content-center text-white">
        <div class="col-12 p-0 text-center">
            <video width="100%" loop="true" autoplay="true" controls muted>
                <source src="{{ asset('frontend/videos/Comp.mp4') }}" type="video/mp4">
                <source src="{{ asset('frontend/videos/Comp.mp4') }}" type="video/ogg">
                Your browser does not support the video tag.
            </video>
        </div>
    </div>
</div>
