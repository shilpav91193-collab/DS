<div class="tab-content group-client-animation" id="myTabContent">
    @foreach($datas as $key => $data)
        <div class="tab-pane @if($loop->first) show active @else fade  @endif"
             id="tab-{{$key}}" role="tabpanel">
            <ul class="group-client">
                @if(count($data->groups) > 0)
                    @foreach($data->groups as $group)
                        <li>
                            <a href="{{$group->url ?? "javascript:void(0)" }}" target="_blank">

                                <figure>
                                    @if(isset($group->featured_image->file_url))
                                    <img src="{{isset($group->featured_image->file_url)
                                     ? $group->featured_image->file_url
                                      : ''}}"/>
                                    @else
                                        <h4>{!! $group->title  !!}</h4>
                                    @endif
                                </figure>

                                {!! $group->description  !!}
                            </a>
                        </li>
                    @endforeach
                @endif
            </ul>
        </div>
    @endforeach
</div>
