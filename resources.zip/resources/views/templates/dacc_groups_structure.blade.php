<h2 class="text-blue text-uppercase mb-5">
    <strong>Dubai Aviation City Corporation Group Structure</strong>
</h2>
<div class="group-structure">
    <div class="slidePlaceholder" onclick="$(this).hide()">
        <img src="{{ asset('frontend/images/swipe.gif') }}">
    </div>
    <ul class="nav nav-tabs " id="myTab" role="tablist">
        @foreach($datas as $key => $data)
            <li class="nav-item" role="presentation">
                <button class="nav-link @if($loop->first) active @endif "
                        id="{{$data->title}}-tab"
                        data-bs-toggle="tab"
                        data-bs-target="#tab-{{$key}}"
                        type="button" role="tab" aria-selected="true">{{$data->title}}</button>
            </li>
        @endforeach
    </ul>
</div>





