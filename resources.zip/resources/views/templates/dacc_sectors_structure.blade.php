@php
$locale = App::getLocale() ? App::getLocale() : 'en';
@endphp
<h2 class="text-uppercase">Our <strong>Diversified sectors</strong></h2>
<ul class="">
    @foreach($datas as $data)
        @php
            $data->meta = $data->meta();
        @endphp
        <li>
            <a href="{{ url("/$locale/sectors/$data->slug") }}">
                <span class="{{ isset($data->meta->icon_class) ? $data->meta->icon_class : '' }}"></span>{{$data->title}}
            </a>
        </li>
    @endforeach
    <span class="overlay"></span>
</ul>

