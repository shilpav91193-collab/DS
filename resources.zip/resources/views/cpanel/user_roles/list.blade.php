@extends('layouts.cpanel')
@section('content')

@php
  $user = Auth::user();
  $can_any_action = \App\Http\Helpers::getAccess($user, 'roles', 'update,delete');
  $can_create = \App\Http\Helpers::getAccess($user, 'roles', 'create');
  $can_update = \App\Http\Helpers::getAccess($user, 'roles', 'update');
  $can_delete = \App\Http\Helpers::getAccess($user, 'roles', 'delete');
@endphp

<div class="content-header">
    <div class="container-fluid">
        <form name="frm" action="" method="get" enctype="multipart/form-data">
            <div class="row my-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark"><small class="fa fa-list"></small> User Roles
                      @if($can_create)
                        <a href="{{route('roles.create')}}" class="btn btn-default ml-2"><i class="fa fa-plus"></i> Add New</a>
                      @endif
                    </h1>
                </div>
                <div class="col-md-3">
                </div>
                <div class="col-md-3">
                    <div class="card-tools">
                        <div class="input-group input-group-sm">
                          <input type="text" name="s" value="{{Request::input('s')}}" class="form-control float-right" placeholder="Search">

                          <div class="input-group-append">
                            <button type="submit" class="btn btn-default">
                              <i class="fas fa-search"></i>
                            </button>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="content">
    <div class="container-fluid">
        @include('layouts.common.messages')
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th width="3%">#.</th>
                                      @if($can_any_action)
                                        <th width="12%">Action</th>
                                      @endif
                                    <th>Name</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($results as $i=>$result)
                                    <tr>
                                        <td>
                                            {{
                                                ($limit = $filter['limit'] ?? 0) *
                                                (($page = app('request')->input('page') ?? 1) - 1 ) +
                                                $loop->iteration
                                            }}
                                        </td>
                                        @if($can_any_action)
                                            <td>
                                                <ul class="list-inline m-0">
                                                    @if($can_update)
                                                          <li class="list-inline-item">
                                                              <a href="{{route('roles.edit', ['id'=>$result->id])}}"
                                                                 data-toggle="tooltip"
                                                                 title="Edit"
                                                                 class="text-primary">
                                                                  <i class="far fa-edit"></i></a>
                                                          </li>
                                                    @endif
                                                    @if($can_delete && $result->id > 4)
                                                          <li class="list-inline-item">
                                                              <a onclick="return confirm('Are you sure you want to delete this role?')"
                                                                 href="{{route('roles.destroy',['id'=>$result->id])}}"
                                                                 data-toggle="tooltip"
                                                                 title="Delete"
                                                                 class="text-danger">
                                                                  <i class="far fa-trash-alt"></i>
                                                              </a>
                                                          </li>
                                                    @endif
                                                    @if($can_update)
                                                          <li class="list-inline-item">
                                                          <div class="custom-control custom-switch custom-switch-off-danger custom-switch-on-success" data-toggle="tooltip" title="Status">
                                                              <input type="checkbox" class="custom-control-input changeStatus" data-id={{$result->id}} data-status-type='user_roles' data-status={{$result->status}} {{ $result->status=='Y' ? 'checked' : '' }} id="customSwitch_{{$i}}">
                                                                <label class="custom-control-label" for="customSwitch_{{$i}}"></label>
                                                              </div>
                                                          </li>
                                                    @endif
                                                </ul>
                                            </td>
                                        @endif
                                        <td>{{ $result->name }}</td>
                                    </tr>
                                @empty
                                    <tr>
                                      <td colspan="2">
                                        No records found!
                                      </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer clearfix">
                        <div class="row">
                              <div class="col-md-1">
                                  {{ Form::select('limit', ['5'=>5,'10'=>10,'25'=>25,'50'=>50,'100'=>100],
                                                app('request')->input('limit') ?
                                                 app('request')->input('limit'):
                                                 $filter['limit'], array(
                                                    'class' => 'form-control input-sm page-limit',
                                                    'id' => 'page_limit'
                                   )) }}
                              </div>
                              <div class="col-md-11">
                                  <div class="d-flex justify-content-end">
                                      <span class="mr-3">Showing {{(($results->currentPage()-1)*$results->perPage())+1}} to {{((($results->currentPage()-1)*$results->perPage())==0)?$results->perPage():($results->currentPage())*$results->perPage()}} of {{$results->total()}} entries </span>
                                        {{ $results->appends(request()->except('page'))->links('pagination::bootstrap-4') }}
                                  </div>
                              </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection



