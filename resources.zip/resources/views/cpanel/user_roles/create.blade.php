@extends('layouts.cpanel')

@section('content')
<!-- Content Wrapper. Contains page content -->

    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row my-2">
          <div class="col-sm-12">
            <h1 class="m-0 text-dark">Create User Role <a href="{{route('roles.list')}}" class="btn btn-secondary float-right"><i class="fas fa-angle-left"></i> Back to Listing</a></h1>
            
          </div><!-- /.col -->
          
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    @php
    $name= old('name');
    $module_access=old('module_access');
    $user_role=Auth::user()->roleid;
    @endphp
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        @include('layouts.common.messages')
        <form method="post" autocomplete="off" enctype="multipart/form-data">
          @csrf
          <div class="row">
              <div class="col-md-9">

                  <div class="card card-primary">
                      <div class="card-body">
                        <div class="form-group">
                          <label for="name">Name <span class="text-danger">*</span></label>
                          <input type="text" required id="name" name="name" class="form-control {{$errors->has('name') ? 'is-invalid': ''}}" value="{{ $name }}">
                        </div>

                        <br />
                        <h6><strong>Define Module Access</strong> <em class="small text-muted">(Click the <strong>Module Name</strong> or <strong>Action</strong> to toggle Check All / Uncheck all)</em></h6>
                        
                              <table class="table w-100">
                                <tbody>
                                  @foreach ($modules as $module_item)

                                  @php   
                                    $parent_id=$module_item->id;
                                    $module_items=\App\Models\ModuleItem::select('module_items.*')->
                                      join('modules as m', function($join) use ($parent_id){
                                        $join->on('module_items.module_id','=','m.id')
                                          ->where('module_items.module_id','=', $parent_id);
                                      })->orderBy('module_items.display_order')->get();
                                    @endphp

                                  @if(!$loop->first)
                                    @if (count($module_items))
                                    <tr><td colspan="6" height="20">&nbsp;</td></tr>
                                    @endif
                                  @endif
                                    <tr>
                                    <th>
                                      @if (count($module_items))
                                      <i class="{{$module_item->icon}}"></i> {{$module_item->name}}
                                      @else
                                        <a href="javascript:void(0)" class="text-dark check_module" data-status="off" id="row_m_{{$parent_id}}"><i class="{{$module_item->icon}}"></i> {{ $module_item->name }}</a>
                                      @endif
                                    </th>
                                      <th width="80" class="text-center">
                                        @if (count($module_items))
                                        <a href="javascript:void(0)" class="text-dark check_access" data-status="off" id="col_{{$parent_id}}_1">View</a>
                                        @else 
                                          <div class="icheck-primary d-inline">
                                          <input type="checkbox" class="row_m_{{$parent_id}}" value="list" id="view_m_{{$module_item->id}}" name="module_access[{{$module_item->slug}}][]"
                                            {{ isset($module_access[$module_item->slug]) ? (in_array('view', $module_access[$module_item->slug]) ? 'checked' : '') : ''}}
                                          >
                                            <label for="view_m_{{$module_item->id}}" data-toggle="tooltip" data-title="Allow View?"></label>
                                          </div>     
                                        @endif
                                      </th>
                                      <th width="80" class="text-center">
                                        @if (count($module_items))
                                        <a href="javascript:void(0)" class="text-dark check_access" data-status="off" id="col_{{$parent_id}}_2">Create</a>
                                        @else 
                                          <div class="icheck-primary d-inline">
                                          <input type="checkbox" class="row_m_{{$parent_id}}" value="create" id="create_m_{{$module_item->id}}" name="module_access[{{$module_item->slug}}][]"
                                            {{ isset($module_access[$module_item->slug]) ? (in_array('create', $module_access[$module_item->slug]) ? 'checked' : '') : ''}}
                                          >
                                            <label for="create_m_{{$module_item->id}}" data-toggle="tooltip" data-title="Allow View?"></label>
                                          </div>     
                                        @endif
                                      </th>
                                      <th width="80" class="text-center">
                                          @if (count($module_items))
                                          <a href="javascript:void(0)" class="text-dark check_access" data-status="off" id="col_{{$parent_id}}_3"> Edit/Update</a>
                                          @else 
                                            <div class="icheck-primary d-inline">
                                            <input type="checkbox" class="row_m_{{$parent_id}}" value="update" id="update_m_{{$module_item->id}}" name="module_access[{{$module_item->slug}}][]"
                                              {{ isset($module_access[$module_item->slug]) ? (in_array('update', $module_access[$module_item->slug]) ? 'checked' : '') : ''}}
                                            >
                                              <label for="update_m_{{$module_item->id}}" data-toggle="tooltip" data-title="Allow View?"></label>
                                            </div>     
                                          @endif
                                      </th>
                                      <th width="80" class="text-center">
                                          @if (count($module_items))
                                          <a href="javascript:void(0)" class="text-dark check_access" data-status="off" id="col_{{$parent_id}}_4">Delete</a>
                                          @else 
                                            <div class="icheck-primary d-inline">
                                            <input type="checkbox" class="row_m_{{$parent_id}}" value="delete" id="delete_m_{{$module_item->id}}" name="module_access[{{$module_item->slug}}][]"
                                              {{ isset($module_access[$module_item->slug]) ? (in_array('delete', $module_access[$module_item->slug]) ? 'checked' : '') : ''}}
                                            >
                                              <label for="delete_m_{{$module_item->id}}" data-toggle="tooltip" data-title="Allow View?"></label>
                                            </div>     
                                          @endif
                                      </th>
                                      <th width="80" class="text-center">
                                          @if (count($module_items))
                                            <a href="javascript:void(0)" class="text-dark check_access" data-status="off" id="col_{{$parent_id}}_5">Restore</a>
                                          @else 
                                            <div class="icheck-primary d-inline">
                                            <input type="checkbox" class="row_m_{{$parent_id}}" value="restore" id="restore_m_{{$module_item->id}}" name="module_access[{{$module_item->slug}}][]"
                                              {{ isset($module_access[$module_item->slug]) ? (in_array('restore', $module_access[$module_item->slug]) ? 'checked' : '') : ''}}
                                            >
                                              <label for="restore_m_{{$module_item->id}}" data-toggle="tooltip" data-title="Allow View?"></label>
                                            </div>     
                                          @endif
                                      </th>
                                    </tr>  

                                    

                                    @foreach ($module_items as $module)
                                    
                                      @if (!$loop->last || $user_role==1)
                                        <tr>
                                            <td>
                                            <a href="javascript:void(0)" class="text-dark check_module" data-status="off" id="row_{{$module->id}}">{{ $module->name }}</a>
                                            </td>
                                            <td class="text-center">
                                                <div class="icheck-primary d-inline">
                                                <input class="row_{{$module->id}} col_{{$parent_id}}_1" type="checkbox" id="view_{{$module->id}}" value="list"
                                                  name="module_access[{{$module->slug}}][]"
                                                  {{ isset($module_access[$module->slug]) ? (in_array('list', $module_access[$module->slug]) ? 'checked' : '') : ''}}
                                                >
                                                  <label for="view_{{$module->id}}" data-toggle="tooltip" data-title="Allow View?"></label>
                                                </div>
                                            </td>
                                            <td class="text-center">
                                                <div class="icheck-primary d-inline">
                                                <input class="row_{{$module->id}} col_{{$parent_id}}_2" type="checkbox" id="create_{{$module->id}}" value="create"
                                                  name="module_access[{{$module->slug}}][]"
                                                  {{ isset($module_access[$module->slug]) ? (in_array('create', $module_access[$module->slug]) ? 'checked' : '') : ''}}
                                                >
                                                  <label for="create_{{$module->id}}" data-toggle="tooltip" data-title="Allow Create?"></label>
                                                </div>
                                            </td>
                                            <td class="text-center">
                                                <div class="icheck-primary d-inline">
                                                  <input class="row_{{$module->id}} col_{{$parent_id}}_3" type="checkbox" id="update_{{$module->id}}" value="update"
                                                    name="module_access[{{$module->slug}}][]"
                                                    {{ isset($module_access[$module->slug]) ? (in_array('update', $module_access[$module->slug]) ? 'checked' : '') : ''}}
                                                  >
                                                  <label for="update_{{$module->id}}" data-toggle="tooltip" data-title="Allow Edit/Update?"></label>
                                                </div>
                                            </td>
                                            <td class="text-center">
                                                <div class="icheck-primary d-inline">
                                                  <input class="row_{{$module->id}} col_{{$parent_id}}_4" type="checkbox" id="delete_{{$module->id}}" value="delete"
                                                    name="module_access[{{$module->slug}}][]"
                                                    {{ isset($module_access[$module->slug]) ? (in_array('delete', $module_access[$module->slug]) ? 'checked' : '') : ''}}
                                                  >
                                                  <label for="delete_{{$module->id}}" data-toggle="tooltip" data-title="Allow Delete?"></label>
                                                </div>
                                            </td>
                                            <td class="text-center">
                                                <div class="icheck-primary d-inline">
                                                  <input class="row_{{$module->id}} col_{{$parent_id}}_5" type="checkbox" id="restore_{{$module->id}}" value="restore"
                                                    name="module_access[{{$module->slug}}][]"
                                                    {{ isset($module_access[$module->slug]) ? (in_array('restore', $module_access[$module->slug]) ? 'checked' : '') : ''}}
                                                  >
                                                  <label for="restore_{{$module->id}}" data-toggle="tooltip" data-title="Allow Restore?"></label>
                                                </div>
                                            </td>
                                          </tr>
                                      @endif
                                    @endforeach
                                  @endforeach
                                    

                                      
                                </tbody>
                              </table>
                               
                                
                        
                      </div>
                      <!-- /.card-body -->
                    </div>
              </div>
              <div class="col-md-3">
                <div class="sticky-top mb-3">

                  <div class="card">
                      <div class="card-body">
                        <!-- the events -->
                          <button type="submit" class="btn btn-block btn-primary"><i class="fas fa-save"></i> Save</button>
                          <a href="{{url('roles')}}" class="btn btn-block btn-default"><i class="fas fa-times"></i> Cancel</a>
                        
                      </div>
                      <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
              </div>
          </div>
        </form>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
@endsection