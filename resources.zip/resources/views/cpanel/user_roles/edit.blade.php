@extends('layouts.cpanel')

@section('content')
<div class="content-header">
    <div class="container-fluid">
        <div class="row my-2">
            <div class="col-sm-12">
                <h1 class="m-0 text-dark">Edit User Role <a href="{{route('roles.list')}}"
                        class="btn btn-secondary float-right"><i class="fas fa-angle-left"></i> Back to Listing</a></h1>

            </div><!-- /.col -->

        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->
@php
$name= old('name') ? old('name') : ( isset($result->name) ? $result->name : "");
$access = isset($result->access) ? json_decode($result->access) : null;

$module_access= old('module_access') ? old('module_access') : ( (isset($access) && isset($access->module_access)) ?
(array) $access->module_access : []);
$user_role=Auth::user()->roleid;
@endphp
<!-- Main content -->
<div class="content">
    <div class="container-fluid">
        @include('layouts.common.messages')
        <form method="post" autocomplete="off" enctype="multipart/form-data">
            @csrf
            <div class="row">
                <div class="col-md-9">

                    <div class="card card-primary">
                        <div class="card-body">
                            <div class="form-group">
                                <label for="name">Name <span class="text-danger">*</span></label>
                                <input type="text" required id="name" name="name"
                                    class="form-control {{$errors->has('name') ? 'is-invalid': ''}}" value="{{ $name }}"
                                    @if(isset($result->name) && $result->id
                                < 5) readonly="readonly" @endif />
                            </div>

                            <br />
                            <h6><strong>Define Module Access</strong> <em class="small text-muted">(Click the
                                    <strong>Module Name</strong> or <strong>Action</strong> to toggle Check All /
                                    Uncheck all)</em></h6>

                            <table class="table w-100">
                                <tbody>
                                    @foreach ($modules as $module_item)

                                    @php
                                    $parent_id=$module_item->id;
                                    $module_items=\App\Models\ModuleItem::select('module_items.*')->
                                    join('modules as m', function($join) use ($parent_id){
                                    $join->on('module_items.module_id','=','m.id')
                                    ->where('module_items.module_id','=', $parent_id);
                                    })->orderBy('module_items.display_order')->get();
                                    @endphp

                                    @if(!$loop->first)
                                    @if (count($module_items))
                                    <tr>
                                        <td colspan="5" height="20">&nbsp;</td>
                                    </tr>
                                    @endif
                                    @endif
                                    <tr>
                                        <th>
                                            @if (count($module_items))
                                            <i class="{{$module_item->icon}}"></i> {{$module_item->name}}
                                            @else
                                            <a href="javascript:void(0)" class="text-dark check_module"
                                                data-status="off" id="row_m_{{$parent_id}}"><i
                                                    class="{{$module_item->icon}}"></i> {{ $module_item->name }}</a>
                                            @endif
                                        </th>
                                        <th width="80" class="text-center">
                                            @if (count($module_items))
                                            <a href="javascript:void(0)" class="text-dark check_access"
                                                data-status="off" id="col_{{$parent_id}}_1">View</a>
                                            @else
                                            <div class="icheck-primary d-inline">
                                                <input type="checkbox" class="row_m_{{$parent_id}}" value="list"
                                                    id="view_m_{{$module_item->id}}"
                                                    name="module_access[{{$module_item->slug}}][]" {{
                                                    isset($module_access[$module_item->slug]) ? (in_array('list',
                                                $module_access[$module_item->slug]) ? 'checked' : '') : ''}}
                                                >
                                                <label for="view_m_{{$module_item->id}}" data-toggle="tooltip"
                                                    data-title="Allow View?"></label>
                                            </div>
                                            @endif
                                        </th>
                                        <th width="80" class="text-center">
                                            @if (count($module_items))
                                            <a href="javascript:void(0)" class="text-dark check_access"
                                                data-status="off" id="col_{{$parent_id}}_2">Create</a>
                                            @else
                                            <div class="icheck-primary d-inline">
                                                <input type="checkbox" class="row_m_{{$parent_id}}" value="create"
                                                    id="create_m_{{$module_item->id}}"
                                                    name="module_access[{{$module_item->slug}}][]" {{
                                                    isset($module_access[$module_item->slug]) ? (in_array('create',
                                                $module_access[$module_item->slug]) ? 'checked' : '') : ''}}
                                                >
                                                <label for="create_m_{{$module_item->id}}" data-toggle="tooltip"
                                                    data-title="Allow View?"></label>
                                            </div>
                                            @endif
                                        </th>
                                        <th width="80" class="text-center">
                                            @if (count($module_items))
                                            <a href="javascript:void(0)" class="text-dark check_access"
                                                data-status="off" id="col_{{$parent_id}}_3"> Edit/Update</a>
                                            @else
                                            <div class="icheck-primary d-inline">
                                                <input type="checkbox" class="row_m_{{$parent_id}}" value="update"
                                                    id="update_m_{{$module_item->id}}"
                                                    name="module_access[{{$module_item->slug}}][]" {{
                                                    isset($module_access[$module_item->slug]) ? (in_array('update',
                                                $module_access[$module_item->slug]) ? 'checked' : '') : ''}}
                                                >
                                                <label for="update_m_{{$module_item->id}}" data-toggle="tooltip"
                                                    data-title="Allow View?"></label>
                                            </div>
                                            @endif
                                        </th>
                                        <th width="80" class="text-center">
                                            @if (count($module_items))
                                            <a href="javascript:void(0)" class="text-dark check_access"
                                                data-status="off" id="col_{{$parent_id}}_4">Delete</a>
                                            @else
                                            <div class="icheck-primary d-inline">
                                                <input type="checkbox" class="row_m_{{$parent_id}}" value="delete"
                                                    id="delete_m_{{$module_item->id}}"
                                                    name="module_access[{{$module_item->slug}}][]" {{
                                                    isset($module_access[$module_item->slug]) ? (in_array('delete',
                                                $module_access[$module_item->slug]) ? 'checked' : '') : ''}}
                                                >
                                                <label for="delete_m_{{$module_item->id}}" data-toggle="tooltip"
                                                    data-title="Allow View?"></label>
                                            </div>
                                            @endif
                                        </th>

                                    </tr>



                                    @foreach ($module_items as $module)

                                    @if (!$loop->last || $user_role==1)
                                    <tr>
                                        <td>
                                            <a href="javascript:void(0)" class="text-dark check_module"
                                                data-status="off" id="row_{{$module->id}}">{{ $module->name }}</a>
                                        </td>
                                        <td class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_{{$module->id}} col_{{$parent_id}}_1" type="checkbox"
                                                    id="view_{{$module->id}}" value="list"
                                                    name="module_access[{{$module->slug}}][]" {{
                                                    isset($module_access[$module->slug]) ? (in_array('list',
                                                $module_access[$module->slug]) ? 'checked' : '') : ''}}
                                                >
                                                <label for="view_{{$module->id}}" data-toggle="tooltip"
                                                    data-title="Allow View?"></label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_{{$module->id}} col_{{$parent_id}}_2" type="checkbox"
                                                    id="create_{{$module->id}}" value="create"
                                                    name="module_access[{{$module->slug}}][]" {{
                                                    isset($module_access[$module->slug]) ? (in_array('create',
                                                $module_access[$module->slug]) ? 'checked' : '') : ''}}
                                                >
                                                <label for="create_{{$module->id}}" data-toggle="tooltip"
                                                    data-title="Allow Create?"></label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_{{$module->id}} col_{{$parent_id}}_3" type="checkbox"
                                                    id="update_{{$module->id}}" value="update"
                                                    name="module_access[{{$module->slug}}][]" {{
                                                    isset($module_access[$module->slug]) ? (in_array('update',
                                                $module_access[$module->slug]) ? 'checked' : '') : ''}}
                                                >
                                                <label for="update_{{$module->id}}" data-toggle="tooltip"
                                                    data-title="Allow Edit/Update?"></label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_{{$module->id}} col_{{$parent_id}}_4" type="checkbox"
                                                    id="delete_{{$module->id}}" value="delete"
                                                    name="module_access[{{$module->slug}}][]" {{
                                                    isset($module_access[$module->slug]) ? (in_array('delete',
                                                $module_access[$module->slug]) ? 'checked' : '') : ''}}
                                                >
                                                <label for="delete_{{$module->id}}" data-toggle="tooltip"
                                                    data-title="Allow Delete?"></label>
                                            </div>
                                        </td>
                                    </tr>
                                    @endif
                                    @endforeach



                                    @endforeach
                                    <tr>
                                        <td colspan="5" height="20">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <th>
                                            <i class="fas fa-file-alt"></i> Contents
                                        </th>
                                        <th width="80" class="text-center">
                                            <a href="javascript:void(0)" class="text-dark check_access"
                                                data-status="off" id="col_service_1">View</a>

                                        </th>
                                        <th width="80" class="text-center">
                                            <a href="javascript:void(0)" class="text-dark check_access"
                                                data-status="off" id="col_service_2">Create</a>

                                        </th>
                                        <th width="80" class="text-center">
                                            <a href="javascript:void(0)" class="text-dark check_access"
                                                data-status="off" id="col_service_3"> Edit/Update</a>

                                        </th>
                                        <th width="80" class="text-center">
                                            <a href="javascript:void(0)" class="text-dark check_access"
                                                data-status="off" id="col_service_4">Delete</a>

                                        </th>

                                        <th width="80" class="text-center">
                                            <a href="javascript:void(0)" class="text-dark check_access"
                                                data-status="off" id="col_service_5">Approve</a>

                                        </th>

                                    </tr>
                                    @php
                                    $services_slug = 'contents';
                                    @endphp
                                    <tr>
                                        <td>
                                            <a href="javascript:void(0)" class="text-dark check_module"
                                                data-status="off" id="row_service_0">Content</a>
                                        </td>
                                        <td class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_service_0 col_service_1" type="checkbox"
                                                    id="service_view_0" value="list"
                                                    name="module_access[{{$services_slug}}][]" {{
                                                    isset($module_access[$services_slug]) ? (in_array('list',
                                                    $module_access[$services_slug]) ? 'checked' : '' ) : '' }}>
                                                <label for="service_view_0" data-toggle="tooltip"
                                                    data-title="Allow View?"></label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_service_0 col_service_2" type="checkbox"
                                                    id="service_create_0" value="create"
                                                    name="module_access[{{$services_slug}}][]" {{
                                                    isset($module_access[$services_slug]) ? (in_array('create',
                                                    $module_access[$services_slug]) ? 'checked' : '' ) : '' }}>
                                                <label for="service_create_0" data-toggle="tooltip"
                                                    data-title="Allow Create?"></label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_service_0 col_service_3" type="checkbox"
                                                    id="service_update_0" value="update"
                                                    name="module_access[{{$services_slug}}][]" {{
                                                    isset($module_access[$services_slug]) ? (in_array('update',
                                                    $module_access[$services_slug]) ? 'checked' : '' ) : '' }}>
                                                <label for="service_update_0" data-toggle="tooltip"
                                                    data-title="Allow Edit/Update?"></label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_service_0 col_service_4" type="checkbox"
                                                    id="service_delete_0" value="delete"
                                                    name="module_access[{{$services_slug}}][]" {{
                                                    isset($module_access[$services_slug]) ? (in_array('delete',
                                                    $module_access[$services_slug]) ? 'checked' : '' ) : '' }}>
                                                <label for="service_delete_0" data-toggle="tooltip"
                                                    data-title="Allow Delete?"></label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_service_0 col_service_5" type="checkbox"
                                                    id="service_approve_0" value="approve"
                                                    name="module_access[{{$services_slug}}][]" {{
                                                    isset($module_access[$services_slug]) ? (in_array('approve',
                                                    $module_access[$services_slug]) ? 'checked' : '' ) : '' }}>
                                                <label for="service_approve_0" data-toggle="tooltip"
                                                    data-title="Allow Approve?"></label>
                                            </div>
                                        </td>
                                    </tr>
                                    @foreach ($services as $service)

                                    @if (!$loop->last || $user_role==1)
                                    <tr>
                                        <td>
                                            <a href="javascript:void(0)" class="text-dark check_module"
                                                data-status="off" id="row_service_{{$service->id}}">{{ $service->title
                                                }}</a>
                                        </td>
                                        <td class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_service_{{$service->id}} col_service_1"
                                                    type="checkbox" id="service_view_{{$service->id}}" value="list"
                                                    name="module_access[{{$service->slug}}][]" {{
                                                    isset($module_access[$service->slug]) ? (in_array('list',
                                                $module_access[$service->slug]) ? 'checked' : '') : ''}}
                                                >
                                                <label for="service_view_{{$service->id}}" data-toggle="tooltip"
                                                    data-title="Allow View?"></label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_service_{{$service->id}} col_service_2"
                                                    type="checkbox" id="service_create_{{$service->id}}" value="create"
                                                    name="module_access[{{$service->slug}}][]" {{
                                                    isset($module_access[$service->slug]) ? (in_array('create',
                                                $module_access[$service->slug]) ? 'checked' : '') : ''}}
                                                >
                                                <label for="service_create_{{$service->id}}" data-toggle="tooltip"
                                                    data-title="Allow Create?"></label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_service_{{$service->id}} col_service_3"
                                                    type="checkbox" id="service_update_{{$service->id}}" value="update"
                                                    name="module_access[{{$service->slug}}][]" {{
                                                    isset($module_access[$service->slug]) ? (in_array('update',
                                                $module_access[$service->slug]) ? 'checked' : '') : ''}}
                                                >
                                                <label for="service_update_{{$service->id}}" data-toggle="tooltip"
                                                    data-title="Allow Edit/Update?"></label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_service_{{$service->id}} col_service_4"
                                                    type="checkbox" id="service_delete_{{$service->id}}" value="delete"
                                                    name="module_access[{{$service->slug}}][]" {{
                                                    isset($module_access[$service->slug]) ? (in_array('delete',
                                                $module_access[$service->slug]) ? 'checked' : '') : ''}}
                                                >
                                                <label for="service_delete_{{$service->id}}" data-toggle="tooltip"
                                                    data-title="Allow Delete?"></label>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_service_{{$service->id}} col_service_5"
                                                    type="checkbox" id="service_approve_{{$service->id}}"
                                                    value="approve" name="module_access[{{$service->slug}}][]" {{
                                                    isset($module_access[$service->slug]) ? (in_array('approve',
                                                $module_access[$service->slug]) ? 'checked' : '') : ''}}
                                                >
                                                <label for="service_approve_{{$service->id}}" data-toggle="tooltip"
                                                    data-title="Allow Approve?"></label>
                                            </div>
                                        </td>
                                    </tr>
                                    @endif
                                    @endforeach

                                    <tr>
                                        <td colspan="5" height="20">&nbsp;</td>
                                    </tr>

                                    @php
                                    $services_slug = 'taxonomy_terms';
                                    @endphp

                                    <tr>
                                        <th>
                                            <a href="javascript:void(0)" class="text-dark check_module"
                                                data-status="off" id="row_taxonomy_term_0"><i
                                                    class="fas fa-file-alt"></i> Taxonomy Terms</a>
                                        </th>
                                        <th class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_taxonomy_term_0 col_taxonomy_term_1" type="checkbox"
                                                    id="taxonomy_term_view_0" value="list"
                                                    name="module_access[{{$services_slug}}][]" {{
                                                    isset($module_access[$services_slug]) ? (in_array('list',
                                                    $module_access[$services_slug]) ? 'checked' : '' ) : '' }}>
                                                <label for="taxonomy_term_view_0" data-toggle="tooltip"
                                                    data-title="Allow View?"></label>
                                            </div>
                                        </th>
                                        <th class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_taxonomy_term_0 col_taxonomy_term_2" type="checkbox"
                                                    id="taxonomy_term_create_0" value="create"
                                                    name="module_access[{{$services_slug}}][]" {{
                                                    isset($module_access[$services_slug]) ? (in_array('create',
                                                    $module_access[$services_slug]) ? 'checked' : '' ) : '' }}>
                                                <label for="taxonomy_term_create_0" data-toggle="tooltip"
                                                    data-title="Allow Create?"></label>
                                            </div>
                                        </th>
                                        <th class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_taxonomy_term_0 col_taxonomy_term_3" type="checkbox"
                                                    id="taxonomy_term_update_0" value="update"
                                                    name="module_access[{{$services_slug}}][]" {{
                                                    isset($module_access[$services_slug]) ? (in_array('update',
                                                    $module_access[$services_slug]) ? 'checked' : '' ) : '' }}>
                                                <label for="taxonomy_term_update_0" data-toggle="tooltip"
                                                    data-title="Allow Edit/Update?"></label>
                                            </div>
                                        </th>
                                        <th class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_taxonomy_term_0 col_taxonomy_term_4" type="checkbox"
                                                    id="taxonomy_term_delete_0" value="delete"
                                                    name="module_access[{{$services_slug}}][]" {{
                                                    isset($module_access[$services_slug]) ? (in_array('delete',
                                                    $module_access[$services_slug]) ? 'checked' : '' ) : '' }}>
                                                <label for="taxonomy_term_delete_0" data-toggle="tooltip"
                                                    data-title="Allow Delete?"></label>
                                            </div>
                                        </th>
                                        <th class="text-center">
                                            <div class="icheck-primary d-inline">
                                                <input class="row_taxonomy_term_0 col_taxonomy_term_5" type="checkbox"
                                                    id="taxonomy_term_approve_0" value="approve"
                                                    name="module_access[{{$services_slug}}][]" {{
                                                    isset($module_access[$services_slug]) ? (in_array('approve',
                                                    $module_access[$services_slug]) ? 'checked' : '' ) : '' }}>
                                                <label for="taxonomy_term_approve_0" data-toggle="tooltip"
                                                    data-title="Allow Approve?"></label>
                                            </div>
                                        </th>
                                    </tr>

                                </tbody>
                            </table>



                        </div>
                        <!-- /.card-body -->
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="sticky-top mb-3">

                        <div class="card">
                            <div class="card-body">
                                <!-- the events -->
                                <button type="submit" class="btn btn-block btn-primary"><i class="fas fa-save"></i>
                                    Save</button>
                                <a href="{{route('roles.list')}}" class="btn btn-block btn-default"><i
                                        class="fas fa-times"></i> Cancel</a>

                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </div>
        </form>
        <!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
@endsection