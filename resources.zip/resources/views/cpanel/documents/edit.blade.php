@extends('layouts.cpanel')
@php
    $user = Auth::user();
    $can_any_action = \App\Http\Helpers::getAccess($user, 'documents', 'update,delete');

    $can_create = \App\Http\Helpers::getAccess($user, 'documents', 'create');
    $can_update = \App\Http\Helpers::getAccess($user, 'documents', 'update');
    $can_delete = \App\Http\Helpers::getAccess($user, 'documents', 'delete');
    $can_approve = \App\Http\Helpers::getAccess($user, 'documents', 'approve');

@endphp
@section('content')
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row my-2">
                <div class="col-sm-6">
                    <h3 class="m-0 text-dark">Add/Edit Document
                        @if($can_create)
                            <a href="{{route('documents.create')}}" class="btn btn-default ml-2"><i
                                    class="fa fa-plus"></i>
                                Add New</a>
                        @endif
                    </h3>
                </div>
                <div class="col-sm-6">
                    <a href="{{ route('documents.list',['s'=>Request::input('s'),'limit'=>Request::input('limit'),'events'=>Request::input('events'),'page'=>Request::input('page')])
                    }}" class="btn btn-secondary float-right"><i class="fas fa-angle-left"></i> Back to Listing</a>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content-header -->
    <section class="content">
        <div class="container-fluid">
            @include('layouts.common.messages')
            <form method="post" autocomplete="off" enctype="multipart/form-data">
                @csrf
                <div class="row">
                    <div class="col-md-9">
                        <div class="card card-warning card-outline card-outline-tabs">
                            <div class="card-body">
                                <div class="row">
                                    <div class="form-group col-sm-12">
                                        <label for="name">Title<span class="text-danger">*</span></label>
                                        <input type="text" id="name" name="title"
                                               class="form-control event-title {{$errors->has('title') ? 'is-invalid': ''}}"
                                               value="{{ isset($result->title)?$result->title:old('title') }}"/>


                                        <div class="pt-2" id="event_slug_area"><strong>slug:</strong>
                                            <span id="event_url">{{ old('slug', $result->slug ??
                                            \App\Http\Helpers::getSlug('documents', 'slug', $result->title ?? '',
                                            $result->id ?? 0)) }}</span>
                                            <input type="hidden" name="slug"
                                                   value="{{ old('slug', $result->slug ?? \App\Http\Helpers::getSlug('documents', 'slug', $result->title ?? '', $result->id ?? 0)) }}"
                                                   id="slug" style="width:200px;">
                                            <button class="btn d-none btn-default btn-sm" type="button"
                                                    id="save_eventname">Ok
                                            </button>
                                            <button class="btn btn-default btn-sm" type="button"
                                                    id="edit_eventname">Edit
                                            </button>
                                        </div>

                                        @if ($result->id ?? 0)
                                            <div class="pt-2"><strong>templating text:</strong>
                                                <span id="copy_area">[dacc_documents :{{ $result->id }}]</span>
                                                <button onclick="copyText('copy_area')" class="btn btn-default btn-sm"
                                                        type="button"><i class="fa fa-copy"></i></button>
                                            </div>
                                        @endif

                                    </div>

                                    @php
                                        $old_type = old('type', $result->type ?? '');
                                    @endphp

                                    <div class="form-group col-sm-12" x-data="documents_section()">
                                        <label for="url">Document Url</label>
                                        <input :disabled="document"
                                               class="form-control {{ $errors->has('url') ? 'is-invalid' : '' }}"
                                               name="url"
                                               value="{{ old('url', $result->url ?? '') }}"/>
                                        <div class="pt-2">
                                            <label for="upload_document">Upload Document Instead</label>
                                            <input @change="setup_document()" type="file" id="upload_document"
                                                   name="file"
                                                   class="form-control {{ $errors->has('upload_document') ? 'is-invalid' : '' }}"/>
                                        </div>
                                    </div>

                                    <script>
                                        function documents_section() {
                                            return {
                                                document: null,
                                                setup_document() {
                                                    this.document = document.getElementById('upload_document').files[0];
                                                }
                                            };
                                        }
                                    </script>

                                    @php
                                        $images = null;
                                        if ($img = old('image', $result->image ?? null)) {
                                            $images = \App\Models\Medias::where('id', $img ?? '')->first();
                                        }
                                        if ($images && $images->file_url) {
                                            $images->file_url = \App\Http\Helpers::asset($images->file_url);
                                            $images = [$images];
                                        }
                                    @endphp
                                    <div class="row form-group"
                                         x-data='__images("image", {{ json_encode($images ?? []) }})'>
                                        <div class="col-sm-6">
                                            <input type="hidden" name="image"
                                                   :value="images.length ? images[0].id : ''">
                                            <label for="featured_image">Icon</label>
                                            <div class="border p-3 bg-gray-light d-flex flex-wrap sort-sections">
                                                <template x-for="(image, i) in images">
                                                    <div class="p-2 position-relative">
                                                        <img loading="lazy"
                                                             class="h-100 w-100 shadow-sm rounded border bg-white"
                                                             style="object-fit: contain;" :src="image.file_url">
                                                        <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                                                            <!--- Create Trash Image button shown at hover ---->
                                                            <button type="button" class="btn btn-danger btn-sm"
                                                                    x-on:click="removeImage(i, 'image')">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </template>

                                                <div x-show="! images.length" class="p-2 d-flex justify-content-center"
                                                     :class="{ 'd-flex': !images.length }"
                                                     style="min-height: 100px; width: 100%;">
                                                    <div
                                                        class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                                                        <!-- Add Button !-->
                                                        <label @click.prevent="openingModal('#editModal')"
                                                               data-toggle="modal" data-drop="false"
                                                               data-target="#editModal"
                                                               type="button" class="btn btn-outline-success btn-sm">
                                                            <i class="fas fa-plus"></i>
                                                        </label>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @include('layouts.common.activity', ['result' => $result, 'activities' => $activities ?? []])
                    </div>

                    <div class="col-md-3">
                        <div class="sticky-top mb-3">
                            @if($can_update)
                                <div class="card">
                                    <div class="card-body">
                                        <!-- the events -->
                                        <button type="submit" class="btn btn-block btn-primary"><i
                                                class="fas fa-save"></i>
                                            Save
                                        </button>
                                        <a href="{{ route('documents.list',['s'=>Request::input('s'),'limit'=>Request::input('limit'),'events'=>Request::input('events'),'page'=>Request::input('page')])
                                    }}" class="btn btn-block btn-default"><i class="fas fa-times"></i> Cancel</a>

                                    </div>
                                    <!-- /.card-body -->
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
                <input type="hidden" name="id" id="id" value="{{isset($result->id)?$result->id:old('id')}}"/>
            </form>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    @include('layouts.common.media-multi', ['multiple' => false])
@endsection
