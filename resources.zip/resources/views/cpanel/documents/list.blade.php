@extends('layouts.cpanel')
@php

$user=Auth::user();
$can_any_action=\App\Http\Helpers::getAccess($user, 'documents', 'update,delete');

$can_create=\App\Http\Helpers::getAccess($user, 'documents', 'create');
$can_update=\App\Http\Helpers::getAccess($user, 'documents', 'update');
$can_delete=\App\Http\Helpers::getAccess($user, 'documents', 'delete');

@endphp
@section('content')
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-12">
                <h3 class="m-0 text-dark">Documents
                    @if($can_create)
                    <a href="{{route('documents.create')}}" class="btn btn-default ml-2"><i class="fa fa-plus"></i>
                        Add New</a>
                    @endif
                </h3>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        @include('layouts.common.messages')
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <form name="documents" action="" method="get" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6">

                                </div>
                                <div class="col-md-3">

                                </div>
                                <div class="col-md-3">
                                    <div class="card-tools">
                                        <div class="input-group input-group-sm">
                                            <input type="text" name="s" value="{{Request::input('s')}}"
                                                class="form-control float-right" placeholder="Search">

                                            <div class="input-group-append">
                                                <button type="submit" class="btn btn-default">
                                                    <i class="fas fa-search"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th width="3%">#.</th>
                                    @if($can_any_action)
                                    <th width="12%">Action</th>
                                    @endif
                                    <th width="55%">Name</th>
                                    <th width="30%">Short code</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($results as $result)
                                <tr>
                                    <td>{{($limit = $filter['limit'] ?? 0)*(($page = app('request')->input('page') ?? 1)
                                        - 1 )+$loop->iteration}}</td>
                                    @if($can_any_action)
                                    <td>
                                        <ul class="list-inline m-0">
                                            @if($can_update)
                                            <li class="list-inline-item"><a href="{{ route('documents.edit',['id'=>$result->id,
                                                    's'=>Request::input('s'),'limit'=>Request::input('limit'),'page'=>Request::input('page')])
                                                    }}" data-toggle="tooltip" title="Edit" class="text-primary"><i
                                                        class="far fa-edit"></i></a></li>
                                            @endif
                                            @if($can_delete)
                                            <li class="list-inline-item"><a
                                                    onclick="return confirm('Are you sure you want to delete this item?')"
                                                    href="{{route('documents.destroy',['id'=>$result->id])}}"
                                                    data-toggle="tooltip" title="Delete" class="text-danger"><i
                                                        class="far fa-trash-alt"></i></a></li>
                                            @endif
                                            @if($can_update)
                                            <li class="list-inline-item">
                                                <div class="custom-control custom-switch custom-switch-off-danger custom-switch-on-success"
                                                    data-toggle="tooltip" title="Status">
                                                    <input type="checkbox" class="custom-control-input changeStatus"
                                                        data-id="{{$result->id}}" data-status-type="documents"
                                                        data-status="{{$result->status}}" {{ $result->status=='Y' ?
                                                    'checked' : '' }} id="customSwitch_{{$loop->iteration }}">
                                                    <label class="custom-control-label"
                                                        for="customSwitch_{{$loop->iteration}}"></label>
                                                </div>
                                            </li>
                                            @endif
                                        </ul>
                                    </td>
                                    @endif

                                    <td>
                                        @if($can_update)
                                        <a href="{{route('documents.edit',['id'=>$result->id])}}"
                                            class="text-dark">{{$result->title}}</a>
                                        @else
                                        {{$result->title}}
                                        @endif
                                    </td>
                                    <td>[dacc_documents :{{ $result->id }}]</td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="4" class="text-center">No records found!</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer clearfix">
                        <div class="row">
                            <div class="col-md-1">
                                <form action="{{ url()->full() }}">
                                    {{ Form::select('limit', ['5'=>5,'10'=>10,'25'=>25,'50'=>50,'100'=>100],
                                    app('request')->input('limit')?app('request')->input('limit'):$filter['limit'],
                                    array(
                                    'class' => 'form-control input-sm page-limit',
                                    'id' => 'page_limit'
                                    )) }}
                                </form>
                            </div>
                            <div class="col-md-11">
                                <div class="d-flex justify-content-end">
                                    <span class="mr-3">Showing {{(($results->currentPage()-1)*$results->perPage())+1}}
                                        to
                                        {{((($results->currentPage()-1)*$results->perPage())==0)?$results->perPage():($results->currentPage())*$results->perPage()}}
                                        of {{$results->total()}} entries </span>
                                    {{ $results->appends(request()->except('page'))->links('pagination::bootstrap-4') }}
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- /.card -->
            </div>
        </div>
    </div>
</section>
<script>
    $(document).ready(function () {
        $('.page-limit').on('change', function () {
            $(this).closest('form').submit();
        });
    });
</script>
@endsection
