@extends('layouts.cpanel')
@php

$user=Auth::user();
$can_any_action=\App\Http\Helpers::getAccess($user, 'media', 'update,delete');

$can_create=\App\Http\Helpers::getAccess($user, 'media', 'create');
$can_update=\App\Http\Helpers::getAccess($user, 'media', 'update');
$can_delete=\App\Http\Helpers::getAccess($user, 'media', 'delete');

@endphp
@section('content')
<link rel="stylesheet" href="{{ asset('cpanel/css/cropper.min.css') }}">
<script src="{{ asset('cpanel/js/cropper.min.js') }}"></script>
<script src="{{ asset('cpanel/js/jquery-cropper.min.js') }}"></script>
<style>
    /* Ensure the size of the image fit the container perfectly */
    .jquery-cropper-wrapper img {
        display: block;
        /* This rule is very important, please don't ignore this */
        max-width: 100%;
    }

    .sortable-placeholder {
        padding: 0.5rem !important;
        background: transparent !important;
        border: 0 !important;
        min-height: 100px;
        width: auto;
    }

    #images_shown>div,
    #sort_sections>div:not(.col-12) {
        width: 25% !important;
    }

    .hover_image {
        transition: all 0.3s ease;
    }

    .hover_image_sibling {
        transition: all 0.3s ease;
        display: none;
    }

    .images_parent:hover .hover_image {
        transform: scale(1.1);
    }

    .images_parent:hover .hover_image_sibling {
        display: block;
    }

    .glass {
        background: rgba(0, 0, 0, 0.5);
        backdrop-filter: saturate(180%) blur(2px);
    }
</style>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-12">
                <h3 class="m-0 text-dark">Media Library</h3>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div x-data="image_modal()" class="media-library-wrapper">

                            <nav class="container">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item">
                                        <a class="nav-link active" href="#existingImg" data-toggle="tab"
                                            aria-expanded="false">Select
                                            Media</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#newImg" data-toggle="tab" id="croTab"
                                            aria-expanded="false">Upload
                                            New</a>
                                    </li>
                                </ul>
                            </nav>
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane fade container" id="newImg">
                                    <div class="row">
                                        <div class="col align-self-end">
                                            <div class="card-tools">
                                                <div class="input-group input-group-sm">
                                                    <input type="text" name="s" value="" class="form-control float-right" placeholder="Search">

                                                    <div class="input-group-append">
                                                        <button type="submit" class="btn btn-default">
                                                            <i class="fas fa-search"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="" style="min-height: 100px;">
                                        <div :class="{'flex-column' : !ajaxLoading && !imageCropping}"
                                            class="justify-content-center rounded p-3 mb-3 d-flex align-items-center">
                                            <!-- Add Button !-->
                                            <label x-show="!ajaxLoading" for="imageAdder" type="button"
                                                class="btn btn-light border btn-sm mb-0">
                                                <span
                                                    x-text="imageCropping ? 'Change Image' : 'Upload Local Image'"></span>
                                                <input type="file" accept="image/*" name="" class="d-none"
                                                    id="imageAdder" x-on:change="addImage($event.target)">
                                            </label>
                                            <div x-show="!ajaxLoading && !imageCropping" class="text-center">
                                                <div class="my-4">Or</div>
                                                <label for="youtube_id">Enter YouTube Video URL&nbsp;<i
                                                        class="fas fa-video"></i></label>
                                                <input type="text" class="form-control youtube_id_area"
                                                    placeholder="Youtube video ID" />
                                                <div class="text-muted text-sm">youtube.com/watch?v=<em
                                                        class="text-danger">Bgu_oYaGQJg</em></div>
                                                <div class="invalid-feedback">Looks like video ID is
                                                    invalid!</div>
                                                <button type="button" @click.prevent="addVideo()"
                                                    class="video_adder_btn btn btn-light mt-2">
                                                    Add Video
                                                </button>
                                            </div>
                                            <button x-show="!ajaxLoading && imageCropping"
                                                class="btn btn-danger btn-sm ml-3"
                                                @click.prevent="uncropImage()">Remove</button>
                                            <button x-show="!ajaxLoading && imageCropping"
                                                class="btn btn-success btn-sm ml-3"
                                                @click.prevent="uploadImage()">Upload Cropped</button>
                                            <button x-show="!ajaxLoading && imageCropping && rawImage"
                                                class="ml-3 btn btn-success btn-sm"
                                                @click.prevent="uploadWithoutCropping()">Upload
                                                Without Cropping</button>
                                            <i x-show="ajaxLoading" :class="{ 'd-block': ajaxLoading }"
                                                class="fa fa-spinner fa-spin fa-lg text-success"></i>
                                        </div>
                                        <div x-show="!ajaxLoading && imageCropping" class="form-group">
                                            <label for="imageTitle">Alt Text</label>
                                            <input type="text" class="form-control" id="imageTitle"
                                                placeholder="Image Alt Text" x-model="file_name">
                                        </div>
                                        <div class="jquery-cropper-wrapper">
                                            <img id="imageCropped" alt="" class="w-100">
                                        </div>
                                    </div>
                                </div>
                                <div role="tabpanel" class="tab-pane fade show active container" id="existingImg">
                                    <div class="bg-gray-light">

                                        <div class="">
                                            <div x-show="shownImages().length" id="images_shown"
                                                :class="{ 'd-flex': shownImages().length }"
                                                class="border p-3 bg-gray-light flex-wrap"
                                                x-ref="sortable_images_selected">
                                                <template x-if="imagesShouldbeShownNow">
                                                    <template x-for="(image, i) in shownImages()">
                                                        <div class="p-2 position-relative images_parent"
                                                            :style="'height:' + $refs.sortable_images_selected.querySelectorAll('.position-relative')[i].offsetWidth + 'px'"
                                                            style="width: 25%;">
                                                            <img loading="lazy" @click="addImageTo(image)" role="button"
                                                                class="h-100 w-100 shadow-sm rounded border bg-light hover_image"
                                                                style="object-fit: contain;" :src="image.file_url">
                                                            <div class="position-absolute p-2 text-center"
                                                                style="right: 0; top: 0; left: 0"
                                                                x-show="image.content_type == 'video'">
                                                                <div class="p-1 rounded-top glass text-white">
                                                                    <i class="fas fa-video"></i>
                                                                </div>
                                                            </div>
                                                            <div class="position-absolute p-2 hover_image_sibling"
                                                                style="right: 0; bottom: 0; left: 0; text-align: right">
                                                                <!--- Create Trash Image button shown at hover ---->
                                                                <div class="p-1 rounded-bottom glass text-white">
                                                                    <button x-show="image.content_type != 'video'"
                                                                        type="button" class="btn text-white btn-sm"
                                                                        x-on:click="editImage(i)">
                                                                        <i class="fas fa-edit"></i>
                                                                    </button>
                                                                    <button type="button" class="btn text-white btn-sm"
                                                                        x-on:click="confirm('Deleting this from here might cause deleting it from everywhere it is used previously! Are you sure?') && deleteImage(i)">
                                                                        <i x-show="deleteLoading != image.id"
                                                                            class="fas fa-trash"></i>
                                                                        <i x-show="deleteLoading == image.id"
                                                                            class="fas fa-spinner fa-spin"></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </template>
                                                </template>
                                            </div>

                                            <div class="my-1 text-center">
                                                <button @click.prevent="fetchImages(true)" type="button"
                                                    :disabled="imagesLoading" class="btn btn-primary"
                                                    x-show="showNextPage()">
                                                    <i x-show="imagesLoading" class="fas fa-spinner fa-spin"></i>
                                                    <span x-show="!imagesLoading">Load More</span>
                                                </button>
                                            </div>

                                            <template x-if="!shownImages().length && !imagesLoading">
                                                <div class="p-3">
                                                    <div class="alert alert-light">
                                                        No Images! Please Add Image from the Upload New tab.
                                                    </div>
                                                </div>
                                            </template>
                                            <template x-if="!shownImages().length && imagesLoading">
                                                <div class="p-3">
                                                    <div class="alert alert-light">
                                                        Loading Images...
                                                    </div>
                                                </div>
                                            </template>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.card -->
            </div>
        </div>
    </div>
</section>
<script src="{{ asset('cpanel/js/alpine.min.js') }}" defer></script>
<script>
    function image_modal() {

    return {
        multipleImages: false,
        name: false,
        init(imagesProps = false) {
            this.fetchImages();
            var self = this;
            $('.media-library-wrapper .nav-tabs a:first').on('shown.bs.tab', function (e) {
                if (self.shownImages().length) {
                    self.imagesShouldbeShownNow = true;
                } else
                    self.fetchImages();
            });
            $('.media-library-wrapper .nav-tabs a:first').on('hide.bs.tab', function (e) {
                self.imagesShouldbeShownNow = false;
            });
        },
        showNextPage() {
            return this.next_url;
        },
        imagesLoading: false,
        next_url: null,
        fetchImages(next = false) {
            if (this.imagesLoading) return;
            if (next && !this.next_url) return;
            if (!next) {
                this.allImages = [];
                self.imagesShouldbeShownNow = false;
            }
            var url = '{{ route('media.list') }}';
            if (next) {
                url = this.next_url;
            }
            $.ajax({
                url: url,
                type: 'GET',
                data: {
                    _token: '{{ csrf_token() }}'
                },
                beforeSend: () => {
                    this.imagesLoading = true;
                },
                success: (response) => {
                    if (next) {
                        this.allImages = this.allImages.concat(response.data);
                    } else {
                        this.allImages = response.data;
                    }
                    this.next_url = response.next_page_url;
                    this.$nextTick(() => {
                        this.imagesShouldbeShownNow = true;
                    });
                },
                complete: () => {
                    this.imagesLoading = false;
                }
            });
        },
        imagesShouldbeShownNow: false,
        images: [],
        allImages: [],
        imageDrop: false,
        shownImages() {
            var images_ = this.allImages.filter(image => {
                return !this.images.map(img => img.id).includes(image.id);
            }).map(image => {
                var item = {...image};
                if (item.content_type == 'video') {
                    item.file_url = "http://img.youtube.com/vi/" + linkifyYouTubeURLs(item.file_url) + "/mqdefault.jpg";
                }
                return item;
            });
            return images_;
        },
        removeImage(index, featured = false) {
            return false;
        },
        deleteLoading: false,
        deleteImage(index) {
            if (this.deleteLoading) {
                return;
            }
            var id = this.shownImages()[index].id;
            var link = this.shownImages()[index].file_url;
            $.ajax({
                url: "{{ route('galleries.removeImage') }}",
                type: "POST",
                data: {
                    id: id,
                    _token: "{{ csrf_token() }}",
                    link: link,
                },
                beforeSend: function () {
                    this.deleteLoading = id;
                }.bind(this),
                success: function(response) {
                    console.log(response)
                    if (response.status) {
                        this.allImages = this.allImages.filter(image => id != image.id);
                    }
                }.bind(this),
                error: function(response) {}.bind(this),
                complete: function() {
                    this.deleteLoading = false;
                }.bind(this)
            });
        },
        adding: false,
        addImageTo(image) {
            return false;
        },
        uncropImage(force = false) {
            if(this.cropper) {
                this.cropper.destroy();
            }
            this.$nextTick(() => {
                $('#imageCropped').removeAttr('src');
                this.imageCropping = false;
                this.cropper = false;
                this.ajaxLoading = false;
            });
        },
        cropper: false,
        imageCropping: false,
        initCropper(url) {
            var $image = document.getElementById('imageCropped');
            var new_image = new Image();
            new_image.src = url;
            $image.src = url;
            new_image.onload = () => {

                if(this.cropper) {
                    this.cropper.replace(url);
                    this.$nextTick(() => this.ajaxLoading = false);
                    return true;
                }

                this.cropper = new Cropper($image, {
                    viewMode: 3,
                    autoCropArea: 1,
                    crop: function(event) {
                        // do nothing
                    }
                });

                // Get the Cropper.js instance after initialized
                // this.cropper = $image.data('cropper');
                this.ajaxLoading = false;
                this.imageCropping = $image;
            };
        },
        file_name: '',
        ajaxLoading: false,
        addImage(input) {
            var files = input.files;
            if (!files.length || this.ajaxLoading || input.value === '') {
                return;
            }
            if (files[0].size > 2048 * 1024) {
                input.value = '';
                alert('Image should be less than 2MB');
                return false;
            }

            this.ajaxLoading = true;

            let reader = new FileReader();
            reader.readAsDataURL(files[0]);
            this.rawImage = files[0];
            // file name without extension
            this.file_name = (files[0].name || '.').split('.').slice(0, -1).join('.');
            reader.onload = () => {
                this.initCropper(reader.result);
            };
        },
        editImage(i) {
            var image = this.shownImages()[i];
            if (image.content_type == 'video') {
                return;
            }
            var aa = $('.media-library-wrapper .nav-tabs a:last').tab('show').one('shown.bs.tab', () => {
                this.$nextTick(()=>{
                    this.file_name = image.file_title;
                    this.initCropper(image.file_url);
                });
            });
        },
        addVideo() {
            var video = $('.youtube_id_area');
            var url = video.val();
            if (url == '' || window.yt_video_checking) {
                return;
            }
            var video_id = linkifyYouTubeURLs(url);
            if (video_id) {
                var formData = new FormData();

                formData.append('_token', "{{ csrf_token() }}");
                formData.append('video_url', 'https://www.youtube.com/embed/' + video_id);
                $.ajax({
                    url: "{{ route('galleries.addVideo') }}",
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    beforeSend: function() {
                        this.ajaxLoading = true;
                    }.bind(this),
                    success: function(response) {
                        if (response.status == 'success') {
                            this.allImages.unshift(response.video);
                            $('.media-library-wrapper .nav-tabs a:first').tab('show');
                            toastr.success('Video added successfully');
                        }
                    }.bind(this),
                    error: function(response) {
                        alert('Something went wrong, please try again!');
                    }.bind(this),
                    complete: function() {
                        this.ajaxLoading = false;
                    }.bind(this)
                });
                $('#video_url').val('');
            }
        },
        rawImage: false,
        uploadWithoutCropping() {
            if (this.rawImage && !this.ajaxLoading) {
                this.ajaxLoading = true;
                this.upload(this.rawImage);
            }
        },
        uploadImage() {
            if (this.cropper && !this.ajaxLoading) {
                this.ajaxLoading = true;
                this.cropper.getCroppedCanvas().toBlob((blob) => {
                    this.upload(blob);
                }, 'image/jpeg');
            } else {
                alert('Error');
            }
        },
        upload(image) {
            var formData = new FormData();

            formData.append('_token', "{{ csrf_token() }}");
            formData.append('image', image);
            formData.append('file_name', this.file_name);
            $.ajax({
                url: "{{ route('galleries.uploadImage') }}",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                enctype: 'multipart/form-data',
                beforeSend: function() {
                    this.ajaxLoading = true;
                }.bind(this),
                success: function(response) {
                    if (response.status == 'success') {
                        this.allImages.unshift(response.image);
                        this.uncropImage();
                        this.rawImage = false;
                        $('.media-library-wrapper .nav-tabs a:first').tab('show');
                        toastr.success('Image Uploaded successfully');
                    }
                }.bind(this),
                error: function(response) {
                    alert('Something went wrong, please try again!');
                }.bind(this),
                complete: function() {
                    this.ajaxLoading = false;
                }.bind(this)
            });
        },
        imagesData() {
            return JSON.stringify(this.images.map(img => img.id));
        }
    };
}
</script>
@endsection