@extends('layouts.cpanel')

@section('content')
@php
$user=Auth::user();
$can_any_action=\App\Http\Helpers::getAccess($user, 'users', 'update,delete');
$can_create=\App\Http\Helpers::getAccess($user, 'users', 'create');
$can_update=\App\Http\Helpers::getAccess($user, 'users', 'update');
$can_delete=\App\Http\Helpers::getAccess($user, 'users', 'delete');
@endphp
<!-- Content Wrapper. Contains page content -->
<form method="GET" action="">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mt-2">
                <div class="col-sm-12">
                    <h1 class="m-0 text-dark"><small class="fa fa-list"></small> Users
                        @if($can_create)
                        <a href="{{route('users.create')}}" class="btn btn-default ml-2"><i class="fa fa-plus"></i> Add
                            New</a>
                        @endif
                    </h1>
                </div>
            </div>

            <div class="row mb-2">
                <div class="col-sm-4"></div>
                <div class="col-sm-2">
                    <select name="status" id="filter2" class="form-control pull-right">
                        <option value="all">-- All Status --</option>
                        <option value="Y" @if($filter['status']=='Y' ) selected="selected" @endif>Active</option>
                        <option value="N" @if($filter['status']=='N' ) selected="selected" @endif>InActive</option>
                    </select>
                </div>
                <div class="col-sm-3">
                    <div class="input-group">
                        <select name="role" class="select2 form-control">
                            <option value="">User role</option>
                            @foreach($roles as $role)
                            <option value="{{$role->id}}" @if($role->id == $filter['role']) selected @endif
                                >{{$role->name}}</option>
                            @endforeach
                        </select>
                        <div class="input-group-append">
                            <button type="submit" class="btn btn-default">Filter</button>
                        </div>
                    </div>

                </div>
                <div class="col-sm-3">
                    <div class="input-group">
                        <input type="text" class="form-control" name="q"
                            value="{{ isset($search_key) ? $search_key : old('search_key') }}"
                            placeholder="Enter your keyword">
                        <div class="input-group-append">
                            <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                </div><!-- /.col -->

            </div><!-- /.row -->

        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            @include('layouts.common.messages')
            <div class="row">
                <div class="col-md-12">
                    @if (session('reset_password'))
                    <div class="alert alert-success mb-3">{!! session('reset_password') !!}</div>
                    @endif
                    <div class="card">
                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">

                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th width="3%">#.</th>
                                        @if($can_any_action)
                                        <th width="15%">Action</th>
                                        @endif
                                        <th width="20%">Name</th>
                                        <th width="20%">Email / Contact Number</th>
                                        <th width="12%">Role</th>
                                        <th width="10%">Type</th>
                                        <th width="25%">Last Login</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse ($results as $i=>$result)
                                    <tr>
                                        <td>{{($limit = $filter['limit'] ?? 0)*(($page = app('request')->input('page')
                                            ?? 1) - 1 )+$loop->iteration}}</td>
                                        @if($can_any_action)
                                        <td>
                                            <ul class="list-inline m-0">
                                                @if($can_update && $result->id != 1)
                                                <li class="list-inline-item"><a
                                                        href="{{route('users.edit',['id'=>$result->id])}}"
                                                        data-toggle="tooltip" title="Edit" class="text-primary"><i
                                                            class="far fa-edit"></i></a></li>
                                                @endif
                                                @if($can_delete && $result->id != 1)
                                                <li class="list-inline-item"><a
                                                        onclick="return confirm('Are you sure you want to delete this user?')"
                                                        href="{{route('users.delete',['id'=>$result->id])}}"
                                                        data-toggle="tooltip" title="Delete" class="text-danger"><i
                                                            class="far fa-trash-alt"></i></a></li>
                                                @endif
                                                @if($can_update)
                                                <li class="list-inline-item"><a
                                                        onclick="return confirm('Are you sure you want to resent the password of this user?')"
                                                        href="{{route('users.reset_password',['id'=>$result->id])}}"
                                                        data-toggle="tooltip" title="Reset Password"
                                                        class="text-success"><i class="fas fa-user-lock"></i></a></li>
                                                @if($result->id != 1)
                                                <li class="list-inline-item">
                                                    <div class="custom-control custom-switch custom-switch-off-danger custom-switch-on-success"
                                                        data-toggle="tooltip" title="Status">
                                                        <input type="checkbox" class="custom-control-input changeStatus"
                                                            data-id="{{$result->id}}" data-status-type='users'
                                                            data-status="{{$result->status}}" {{ $result->status=='Y' ?
                                                        'checked' : '' }} id="customSwitch_{{$i}}">
                                                        <label class="custom-control-label"
                                                            for="customSwitch_{{$i}}"></label>
                                                    </div>
                                                </li>
                                                @endif
                                                @endif
                                            </ul>
                                        </td>
                                        @endif
                                        <td>
                                            {{ implode(' ',array_filter([$result->name,$result->lastName])) }}
                                        </td>
                                        <td>{!! implode("<br /><i class='fas fa-phone-alt' data-toggle='tooltip'
                                                title='Contact Number'></i>
                                            ",array_filter([$result->email,$result->contactNumber])) !!}</td>
                                        <td>{{ $result->user_role }}</td>
                                        <td>{{ $result->type }}</td>
                                        <td>{{ $result->lastlogin ? date("jS M. Y h:i A",strtotime($result->lastlogin))
                                            : '' }}</td>
                                    </tr>
                                    @empty
                                    <tr>
                                        <td colspan="6">
                                            No records found!
                                        </td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>

                        <!-- /.card-body -->
                        <div class="clearfix m-3">
                            <div class="row">
{{--                                <div class="col-md-1">--}}
{{--                                    {{ Form::select('limit', ['5'=>5,'10'=>10,'25'=>25,'50'=>50,'100'=>100],--}}
{{--                                    app('request')->input('limit')?app('request')->input('limit'):$filter['limit'],--}}
{{--                                    array(--}}
{{--                                    'class' => 'form-control input-sm page-limit',--}}
{{--                                    'id' => 'page_limit'--}}
{{--                                    )) }}--}}
{{--                                </div>--}}
                                <div class="col-md-11">
                                    <div class="d-flex justify-content-end">
                                        <span class="mr-3">Showing
                                            {{(($results->currentPage()-1)*$results->perPage())+1}} to
                                            {{((($results->currentPage()-1)*$results->perPage())==0)?$results->perPage():($results->currentPage())*$results->perPage()}}
                                            of {{$results->total()}} entries </span>
                                        {{
                                        $results->appends(request()->except('page'))->links('pagination::bootstrap-4')
                                        }}
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>

            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
</form>
<!-- /.content -->
<script>
    $(document).ready(function(){
    $('.page-limit').change(function(){
      $(this).closest('form').submit();
    });
  });
</script>
@endsection
