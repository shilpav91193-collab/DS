@extends('layouts.login-layout')

@section('content')

<div class="container" style="max-width:600px">
    <div class="login-logo">
        <a href="{{url('/')}}"><img class="img-fluid" src="{{asset('assets/img/marriott-logo.png')}}" /></a>
    </div>
            <div class="card">
                <div class="card-body text-center">
                <h3>Congratulations!</h3>
                <p>You have successfully registered to Contenthub. Please note that the administrator is now reviewing your account. You will receive an email notification once your account is active.
                </p>
                <p>
                    Thank you.
                </p>

                
                <a href="{{url('/')}}" class="btn btn-outline-primary">Go back to login page</a>

            </div>
        </div>
</div>      
@endsection
