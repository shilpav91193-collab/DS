@extends('layouts.register-layout')

@section('content')

@php
    $name= old('name');
    $last_name= old('last_name');
    $job_title=old('job_title');
    $enterprise_id=old('enterprise_id');
    $contact_number= old('contact_number');
    $email= old('email');
    $access_type=old('access_type');
    $other_department=old('other_department');
    // $user_role= old('user_role');
    $department= old('department');

    $selected_countries=old('access_meta.countries') ? old('access_meta.countries') : [];
    $selected_properties=old('access_meta.properties') ? old('access_meta.properties') : [];
    $ex_properties=old('access_excluded.properties') ? old('access_excluded.properties') : [];
    $selected_country=old('access_meta.country');
    $selected_cities=old('access_meta.cities') ? old('access_meta.cities') : [];
    $selected_property=old('access_meta.property');
    $selected_outlets=old('access_meta.outlets') ? old('access_meta.outlets') : [];
    
    if($selected_countries){
      $properties=App\Properties::getProperties(['country_ids'=>$selected_countries], true);  
    } elseif($selected_cities){
      $properties=App\Properties::getProperties(['city_ids'=>$selected_cities], true);
    }

    $cities=App\Cities::when($selected_countries, function($query, $selected_countries){
          return $query->whereIn('countryID',$selected_countries)->whereNotNull('countryID');
      })->when($selected_country, function($query, $selected_country){
          return $query->where('countryID',$selected_country)->whereNotNull('countryID');
      })->orderBy('name')->get();
    
    if($selected_property){
      $outlets = \App\Outlets::getOutlets(['property_id'=>$selected_property,'selected_outlets'=>$selected_outlets]);
    }

    $hidden_class=($department==42) ? "" : 'd-none';
    @endphp

<div class="container" style="max-width:600px">
    <div class="login-logo">
        <a href="{{url('/')}}"><img class="img-fluid" src="{{asset('assets/img/marriott-logo.png')}}" /></a>
    </div>
            <div class="card">
                
                <div class="card-body">
                    <h3 class="text-center">Register yourself as a Contributor.</h3>
                    <p class="text-center">Welcome to the Content Hub, the single place from where you can manage content for the properties you handle.
                    </p>
                    <hr />
                    @include('inc.messages')
                    <form method="POST">
                        @csrf

                        <div class="row">
                          
                                    <div class="form-group col-sm-12">
                                        <label for="enterprise_id">Marriott Enterprise ID <span class="text-danger">*</span></label>
                                        <input required type="text" id="enterprise_id" name="enterprise_id" class="form-control {{$errors->has('enterprise_id') ? 'is-invalid': ''}}" value="{{ $enterprise_id }}">
                                        
                                    </div>
                                    
                                
                                    <div class="form-group col-sm-6">
                                        <label for="name">First name <span class="text-danger">*</span></label>
                                        <input required type="text" id="name" name="name" class="form-control {{$errors->has('name') ? 'is-invalid': ''}}" value="{{ $name }}">
                                    </div>
                                    
                                    <div class="form-group col-sm-6">
                                        <label for="last_name">Last name <span class="text-danger">*</span></label>
                                        <input required type="text" id="last_name" name="last_name" class="form-control {{$errors->has('last_name') ? 'is-invalid': ''}}" value="{{ $last_name }}">
                                    </div>
        
                                    <div class="form-group col-sm-6">
                                        <label for="job_title">Job title <span class="text-danger">*</span></label>
                                        <input required type="text" id="job_title" name="job_title" class="form-control {{$errors->has('job_title') ? 'is-invalid': ''}}" value="{{ $job_title }}">
                                    </div>

                                    <div class="form-group col-sm-6">
                                        <label for="department">Department <span class="text-danger">*</span></label>
                                        <select required name="department" id="department" class="form-control select2" data-title="Select Department" data-placeholder="Select Department" data-allow-clear="true" >
                                            <option value=""></option>
                                            @foreach ($db_department as $department_item)
                                            <option value="{{$department_item->id}}" {{ $department==$department_item->id ? 'selected' : ''}}>{{$department_item->name}}</option>
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="form-group offset-sm-6 col-sm-6 {{$hidden_class}}">
                                        <input type="text" placeholder="Please specify the other department" id="other_department" name="other_department" class="form-control {{$errors->has('other_department') ? 'is-invalid': ''}}" value="{{ $other_department }}">
                                    </div>
                                
                                    <div class="form-group col-sm-6">
                                        <label for="contact_number">Contact number <span class="text-danger">*</span></label>
                                        <input required type="text" id="contact_number" name="contact_number" class="form-control {{$errors->has('contact_number') ? 'is-invalid': ''}}" value="{{ $contact_number }}">
                                    </div>
        
                                    <div class="form-group col-sm-6">
                                        <label for="email">Marriott Email Address <span class="text-danger">*</span></label>
                                        <input required type="email" id="email" name="email" class="form-control {{$errors->has('email') ? 'is-invalid': ''}}" value="{{ $email }}">
                                    </div>
                               
                                    <div class="form-group col-sm-6">
                                        <label for="password">Password <span class="text-danger">*</span></label>
                                        <input required type="password" id="password" name="password" class="form-control {{$errors->has('password') ? 'is-invalid': ''}}">
                                    </div>
            
                                    <div class="form-group col-sm-6">
                                        <label for="confirm_password">Confirm Password <span class="text-danger">*</span></label>
                                        <input required type="password" id="confirm_password" name="confirm_password" class="form-control {{$errors->has('password') ? 'is-invalid': ''}}">
                                    </div>
                               
                                    {{-- <div class="form-group col-sm-6">
                                        <label for="user_role">Role <span class="text-danger">*</span></label>
                                        <select required name="user_role" class="form-control select2" data-title="Select Role" data-placeholder="Select Role" data-allow-clear="true" >
                                            <option value=""></option>
                                            @foreach ($user_roles as $role_item)
                                            <option value="{{$role_item->id}}" {{ $user_role==$role_item->id ? 'selected' : ''}}>{{$role_item->name}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                         --}}
                                        

                                    <div class="form-group col-sm-6">
                                        <label for="access_type">Access Level <span class="text-danger">*</span></label>
                                        <select required name="access_type" data-id="" id="access_type" class="form-control select2 {{$errors->has('access_type') ? 'is-invalid': ''}}" data-title="Select Access Type" data-placeholder="Select Access Type" data-allow-clear="true" >
                                            <option value=""></option>
                                            @foreach ($access_types as $access_item)
                                            <option value="{{$access_item->id}}" {{ $access_type==$access_item->id ? 'selected' : ''}}>{{$access_item->name}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                
                                
                                <div class="access_area col-sm-12">
                                    @include('inc.access_type')
                                </div>
                                
                                {{-- <div class="col-sm-12">
                                    <div class="icheck-primary">
                                    <input type="checkbox" id="terms" name="terms" value="Y" {{ $terms == 'Y' ? 'checked' : ''}}>
                                    <label for="terms">
                                        I agree to the <a href="#">terms and conditions</a>.
                                    </label>
                                    </div>
                                </div> --}}
                            
                        </div>
                        <hr />
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <button type="submit" class="btn btn-primary">Register</button>
                                
                            </div>
                            <div class="col-sm-6 form-group text-sm-right">
                                <a href="{{url('/')}}" class="mt-2 d-inline-block">I already have an account</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
</div>      
@endsection
