@extends('layouts.cpanel')

@section('content')

<div class="content-header">
    <div class="container-fluid">
        <div class="row my-2">
            <div class="col-sm-12">
                <h1 class="m-0 text-dark">Edit User <a href="{{route('users.list')}}"
                        class="btn btn-secondary float-right"><i class="fas fa-angle-left"></i> Back to Listing</a></h1>

            </div><!-- /.col -->

        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->
@php
$name= old('name') ? old('name') : ( isset($result->name) ? $result->name : "");
$lastname = old('lastname') ? old('lastname') : ( isset($result->lastname) ? $result->lastname : ""); ;
$phone = old('phone') ? old('phone') : ( isset($result->phone) ? $result->phone : ""); ;
$email= old('email') ? old('email') : ( isset($result->email) ? $result->email : "");
$roleid= old('roleid') ? old('roleid') : ( isset($result->roleid) ? $result->roleid : "");
$status= old('status') ? old('status') : ( isset($result->status) ? $result->status : "");

@endphp
<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        @include('layouts.common.messages')
        <form method="post" autocomplete="off" enctype="multipart/form-data">
            @csrf
            <div class="row">
                <div class="col-md-9">

                    <div class="card card-primary">
                        <div class="card-body">
                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <label for="name">First name <span class="text-danger">*</span></label>
                                    <input required type="text" id="name" name="name"
                                        class="form-control {{$errors->has('name') ? 'is-invalid': ''}}"
                                        value="{{ $name }}">
                                </div>

                                <div class="form-group col-sm-6">
                                    <label for="lastname">Last name</label>
                                    <input type="text" id="lastname" name="lastname"
                                        class="form-control {{$errors->has('lastname') ? 'is-invalid': ''}}"
                                        value="{{ $lastname }}">
                                </div>

                                <div class="form-group col-sm-6">
                                    <label for="phone">Phone</label>
                                    <input type="number" id="phone" name="phone" class="form-control"
                                        value="{{ $phone }}">
                                </div>

                                <div class="form-group col-sm-6">
                                    <label for="email">Email Address <span class="text-danger">*</span></label>
                                    <input required type="email" id="email" name="email"
                                        class="form-control {{$errors->has('email') ? 'is-invalid': ''}}"
                                        value="{{ $email }}">
                                </div>
                                @if(empty($result->id) || $result->id != 1)
                                <div class="form-group col-sm-6">
                                    <label for="roleid">Role </label>
                                    <select name="roleid" class="form-control select2 roleid" data-title="Select Role"
                                        data-placeholder="Select Role" data-allow-clear="true">
                                        <option value=""></option>
                                        @foreach ($roleids as $role_item)
                                        <option value="{{$role_item->id}}" {{ $roleid==$role_item->id ? 'selected' :
                                            ''}}>{{$role_item->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @endif
                                <div class="form-group col-sm-6">
                                    <label for="status">Status <span class="text-danger">*</span></label><br />
                                    <div class="icheck-primary d-inline-block">
                                        <input type="radio" id="radioPrimary1" name="status" value="Y" {{ ($status=='Y'
                                            || $status==null) ? 'checked' : '' }}>
                                        <label for="radioPrimary1">
                                            Active &nbsp;&nbsp;&nbsp;
                                        </label>
                                    </div>
                                    <div class="icheck-danger d-inline-block">
                                        <input type="radio" id="radioPrimary2" name="status" value="N" {{ $status=='N'
                                            ? 'checked' : '' }}>
                                        <label for="radioPrimary2">
                                            Inactive
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="sticky-top mb-3">

                        <div class="card">
                            <div class="card-body">
                                <!-- the events -->
                                <button type="submit" class="btn btn-block btn-primary"><i class="fas fa-save"></i>
                                    Save</button>
                                <a href="{{route('users.list')}}" class="btn btn-block btn-default"><i
                                        class="fas fa-times"></i> Cancel</a>

                            </div>
                            <!-- /.card-body -->
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Media</h3>
                            </div>
                            <div class="card-body">
                                @if(isset($result->avatar) && $result->avatar != '' &&
                                Storage::disk('public')->exists('profiles/'.$result->avatar))
                                <img src="{{asset('storage/profiles/' . $result->avatar)}}" alt="" width="100"
                                    class="image-image" />
                                <input type="hidden" value="{{$result->avatar}}" name="filename" />
                                @endif
                                <div class="form-group">
                                    <label>Avatar</label>
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="avatar" name="avatar">
                                        <label class="custom-file-label" for="avatar">Choose file</label>
                                    </div>
                                </div>
                            </div>


                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->

                        <!-- /.card -->
                    </div>
                </div>
            </div>
        </form>
        <!-- /.row -->
    </div><!-- /.container-fluid -->
</section>
<!-- /.content -->
@endsection
