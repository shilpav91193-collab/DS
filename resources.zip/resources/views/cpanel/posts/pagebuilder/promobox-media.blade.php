<div class="col-sm-12 form-group">
    <input type="hidden" name="image" :value="featuredImages.length ? featuredImages[0].id : ''">
    <label for="featured_image">Image</label>
    <div class="d-flex flex-wrap sort-sections">
        <template x-for="(image, i) in featuredImages">
            <div class="position-relative">
                <img loading="lazy" class="h-100 w-100 shadow-sm rounded border bg-white" style="object-fit: contain;" :src="image.file_url">
                <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                    <!--- Create Trash Image button shown at hover ---->
                    <button type="button" class="btn btn-danger btn-sm" x-on:click="removeImage(i, 'featured')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </template>

        <div x-show="! featuredImages.length" class="d-flex justify-content-center" :class="{ 'd-flex': !featuredImages.length }" style="min-height: 100px; width: 100%;">
            <div class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                <!-- Add Button !-->
                <label @click.prevent="imageDrop = 'featured'" data-toggle="modal" data-drop="false" data-target="#editModal" type="button" class="btn btn-outline-success btn-sm">
                    <i class="fas fa-plus"></i>
                </label>
            </div>
        </div>

    </div>
</div>
<div class="col-sm-12 form-group">
    <div class="d-flex flex-wrap">
        <label for="video_id">Video ID</label>       
        <textarea rows="4" name="meta[video_id]" class="form-control" placeholder="Paste Video Embed Code Here">{!! isset($post->meta->video_id)?$post->meta->video_id:old('meta.video_id') !!}</textarea>
        <code class="text-pink text-small">&lt;iframe width="420" height="315" src="https://www.youtube.com/embed/t1gb4ncN8ym7Z7vIqiY"&gt;&lt;/iframe&gt;
        </code>
    </div>
</div>
<div class="col-sm-12 form-group">
        <label>Box Type</label> <br>
        @php
        $old_box_type  = isset($post->meta->box_type)?$post->meta->box_type:'both';
        @endphp

        <div class="icheck-primary d-inline">
            <input type="radio" id="radioBoxtype1" name="meta[box_type]" value="both" @if($old_box_type == 'both') checked @endif >
            <label for="radioBoxtype1">
            Both content & media&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </label>
        </div>
        <div class="icheck-primary d-inline">
            <input type="radio" id="radioBoxtype2" name="meta[box_type]" value="content" @if($old_box_type == 'content') checked @endif >
            <label for="radioBoxtype2">
            Content only&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </label>
        </div>
        <div class="icheck-primary d-inline">
            <input type="radio" id="radioBoxtype3" name="meta[box_type]" value="media" @if($old_box_type == 'media') checked @endif >
            <label for="radioBoxtype3">
            Media only&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </label>
        </div>
</div>
<div class="col-sm-12 form-group">
        <label>Media Type</label> <br>
        @php
        $old_media_type  = isset($post->meta->media_type)?$post->meta->media_type:'image';
        @endphp

        <div class="icheck-primary d-inline">
            <input type="radio" id="radioMediatype1" name="meta[media_type]" value="image" @if($old_media_type == 'image') checked @endif >
            <label for="radioMediatype1">
            Image&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </label>
        </div>
        <div class="icheck-primary d-inline">
            <input type="radio" id="radioMediatype2" name="meta[media_type]" value="video" @if($old_media_type == 'video') checked @endif >
            <label for="radioMediatype2">
            Video&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </label>
        </div>
</div>
<div class="form-group">
        <label>Media Position</label> <br>
        @php
        $old_media_position  = isset($post->meta->media_position)?$post->meta->media_position:'left';
        @endphp
        <div class="icheck-primary d-inline">
            <input type="radio" id="radioMediaPosition1" name="meta[media_position]" value="left" @if($old_media_position == 'left') checked @endif >
            <label for="radioMediaPosition1">
                Left &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </label>
        </div>    
        <div class="icheck-primary d-inline">
            <input type="radio" id="radioMediaPosition2" name="meta[media_position]" value="top" @if($old_media_position == 'top') checked @endif >
            <label for="radioMediaPosition2">
            Top&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </label>
        </div>
        <div class="icheck-primary d-inline">
            <input type="radio" id="radioMediaPosition3" name="meta[media_position]" value="right" @if($old_media_position == 'right') checked @endif >
            <label for="radioMediaPosition3">
            Right&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </label>
        </div>
        <div class="icheck-primary d-inline">
            <input type="radio" id="radioMediaPosition4" name="meta[media_position]" value="bottom" @if($old_media_position == 'bottom') checked @endif >
            <label for="radioMediaPosition4">
            Bottom&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </label>
        </div>        
</div>
