@include('cpanel.posts.pagebuilder.add-sections',['post'=>$post])
<div class="sections-list sort-sections" id="sections_sortable">
    @if(isset($post->sections))
    @foreach($post->sections as $section)
    @php
    $section->meta = $section->meta();
    @endphp
    <div data-id="{{$section->id}}" class="section section-{{$section->id}} mb-4 p-0" style="min-height: 200px;">
        @include('cpanel.posts.pagebuilder.add-section-wrap',['section'=>$section])
    </div>
    @endforeach
    @endif
</div>