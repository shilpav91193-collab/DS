<div class="form-group">
    <div class="col-md-6">
        <select data-id="{{$post_id}}" class="form-control" id="column_selection" name="columns" required>
            <option value="">Select Column</option>
            <option value="1">Single Column</option>
            <option value="2">Two Columns</option>
            <option value="3">Three Columns</option>
            <option value="4">Four Columns</option>
        </select>
    </div>
</div>