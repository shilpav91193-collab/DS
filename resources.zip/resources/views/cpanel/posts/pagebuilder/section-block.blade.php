@php

$showMedia = $block_type == 'all';
$showContent = $block_type == 'content' || $showMedia;
$showImage = $block_type == 'image' || $showMedia;
$showTabs = $block_type == 'tab' || $block_type == 'accordion';
$showButton = $block_type == 'button';
$showTable = $block_type == 'table';
$showGallery = $block_type == 'gallery';
$showBrochure = $block_type == 'brochure';
$showBgImage = true; // because currently we support bg image for all block types
$showBgColor = true; // because currently we support bg color for all block types
@endphp
<script>
function loadTabContent(){

    return  {




            init() {

                @if($showTabs || $showButton)

                this.$watch("tabs", (tabs) => {

                   //$( "#tabs_area" ).sortable("refresh");

                    $(".textEditor").summernote({

                        height: 200,

                        disableDragAndDrop : false,

                        toolbar: TOOLBAR,

                        styleTags: STYLETAGS,

                    });

                });

                @endif

            },

            @if($showTabs || $showButton)

            tabs: {!! $block->meta->tabs ?? "[]" !!},




                addNewTab() {

                    if (this.tabs.filter(tab => typeof tab.title != "string" || tab.title == "" ).length) {

                        alert("Please fill in all tab titles and descriptions");

                        return;

                    }

                    this.tabs.push({

                        title: "",

                        content: ""

                    });

                    this.$nextTick(() => {

                        document.querySelector(".tab-content").scrollIntoView({

                            behavior: "smooth",

                            block: "end"

                        });

                    });

                },




                filteredData() {

                    return this.tabs.filter(tab => !(typeof tab.title != "string" || tab.title == "" || (typeof tab.content == "string" && tab.content == "")));

                },




                deleteTab(index) {

                    this.tabs.splice(index, 1);

                }

            @endif

    };

}
</script>

<form x-data='loadTabContent()' method="post" id="section_block_frm" name="section-block-frm" autocomplete="off"
    enctype="multipart/form-data">
    @csrf
    <input type="hidden" name="action" value="save-content-block" />
    <input type="hidden" name="section_id" value="{{$section}}" />
    <input type="hidden" name="sort_order" value="{{isset($block->sort_order)?$block->sort_order:$column}}" />
    <input type="hidden" name="post_id" value="{{isset($block->post_id)?$block->post_id :$post_id}}" />
    <input type="hidden" name="id" value="{{isset($block->id)?$block->id :''}}" />
    <input type="hidden" name="meta[block_type]" value="{{ $block_type }}" />
    <div class="col-md-12 columns-inputs">
        <div class="form-group">
            <label for="name">Title <span class="text-danger">*</span></label>
            <input type="text" required="" id="title" name="title" class="form-control"
                value="{{isset($block->title)?$block->title:''}}">
        </div>
        <div class="form-group">
            <label>Show Title</label> <br>
            @php
            $hide_title=$block_type.'_hide_title';
            $old_hide_title = isset($block->meta->hide_title)?$block->meta->hide_title:'Y';
            @endphp
            <div class="icheck-primary d-inline">
                <input type="radio" id="hideTitle1" name="meta[hide_title]" value="N" @if($old_hide_title=='N' ) checked
                    @endif>
                <label for="hideTitle1">
                    Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
            <div class="icheck-primary d-inline">
                <input type="radio" id="hideTitle2" name="meta[hide_title]" value="Y" @if($old_hide_title=='Y' ) checked
                    @endif>
                <label for="hideTitle2">
                    No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
        </div>
        @if($showTabs)

        <h4 class="h4">{{ ucfirst($block_type) }} Contents <button type="button" @click.prevent="addNewTab()"
                class="btn btn-default">Add
                New</button></h4>
        <div class="row py-3">
            <div class="col-sm-12 bg-gray-light">
                <div class="container my-4">
                    {{--<input type="text" name="meta[tabs]" :value="JSON.stringify(filteredData())">--}}
                    <div id="tabs_area" class="tab-content">
                        <template x-for="(tab, i) in tabs">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label :for="'tab_title'+i">Tab Title</label>
                                                <input type="text" :name="'tab_title[]'" :id="'tab_title'+i"
                                                    class="form-control" @input="tab.title = $event.target.value"
                                                    :value="tab.title">
                                            </div>
                                            <div class="form-group">
                                                <label :for="'tab_content'+i">Tab Content</label>
                                                <textarea rows="4" :name="'tab_content[]'" :id="'tab_content'+i"
                                                    class="form-control textEditor"
                                                    @input="tab.content = $event.target.value"
                                                    :value="tab.content"></textarea>
                                            </div>
                                            <!--- Trash button to delete by index -->
                                            <button type="button" @click.prevent="deleteTab(i)"
                                                class="btn btn-danger"><i class="fa fa-trash"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
            </div>
        </div>

        <script>
        $(document).ready(function() {
            $("#tabs_area").sortable({
                items: "#tabs_area > div",
                cursor: 'move',
                revert: true,
            });
        });
        </script>

        @endif

        @if($showButton)

        <h4 class="h4"> Buttons <button type="button" @click.prevent="addNewTab()" class="btn btn-default">Add
                New</button></h4>
        <div class="row py-3">
            <div class="col-sm-12 bg-gray-light">
                <div class="container my-4">
                    <input type="hidden" name="meta[tabs]" :value="JSON.stringify(filteredData())">
                    <div id="tabs_area" class="tab-content">
                        <template x-for="(tab, i) in tabs">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label :for="'tab_title'+i">Button label</label>
                                                <input type="text" :name="'button_label[]'" :id="'tab_title'+i"
                                                    class="form-control" @input="tab.title = $event.target.value"
                                                    :value="tab.title">
                                            </div>
                                            <div class="form-group">
                                                <label :for="'tab_content'+i">Button link</label>
                                                <input type="text" :name="'button_url[]'" :id="'tab_content'+i"
                                                    class="form-control" @input="tab.content = $event.target.value"
                                                    :value="tab.content">
                                            </div>
                                            <div class="form-group">
                                                <label>Link Target</label> <br>
                                                @php
                                                $old_buttonurl_newtab =
                                                isset($block->meta->buttonurl_newtab)?$block->meta->buttonurl_newtab:'N';
                                                @endphp
                                                <select :name="'button_target[]'" :id="'button_target'+i"
                                                    class="form-control" @input="tab.target = $event.target.value"
                                                    :value="tab.target">
                                                    <option value="_self">Self</option>
                                                    <option value="_blank">New tab / window</option>
                                                </select>
                                            </div>
                                            <!--- Trash button to delete by index -->
                                            <button type="button" @click.prevent="deleteTab(i)"
                                                class="btn btn-danger"><i class="fa fa-trash"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
            </div>
        </div>

        <script>
        $(document).ready(function() {
            $("#tabs_area").sortable({
                items: "#tabs_area > div",
                cursor: 'move',
                revert: true,
            });
        });
        </script>

        @endif

        @if($showContent)
        <div class="form-group">
            <label for="content">Content</label>
            <textarea id="content" name="content" class="form-control textEditor"
                rows="10">{!! isset($block->content)?$block->content:'' !!}</textarea>
        </div>
        <div class="form-group">
            <label for="video_link">Button Text</label>
            <input type="text" id="button_text" name="meta[button_text]" class="form-control"
                value="{{isset($block->meta->button_text)?$block->meta->button_text:''}}">
        </div>
        <div class="form-group">
            <label for="video_link">Button URL</label>
            <input type="text" id="button_url" name="meta[button_url]" class="form-control"
                value="{{isset($block->meta->button_url)?$block->meta->button_url:''}}" placeholder="https://">
        </div>
        @endif

        @if($showImage)
        @php
        $images = null;
        if ($block && ($img = $block->image)) {
        $images = \App\Models\Medias::where('id', $img ?? '')->first();
        }
        if ($images && $images->file_url) {
        $images->file_url = \App\Http\Helpers::asset($images->file_url);
        $images = [$images];
        }
        @endphp
        <div class="row form-group" x-data="__images('block_images', {{ json_encode($images ?? []) }})">
            <div class="col-sm-12">
                <input type="hidden" name="image" :value="images.length ? images[0].id : ''">
                <label for="image">Media</label>
                <div class="border p-3 bg-gray-light d-flex flex-wrap sort-sections">
                    <template x-for="(image, i) in images">
                        <div class="p-2 position-relative">
                            <img loading="lazy" class="h-100 w-50 shadow-sm rounded border bg-white"
                                style="object-fit: contain;" :src="image.file_url">
                            <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                                <!--- Create Trash Image button shown at hover ---->
                                <button type="button" class="btn btn-danger btn-sm" x-on:click="removeImage(i)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    </template>

                    <div x-show="! images.length" class="p-2 d-flex justify-content-center"
                        :class="{ 'd-flex': !images.length }" style="min-height: 100px; width: 100%;">
                        <div
                            class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                            <!-- Add Button !-->
                            <label @click.prevent="openingModal('#editModal')" data-toggle="modal" data-drop="false"
                                data-target="#editModal" type="button" class="btn btn-outline-success btn-sm">
                                <i class="fas fa-plus"></i>
                            </label>
                        </div>
                    </div>

                </div>
            </div>
        </div>


        <div class="form-group image">
            <label for="image_text">Media Caption</label>
            <input type="text" id="image_text" name="meta[image_text]" class="form-control"
                value="{{isset($block->meta->image_text)?$block->meta->image_text:''}}" placeholder="Media Caption">
        </div>
        <div class="form-group image">
            <label for="image_text">External Link URL</label>
            <input type="text" id="external_url" name="meta[image_external_url]" class="form-control"
                value="{{isset($block->meta->image_external_url)?$block->meta->image_external_url:''}}"
                placeholder="https://">
        </div>

        @if(!$showMedia)
        <div class="form-group">
            <label>Show Media in Full Width</label> <br>
            @php
            $old_media_full_width = isset($block->meta->media_full_width)?$block->meta->media_full_width:'N';
            @endphp
            <div class="custom-control custom-radio custom-control-inline">
                <input type="radio" id="media_full_width_1" name="meta[media_full_width]" class="custom-control-input"
                    value="Y" {{ $old_media_full_width=='Y' ? 'checked' : '' }}>
                <label class="custom-control-label" for="media_full_width_1">Yes</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
                <input type="radio" id="media_full_width_2" name="meta[media_full_width]" class="custom-control-input"
                    value="N" {{ $old_media_full_width=='N' ? 'checked' : '' }}>
                <label class="custom-control-label" for="media_full_width_2">No</label>
            </div>
        </div>
        @endif

        @endif

        @if($showMedia)
        <div class="form-group">
            <label>Media position</label> <br>
            @php
            $old_image_position = isset($block->meta->image_position)?$block->meta->image_position:'right_inline';
            @endphp
            <!-- Inline Leftand Inline Right options also -->
            <div class="icheck-primary d-inline">
                <input type="radio" id="radioImagePosition6" name="meta[image_position]" value="right_inline"
                    @if($old_image_position=='right_inline' ) checked @endif>
                <label for="radioImagePosition6">
                    Inline Right &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
            <div class="icheck-primary d-inline">
                <input type="radio" id="radioImagePosition5" name="meta[image_position]" value="left_inline"
                    @if($old_image_position=='left_inline' ) checked @endif>
                <label for="radioImagePosition5">
                    Inline Left&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
            <div class="icheck-primary d-inline">
                <input type="radio" id="radioImagePosition2" name="meta[image_position]" value="top"
                    @if($old_image_position=='top' ) checked @endif>
                <label for="radioImagePosition2">
                    Top&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
            <div class="icheck-primary d-inline">
                <input type="radio" id="radioImagePosition3" name="meta[image_position]" value="right"
                    @if($old_image_position=='right' ) checked @endif>
                <label for="radioImagePosition3">
                    Right&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
            <div class="icheck-primary d-inline">
                <input type="radio" id="radioImagePosition4" name="meta[image_position]" value="bottom"
                    @if($old_image_position=='bottom' ) checked @endif>
                <label for="radioImagePosition4">
                    Bottom&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
            <div class="icheck-primary d-inline">
                <input type="radio" id="radioImagePosition1" name="meta[image_position]" value="left"
                    @if($old_image_position=='left' ) checked @endif>
                <label for="radioImagePosition1">
                    Left &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>

        </div>
        <div class="form-group col-md-2">
            <label>Content - Media Ratio</label> <br>
            @php
            $old_content_media_ratio =
            isset($block->meta->content_media_ratio)?$block->meta->content_media_ratio:'6:6';
            @endphp
            <!--- ratio in a total of 12 -->
            <select class="form-control select2" name="meta[content_media_ratio]" style="width: 100%;">
                <option value="6:6" @if($old_content_media_ratio=='6:6' ) selected @endif>6:6</option>
                <option value="5:7" @if($old_content_media_ratio=='5:7' ) selected @endif>5:7</option>
                <option value="7:5" @if($old_content_media_ratio=='7:5' ) selected @endif>7:5</option>
                <option value="4:8" @if($old_content_media_ratio=='4:8' ) selected @endif>4:8</option>
                <option value="8:4" @if($old_content_media_ratio=='8:4' ) selected @endif>8:4</option>
                <option value="3:9" @if($old_content_media_ratio=='3:9' ) selected @endif>3:9</option>
                <option value="9:3" @if($old_content_media_ratio=='9:3' ) selected @endif>9:3</option>
                <option value="2:10" @if($old_content_media_ratio=='2:10' ) selected @endif>2:10</option>
                <option value="10:2" @if($old_content_media_ratio=='10:2' ) selected @endif>10:2</option>
            </select>
        </div>
        @endif
        @if($showTable)
        <div class="form-group">
            <label>Table</label> <br>
            @php
            $old_table = isset($block->meta->table)?$block->meta->table:'';
            $tables = App\Models\Tables::where('status','Y')->get();

            @endphp
            <div>
                <input type="hidden" value="tables" name="short_code">
                <select class="form-control select-2" name="meta[table]">
                    @foreach($tables as $table)

                    <option value="{{$table->id}}" @if($table->id == $old_table) selected @endif>{{$table->title}}
                    </option>

                    @endforeach
                </select>
            </div>
            <script>
            $(document).ready(function() {
                $('.select2').select2({
                    selectOnClose: true
                });
            });
            </script>
        </div>
        @endif

        @if($showGallery)
        <div class="form-group">
            <label>Gallery</label> <br>
            @php
            $old_table = isset($block->meta->gallery)?$block->meta->gallery:'';
            $galleries = App\Models\Galleries::get();
           
            @endphp
            <div>
                <input type="hidden" value="galleries" name="short_code">
                <select class="form-control select-2" name="meta[gallery]">
                    @foreach($galleries as $gallery)

                    <option value="{{$gallery->id}}" @if($gallery->id == $old_table) selected @endif>{{$gallery->title}}
                    </option>

                    @endforeach
                </select>
            </div>
            <script>
            $(document).ready(function() {
                $('.select2').select2({
                    selectOnClose: true
                });
            });
            </script>
        </div>
        <div class="form-group">
            <label>Image Title Show</label> <br>
            @php
            $gallery_image_title=$block_type.'gallery_image_title';
            $old_gallery_image_title = isset($block->meta->gallery_image_title)?$block->meta->gallery_image_title:'false';
            @endphp
             
                <div class="icheck-primary d-inline">
                    <input type="radio" id="gallery_image_title1_true" name="meta[gallery_image_title]" value="true" @if($old_gallery_image_title=='true' ) checked
                        @endif>
                    <label for="gallery_image_title1_true">
                    Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </label>
                </div>      
                <div class="icheck-primary d-inline">
                <input type="radio" id="gallery_image_title1_false" name="meta[gallery_image_title]" value="false" @if($old_gallery_image_title=='false' ) checked
                    @endif>
                <label for="gallery_image_title1_false">
                No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>    
        </div>
        <div class="form-group">
            <label>Gallery Display Type</label> <br>
            @php
            $gallery_display_type=$block_type.'gallery_display_type';
            $old_gallery_display_type = isset($block->meta->gallery_display_type)?$block->meta->gallery_display_type:'slider';
            @endphp
            <!-- <div class="icheck-primary d-inline">
                <input type="radio" id="gallery_display_type" name="meta[gallery_display_type]" value="carousel" @if($old_gallery_display_type=='carousel' ) checked
                    @endif>
                <label for="gallery_display_type">
                Carousel &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div> -->
            <div class="icheck-primary d-inline">
                <input type="radio" id="gallery_display_type1" class="gallery_display_type" name="meta[gallery_display_type]" value="slider" @if($old_gallery_display_type=='slider' ) checked
                    @endif>
                <label for="gallery_display_type1">
                Slider &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
            <div class="icheck-primary d-inline">
                <input type="radio" id="gallery_display_type2" class="gallery_display_type" name="meta[gallery_display_type]" value="grid_view" @if($old_gallery_display_type=='grid_view' ) checked
                    @endif>
                <label for="gallery_display_type2">
                  Grid View &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
            </div>
            <div class="form-group d-none col-md-3 col-drop-down">
                <label>Gallery Column</label> <br>
                @php
                $gallery_image_col=$block_type.'gallery_image_col';
                $old_gallery_image_col = isset($block->meta->gallery_image_col)?$block->meta->gallery_image_col:4;
                @endphp
                
                <select class="form-control select-2" name="meta[gallery_image_col]">
                        @for($i=1;$i<=6;$i++)

                        <option value="{{$i}}" @if($i == $old_gallery_image_col) selected @endif>{{$i}}
                        </option>

                        @endfor
                </select>   
           </div>
        @endif

        <!-- ////////Brochure///////////// -->
        @if($showBrochure)
            <div class="form-group">
                <label>Brochure</label> <br>
                @php
                $old_table = isset($block->meta->brochure)?$block->meta->brochure:'';
                $brochures = App\Models\Brochure::get();
            
                @endphp
                <div>
                    <input type="hidden" value="galleries" name="short_code">
                    <select class="form-control select-2" name="meta[brochure]">
                        @foreach($brochures as $brochure)

                        <option value="{{$brochure->id}}" @if($brochure->id == $old_table) selected @endif>{{$brochure->title}}
                        </option>

                        @endforeach
                    </select>
                </div>
                <script>
                $(document).ready(function() {
                    $('.select2').select2({
                        selectOnClose: true
                    });
                });
                </script>
            </div>
        @endif

        <!-- ///End////// -->

        <!-- @if($showBgImage)
        @php
        $images = null;
        if ($block && ($img = $block->meta->bgImage ?? null)) {
        $images = \App\Models\Medias::where('id', $img ?? '')->first();
        }
        if ($images && $images->file_url) {
        $images->file_url = \App\Http\Helpers::asset($images->file_url);
        $images = [$images];
        }
        @endphp
        <div class="row form-group" x-data="__images('bg_images', {{ json_encode($images ?? []) }})">
            <div class="col-sm-12">
                <input type="hidden" name="meta[bgImage]" :value="images.length ? images[0].id : ''">
                <label for="image">Bakground Image</label>
                <div class="border p-3 bg-gray-light d-flex flex-wrap sort-sections">
                    <template x-for="(image, i) in images">
                        <div class="p-2 position-relative">
                            <img loading="lazy" class="h-100 w-50 shadow-sm rounded border bg-white"
                                style="object-fit: contain;" :src="image.file_url">
                            <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                              
                                <button type="button" class="btn btn-danger btn-sm" x-on:click="removeImage(i)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    </template>

                    <div x-show="! images.length" class="p-2 d-flex justify-content-center"
                        :class="{ 'd-flex': !images.length }" style="min-height: 100px; width: 100%;">
                        <div
                            class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                          
                            <label @click.prevent="openingModal('#editModal')" data-toggle="modal" data-drop="false"
                                data-target="#editModal" type="button" class="btn btn-outline-success btn-sm">
                                <i class="fas fa-plus"></i>
                            </label>
                        </div>
                    </div>

                </div>
            </div>
        </div> -->

        <!-- <div class="form-group">
            <label>Background Overlap to Fullwidth</label>
            <br>
            <div class="icheck-primary d-inline">
                <input type="radio" id="radioBgOverlap1" name="meta[bg_overlap]" value="1"
                    @if(isset($block->meta->bg_overlap) && $block->meta->bg_overlap==1 ) checked @endif>
                <label for="radioBgOverlap1">
                    Yes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
            <div class="icheck-primary d-inline">
                <input type="radio" id="radioBgOverlap2" name="meta[bg_overlap]" value="0"
                    @if(isset($block->meta->bg_overlap) && $block->meta->bg_overlap==0 ) checked @endif>
                <label for="radioBgOverlap2">
                    No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
            <small class="form-text text-muted">This won't effect if column width is not set to Full</small>
        </div> -->
        @endif

        <!-- @if($showBgColor)

        <div class="form-group">
            <label>Show Theme Background Color</label>
            <br>
            <div class="icheck-primary d-inline">
                <input type="radio" id="radioBgColor1" name="meta[bg_color]" value="1" @if(isset($block->meta->bg_color)
                && $block->meta->bg_color==1 ) checked @endif>
                <label for="radioBgColor1">
                    Yes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
            <div class="icheck-primary d-inline">
                <input type="radio" id="radioBgColor2" name="meta[bg_color]" value="0" @if(isset($block->meta->bg_color)
                && $block->meta->bg_color==0 ) checked @endif>
                <label for="radioBgColor2">
                    No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
            <small class="form-text text-muted">Background Color will be overlapped to full width.</small>
        </div>

        @endif -->

        <div class="row">
            <div class="form-group col-md-3">
                <label for="cols">Block Width</label>
                @php
                $old_cols = $block->meta->cols ?? 12;
                @endphp
                <select name="meta[cols]" id="cols" class="form-control">
                    <option @if($old_cols==12) selected @endif value="12">Full</option>
                    <option @if($old_cols==9) selected @endif value="9">3/4</option>
                    <option @if($old_cols==8) selected @endif value="8">2/3</option>
                    <option @if($old_cols==6) selected @endif value="6">1/2</option>
                    <option @if($old_cols==4) selected @endif value="4">1/3</option>
                    <option @if($old_cols==3) selected @endif value="3">1/4</option>
                </select>
            </div>
        </div>

        <!---- custom class ---->
        <div class="form-group">
            <label for="custom_class">Custom Classes (Space Seperated)</label>
            <input type="text" name="meta[custom_class]" id="custom_class" class="form-control"
                value="{{ $block->meta->custom_class ?? '' }}">
        </div>

        <hr />
        <div class="form-group">
            <button type="submit" class="submit btn btn-primary float-right"><i class="fas fa-save"></i>
                Save</button>
            <button type="button" class="btn btn-default float-right mr-2" data-dismiss="modal" aria-label="Close"><i
                    class="fas fa-minus-circle"></i> Cancel</button>
        </div>
    </div>

</form>
<script>
$(document).ready(function() {
    setTimeout(function () {   
        if($('.gallery_display_type:checked').val()=='grid_view')
        {
            $('.col-drop-down').removeClass("d-none");
        }else{
            $('.col-drop-down').addClass("d-none");
        } }, 1000);
   
    $(".textEditor").summernote({
        height: 200,
        disableDragAndDrop: false,
        toolbar: TOOLBAR,
        styleTags: STYLETAGS,
    });

    $("body").on("click",".gallery_display_type",function(e){
       
       e.preventDefault;
       if($(this).val()=='grid_view')
        {
            $('.col-drop-down').removeClass("d-none");
        }else{
            $('.col-drop-down').addClass("d-none");
        }
   
   });
});
</script>