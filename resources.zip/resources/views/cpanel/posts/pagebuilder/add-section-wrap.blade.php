<div class="row ">
    <div class="col-12 col-md-12 d-flex  bg-gray-light py-1">
        <span class="ml-3 mr-auto text-muted">{!! $section->title !!} ({{ ucfirst($section->type ?? 'plain') }})</span>
        <ul class="d-flex flex-row justify-content-right my-0 pr-2">
            <li class="list-inline-item">
                <div class="dropleft">
                    <a href="javascript:" title="Block:{{isset($block->id)?$block->id:''}}" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false"
                        class="text-muted edit_content_block_dropdown mr-3 dropdown-toggle"
                        data-post_id="{{$section->post_id}}" data-id="{{isset($block->id)?$block->id:''}}"
                        data-section="{{$section->id}}" data-column="{{$section->blocks+1}}">
                        <i class="fa fa-plus-circle mr-1"></i>Add block
                    </a>
                    <div class="dropdown-menu width-400" aria-labelledby="dropdownMenuButton">
                        <div class="row mx-2 g-2">
                            <div class="col-6">
                                <a class="btn btn-default d-block text-left dropdown-item" data-block-type="all"
                                    href="javascript:void(0)"><i class="fa fa-file-image mr-1" aria-hidden="true"></i>
                                    Content And Media</a>
                            </div>
                            <div class="col-6">
                                <a class="btn btn-default d-block text-left dropdown-item" data-block-type="image"
                                    href="javascript:void(0)"><i class="fa fa-image mr-1" aria-hidden="true"></i> Media
                                    Only</a>
                            </div>
                            <div class="col-6">
                                <a class="btn btn-default d-block text-left dropdown-item" data-block-type="content"
                                    href="javascript:void(0)"><i class="fa fa-file mr-1" aria-hidden="true"></i> Content
                                    Only</a>
                            </div>
                            {{-- <div class="col-6">
                                <a class="btn btn-default d-block text-left dropdown-item" data-block-type="bgimage"
                                    href="javascript:void(0)"><i class="fa fa-file-image mr-1"
                                        aria-hidden="true"></i>Backgroud Image</a>
                            </div> --}}
                            <div class="col-6">
                                <a class="btn btn-default d-block text-left dropdown-item" data-block-type="tab"
                                    href="javascript:void(0)"><i class="fa fa-list-alt mr-1" aria-hidden="true"></i> Tab
                                    Content</a>
                            </div>
                            <div class="col-6">
                                <a class="btn btn-default d-block text-left dropdown-item" data-block-type="accordion"
                                    href="javascript:void(0)"><i class="fa fa-bars mr-1" aria-hidden="true"></i>
                                    Accordion Content</a>
                            </div>
                            <div class="col-6">
                                <a class="btn btn-default d-block text-left dropdown-item" data-block-type="button"
                                    href="javascript:void(0)"><i class="fa fa-link mr-1" aria-hidden="true"></i>
                                    Buttons</a>
                            </div>
                            <div class="col-6">
                                <a class="btn btn-default d-block text-left dropdown-item" data-block-type="table"
                                    href="javascript:void(0)"><i class="fa fa-table mr-1" aria-hidden="true"></i>
                                    Table</a>
                            </div>
                            <div class="col-6">
                                <a class="btn btn-default d-block text-left dropdown-item" data-block-type="gallery"
                                    href="javascript:void(0)"><i class="fa fa-image mr-1" aria-hidden="true"></i>
                                    Gallery</a>
                            </div>
                            <div class="col-6">
                                <a class="btn btn-default d-block text-left dropdown-item" data-block-type="brochure"
                                    href="javascript:void(0)"><i class="fas fa-file-pdf mr-1" aria-hidden="true"></i>
                                    Brochure</a>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </li>
            <li class="list-inline-item">
                @if(isset($section->status) && $section->status == 'N')
                <a href="javascript" class="text-muted section-status-update" data-id="{{$section->id}}"
                    data-status="{{$section->staus}}" data-toggle="tooltip" title="Show" data-original-title="Show"><i
                        class="fa fa-eye-slash" aria-hidden="true"></i></a>
                @else
                <a href="javascript" class="text-primary section-status-update" data-id="{{$section->id}}"
                    data-status="{{$section->staus}}" data-toggle="tooltip" title="Hide" data-original-title="Hide"><i
                        class="fa fa-eye" aria-hidden="true"></i></a>
                @endif
            </li>
            <li class="list-inline-item">
                <a href="javascript:void(0);" class="text-danger delete-content-section" data-toggle="tooltip"
                    title="Remove" data-original-title="Remove" data-post_id="{{$section->post_id}}"
                    data-section="{{$section->id}}"><i class="far fa-trash-alt"></i></a>
            </li>
            <!--                <li class="list-inline-item">
                    <a href="javascript:" class="text-primary" data-toggle="tooltip" title="Clone" data-original-title="Clone" data-post_id="{{$section->post_id}}" data-section="{{$section->id}}"><i class="fas fa-clone text-muted" ></i></a></li>-->
            <li class="list-inline-item">
                <a href="javascript:" class="text-primary section-settings" data-toggle="tooltip" title="Attributes"
                    data-original-title="Attributes" data-post_id="{{$section->post_id}}"
                    data-section="{{$section->id}}"><i class="fas fa-cog text-muted"></i></a>
            </li>
        </ul>
    </div>
</div>
<div class="py-5 px-3 border">
    @php
    $num_columns = isset($section->meta->num_columns)?$section->meta->num_columns:1;
    @endphp
    <div class="row row-cols-{{$num_columns}} sort-blocks">
        @php
        $i = 0;
        $blocks = $section->blockItems();
        @endphp
        @forelse($blocks as $block)
        @php
        $i++;
        if (!$block){ continue; }
        $block->meta = $block->meta();
        @endphp
        <div class="col-{{ $block->meta()->cols ?? 12 }} mb-3 text-muted block column-{{$section->id}}-{{$i}}"
            data-id="{{isset($block->id)?$block->id:''}}">
            <div class="border bg-gray-light py-2 px-4 text-center">
                <em class="column-title">{{ isset($block->title) ? $block->title : 'Add title'}}</em><br />
                @php
                $type = $block->meta->block_type;
                $fa_classes = [
                'all' => 'fa-file-image',
                'bgimage' => 'fa-file-image',
                'content' => 'fa-file',
                'image' => 'fa-image',
                'video' => 'fa-video',
                'contentvideo' => 'fa-file-alt',
                'tab' => 'fa-list-alt',
                'accordion' => 'fa-bars',
                'button' => 'fa-link',
                'table' => 'fa-table',
                'gallery' => 'fa-image',
                'brochure' => 'fas fa-file-pdf',
                
                ];
                @endphp

                <i class="fa {{ $fa_classes[$type] }}" data-toggle="tooltip" data-placement="top"
                    title="{{ ($type == 'all' ) ? 'Content And Media' : $type }}"></i>&nbsp;
                <a href="javascript:" title="Block:{{isset($block->id)?$block->id:''}}"
                    class="text-muted edit_content_block" data-post_id="{{$section->post_id}}"
                    data-id="{{isset($block->id)?$block->id:''}}" data-section="{{$section->id}}" data-column="{{$i}}"
                    data-block-type="{{ $block && isset($block->meta->block_type) ? $block->meta->block_type: 'all'}}">
                    <i class="text-primary far fa-edit"></i>
                </a>
                @if($block->id)
                | <a href="javascript:" title="Duplicate" class="section_block_copy"
                    data-id="{{isset($block->id)?$block->id:''}}">
                    <i class="fa fa-copy"></i>
                </a>
                | <a href="javascript:" title="Remove" class="text-danger delete-content-block"
                    data-post_id="{{$section->post_id}}" data-id="{{isset($block->id)?$block->id:''}}"
                    data-section="{{$section->id}}" data-column="{{$i}}">
                    <i class="far fa-trash-alt"></i>
                </a>
                @endif
            </div>
        </div>
        @empty
        <div class="border bg-gray-light py-2 px-4 w-100 text-muted column-{{$section->id}}-0">
            <em class="column-title">No blocks added.</em>
        </div>
        @endforelse
    </div>
</div>