<div class="form-group">
        @if(isset($post->id))
        <button type="button" class="btn btn-default btn-block" id="pagebuilder_add_section" data-id="{{$post->id}}">Add Section</button>
        @else
        <span class="text-danger">Please create content first.</span>
        @endif
</div>