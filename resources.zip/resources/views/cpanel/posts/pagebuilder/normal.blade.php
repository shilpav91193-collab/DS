<label for="title">Content</label> 
<textarea name="content" rows="8" id="content" class="form-control textEditor" placeholder="Enter the long description" >{!! isset($post->content)?$post->content:old('content') !!}</textarea>
