<form method="post" id="section_settings_frm" name="section-settings-frm" autocomplete="off"
    enctype="multipart/form-data">
    @csrf
    <input type="hidden" name="action" value="save-section-settings" />
    <input type="hidden" name="id" value="{{$section->id}}" />
    <div class="form-group row">
        <div class="col-md-8">
            <label for="name">Title</label>
            <input type="text" id="title" name="title" class="form-control"
                value="{{isset($section->title)?$section->title:''}}">
        </div>
        <div class="col-md-4">
            <label>Show Title</label> <br>
            @php
            $old_show_title = isset($section->meta->show_title)?$section->meta->show_title:'N';
            @endphp
            <div class="icheck-primary d-inline">
                <input type="radio" id="show_title1" name="meta[show_title]" value="Y" @if($old_show_title=='Y' )
                    checked @endif>
                <label for="show_title1">
                    Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
            <div class="icheck-primary d-inline">
                <input type="radio" id="show_title2" name="meta[show_title]" value="N" @if($old_show_title=='N' )
                    checked @endif>
                <label for="show_title2">
                    No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
        </div>
    </div>

    <div class="form-group row">
        <div class="col-md-2">
            <label for="sort_order">Sort order</label>
            <input type="number" id="sort_order" min="1" name="sort_order" class="form-control"
                value="{{isset($section->sort_order)?$section->sort_order:''}}">
        </div>
        <div class="col-md-4">
            <label for="type">Section type</label>
            <select name="type" id="type" class="form-control">
                <option value="plain">Plain</option>
                <option value="accordion" @if($section->type=='accordion') selected @endif>Accordion</option>
                <option value="tabs" @if($section->type=='tabs') selected @endif>Tabs</option>
            </select>
        </div>
        <div class="col-md-6">
            <label for="custom_class">Custom Class (Comma Seperated)</label>
            <input type="text" id="custom_class" name="meta[custom_class]" class="form-control"
                value="{{isset($section->meta->custom_class)?$section->meta->custom_class:''}}">
        </div>
    </div>

    <div class="form-group row d-none">
        <div class="col-md-8">
            @php
            $old_display = isset($section->meta->display)?$section->meta->display:'Full';
            @endphp
            <label for="name">Column display</label><br>
            <div class="icheck-primary d-inline">
                <input class="display-change" type="radio" id="display3" name="meta[display]" value="Full"
                    @if($old_display=='Full' ) checked @endif>
                <label for="display3">
                    Full width &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
            <div class="icheck-primary d-inline">
                <input class="display-change" type="radio" id="display1" name="meta[display]" value="Grid"
                    @if($old_display=='Grid' ) checked @endif>
                <label for="display1">
                    Grid view &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>
            <div class="icheck-primary d-inline">
                <input class="display-change" type="radio" id="display2" name="meta[display]" value="Carousel"
                    @if($old_display=='Carousel' ) checked @endif>
                <label for="display2">
                    Carousel&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </label>
            </div>

        </div>
        <div class="col-md-2 nums-rows  @if($old_display == 'Full') d-none @endif">
            <label for="name">Columns in a row</label>
            <input type="number" id="num_columns" min="1" max="4" name="meta[num_columns]" class="form-control"
                value="{{isset($section->meta->num_columns)?$section->meta->num_columns:1}}">
        </div>

    </div>
    <hr />
    <div class="form-group">

        <button type="submit" class="submit btn btn-primary float-right"><i class="fas fa-save"></i> Save</button>
        <button type="button" class="btn btn-default float-right mr-2" data-dismiss="modal" aria-label="Close"><i
                class="fas fa-minus-circle"></i> Cancel</button>
    </div>
    </div>

</form>