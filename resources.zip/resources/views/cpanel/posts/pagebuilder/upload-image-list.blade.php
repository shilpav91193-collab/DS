@if($items)
@foreach($items as $item)
<div class="col-sm-6">
    @if(count($items) > 1)
    <input type="hidden" class="img_input" name="image[]" value="{{$item['filename']}}">    
    @else
    <input type="hidden" class="img_input" name="image" value="{{$item['filename']}}">
    @endif
    <a href="javascript:void(0);" class="delete_tmp_image" data-name="{{$item['filename']}}"><i class="fas fa-times"></i></a>
    <a href="{{$item['url']}}" data-fancybox="{{$item['filename']}}" data-toolbar="" data-small-btn="true">
        <img src="{{$item['url']}}" class="img-fluid mb-3">

    </a>
</div>
@endforeach
@endif