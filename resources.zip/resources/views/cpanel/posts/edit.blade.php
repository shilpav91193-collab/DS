@extends('layouts.cpanel')

@section('content')
@php
    $user=Auth::user();
    $can_any_action=\App\Http\Helpers::getAccess($user, $post_type, 'update,delete');
    $can_create=\App\Http\Helpers::getAccess($user, $post_type, 'create');
    $can_update=\App\Http\Helpers::getAccess($user, $post_type, 'update');
    $can_delete=\App\Http\Helpers::getAccess($user, $post_type, 'delete');
    $can_approve=true; //\App\Http\Helpers::getAccess($user, $post_type, 'approve');
    $slugArray= preg_split("/[,]/",config('settings._not_editable_post_slug'));
@endphp

<script>
function loadTabContent() {
    return {
        ...
        @if($post_type == 'contents' && ($post->content_type == 'tabs' || $post->content_type == 'accordion')) {
            ...@endif {}
            @if($post_type == 'contents' && ($post->content_type == 'tabs' || $post->content_type ==
            'accordion')),
            tabContents: {!!$post->content ?? "{tabs:[],hide_title:\"N\"}"!!},
            init() {
                this.$watch("tabContents.tabs", (tabs) => {
                    this.$nextTick(() => {
                        $("#tabs_area").sortable("refresh");
                        $(".textEditor").summernote({
                            height: 200,
                            disableDragAndDrop: false,
                            toolbar: TOOLBAR,
                            styleTags: STYLETAGS,
                        });
                    });
                });
            },
            addNewTab() {

                if (this.tabContents.tabs.filter(tab => typeof tab.title != "string" || tab.title == "").length) {
                    alert("Please fill in all tab titles");
                    return;
                }

                this.tabContents.tabs.push({
                    title: "",
                    content: ""
                });
                this.$nextTick(() => {
                    document.querySelector(".tab-content").scrollIntoView({
                        behavior: "smooth",
                        block: "end"
                    });
                    $("#tabs_area").sortable("refresh");
                    $(".textEditor").summernote({
                        height: 200,
                        disableDragAndDrop: false,
                        toolbar: TOOLBAR,
                        styleTags: STYLETAGS,
                    });
                });
            },
            deleteTab(index) {
                this.tabContents.tabs.splice(index, 1);
            }
        }
        @endif
    };
}
</script>
<div x-data='loadTabContent()'>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row my-2">
                <div class="col-sm-12">
                    <h1 class="m-0 text-dark">Edit {{config('content_type.'.$post_type)->edit}}
                        @if ($post->service_id)/ {{ $post->service->title }} @endif
                        <a href="{{route('posts.create',[
                                'post_type'=>$post_type,
                                 'service_id' => $post->service_id])}}"
                            class="btn btn-default"><i class="fa fa-plus"></i> Add new</a>
                        <a href="{{route('posts.list',[
                                'post_type'=>$post_type,
                                 'service_id' => $post->service_id])}}"
                            class="btn btn-secondary float-right">
                            <i class="fas fa-angle-left"></i> Back to Listing</a>
                    </h1>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            @include('layouts.common.messages')
            <form method="post" autocomplete="off" enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="id" id="post_id" value="{{ isset($post->id)?$post->id:'' }}" />
                <input type="hidden" name="post_type" id="post_type" value="{{ $post_type }}" />
                <input type="hidden" name="service_id" id="service_id" value="{{ $post->service_id }}" />
                <div class="row">
                    <div class="col-md-9">
                        <div class="card card-primary">
                            <div class="card-body">
                                <div class="row">
                                    <div class="form-group col-sm-12">
                                        @if($post_type == 'contents' && $post->content_type == 'title')
                                        <h5 class="h5">Title and Description Section</h5>
                                            @endif
                                            @if($post->content_type == 'external_url')
                                            <h5 class="h5">Image Title and Description Section</h5>
                                                @endif
                                                <label for="title">Title
                                                    <span class="text-danger">*</span></label>
                                                <input id="title" type="text"
                                                       class="form-control post-title"
                                                    name="title"
                                                    value="{{ isset($post->title)?$post->title:old('title')}}"
                                                       required
                                                    placeholder="Enter Title">

                                                @if((config('content_type.'.$post_type)->url == true) &&
                                                    (!in_array($post->slug,$slugArray)))

                                                <span id="slug_area" class="{{isset($post->id)?'':'hide'}}">
                                                        {{ $post->post_type == 'page' ? '' :
                                                                    ($post->post_type . '/') }}
                                                        @if($post->service_id)
                                                            {{$post->service->slug }}/
                                                          @endif
                                                            @php
                                                                $parents = \App\Http\Helpers::parentPostWithSlug($post->id);
                                                                $breadcrumbs = array_reverse($parents,true);
                                                                $parent_html = '';
                                                                foreach($breadcrumbs as $index=>$val){
                                                                    if($val != end($breadcrumbs)){
                                                                        $parent_html .='<span>'.$index.'</span>/';
                                                                    }
                                                                }
                                                            @endphp
                                                        <code>{!! $parent_html !!}
                                                            <span id="post_url">{{isset($post->slug)?$post->slug:old('slug')}}</span>
                                                        </code>
                                                        <input type="hidden" name="slug"
                                                            value="{{isset($post->slug)?$post->slug:old('slug')}}" id="slug"
                                                            style="width:200px;">

                                                        <button class="btn d-none btn-default btn-xs" type="button"
                                                            id="save_postname">Ok</button>
                                                        <button class="btn btn-default btn-xs " type="button"
                                                            id="edit_postname">Edit</button>
                                                </span>
                                                <div class="col-sm-12 text-muted ">
                                                    <div class="icheck-primary d-inline">
                                                        <span>
                                                            OR use external url
                                                        </span>
                                                        <input @if((old('meta.use_external_url') ??
                                                            $post->meta->use_external_url ?? '') == 'Y')
                                                                   checked @endif
                                                        type="checkbox" name="meta[use_external_url]"
                                                        id="use_external_url" value="Y">
                                                    </div>
                                                </div>
                                                <script>
                                                $(document).ready(function() {
                                                    $('#use_external_url').on('change', function(event) {
                                                        if ($(this).prop('checked')) {
                                                            $('.use_external_url_area').removeClass(
                                                                'd-none');
                                                        } else {
                                                            $('.use_external_url_area').addClass(
                                                                'd-none');
                                                        }
                                                    });
                                                });
                                                </script>
                                                <div
                                                    class="col-sm-12
                                                    @if( (old('meta.use_external_url') ??
                                                            $post->meta->use_external_url ??
                                                            '') != 'Y') d-none @endif
                                                            text-muted use_external_url_area p-2
                                                             border bg-light">
                                                    <input id="external_url" type="text"
                                                        class="form-control post-external_url"
                                                           name="meta[external_url]"
                                                        value="{{ isset($post->meta->external_url) ?
                                                            $post->meta->external_url :
                                                            old('meta.external_url')}}"
                                                        placeholder="https://www.yourdomain.com/pageurl">

                                                    <div class="my-2">
                                                        <em>Open in new window?</em>
                                                        <div class="icheck-primary d-inline">
                                                            <input @if((old('meta.open_in_new_window') ??
                                                                $post->meta->open_in_new_window ?? '') == 'Y')
                                                                       checked
                                                            @endif type="radio" name="meta[open_in_new_window]"
                                                            id="newWindow12" value="Y">
                                                            <label for="newWindow12">
                                                                Yes &nbsp;&nbsp;&nbsp;
                                                            </label>
                                                        </div>
                                                        <div class="icheck-primary d-inline">
                                                            <input @if((old('meta.open_in_new_window') ??
                                                                $post->meta->open_in_new_window ?? '') == 'N')
                                                                       checked
                                                            @endif type="radio" name="meta[open_in_new_window]"
                                                            id="newWindow22" value="N">
                                                            <label for="newWindow22">
                                                                No
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                @endif
                                    </div>
                                    @if($post_type == 'page')
                                        <div class="form-group col-sm-6">
                                            @include('layouts.common.user-type', ['result' => $post])
                                        </div>
                                    @endif
                                    @if($post_type == 'contents' && $post->content_type == 'tabs')
                                        <div class="form-group col-sm-12">
                                            <label>Show Title</label> <br>
                                            <div class="icheck-primary d-inline">
                                                <input :checked="tabContents.hide_title == 'N'"
                                                    @change="tabContents.hide_title = 'N'"
                                                       type="radio" name="hide_title"
                                                    id="hideTitle1" value="Y">
                                                <label for="hideTitle1">
                                                    Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                </label>
                                            </div>
                                            <div class="icheck-primary d-inline">
                                                <input :checked="tabContents.hide_title == 'Y'"
                                                    @change="tabContents.hide_title = 'Y'"
                                                       type="radio" name="hide_title"
                                                    id="hideTitle2" value="N">
                                                <label for="hideTitle2">
                                                    No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                </label>
                                            </div>
                                        </div>
                                    @endif
                                    @if(config('content_type.'.$post_type)->enable_short_description == true)
                                        <div class="form-group col-sm-12">
                                            <label for="excerpt">Short Description</label>
                                            <textarea name="meta[short_description]" class="form-control"
                                                      cols="40" rows="4"
                                                      placeholder="Enter short description">{{ isset($post->meta->short_description)?$post->meta->short_description:old('meta.short_description') }}</textarea>
                                        </div>
                                    @endif

                                    @if(config('content_type.'.$post_type)->enable_excerpt == true &&
                                        $post->content_type != 'normal')
                                        <div class="form-group col-sm-12">
                                            <label for="excerpt">Description</label>
                                            <textarea name="content" id="excerpt" class="form-control
                                            @if(in_array($post->slug,$slugArray)) textEditor @endif"
                                                      cols="40" rows="4"
                                                placeholder="Enter description">{{ isset($post->content)?$post->content:old('content') }}</textarea>
                                        </div>
                                    @endif
                                    @if(config('content_type.'.$post_type)->enable_note == true)
                                        <div class="form-group col-sm-12">
                                            <label for="notes">Description</label>
                                            <textarea id="notes" name="meta[notes]" class="form-control textEditor" cols="40" rows="4"
                                                      placeholder="">{{ isset($post->meta->{'notes'}) ? $post->meta->{'notes'} : old('meta.notes') }}</textarea>
                                        </div>
                                    @endif
                                    @if(isset(config('content_type.'.$post_type)->enable_disctrict_note) == true
                                        && config('content_type.'.$post_type)->enable_disctrict_note == true)
                                        <div class="form-group col-sm-6">
                                            <label for="worth_assets_key">Worth Assets Text</label>
                                            <input id="worth_assets_key" type="text" class="form-control" name="meta[worth_assets_key]"
                                                   value="{{ isset($post->meta->{'worth_assets_key'}) ? $post->meta->{'worth_assets_key'}:old('meta.worth_assets_key') }}" />
                                        </div>
                                        <div class="form-group col-sm-6">
                                            <label for="worth_assets">Worth Assets</label>
                                            <input id="worth_assets" type="text" class="form-control" name="meta[worth_assets]"
                                                   value="{{ isset($post->meta->{'worth_assets'}) ? $post->meta->{'worth_assets'}:old('meta.worth_assets_key') }}" />
                                        </div>
                                        <div class="form-group col-sm-6">
                                            <label for="area_covered_key">Area Covered Text</label>
                                            <input id="area_covered_key" type="text" class="form-control" name="meta[area_covered_key]"
                                                   value="{{ isset($post->meta->{'area_covered_key'}) ? $post->meta->{'area_covered_key'}:old('meta.area_covered_key') }}" />
                                        </div>
                                        <div class="form-group col-sm-6">
                                            <label for="area_covered">Area Covered</label>
                                            <input id="area_covered" type="text" class="form-control" name="meta[area_covered]"
                                                   value="{{ isset($post->meta->{'area_covered'}) ? $post->meta->{'area_covered'}:old('meta.area_covered') }}" />
                                        </div>
                                    @endif
                                    @if(config('content_type.'.$post_type)->enable_subtitle == true &&
                                    $post->content_type != 'title' &&
                                    $post->content_type != 'tabs' )
                                        <div class="form-group col-sm-12">
                                            <label for="title">Sub title</label>
                                            <input id="link" type="text" class="form-control" name="meta[subtitle]"
                                                value="{{ isset($post->meta->{'subtitle'}) ? $post->meta->{'subtitle'}:old('meta.subtitle') }}" />
                                        </div>
                                    @endif
                                    @if(isset($post->slug) && $post->slug != 'home' )
                                        @if(isset($post->content_type) && $post->content_type == 'builder')
                                            <div class="form-group col-sm-12 mt-2" id="conten_sections">
                                                @include('cpanel.posts.pagebuilder.sections',['post'=>$post])
                                            </div>
                                        @endif
                                    @endif
                                </div>
                            </div>
                        </div>

                        @if(isset($post->id) && View::exists('cpanel.posts.inc.'.$post->slug.'-meta-content') )
                            @include('cpanel.posts.inc.'.$post->slug.'-meta-content')
                        @endif

                        @if (View::exists('cpanel.posts.inc.'.$post_type.'-meta-content'))
                            @include('cpanel.posts.inc.'.$post_type.'-meta-content')
                        @endif

                        @if($post->content_type == 'tabs' || $post->content_type == 'accordion')
                        <h4 class="h4 mt-4 ml-2">Tab Contents <button type="button" @click.prevent="addNewTab()"
                                class="btn btn-default">Add New</button></h4>
                        <div class="row pb-3">
                            <div class="col-sm-12 bg-gray-light">
                                <div class="container mb-4 mt-2">
                                    <div class="tab-content" id="tabs_area">
                                        <template x-for="(tab, i) in tabContents.tabs" :key="tab">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-sm-12">
                                                            <div class="form-group">
                                                                <label :for="'tab_title'+i">Tab Title</label>
                                                                <input required type="text" :name="'tab_title[]'"
                                                                    :id="'tab_title'+i" class="form-control"
                                                                    @input="tab.title = $event.target.value"
                                                                    :value="tab.title">
                                                            </div>
                                                            <div class="form-group">
                                                                <label :for="'tab_content'+i">Tab Content</label>
                                                                <textarea required rows="4" :name="'tab_content[]'"
                                                                    :id="'tab_content'+i"
                                                                    class="form-control textEditor"
                                                                    @input="tab.content = $event.target.value"
                                                                    :value="tab.content"></textarea>
                                                            </div>
                                                            <!--- Trash button to delete by index -->
                                                            <button type="button" @click.prevent="deleteTab(i)"
                                                                class="btn btn-danger"><i
                                                                    class="fa fa-trash"></i></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </template>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <script>
                        $(document).ready(function() {
                            $("#tabs_area").sortable({
                                items: "#tabs_area > div",
                                cursor: 'move',
                                revert: true,
                            });
                        });
                        </script>
                        @endif

                        @if ($post->post_type == 'page')
                        @include('cpanel.posts.inc.page-meta-content', ['result' => $post])
                        @endif

                        @include('layouts.common.activity', ['result' => $post, 'activities' => $activities ?? []])


                    </div>
                    <div class="col-md-3">
                        <div class="sticky-top mb-3">
                            @if($can_update)
                            <div class="card">
                                <div class="card-body">
                                    <button type="submit" class="btn btn-block btn-primary"><i class="fas fa-save"></i>
                                        Update</button>
                                    <a href="{{ route('posts.list',['post_type'=>$post_type,'service_id' =>
                                        $post->service_id,'s'=>Request::input('s'),'limit'=>Request::input('limit'),'events'=>Request::input('events'),'page'=>Request::input('page')])
                                        }}" class="btn btn-block btn-default"><i class="fas fa-times"></i> Cancel</a>
                                    @if(config('content_type.'.$post_type)->date == true)
                                        <div class="form-group mt-2">
                                            <label for="">Published on</label>
                                            <div class="input-group">
                                                <input type="text" class="form-control datetimepicker"
                                                       name="created_at"
                                                    id="created_at" autocomplete="off"
                                                       value="{{isset($post->created_at)?date(" Y-m-d",
                                                    strtotime($post->created_at)):old('created_at')}}" />
                                                <label class="input-group-addon btn" for="created_at">
                                                    <span class="fa fa-calendar open-datepicker"></span>
                                                </label>
                                            </div>
                                        </div>
                                    @endif

                                    @if(config('content_type.'.$post_type)->enable_author == true)
                                        <div class="form-group">
                                            <label for="">Author</label>
                                            <div class="input-group">
                                                <input type="text" placeholder="Enter Author"
                                                       class="form-control "
                                                    name="meta[author]" id="author" autocomplete="off"
                                                    value="{{isset($post->meta->author) ?
                                                                    $post->meta->author :
                                                                    old('meta.author')}}" />
                                            </div>
                                        </div>
                                    @endif

                                    @if(config('content_type.'.$post_type)->enable_location == true)
                                        <div class="form-group">
                                            <label for="">Location</label>
                                            <div class="input-group">
                                                <input type="text" placeholder="Enter Location"
                                                       class="form-control "
                                                       name="meta[location]" id="location" autocomplete="off"
                                                       value="{{isset($post->meta->location) ?
                                                                $post->meta->location :
                                                                old('meta.location')}}" />
                                            </div>
                                        </div>
                                    @endif

                                    <div class="form-group">
                                        <label for="status">Status</label>
                                        <select name="status" id="status" class="form-control">
                                            <option value="N" {{ isset($post->status) && $post->status != 'Y' ?
                                                'selected':'' }}>Draft</option>
                                            @if($can_approve)
                                            <option value="Y" {{ isset($post->status) && $post->status == 'Y' ?
                                                'selected':'' }}>Published</option>
                                            @endif
                                        </select>
                                    </div>

                                    @if($post_type == 'page' && (!in_array($post->slug,$slugArray)))
                                        <div class="form-group">
                                            <label for="parent">Parent</label>
                                            <select style="white-space: pre-wrap;" @if(!$can_update) selected @endif
                                                name="parent" id="parent" class="form-control select2">
                                                <option value="" {{ !isset($post->parent_id) || !$post->parent_id ?
                                                    'selected':'' }}>-- No Parent --</option>
                                                {{-- <optgroup label="Pages"> --}}
                                                @foreach ($pages as $page)
                                                <option value="{{ $page->id }}" {{ isset($post->parent_id) &&
                                                        $post->parent_id == $page->id ? 'selected':'' }}>{{ $page->title }}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    @endif

                                    @if($post_type == 'contents')
                                        @if($post->content_type == 'normal' || $post->content_type == 'builder')
                                            <div class="form-group">
                                                <label for="parent">Parent</label>
                                                <select name="parent" id="parent" class="form-control select2">
                                                    <option value="" {{ !isset($post->parent_id) || !$post->parent_id ?
                                                        'selected':'' }}>-- No Parent --</option>
                                                    @if($can_update)
                                                        @foreach($services as $service_)
                                                            <option value="{{ $service_->id }}"
                                                                {{ isset($post->parent_id) &&
                                                                $post->parent_id == $service_->id ? 'selected':'' }}>
                                                                    {{ $service_->title}}
                                                            </option>
                                                        @endforeach
                                                    @endif
                                                </select>
                                            </div>
                                        @endif
                                    @endif

                                </div>
                            </div>
                            @endif
                            @php

                                $terms = config('content_type.' . $post_type) ?->terms??[];

                                $service_meta_term_array=[];

                                if(isset($service) && $service->service_meta)
                                {
                                $service_meta=json_decode($service->service_meta ?? ['term'=>[]]);
                                $service_meta_term_array=$service_meta->term;

                                }
                            @endphp

                            @if ($post->content_type != 'title' && $post->content_type != 'tabs' && $post->content_type
                            != 'accordion' && $post->content_type != 'normal')
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Media</h3>
                                </div>
                                <div class="card-body">

                                    @if(config('content_type.'.$post_type)->image == true)
                                    @php
                                    $images = null;
                                    if (($img = old('image', $post->image))) {
                                    $images = \App\Models\Medias::where('id', $img ?? '')->first();
                                    }
                                    if ($images && $images->file_url) {
                                    $images->file_url = \App\Http\Helpers::asset($images->file_url);
                                    $images = [$images];
                                    }
                                    @endphp
                                    <div class="row form-group"
                                        x-data='__images("featured", {{ json_encode($images ?? []) }})'>
                                        <div class="col-sm-12">

                                            <label for="featured_image">Featured Image</label>

                                            <input type="hidden" name="image"
                                                :value="images.length ? images[0].id : ''">
                                            <div class="border p-3 bg-gray-light d-flex flex-wrap sort-sections">
                                                <template x-for="(image, i) in images">
                                                    <div class="p-2 position-relative">
                                                        <img loading="lazy"
                                                            class="h-100 w-100 shadow-sm rounded border bg-white"
                                                            style="object-fit: contain;" :src="image.file_url">
                                                        <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                                                            <!--- Create Trash Image button shown at hover ---->
                                                            <button type="button" class="btn btn-danger btn-sm"
                                                                x-on:click="removeImage(i, 'featured')">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </template>

                                                <div x-show="! images.length" class="p-2 d-flex justify-content-center"
                                                    :class="{ 'd-flex': !images.length }"
                                                    style="min-height: 100px; width: 100%;">
                                                    <div
                                                        class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                                                        <!-- Add Button !-->
                                                        <label @click.prevent="openingModal('#editModal')"
                                                            data-toggle="modal" data-drop="false"
                                                            data-target="#editModal" type="button"
                                                            class="btn btn-outline-success btn-sm">
                                                            <i class="fas fa-plus"></i>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>

                                            <input type="hidden" id="use_featured_as_banner_hidden"
                                                name="meta[use_featured_as_banner]" value="{{ (old('meta.use_featured_as_banner')
                                                ?? $post->meta->use_featured_as_banner ?? '') }}">
                                            <div class="icheck-primary mt-3">
                                                <input class="custom-checkbox" @if((old('meta.use_featured_as_banner')
                                                    ?? $post->meta->use_featured_as_banner ?? '') == 'Y') checked
                                                @endif
                                                type="checkbox"
                                                onclick="$('#use_featured_as_banner_hidden').val(this.checked ? 'Y' :
                                                'N')"
                                                id="use_featured_as_banner" value="Y">
                                                <label for="use_featured_as_banner" class="font-weight-normal">Use as
                                                    Banner Image</label>
                                            </div>
                                        </div>
                                    </div>
                                    @if(!in_array($post->slug,$slugArray))
                                    @php
                                    $images = null;
                                    if (($img = old('image', $post->thumbnail))) {
                                    $images = \App\Models\Medias::where('id', $img ?? '')->first();
                                    }
                                    if ($images && $images->file_url) {
                                    $images->file_url = \App\Http\Helpers::asset($images->file_url);
                                    $images = [$images];
                                    }
                                    @endphp

                                    <div class="row form-group"
                                        x-data='__images("thumbnail", {{ json_encode($images ?? []) }})'>
                                        <div class="col-sm-12">
                                            <input type="hidden" name="thumbnail"
                                                :value="images.length ? images[0].id : ''">
                                            <label for="thumbnail_image">Thumbnail</label>
                                            <div class="border p-3 bg-gray-light d-flex flex-wrap sort-sections">
                                                <template x-for="(image, i) in images">
                                                    <div class="p-2 position-relative">
                                                        <img loading="lazy"
                                                            class="h-100 w-100 shadow-sm rounded border bg-white"
                                                            style="object-fit: contain;" :src="image.file_url">
                                                        <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                                                            <!--- Create Trash Image button shown at hover ---->
                                                            <button type="button" class="btn btn-danger btn-sm"
                                                                x-on:click="removeImage(i)">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </template>

                                                <div x-show="! images.length" class="p-2 d-flex justify-content-center"
                                                    :class="{ 'd-flex': !images.length }"
                                                    style="min-height: 100px; width: 100%;">
                                                    <div
                                                        class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                                                        <!-- Add Button !-->
                                                        <label @click.prevent="openingModal('#editModal')"
                                                            data-toggle="modal" data-drop="false"
                                                            data-target="#editModal" type="button"
                                                            class="btn btn-outline-success btn-sm">
                                                            <i class="fas fa-plus"></i>
                                                        </label>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                    @endif
                                    @if(config('content_type.'.$post_type)->enable_video == true)
                                    <hr>
                                    <div class="form-group">
                                        <label for="">YouTube Video ID&nbsp;<i class="fab fa-youtube"></i></label>
                                        <input type="text" class="form-control" name="meta[video]"
                                            value="{{ isset($post->meta->{'video'})?$post->meta->{'video'}:old('meta.video')}}"
                                            placeholder="Enter Video ID" />
                                        <small class="gray">eg: https://www.youtube.com/watch?v=<strong
                                                class="text-danger">JfMM34rmjYQ</strong></small>

                                    </div>
                                    @endif
                                    @if(config('content_type.'.$post_type)->enable_icon_class == true)
                                        <hr>
                                        <div class="form-group">
                                            <label for="">Icon Class</label>
                                            <input type="text" class="form-control" name="meta[icon_class]"
                                                   value="{{ isset($post->meta->{'icon_class'}) ?
                                                $post->meta->{'icon_class'} : old('meta.icon_class')}}"
                                                   placeholder="Enter icon class" />

                                        </div>
                                    @endif
                                    @if(config('content_type.'.$post_type)->enable_fotos == true)
                                    <hr>
                                    <div class="form-group">
                                        <label for="">Photos</label>
                                        <div class="col-md-12">
                                            <div class="upload-response"></div>
                                            <ul class="images-list">
                                                @if(isset($post->photos))
                                                @forelse($post->photos as $i=>$photo)
                                                @if(isset($photo->filename) &&
                                                Storage::disk('public')->exists('posts/'.$photo->filename) )
                                                <li class="upload-thumb">
                                                    <a href="javascript:void(0);" data-id="{{$photo->id}}"
                                                        data-image="{{$photo->image}}" class="remove-post-image red"><i
                                                            class="fa fa-trash" aria-hidden="true"></i></a>
                                                    <a href="{{asset('storage/posts/' . $photo->filename)}}"
                                                        target="_blank"><img
                                                            src="{{asset('storage/posts/' . $photo->filename)}}"
                                                            width="90" alt="{{$photo->title}}"></a>
                                                    <input type="hidden" name="photos[]" value="{{$photo->image}}" />
                                                </li>
                                                @endif
                                                @empty
                                                @endforelse
                                                @endif
                                                <li class="upload-addimg">
                                                    <span class="upload btn-file">
                                                        <a href="javascript:void(0)"
                                                            class="text-muted post-image-button"><i
                                                                class="fa fa-upload fa-3x"></i></a>
                                                        <input name="post_image[]" type="file" class="post-image"
                                                            multiple />
                                                    </span>
                                                </li>
                                                <div class="cleafix"></div>
                                            </ul>

                                        </div>
                                        <div class="cleafix"></div>
                                    </div>
                                    @endif

                                    @if(isset($post->id) && View::exists('cpanel.posts.inc.'.$post->slug.'-side') )
                                    @include('cpanel.posts.inc.'.$post->slug.'-side')
                                    @endif
                                    @if (View::exists('cpanel.posts.inc.'.$post_type.'-side'))
                                    @include('cpanel.posts.inc.'.$post_type.'-side')
                                    @endif

                                    @if($post->content_type != 'external_url')
                                    <div class="form-group">
                                        <label for="">
                                            Banner
                                        </label>
                                        <select name="meta[banner_id]" id="banner_id" class="form-control">
                                            <option value="">Select Banner</option>
                                            @foreach($banners as $banner)
                                            @php
                                            $old_bannerid = isset($post->meta->banner_id) ? $post->meta->banner_id :
                                            old('meta.banner_id');
                                            @endphp
                                            <option value="{{$banner->id}}" {{ $old_bannerid==$banner->id ?
                                                'selected':'' }}>{{$banner->title}}</option>
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="d-none">
                                        <div class="mb-2 text-center">
                                            <strong>Or</strong>
                                        </div>

                                        <div class="form-group">
                                            <label for="">
                                                Gallery
                                            </label>
                                            <select name="meta[gallery_id]" id="gallery_id" class="form-control">
                                                <option value="">Select Gallery</option>
                                                @foreach($galleries as $gallery)
                                                @php
                                                $old_galleryid = isset($post->meta->gallery_id) ?
                                                $post->meta->gallery_id :
                                                old('meta.gallery_id');
                                                @endphp
                                                <option value="{{$gallery->id}}" {{ $old_galleryid==$gallery->id ?
                                                    'selected':'' }}>{{$gallery->title}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    @endif
                                </div>
                            </div>
                            @endif
                            @if(config('content_type.'.$post_type)->enable_seo == true && $post->content_type != 'title'
                            && $post->content_type != 'tabs' && $post->content_type != 'accordion' &&
                            $post->content_type != 'external_url')
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">SEO Content</h3>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="excerpt">Page Title</label>
                                        <input type="text" name="meta[meta_title]"
                                            value="{{ isset($post->meta->{'meta_title'})?$post->meta->{'meta_title'}:old('meta.meta_title') }}"
                                            id="meta_title" class="form-control" placeholder="Enter the SEO title" />
                                    </div>
                                    <div class="form-group">
                                        <label for="excerpt">Keywords</label>
                                        <textarea name="meta[meta_keyword]" id="meta_keyword" class="form-control"
                                            cols="40" rows="4"
                                            placeholder="Enter the SEO keywords">{{ isset($post->meta->{'meta_keyword'})?$post->meta->{'meta_keyword'}:old('meta.meta_keyword') }}</textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="excerpt">Description</label>
                                        <textarea name="meta[meta_description]" id="meta_description"
                                            class="form-control" cols="40" rows="4"
                                            placeholder="Enter the SEO description">{{ isset($post->meta->{'meta_description'})?$post->meta->{'meta_description'}:old('meta.meta_description') }}</textarea>
                                    </div>
                                </div>
                            </div>
                            @endif
                        </div>
                        @if(isset($post->id) && View::exists('cpanel.posts.inc.'.$post->slug.'-meta-side') )
                        @include('cpanel.posts.inc.'.$post->slug.'-meta-side')
                        @endif
                        @if (View::exists('cpanel.posts.inc.'.$post_type.'-meta-side'))
                        @include('cpanel.posts.inc.'.$post_type.'-meta-side')
                        @endif

                    </div>
                </div><input class="content_type" type="hidden" name="content_type"
                    value="{{ $post->content_type ?? 'title' }}" />
            </form>
        </div>
    </section>
    <div class="full-screen-modal modal fade select-section-popup" id="select-section-popup" role="dialog"
        aria-labelledby="batch" aria-hidden="true" data-keyboard="false" data-backdrop="static">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Select Section</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                </div>
            </div>
        </div>
    </div>
    @include('layouts.common.media-multi', ['multiple' => false])
    <style>
    .full-screen-modal {
        padding: 0 !important;
    }

    .full-screen-modal .modal-dialog {
        width: 100%;
        max-width: none;
        height: 100%;
        margin: 0;
    }

    .full-screen-modal .modal-content {
        height: 100%;
        border: 0;
        border-radius: 0;
        padding-top: 0.5rem;
        padding-bottom: 0.5rem;
    }

    .full-screen-modal .modal-body {
        overflow-y: auto;
    }
    </style>

    <script>
    $(function() {
        $('.datepicker').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true
        });

        $(document).on('change', '#home_sector_active_status', function(e) {
            e.preventDefault();
            if (confirm('Are you sure you want to change the status?')) {
                var isChecked = $(this).is(':checked');
                if (isChecked) {
                    $('#sector-active-status-switch').addClass('custom-switch-on-success');
                    $('#sector-active-status-switch').removeClass('custom-switch-off-danger');
                    $(this).prop('value', 'Y');
                } else {
                    $('#sector-active-status-switch').removeClass('custom-switch-on-success');
                    $('#sector-active-status-switch').addClass('custom-switch-off-danger');
                    $(this).prop('value', 'N');
                }
            }
        });

        $(document).on('change', '#home_who_we_active_status', function(e) {
            e.preventDefault();
            if (confirm('Are you sure you want to change the status?')) {
                var isChecked = $(this).is(':checked');
                if (isChecked) {
                    $('#who-we-active-status-switch').addClass('custom-switch-on-success');
                    $('#who-we-active-status-switch').removeClass('custom-switch-off-danger');
                    $(this).prop('value', 'Y');
                } else {
                    $('#who-we-active-status-switch').removeClass('custom-switch-on-success');
                    $('#who-we-active-status-switch').addClass('custom-switch-off-danger');
                    $(this).prop('value', 'N');
                }
            }
        });

        $(document).on('change', '#home_counter_active_status', function(e) {
            e.preventDefault();
            if (confirm('Are you sure you want to change the status?')) {
                var isChecked = $(this).is(':checked');
                if (isChecked) {
                    $('#counter-active-status-switch').addClass('custom-switch-on-success');
                    $('#counter-active-status-switch').removeClass('custom-switch-off-danger');
                    $(this).prop('value', 'Y');
                } else {
                    $('#counter-active-status-switch').removeClass('custom-switch-on-success');
                    $('#counter-active-status-switch').addClass('custom-switch-off-danger');
                    $(this).prop('value', 'N');
                }
            }
        });

        $(document).on('change', '#home_leaders_active_status', function(e) {
            e.preventDefault();
            if (confirm('Are you sure you want to change the status?')) {
                var isChecked = $(this).is(':checked');
                if (isChecked) {
                    $('#leaders-status-switch').addClass('custom-switch-on-success');
                    $('#leaders-status-switch').removeClass('custom-switch-off-danger');
                    $(this).prop('value', 'Y');
                } else {
                    $('#leaders-status-switch').removeClass('custom-switch-on-success');
                    $('#leaders-status-switch').addClass('custom-switch-off-danger');
                    $(this).prop('value', 'N');
                }
            }
        });

        $(document).on('change', '#home_roles_active_status', function(e) {
            e.preventDefault();
            if (confirm('Are you sure you want to change the status?')) {
                var isChecked = $(this).is(':checked');
                if (isChecked) {
                    $('#roles-status-switch').addClass('custom-switch-on-success');
                    $('#roles-status-switch').removeClass('custom-switch-off-danger');
                    $(this).prop('value', 'Y');
                } else {
                    $('#roles-status-switch').removeClass('custom-switch-on-success');
                    $('#roles-status-switch').addClass('custom-switch-off-danger');
                    $(this).prop('value', 'N');
                }
            }
        });

        $(document).on('change', '#home_groups_active_status', function(e) {
            e.preventDefault();
            if (confirm('Are you sure you want to change the status?')) {
                var isChecked = $(this).is(':checked');
                if (isChecked) {
                    $('#groups-status-switch').addClass('custom-switch-on-success');
                    $('#groups-status-switch').removeClass('custom-switch-off-danger');
                    $(this).prop('value', 'Y');
                } else {
                    $('#groups-status-switch').removeClass('custom-switch-on-success');
                    $('#groups-status-switch').addClass('custom-switch-off-danger');
                    $(this).prop('value', 'N');
                }
            }
        });

        $(document).on('change', '#home_footprints_active_status', function(e) {
            e.preventDefault();
            if (confirm('Are you sure you want to change the status?')) {
                var isChecked = $(this).is(':checked');
                if (isChecked) {
                    $('#footprints-status-switch').addClass('custom-switch-on-success');
                    $('#footprints-status-switch').removeClass('custom-switch-off-danger');
                    $(this).prop('value', 'Y');
                } else {
                    $('#footprints-status-switch').removeClass('custom-switch-on-success');
                    $('#footprints-status-switch').addClass('custom-switch-off-danger');
                    $(this).prop('value', 'N');
                }
            }
        });

        $(document).on('change', '#home_news_active_status', function(e) {
            e.preventDefault();
            if (confirm('Are you sure you want to change the status?')) {
                var isChecked = $(this).is(':checked');
                if (isChecked) {
                    $('#news-status-switch').addClass('custom-switch-on-success');
                    $('#news-status-switch').removeClass('custom-switch-off-danger');
                    $(this).prop('value', 'Y');
                } else {
                    $('#news-status-switch').removeClass('custom-switch-on-success');
                    $('#news-status-switch').addClass('custom-switch-off-danger');
                    $(this).prop('value', 'N');
                }
            }
        });

        $(document).on('change', '#home_video_active_status', function(e) {
            e.preventDefault();
            if (confirm('Are you sure you want to change the status?')) {
                var isChecked = $(this).is(':checked');
                if (isChecked) {
                    $('#video-status-switch').addClass('custom-switch-on-success');
                    $('#video-status-switch').removeClass('custom-switch-off-danger');
                    $(this).prop('value', 'Y');
                } else {
                    $('#video-status-switch').removeClass('custom-switch-on-success');
                    $('#video-status-switch').addClass('custom-switch-off-danger');
                    $(this).prop('value', 'N');
                }
            }
        });
    });
    </script>

</div>
@endsection
