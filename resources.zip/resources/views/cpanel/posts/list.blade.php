@extends('layouts.cpanel')

@section('content')
@php
    $user = Auth::user();
    $can_any_action=\App\Http\Helpers::getAccess($user, $post_type, 'update,delete');

    $can_create=\App\Http\Helpers::getAccess($user, $post_type, 'create');
    $can_update=\App\Http\Helpers::getAccess($user, $post_type, 'update');
    $can_delete=\App\Http\Helpers::getAccess($user, $post_type, 'delete');
    $can_approve=\App\Http\Helpers::getAccess($user, $post_type, 'approve');
@endphp

@if($post_type == 'contents')
    <script src="https://www.timesworld.com/vendor/js-sort/jquery.tablednd.js"></script>
@endif

<div class="content-header">
    <div class="container-fluid">
        <div class="row my-2">
            <div class="col-sm-12">
                <h1 class="m-0 text-dark"><small class="fa fa-list"></small> All
                    {{config('content_type.'.$post_type)->plural}} @if ($service_id) - {{ $service->title }} @endif
                    @if($can_create)
                    <a href="{{route('posts.create',['post_type'=>$post_type, 'service_id' => $service_id])}}"
                        class="btn btn-default"><i class="fa fa-plus"></i> Add New</a>
                    @endif
                </h1>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        @include('layouts.common.messages')
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <form name="forms" action="" method="get" enctype="multipart/form-data">
                            <input type="hidden" name="post_type" value="{{$post_type}}" />
                            <input type="hidden" name="service_id" value="{{Request::input('service_id')}}" />
                            <div class="row">
                                <div class="col-sm-7">
                                </div>
                                <div class="col-sm-2">
                                    <div class="input-group input-group-sm">
                                        <select name="status" id="filter2" class="form-control pull-right">
                                            <option @if(request()->input('status') == 'all' ) selected="selected" @endif value="all">-- All Status --</option>
                                            <option value="Y" @if(request()->input('status') == 'Y' ) selected="selected" @endif>Active</option>
                                            <option value="N" @if(request()->input('status') =='N' ) selected="selected" @endif>InActive</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-tools">
                                        <div class="input-group input-group-sm">
                                            <input type="text" name="s" value="{{Request::input('s')}}"
                                                class="form-control float-right" placeholder="Search">

                                            <div class="input-group-append">
                                                <button type="submit" class="btn btn-default">
                                                    <i class="fas fa-search"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="card-body table-responsive p-0">

                        <table class="table table-hover" id="table-sort">
                            <thead>
                                <tr>
                                    <th width="3%">#.</th>
                                    @if($post_type == 'contents')
                                        <th width="5%">Order</th>
                                    @endif
                                    @if($can_any_action)
                                        <th width="12%">Action</th>
                                    @endif
                                    <th width="43%">Name</th>
                                    <th width="25%">Published on</th>
                                </tr>
                            </thead>
                            <tbody>
                            @forelse ($results as $i=>$result)
                                @include('cpanel.posts.inc.tr', ['result' => $result, 'i' => $i])
                                @if ($result->pages->count() > 0)
                                    @foreach ($result->pages as $page)
                                        @php
                                            $page->title = '---'.$page->title;
                                        @endphp
                                        @include('cpanel.posts.inc.tr', ['result' => $page, 'i' => $i])
                                        @if ($page->pages->count() > 0)
                                            @foreach ($page->pages as $child)
                                                @php
                                                    $child->title = '---'.$child->title;
                                                @endphp
                                                @include('cpanel.posts.inc.tr', ['result' => $child, 'i' => $i])
                                            @endforeach
                                        @endif
                                    @endforeach
                                @endif
                            @empty
                                <tr>
                                    <td colspan="4">
                                        No records found!
                                    </td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>
                    <div class="col-sm-2 mt-2">
                        <button type="button" name="update_order" id="update_order" class="btn btn-danger pull-right">Update Order</button>
                    </div>

                    <div class="card-footer clearfix">
                        @if($results->total() > 0 )
                            <div class="row">
                                <div class="col-md-1">
                                    {{ Form::select('limit', ['5'=>5,'10'=>10,'25'=>25,'50'=>50,'100'=>100],
                                    app('request')->input('limit')?app('request')->input('limit'):$filter['limit'], array(
                                    'class' => 'form-control input-sm page-limit',
                                    'id' => 'page_limit'
                                    )) }}
                                </div>
                                <div class="col-md-11">
                                    <div class="d-flex justify-content-end">

                                        <span class="mr-3">Showing {{(($results->currentPage()-1) * $results->perPage())+1}}
                                            to
                                            {{((($results->currentPage()-1)* $results->perPage()) ==0 ) ?
                                                    $results->perPage() :
                                                    ($results->currentPage()) * $results->perPage()}}
                                            of {{$results->total()}} entries </span>

                                        {{ $results->appends(request()->except('page'))->links('pagination::bootstrap-4') }}
                                    </div>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@if($post_type == 'contents')
    <script>
        $(document).ready(function() {
            $('#table-sort').tableDnD({
                onDragStart: function (table, row) {
                    $(row).closest('tr').addClass('bg-dark text-white border shadow');
                },
                onDragStop: function (table, row) {
                    $(row).closest('tr').removeClass('bg-dark text-white border shadow');
                },
                dragHandle: ".sort-handler"
            });
        });
    </script>
@endif

<script>
   $(document).ready(function(e) {
    $('.check_all').click(function(e) {
        if($(this).is(':checked') == true){
			$('.bulk').prop('checked',true);
		}
		else{
			$('.bulk').prop('checked',false);
		}
    });

    $('#bulkactionConfirm').click(function() {
		if ($('#bulkaction').val() == '') {
			alert('Please select any action.!');
		}
		else if ($('#bulkaction').val() == 'trash') {
			if ($('.bulk:checked').length > 0 ) {
				if(confirm("Are you sure to trash selected product(s)?")){
                    $('#postsFrm').attr('action',"{!!asset('posts/destroy')!!}").submit();
				}
			}
			else{
				alert('Please select at least one record.!');
				return false;
			}
		} else if($('#bulkaction').val() == 'restore') {
			if($('.bulk:checked').length > 0 ){
				if(confirm("Are you sure to restore selected product(s)?")){
                    $('#postsFrm').attr('action',"{!!asset('posts/restore')!!}").submit();
				}
			}
			else{
				alert('Please select at least one record.!');
				return false;
			}
		} else if ($('#bulkaction').val() == 'delete') {
			if($('.bulk:checked').length > 0 ){
				if(confirm("Are you sure to delete permanently selected product(s)?")){
                    $('#postsFrm').attr('action',"{!!asset('posts/delete')!!}").submit();
				}
			}
			else{
				alert('Please select at least one record.!');
				return false;
			}
		}
	});


    $('#update_order').click(function(){
        if($('#table-sort tr.data').length > 0) {
            var ids = []; var statusType="posts";
            $('#table-sort tr.data').each(function(){
               ids.push(parseInt($(this).attr('id')))
            })
            if(ids.length > 0 ){
               $.ajax({
                    url: "{{url('d-admin/ajax/changeOrder')}}",
                    method: 'POST',
                    dataType: 'json',
                    data:{ action: 'sort_order',ids:ids, statusType: statusType },
                    error: function(){
                        alert('Internal server error.!!');
                        location.reload();
                    },
                    success: function (data) {

                        if(data.status == 'success'){
                           alert('Order has been updated');
                           location.reload(true);
                        }
                        else{
                                alert(data.message);
                                location.reload();
                        }
                    }
               });
            }
        }
    });
 });

</script>
@endsection
