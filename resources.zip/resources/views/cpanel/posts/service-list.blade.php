@extends('layouts.cpanel')

@section('content')
@php

$user=Auth::user();
$can_any_action=\App\Http\Helpers::getAccess($user, $post_type, 'update,delete');

$can_create=\App\Http\Helpers::getAccess($user, $post_type, 'create');
$can_update=\App\Http\Helpers::getAccess($user, $post_type, 'update');
$can_delete=\App\Http\Helpers::getAccess($user, $post_type, 'delete');
$can_approve=\App\Http\Helpers::getAccess($user, $post_type, 'approve');

@endphp

@if($post_type == 'contents')
<script src="https://www.timesworld.com/vendor/js-sort/jquery.tablednd.js"></script>
@endif

<div class="content-header">
    <div class="container-fluid">
        <div class="row my-2">
            <div class="col-sm-12">
                <h1 class="m-0 text-dark"><small class="fa fa-list"></small> All
                    {{config('content_type.'.$post_type)->plural}} @if ($service_id) - {{ $service->title }} @endif
                    @if($can_create)
                    <a href="{{route('posts.create',['post_type'=>$post_type, 'service_id' => $service_id])}}"
                        class="btn btn-default"><i class="fa fa-plus"></i> Add New</a>
                    @endif
                </h1>
            </div>
            <!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        @include('layouts.common.messages')
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <form name="forms" action="" method="get" enctype="multipart/form-data">
                            <input type="hidden" name="post_type" value="{{$post_type}}" />
                            <input type="hidden" name="service_id" value="{{Request::input('service_id')}}" />
                            <div class="row">
                                <div class="col-sm-9">
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-tools">
                                        <div class="input-group input-group-sm">
                                            <input type="text" name="s" value="{{Request::input('s')}}"
                                                class="form-control float-right" placeholder="Search">

                                            <div class="input-group-append">
                                                <button type="submit" class="btn btn-default">
                                                    <i class="fas fa-search"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">

                        <table class="table table-hover" id="table-sort">
                            <thead>
                                <tr>
                                    <th width="3%">#.</th>
                                    @if($post_type == 'contents')
                                    <th width="5%">Order</i></th>
                                    @endif
                                    @if($can_any_action)
                                    <th width="12%">Action</th>
                                    @endif
                                    <th width="43%">Name</th>
                                    <th width="25%">Published on</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($results as $i=>$result)
                                @php
                                $result->meta = $result->meta();
                                @endphp
                                <tr>
                                    <td>{{($limit = $filter['limit'] ?? 0)*(($page = app('request')->input('page') ?? 1)
                                        - 1 )+$loop->iteration}}</td>
                                    @if($post_type == 'contents')
                                    <td class="sort-handler text-gray" style="cursor: move;" width="5%"><i
                                            class="fa fa-arrows-alt"></i></td>
                                    <input type="hidden" class="ids_list" value="{{ $result->id }}">
                                    @endif
                                    @if($can_any_action)
                                    <td>
                                        <ul class="list-inline m-0">
                                            @if($can_update)
                                            <li class="list-inline-item"><a
                                                    href="{{ route('posts.edit',['id'=>$result->id,
                                                    's'=>Request::input('s'),'limit'=>Request::input('limit'),'page'=>Request::input(" page")])
                                                    }}" data-toggle="tooltip" title="Edit" class="text-primary"><i
                                                        class="far fa-edit"></i></a></li>
                                            @endif
                                            @if($can_delete)
                                            @if((isset($result->id) && config('settings._front_page_id') != $result->id
                                            && $result->id != 1 )|| empty($result->id) )
                                            <li class="list-inline-item"><a
                                                    onclick="return confirm('Are you sure you want to delete this menu item?')"
                                                    href="{{route('posts.delete',['id'=>$result->id,'post_type'=>Request::input('post_type'),
                                                    'service_id' => $service_id])}}" data-toggle="tooltip"
                                                    title="Delete" class="text-danger"><i
                                                        class="far fa-trash-alt"></i></a></li>
                                            @endif
                                            @endif
                                            @if((($can_update && $post_type != 'contents') || $can_approve) &&
                                            $result->id != 1)
                                            <li class="list-inline-item">
                                                <div class="custom-control custom-switch custom-switch-off-danger custom-switch-on-success"
                                                    data-toggle="tooltip" title="Status">
                                                    <input type="checkbox" class="custom-control-input changeStatus"
                                                        data-id="{{$result->id}}" data-status-type="posts"
                                                        data-status="{{$result->status}}" {{ $result->status=='Y' ?
                                                    'checked' : '' }} id="customSwitch_{{$loop->iteration }}">
                                                    <label class="custom-control-label"
                                                        for="customSwitch_{{$loop->iteration}}"></label>
                                                </div>
                                            </li>
                                            @endif
                                        </ul>
                                    </td>
                                    @endif
                                    <td>
                                        @if($can_update)
                                        <a href="{{ route('posts.edit',['id'=>$result->id,
                                            's'=>Request::input('s'),'limit'=>Request::input('limit'),'page'=>Request::input('page')]) }}"
                                            class="text-dark">{{ $result->title }}</a>
                                        @else
                                        {{ $result->title }}
                                        @endif

                                        @if(isset($result->meta->use_external_url) && $result->meta->use_external_url ==
                                        'Y')
                                        <a href="{{$result->meta->external_url ?? ''}}" target="_blank"><i
                                                class="ml-3 text-primary fa fa-external-link-alt"
                                                title="External link"></i></a>
                                        @endif
                                        <br /><span class="small text-muted">{{isset($result->parent->title)? 'Parent:
                                            '.$result->parent->title:''}}{{isset($result->parent->service_title)?
                                            '('.$result->parent->service_title.')':''}}</span>
                                        @if($result->status == 'D')
                                        <span class="badge badge-secondary">Draft</span>
                                        @elseif($result->status == 'N')
                                        <span class="badge badge-warning">Inactive</span>
                                        @endif

                                    </td>
                                    <td>{{ date("d M, Y h:i A", strtotime($result->created_at)) }}<br />
                                        <span class="small text-muted">
                                            {{isset($result->createdby->name)? 'Created by:
                                            '.$result->createdby->name:''}}&nbsp;
                                            {{isset($result->createdby->lastname)?$result->createdby->lastname:''}}</span>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="4">
                                        No records found!
                                    </td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    @if($post_type == 'contents')
                    <script>
                        $(document).ready(function(){
                    $('#table-sort').tableDnD({
                        onDragStart: function(table, row) {
                            $(row).closest('tr').addClass('bg-dark text-white border shadow');
                        },
                        onDragStop: function(table, row) {
                            $(row).closest('tr').removeClass('bg-dark text-white border shadow');
                        },
                        dragHandle: ".sort-handler"
                    });

                    $('#update_order').on('click', function(){
                        if($('#table-sort .ids_list').length > 0){
                            var ids = [];
                            $('#table-sort .ids_list').each(function(){
                                ids.push(parseInt($(this).val()));
                            })
                            if(ids.length > 0 ){
                                    $.ajax({
                                        url: "{{ route('posts.ajax.post') }}",
                                        method: 'POST',
                                        dataType: 'json',
                                        data:{ action: 'sort_order',ids:ids },
                                        beforeSend: function(){
                                            $('#update_order').attr('disabled',true).html('Updating <i class="fa fa-spinner fa-spin ml-1"></i>');
                                        },
                                        complete: function(){
                                            $('#update_order').attr('disabled',false).html('Update Order');
                                        },
                                        error: function(){
                                            alert('Internal server error.!!');
                                            location.reload();
                                        },
                                        success: function (data) {

                                            if(data.status == 'success'){
                                                alert('Order has been updated');
                                            }
                                            else{
                                                    alert(data.message);
                                                    location.reload();
                                            }

                                        }

                                    });
                                }
                            }

                    });
                });

                    </script>
                    @endif

                    <div class="card-footer clearfix">
                        @if($results->total() > 0 )
                        <div class="row">
                            <div class="col-md-1">
                                {{ Form::select('limit', ['5'=>5,'10'=>10,'25'=>25,'50'=>50,'100'=>100],
                                app('request')->input('limit')?app('request')->input('limit'):$filter['limit'], array(
                                'class' => 'form-control input-sm page-limit',
                                'id' => 'page_limit'
                                )) }}
                            </div>
                            <div class="col-md-11">
                                <div class="d-flex justify-content-end">

                                    <span class="mr-3">Showing {{(($results->currentPage()-1)*$results->perPage())+1}}
                                        to
                                        {{((($results->currentPage()-1)*$results->perPage())==0)?$results->perPage():($results->currentPage())*$results->perPage()}}
                                        of {{$results->total()}} entries </span>

                                    {{ $results->appends(request()->except('page'))->links('pagination::bootstrap-4') }}
                                </div>
                            </div>

                        </div>
                        @endif
                        @if ($post_type == 'contents')
                        <div class="row mt-2">
                            <div class="col-sm-12 text-left">
                                <button class="btn btn-primary" id="update_order">
                                    Update Order
                                </button>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
                <!-- /.card -->
            </div>

        </div>
        <!-- /.row -->
    </div><!-- /.container-fluid -->
</section>
<!-- /.content -->


<script>
    //****** Common click funtion ***//
   $(document).ready(function(e) {

    $('.check_all').click(function(e) {
        if($(this).is(':checked') == true){
			$('.bulk').prop('checked',true);
		}
		else{
			$('.bulk').prop('checked',false);
		}
    });

    /**** Bulk action ****/
    $('#bulkactionConfirm').click(function(){
		if($('#bulkaction').val() == ''){
			alert('Please select any action.!');
		}
		else if($('#bulkaction').val() == 'trash'){
			if($('.bulk:checked').length > 0 ){
				if(confirm("Are you sure to trash selected product(s)?")){
                                   $('#postsFrm').attr('action',"{!!asset('posts/destroy')!!}").submit();
				}
			}
			else{
				alert('Please select at least one record.!');
				return false;
			}
		}
                else if($('#bulkaction').val() == 'restore'){
			if($('.bulk:checked').length > 0 ){
				if(confirm("Are you sure to restore selected product(s)?")){
                                   $('#postsFrm').attr('action',"{!!asset('posts/restore')!!}").submit();
				}
			}
			else{
				alert('Please select at least one record.!');
				return false;
			}
		}
                else if($('#bulkaction').val() == 'delete'){
			if($('.bulk:checked').length > 0 ){
				if(confirm("Are you sure to delete permanently selected product(s)?")){
                                   $('#postsFrm').attr('action',"{!!asset('posts/delete')!!}").submit();
				}
			}
			else{
				alert('Please select at least one record.!');
				return false;
			}
		}


	});
 });
</script>
@endsection