@extends('layouts.cpanel')

@section('content')
@php
$user=Auth::user();
$can_any_action=\App\Http\Helpers::getAccess($user, $post_type, 'update,delete');
$can_create=\App\Http\Helpers::getAccess($user, $post_type, 'create');
$can_update=\App\Http\Helpers::getAccess($user, $post_type, 'update');
$can_delete=\App\Http\Helpers::getAccess($user, $post_type, 'delete');
@endphp
<div class="content-header">
    <div class="container-fluid">
        <div class="row my-2">
            <div class="col-sm-12">
                <h1 class="m-0 text-dark">Edit {{config('content_type.'.$post_type)->edit}}
                    @if ($service_id)/{{$service->title }}@endif
                    <a href="{{route('posts.create',[
                                'post_type'=>$post_type,
                                 'service_id' => $service_id])}}"

                        class="btn btn-default"><i class="fa fa-plus"></i> Add new</a>
                    <a href="{{ route('posts.list',['post_type'=>$post_type,
                        'service_id' => $service_id,
                        's' => Request::input('s'),
                        'limit' => Request::input('limit'),
                        'events'=>Request::input('events'),
                        'page'=>Request::input('page')]) }}"
                        class="btn btn-secondary float-right">
                        <i class="fas fa-angle-left"></i> Back to
                        Listing</a>
                </h1>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        @include('layouts.common.messages')
        <form method="post" autocomplete="off" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="id" id="post_id"
                   value="{{ isset($post->id)?$post->id:'' }}" />
            <input type="hidden" name="post_type" id="post_type"
                   value="{{ $post_type }}" />
            <input type="hidden" name="service_id" id="service_id"
                   value="{{ $service_id }}" />
            <div class="row">
                <div class="col-md-9">
                    <div class="card card-primary">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="title">Title
                                            <span class="text-danger">*</span></label>
                                        <input id="title" type="text"
                                               class="form-control post-title" name="title"
                                            value="{{ isset($post->title) ?
                                                        $post->title :
                                                        old('title')}}"
                                               required
                                            placeholder="Enter Title">
                                    </div>
                                </div>
                                @if(config('content_type.'.$post_type)->pagebuilder == true)
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Content type</label>
                                        <div class="row row-cols-2
                                         row-cols-sm-4 row-cols-md-5 row-cols-lg-6">
                                            @if ($post_type == 'contents')
                                                <div class="col my-2">
                                                    <input type="radio"
                                                           id="radioMediaType1_title_posts_create"
                                                        class="btn-check" name="content_type" value="title"
                                                        autocomplete="off" required />
                                                    <label class="btn btn-sm border w-100"
                                                        for="radioMediaType1_title_posts_create">
                                                        <img src="{{asset('cpanel/img/fancy_heading.png')}}"
                                                             alt="" /><br />
                                                        Heading
                                                    </label>
                                                </div>
                                            @endif
                                            <div class="col my-2">
                                                <input type="radio" id="radioMediaType2_title_posts_create"
                                                    class="btn-check" name="content_type" value="normal"
                                                    autocomplete="off" required />
                                                <label class="btn btn-sm border w-100"
                                                    for="radioMediaType2_title_posts_create">
                                                    <img src="{{asset('cpanel/img/promo_box.png')}}"
                                                         alt="" /><br />
                                                    Promo Box
                                                </label>
                                            </div>
                                            <div class="col my-2">
                                                <input type="radio" id="radioMediaType3_title_posts_create"
                                                    class="btn-check" name="content_type" value="builder"
                                                    autocomplete="off" required />
                                                <label class="btn btn-sm border w-100"
                                                    for="radioMediaType3_title_posts_create">
                                                    <img src="{{asset('cpanel/img/article_box.png')}}"
                                                         alt="" /><br />
                                                    Story Box
                                                </label>
                                            </div>
                                            @if ($post_type == 'contents')
                                            <div class="col my-2">
                                                <input type="radio" id="radioMediaType4_title_posts_create"
                                                    class="btn-check" name="content_type" value="tabs"
                                                    autocomplete="off" required />
                                                <label class="btn btn-sm border w-100"
                                                    for="radioMediaType4_title_posts_create">
                                                    <img src="{{asset('cpanel/img/tabs.png')}}"
                                                         alt="" /><br />
                                                    Tabs
                                                </label>
                                            </div>
                                            <div class="col my-2">
                                                <input type="radio" id="radioMediaType5_title_posts_create"
                                                    class="btn-check" name="content_type" value="accordion"
                                                    autocomplete="off" required />
                                                <label class="btn btn-sm border w-100"
                                                    for="radioMediaType5_title_posts_create">
                                                    <img src="{{asset('cpanel/img/accordion.png')}}"
                                                         alt="" /><br />
                                                    Accordion
                                                </label>
                                            </div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                @endif
                                @if($can_update)
                                    <div class="form-group col-sm-12">
                                        <button type="submit" class="btn btn-primary float-right"><i
                                                class="fas fa-arrow-right"></i> Next</button>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>
@endsection
