@if(isset($items))
@foreach($items as $item)
@if(isset($item['filename']) && file_exists('temp/'.$item['filename']))
<li class="upload-thumb"> 
    <a href="javascript:void(0);" class="remove-upload red"><i class="fa fa-trash" aria-hidden="true"></i></a>
    <a href="{{URL::asset('temp/'.$item['filename'])}}" target="_blank"><img src="{{URL::asset('temp/'.$item['filename'])}}" width="90" ></a>
    <input type="hidden" name="photos[]" value="{{$item['filename']}}" />
</li>
@endif   
@endforeach
@endif