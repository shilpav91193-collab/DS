@if(isset($result->id) && false)
<div class="mx-2" x-data="app()">
    <h4 class="mt-5 mb-2 text-dark">Contacts List <button @click.prevent="addContact()" type="button"
            class="btn btn-default">Add New</button></h4>
    <template x-if="!contacts.length">
        <div class="mt-2 mb-4">No Contact List!</div>
    </template>
    <template x-if="contacts.length">
        <input type="hidden" name="contacts_list" :value="JSON.stringify(contacts)">
    </template>
    <div id="contact_blocks_area">
        <template x-for="(contact, i) in contacts">
            <div class="mb-4 card card-warning card-outline card-outline-tabs">
                <div class="card-body">
                    <div class="row">
                        <div :data-sort-order-index="i" class="form-group col-sm-6">
                            <label :for="'title'+i">Title <span class="text-danger">*</span></label>
                            <input @input="contact.title = $event.target.value" :id="'title'+i" type="text"
                                class="form-control title" :name="'title'+i" :value="contact.title" required
                                placeholder="Enter Name">
                        </div>

                        <!-- description -->
                        <div class="form-group col-sm-6">
                            <label :for="'description'+i">Description</label>
                            <textarea @input="contact.description = $event.target.value" :id="'description'+i"
                                class="form-control description" :name="'description'+i" :value="contact.description"
                                placeholder="Enter Description"></textarea>
                        </div>

                        <div class="form-group col-sm-6">
                            <label :for="'email'+i">Email</label>
                            <input @input="contact.email = $event.target.value" :id="'email'+i" type="email"
                                class="form-control email" :name="'email'+i" :value="contact.email"
                                placeholder="Enter Email">
                        </div>

                        <div class="form-group col-sm-6">
                            <label :for="'phone'+i">Phone</label>
                            <input @input="contact.phone = $event.target.value" :id="'phone'+i" type="number"
                                class="form-control phone" :name="'phone'+i" :value="contact.phone"
                                placeholder="Enter Phone">
                        </div>

                        <div class="form-group col-sm-12">
                            <label for="">
                                Icon
                            </label>
                            <div class="imageArea">
                                <template x-if="contact.image">
                                    <div>
                                        <img :src="contact.image" alt="" width="100"
                                            class="border bg-primary border-primary" />
                                        <br />
                                        <template x-if="!contact.loading">
                                            <a @click.prevent="deleteImage(i, $event.target)" href="javascript:"
                                                :id="'deleteImage'+i" class="mg0_10 pull-left" :data-id="contact.id"
                                                title="Click to delete"><i class="fa fa-trash"></i> Remove Image</a>
                                        </template>
                                        <template x-if="contact.loading">
                                            <i class="fa fa-spinner fa-pulse"></i> Please wait..
                                        </template>
                                    </div>
                                </template>
                                <template x-if="!contact.loading && !contact.image">
                                    <input @change="checkImage($event)"
                                        accept="image/jpg,image/jpeg,image/gif,image/png" :id="'image'+i" type="file"
                                        :name="'image'+i" class="custom-file-input1" style="width: 100%;" />
                                </template>

                            </div>
                        </div>

                        <div class="form-group col-sm-12">
                            <button type="button" @click.prevent="deleteContact(i)" class="btn btn-secondary"><i
                                    class="fa fa-trash"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </template>
    </div>
</div>

<script>
    $(document).ready(function(){
                    $( "#contact_blocks_area" ).sortable({
                        items: "#contact_blocks_area > div",
                        cursor: 'move',
                        revert: true,
                    });
                });
                function app() {
                    return {
                        @php
                            $contacts_list = json_decode(old('contacts_list'));
                            if (isset($contacts_list)) {
                                foreach ($contacts_list as $key => $contact) {
                                    if(old('image'.$key) !=  null && file_exist('temp/'.old('image'.$key))){
                                        $contact->image = asset('temp/' . old('image'.$key));
                                    }
                                }
                            } else {
                                $contacts_list = $result->contactBlocks ?? [];
                                foreach ($contacts_list as $key => $contact) {
                                    if(isset($contact->image) && $contact->image != '' && Storage::disk('public')->exists('contents/contacts/'.$contact->image)){
                                        $contact->image = asset('storage/contents/contacts/' . $contact->image);
                                    }
                                }
                            }
                        @endphp
                        init() {
                            var self = this;
                            $(document).ready(function(){
                                $( "#contact_blocks_area" ).sortable({
                                    items: "#contact_blocks_area > div",
                                    cursor: 'move',
                                    revert: true,
                                    update() {
                                        var index;
                                        $( "#contact_blocks_area" ).each(function(i, obj) {
                                            index = $(this).data('sort-order-index');
                                            self.contacts[index].sort_order = i;
                                        });
                                        self.contacts = contacts.sort(function(a, b) {
                                            return a.sort_order - b.sort_order;
                                        });
                                    }
                                });
                            });

                            this.$watch('contacts', (contacts) => {
                                $( "#contact_blocks_area" ).sortable('refresh');
                            });
                        },
                        contacts: {!! old('contacts_list') ?? json_encode($contacts_list) !!},
                        addContact() {
                            // check if all title fields in the contacts are not blank
                            let all_titles_not_blank = true;
                            this.contacts.forEach(contact => {
                                if (contact.title == '' || !contact.title || (!isNaN(contact.title) && contact.title.trim() == '')) {
                                    all_titles_not_blank = false;
                                }
                            });
                            // return alert if blank
                            if (!all_titles_not_blank) {
                                return alert('Please fill all the title fields');
                            }
                            this.contacts.push({
                                title: '',
                                description: '',
                                email: '',
                                phone: '',
                                service_id: {{ $result->id }},
                            });
                            this.$nextTick(() => {
                                document.querySelector("#contact_blocks_area").scrollIntoView({
                                    behavior: "smooth",
                                    block: "end"
                                });
                            });
                        },
                        deleteContact(index) {
                            this.contacts.splice(index, 1);
                        },
                        checkImage(e) {
                            let file = e.target.files[0];
                            let reader = new FileReader();
                            reader.onload = (ev) => {
                                // show error if is too large or not file type of jpg, png or gif
                                if (file.size > 2000000 || file.type != 'image/jpeg' && file.type != 'image/png' && file.type != 'image/gif' && file.type != 'image/jpg') {
                                    alert('File is larger than 2 MB or not a valid image of JPG, PNG or GIF');
                                    e.target.value = '';
                                    return;
                                }
                            };
                            reader.readAsDataURL(file);
                        },
                        deleteImage(index, $this) {
                            var id = $this.getAttribute('data-id');
                            var contact = this.contacts[index];
                            if(confirm("Are you sure to remove this image?")){
                                contact.loading = true;
                                $.getJSON('{{ url('d-admin/posts/ajax') }}',{id : id, action: 'remove_image_contact' },function(data){
                                    contact.loading = false;
                                    if(data.status == 'success'){
                                        contact.image = false;
                                    }
                                });
                            }
                        }
                    };
                }
</script>
@endif
