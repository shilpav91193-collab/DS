@php
    $result->meta = $result->meta();
@endphp
<tr class="data" id="{{$result->id}}">

    <td>{{($limit = $filter['limit'] ?? 0)*(($page = app('request')->input('page') ?? 1)
        - 1 )+$loop->iteration}}</td>
    @if($post_type == 'contents')
        <td class="sort-handler text-gray" style="cursor: move;" width="5%"><i class="fa fa-arrows-alt"></i></td>
        <input type="hidden" class="ids_list" value="{{ $result->id }}">
    @endif
    <?php $slugArray= preg_split("/[,]/",config('settings._not_editable_post_slug'));?>

    @if($can_any_action)
        <td>
            <ul class="list-inline m-0">
                @if($can_update)
                    <li class="list-inline-item sorting_1 dragHandle"><a href="javascript:" title="Drag to change order" class="gray"><i
                                class="fa fa-ellipsis-v"></i>&nbsp;<i class="fa fa-ellipsis-v"></i></a></li>


                    <li class="list-inline-item"><a
                            href="{{ route('posts.edit',['id'=>$result->id,
                                                    's'=>Request::input('s'),'limit'=>Request::input('limit'),'page'=>Request::input(" page")])
                    }}" data-toggle="tooltip" title="Edit" class="text-primary"><i class="far fa-edit"></i></a></li>
                @endif
                @if($can_delete && !in_array($result->slug,$slugArray))
                    <li class="list-inline-item"><a onclick="return confirm('Are you sure you want to delete this menu item?')"
                                                    href="{{route('posts.delete',['id'=>$result->id,'post_type'=>Request::input('post_type'),
                                                        'service_id' => $service_id])}}" data-toggle="tooltip"
                                                    title="Delete" class="text-danger"><i class="far fa-trash-alt"></i></a></li>
                @endif
                @if(($can_update && $post_type != 'contents') || $can_approve)
                    <li class="list-inline-item">
                        <div class="custom-control custom-switch custom-switch-off-danger custom-switch-on-success"
                             data-toggle="tooltip" title="Status">
                            <input type="checkbox" class="custom-control-input changeStatus" data-id="{{$result->id}}"
                                   data-status-type="posts" data-status="{{$result->status}}" {{ $result->status=='Y' ?
                    'checked' : '' }} id="customSwitch_{{$result->id.'_'.$loop->iteration }}">
                            <label class="custom-control-label" for="customSwitch_{{$result->id.'_'.$loop->iteration }}"></label>
                        </div>
                    </li>
                @endif
            </ul>
        </td>
    @endif
    <td>
        @php
            if (request()->input('s') && !$result->parent_id) {
                $result->title =  $result->title;
            }
        @endphp
        @if($can_update)
            <a href="{{ route('posts.edit',['id'=>$result->id,
                                            's'=>Request::input('s'),'limit'=>Request::input('limit'),'page'=>Request::input('page')]) }}"
               class="text-dark">
                @if(request()->input('s') && $result->parent_id)
                    ---{!! ltrim($result->title, '---'); !!}
                @else
                    {!! $result->title !!}
                @endif</a>
        @else
            @if(request()->input('s') && $result->parent_id)
                ---{!! ltrim($result->title, '---'); !!}
                @else
                    {!! $result->title !!}
                @endif</a>
            @endif

            @if(isset($result->meta->use_external_url) && $result->meta->use_external_url ==
            'Y')
                <a href="{{$result->meta->external_url ?? ''}}" target="_blank"><i
                        class="ml-3 text-primary fa fa-external-link-alt" title="External link"></i></a>
            @endif
            @if($result->status == 'D')
                <span class="badge badge-secondary">Draft</span>
            @elseif($result->status == 'N')
                <!--<span class="badge badge-warning" id="badge{{$result->id}}">Inactive</span>-->
            @endif


    </td>
    <td>{{ date("d M, Y h:i A", strtotime($result->created_at)) }}<br />
        <span class="small text-muted">
            {{isset($result->createdby->name)? 'Created by:
            '.$result->createdby->name:''}}&nbsp;
            {{isset($result->createdby->lastname)?$result->createdby->lastname:''}}</span>
    </td>
</tr>
