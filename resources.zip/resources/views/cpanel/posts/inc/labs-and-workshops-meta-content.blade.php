<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-12">
                <div class="form-group">
                    <label :for="'footer_content'+i">Footer Text</label>
                  
                        <textarea name="meta[footer_content]" id="excerpt" class="form-control textEditor" row='6'
                                            placeholder="Enter footer text">{{ isset($post->meta->footer_content)?$post->meta->footer_content:old('meta.footer_content') }}</textarea>
                </div>
            </div>
        </div>
    </div>
</div>