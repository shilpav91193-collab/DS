<div class="card">
    <div class="card-body">
    <div class="row">
        <!-- <div class="form-group col-sm-12">
            <label for="excerpt">Employers Title</label>
            <input type="text" class="form-control" name="meta[student_placement_emplyer_title]" placeholder="Enter accreditation title" value="{{ isset($post->meta->student_placement_emplyer_title)?$post->meta->student_placement_emplyer_title:old('meta.student_placement_emplyer_title') }}">               
        </div>             -->
        <div class="col-sm-12">
            <label for="title">Employers</label>

            <select name="meta[student_placement_emplyer][]" id="student_placement_emplyer" multiple class="form-control select2">
                <option value="">Select Employers</option>
                @foreach($employers as $emp)
                <option value="{{$emp->id}}" {{ isset($post->meta->student_placement_emplyer) && in_array($emp->id,
                    json_decode($post->meta->student_placement_emplyer ?? [])) ? 'selected' : '' }}>
                    {{$emp->title}}</option>
                @endforeach
            </select>
        </div>
        </div>
    </div>
</div>