    <div class="form-group">
        
        <div class="col-md-12">
            @php
            $old_faq_subject = isset($post->meta->_faq_subjects)?$post->meta->_faq_subjects:old('meta._faq_subjects');
            $_faq_subjects = explode(',', config('settings._faq_subjects'));
            @endphp
            <label id="faq_subject">Subject</label>
            <select class="form-control select2" name="meta[_faq_subjects]" id="faq_subject"  autocomplete='off'>
                <option value="">Select subject</option>
                @foreach($_faq_subjects as $subject)
                <option value="{{$subject}}" @if($old_faq_subject == trim($subject)) selected @endif >{{$subject}}</option>
                @endforeach      
            </select>
        </div>
    </div>