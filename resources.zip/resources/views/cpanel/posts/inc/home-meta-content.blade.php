<div class="card">
    <div class="card-header row d-flex justify-content-between">
        <div class="col-6">
            <h3 class="card-title">Diversified Sector Section</h3>
        </div>
        <div class="col-6 text-end">
            <div id="sector-active-status-switch" class="
                @if(isset($post->meta->home_sector_active_status) &&
                $post->meta->home_sector_active_status =='Y') custom-control custom-switch
                custom-switch-on-success @else custom-control custom-switch custom-switch-off-danger
                  @endif">
                <input name="meta[home_sector_active_status]"
                       @if(isset($post->meta->home_sector_active_status) && $post->meta->home_sector_active_status =='Y') checked @endif
                       @if(isset($post->meta->home_sector_active_status) && $post->meta->home_sector_active_status =='Y') value="Y" @else value="N" @endif
                       type="checkbox" id="home_sector_active_status" class="custom-control-input changeActiveStatus">
                <label class="custom-control-label" for="home_sector_active_status"  data-toggle="tooltip" title="Status"></label>
            </div>
        </div>

    </div>
    <div class="card-body">
        <div class="row">
            <div class="form-group col-sm-6">
                <label for="excerpt">Title</label>
                <input type="text" class="form-control"
                       name="meta[home_diversified_sector_title]"
                       placeholder="Enter title"
                       value="{{ isset($post->meta->home_diversified_sector_title) ?
                        $post->meta->home_diversified_sector_title :
                         old('meta.home_diversified_sector_title') }}">
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <label for="title">Sectors</label>
                <select name="meta[home_diversified_sectors][]"
                        multiple class="form-control select2">
                    @foreach($sectors as $sector)
                        <option value="{{$sector->id}}" {{ isset($post->meta->home_diversified_sectors) && in_array($sector->id,
                        json_decode($post->meta->home_diversified_sectors ?? [])) ? 'selected' : '' }}>
                            {{$sector->title}}</option>
                    @endforeach
                </select>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header row d-flex justify-content-between">
        <div class="col-6">
            <h3 class="card-title">Who We Are Section</h3>
        </div>
        <div class="col-6 text-end">
            <div id="who-we-active-status-switch" class="
                @if(isset($post->meta->home_who_we_active_status) &&
                $post->meta->home_who_we_active_status =='Y') custom-control custom-switch
                custom-switch-on-success @else custom-control custom-switch custom-switch-off-danger
                  @endif">
                <input name="meta[home_who_we_active_status]"
                       @if(isset($post->meta->home_who_we_active_status) && $post->meta->home_who_we_active_status =='Y') checked @endif
                       @if(isset($post->meta->home_who_we_active_status) && $post->meta->home_who_we_active_status =='Y') value="Y" @else value="N" @endif
                       type="checkbox" id="home_who_we_active_status" class="custom-control-input changeActiveStatus">
                <label class="custom-control-label" for="home_who_we_active_status"  data-toggle="tooltip" title="Status"></label>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
             <div class="form-group col-sm-6">
                <label for="excerpt">Title</label>
                <input type="text" class="form-control"
                       name="meta[home_who_we_are_title]"
                       placeholder="Enter title"
                       value="{{ isset($post->meta->home_who_we_are_title) ?
                        $post->meta->home_who_we_are_title : old('meta.home_who_we_are_title') }}">
            </div>
        </div>
        <div class="row">
            <div class="form-group col-sm-6">
                <label for="excerpt">Button Label</label>
                <input type="text" class="form-control"
                       name="meta[home_who_we_are_button_name]"
                       placeholder="Enter button name"
                       value="{{ isset($post->meta->home_who_we_are_button_name) ?
                                $post->meta->home_who_we_are_button_name :
                                 old('meta.home_who_we_are_button_name') }}">
            </div>
            <div class="form-group col-sm-6">
                <label for="excerpt">Button URL</label>
                <input type="text" class="form-control"
                       name="meta[home_who_we_are_button_url]"
                       placeholder="Enter url"
                       value="{{ isset($post->meta->home_who_we_are_button_url) ?
                            $post->meta->home_who_we_are_button_url :
                            old('meta.home_who_we_are_button_url') }}">
            </div>
            <div class="form-group col-sm-12">
                <label for="excerpt">Description</label>
                <textarea name="meta[home_who_we_are_description]"
                          class="form-control" cols="40" rows="4"
                    placeholder="Enter description">{{ isset($post->meta->home_who_we_are_description) ? $post->meta->home_who_we_are_description : old('meta.home_who_we_are_description') }}</textarea>
            </div>
        </div>

        <div class="row">
            <div class="form-group col-sm-12">

                @php
                    $images = null;
                    if ( isset($post->meta->home_who_we_are_image) || old('meta.home_who_we_are_image')) {
                        $img = $post->meta->home_who_we_are_image ?? old('meta.home_who_we_are_image');
                        $images = \App\Models\Medias::where('id', $img ?? '')->first();
                    }
                    if ($images && isset($images->file_url)) {
                        $images->file_url = \App\Http\Helpers::asset($images->file_url);
                        $images = [$images];
                    }
                @endphp
                <div class="row form-group" x-data='__images("box1image", {{ json_encode($images ?? []) }})'>
                    <div class="col-sm-12">

                        <label for="box1image">image</label>

                        <input type="hidden" name="meta[home_who_we_are_image]" :value="images.length ? images[0].id : ''">
                        <div class="border p-3 bg-gray-light d-flex flex-wrap sort-sections">
                            <template x-for="(image, i) in images">
                                <div class="p-2 position-relative" style="height:200px; width:200px;">
                                    <img loading="lazy" class="h-100 w-100 shadow-sm rounded border bg-light"
                                         style="object-fit: contain;" :src="image.file_url">
                                    <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                                        <!--- Create Trash Image button shown at hover ---->
                                        <button type="button" class="btn btn-danger btn-sm"
                                                x-on:click="removeImage(i, 'featured')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </template>

                            <div x-show="! images.length" class="p-2 d-flex justify-content-center"
                                 :class="{ 'd-flex': !images.length }" style="min-height: 100px; width: 100%;">
                                <div
                                    class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                                    <!-- Add Button !-->
                                    <label @click.prevent="openingModal('#editModal')" data-toggle="modal"
                                           data-drop="false" data-target="#editModal" type="button"
                                           class="btn btn-outline-success btn-sm">
                                        <i class="fas fa-plus"></i>
                                    </label>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header row d-flex justify-content-between">
        <div class="col-6">
            <h3 class="card-title">Counters Section</h3>
        </div>
        <div class="col-6 text-end">
            <div id="counter-active-status-switch" class="
                @if(isset($post->meta->home_counter_active_status) &&
                $post->meta->home_counter_active_status =='Y') custom-control custom-switch
                custom-switch-on-success @else custom-control custom-switch custom-switch-off-danger
                  @endif">
                <input name="meta[home_counter_active_status]"
                       @if(isset($post->meta->home_counter_active_status) && $post->meta->home_counter_active_status =='Y') checked @endif
                       @if(isset($post->meta->home_counter_active_status) && $post->meta->home_counter_active_status =='Y') value="Y" @else value="N" @endif
                       type="checkbox" id="home_counter_active_status" class="custom-control-input changeActiveStatus">
                <label class="custom-control-label" for="home_counter_active_status"  data-toggle="tooltip" title="Status"></label>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">

            <div class="form-group col-sm-6">
                <label for="excerpt">Total Assets Text</label>
                <input type="text" class="form-control"
                       name="meta[home_total_assets_key]"
                       placeholder="Enter total assets text"
                       value="{{ isset($post->meta->home_total_assets_key) ?
                        $post->meta->home_total_assets_key :
                         old('meta.home_total_assets_key') }}">
            </div>
            <div class="form-group col-sm-6">
                <label for="excerpt">Total Assets</label>
                <input type="text" class="form-control"
                       name="meta[home_total_assets]"
                       placeholder="Enter total assets"
                       value="{{ isset($post->meta->home_total_assets) ?
                        $post->meta->home_total_assets :
                         old('meta.home_total_assets') }}">
            </div>

            <div class="form-group col-sm-6">
                <label for="excerpt">Total Area Covered Text</label>
                <input type="text" class="form-control"
                       name="meta[home_total_area_covered_key]"
                       placeholder="Enter total area covered text"
                       value="{{ isset($post->meta->home_total_area_covered_key) ?
                        $post->meta->home_total_area_covered_key :
                         old('meta.home_total_area_covered_key') }}">
            </div>
            <div class="form-group col-sm-6">
                <label for="excerpt">Total Area Covered</label>
                <input type="text" class="form-control"
                       name="meta[home_total_area_covered]"
                       placeholder="Enter total area covered"
                       value="{{ isset($post->meta->home_total_area_covered) ?
                        $post->meta->home_total_area_covered :
                         old('meta.home_total_area_covered') }}">
            </div>

            <div class="form-group col-sm-6">
                <label for="excerpt">Total Airport Text</label>
                <input type="text" class="form-control"
                       name="meta[home_total_air_ports_key]"
                       placeholder="Total airport text"
                       value="{{ isset($post->meta->home_total_air_ports_key) ?
                        $post->meta->home_total_air_ports_key :
                         old('meta.home_total_air_ports_key') }}">
            </div>
            <div class="form-group col-sm-6">
                <label for="excerpt">Total Airports</label>
                <input type="text" class="form-control"
                       name="meta[home_total_air_ports]"
                       placeholder="Total Airports"
                       value="{{ isset($post->meta->home_total_air_ports) ?
                        $post->meta->home_total_air_ports :
                         old('meta.home_total_air_ports') }}">
            </div>

            <div class="form-group col-sm-6">
                <label for="excerpt">Total Subsidiaries Text</label>
                <input type="text" class="form-control"
                       name="meta[home_total_subsidiaries_key]"
                       placeholder="Enter total subsidiaries text"
                       value="{{ isset($post->meta->home_total_subsidiaries_key) ?
                        $post->meta->home_total_subsidiaries_key :
                         old('meta.home_total_subsidiaries_key') }}">
            </div>
            <div class="form-group col-sm-6">
                <label for="excerpt">Total Subsidiaries</label>
                <input type="text" class="form-control"
                       name="meta[home_total_subsidiaries]"
                       placeholder="Enter total subsidiaries"
                       value="{{ isset($post->meta->home_total_subsidiaries) ?
                        $post->meta->home_total_subsidiaries :
                         old('meta.home_total_subsidiaries') }}">
            </div>

            <div class="form-group col-sm-6">
                <label for="excerpt">Our District Text</label>
                <input type="text" class="form-control"
                       name="meta[home_total_our_dist_key]"
                       placeholder="Enter district text"
                       value="{{ isset($post->meta->home_total_our_dist_key) ?
                        $post->meta->home_total_our_dist_key :
                         old('meta.home_total_our_dist_key') }}">
            </div>
            <div class="form-group col-sm-6">
                <label for="excerpt">Our Districts</label>
                <input type="text" class="form-control"
                       name="meta[home_total_our_dist]"
                       placeholder="Enter district count"
                       value="{{ isset($post->meta->home_total_our_dist) ?
                        $post->meta->home_total_our_dist :
                         old('meta.home_total_our_dist') }}">
            </div>

            <div class="form-group col-sm-6">
                <label for="excerpt">Total Employees Text</label>
                <input type="text" class="form-control"
                       name="meta[home_total_employees_key]"
                       placeholder="Enter total employees text"
                       value="{{ isset($post->meta->home_total_employees_key) ?
                        $post->meta->home_total_employees_key :
                         old('meta.home_total_employees_key') }}">
            </div>

            <div class="form-group col-sm-6">
                <label for="excerpt">Total Employees</label>
                <input type="text" class="form-control"
                       name="meta[home_total_employees]"
                       placeholder="Enter total employees"
                       value="{{ isset($post->meta->home_total_employees) ?
                        $post->meta->home_total_employees :
                         old('meta.home_total_employees') }}">
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header row d-flex justify-content-between">
        <div class="col-6">
            <h3 class="card-title">Our Leaders Section</h3>
        </div>
        <div class="col-6 text-end">
            <div id="leaders-status-switch" class="
                @if(isset($post->meta->home_leaders_active_status) &&
                $post->meta->home_leaders_active_status =='Y') custom-control custom-switch
                custom-switch-on-success @else custom-control custom-switch custom-switch-off-danger
                  @endif">
                <input name="meta[home_leaders_active_status]"
                       @if(isset($post->meta->home_leaders_active_status) && $post->meta->home_leaders_active_status =='Y') checked @endif
                       @if(isset($post->meta->home_leaders_active_status) && $post->meta->home_leaders_active_status =='Y') value="Y" @else value="N" @endif
                       type="checkbox" id="home_leaders_active_status" class="custom-control-input changeActiveStatus">
                <label class="custom-control-label" for="home_leaders_active_status"  data-toggle="tooltip" title="Status"></label>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="form-group col-sm-6">
                <label for="excerpt">Title</label>
                <input type="text" class="form-control"
                       name="meta[home_our_leaders_title]"
                       placeholder="Enter title"
                       value="{{ isset($post->meta->home_our_leaders_title) ?
                            $post->meta->home_our_leaders_title :
                            old('meta.home_our_leaders_title') }}">
            </div>
            <div class="form-group col-sm-6">
                <label for="excerpt">Button Label</label>
                <input type="text" class="form-control"
                       name="meta[home_our_leaders_button_name]"
                       placeholder="Enter button name"
                       value="{{ isset($post->meta->home_our_leaders_button_name) ?
                                $post->meta->home_our_leaders_button_name :
                                 old('meta.home_our_leaders_button_name') }}">
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <label for="title">Leaders</label>
                <select name="meta[home_our_leaders][]"
                        multiple class="form-control select2">
                    @foreach($teamsLeaders as $leader)
                        <option value="{{$leader->id}}" {{ isset($post->meta->home_our_leaders) && in_array($leader->id,
                        json_decode($post->meta->home_our_leaders ?? [])) ? 'selected' : '' }}>
                            {{$leader->name}}</option>
                    @endforeach
                </select>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header row d-flex justify-content-between">
        <div class="col-6">
            <h3 class="card-title">Our Role Section</h3>
        </div>
        <div class="col-6 text-end">
            <div id="roles-status-switch" class="
                @if(isset($post->meta->home_roles_active_status) &&
                $post->meta->home_roles_active_status =='Y') custom-control custom-switch
                custom-switch-on-success @else custom-control custom-switch custom-switch-off-danger
                  @endif">
                <input name="meta[home_roles_active_status]"
                       @if(isset($post->meta->home_roles_active_status) && $post->meta->home_roles_active_status =='Y') checked @endif
                       @if(isset($post->meta->home_roles_active_status) && $post->meta->home_roles_active_status =='Y') value="Y" @else value="N" @endif
                       type="checkbox" id="home_roles_active_status" class="custom-control-input changeActiveStatus">
                <label class="custom-control-label" for="home_roles_active_status"  data-toggle="tooltip" title="Status"></label>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="form-group col-sm-6">
                <label for="excerpt">Title</label>
                <input type="text" class="form-control"
                       name="meta[home_our_role_title]"
                       placeholder="Enter title"
                       value="{{ isset($post->meta->home_our_role_title) ?
                        $post->meta->home_our_role_title : old('meta.home_our_role_title') }}">
            </div>
        </div>
        <div class="row">
            <div class="form-group col-sm-6">
                <label for="excerpt">Button Label</label>
                <input type="text" class="form-control"
                       name="meta[home_our_role_button_name]"
                       placeholder="Enter button name"
                       value="{{ isset($post->meta->home_our_role_button_name) ?
                                $post->meta->home_our_role_button_name :
                                 old('meta.home_our_role_button_name') }}">
            </div>
            <div class="form-group col-sm-6">
                <label for="excerpt">Button URL</label>
                <input type="text" class="form-control"
                       name="meta[home_our_role_button_url]"
                       placeholder="Enter url"
                       value="{{ isset($post->meta->home_our_role_button_url) ?
                            $post->meta->home_our_role_button_url :
                            old('meta.home_our_role_button_url') }}">
            </div>
            <div class="form-group col-sm-12">
                <label for="excerpt">Description</label>
                <textarea name="meta[home_our_role_description]"
                          class="form-control" cols="40" rows="4"
                          placeholder="Enter description">{{ isset($post->meta->home_our_role_description) ? $post->meta->home_our_role_description : old('meta.home_our_role_description') }}</textarea>
            </div>
        </div>

        <div class="row">
            <div class="form-group col-sm-12">
                @php
                    $roleImages = null;
                    if ( isset($post->meta->home_our_role_image) || old('meta.home_our_role_image')) {
                        $roleimg = $post->meta->home_our_role_image ?? old('meta.home_our_role_image');
                        $roleImages = \App\Models\Medias::where('id', $roleimg ?? '')->first();
                    }
                    if ($roleImages && isset($roleImages->file_url)) {
                        $roleImages->file_url = \App\Http\Helpers::asset($roleImages->file_url);
                        $roleImages = [$roleImages];
                    }
                @endphp
                <div class="row form-group"
                     x-data='__images("box2image", {{ json_encode($roleImages ?? []) }})'>
                    <div class="col-sm-12">

                        <label for="box2image">Image</label>

                        <input type="hidden" name="meta[home_our_role_image]"
                               :value="images.length ? images[0].id : ''">
                        <div class="border p-3 bg-gray-light d-flex flex-wrap sort-sections">
                            <template x-for="(image, i) in images">
                                <div class="p-2 position-relative" style="height:200px; width:200px;">
                                    <img loading="lazy"
                                         class="h-100 w-100 shadow-sm rounded border bg-light"
                                         style="object-fit: contain;" :src="image.file_url">
                                    <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                                        <!--- Create Trash Image button shown at hover ---->
                                        <button type="button" class="btn btn-danger btn-sm"
                                                x-on:click="removeImage(i, 'featured')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </template>

                            <div x-show="! images.length" class="p-2 d-flex justify-content-center"
                                 :class="{ 'd-flex': !images.length }"
                                 style="min-height: 100px; width: 100%;">
                                <div
                                    class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                                    <!-- Add Button !-->
                                    <label @click.prevent="openingModal('#editModal')" data-toggle="modal"
                                           data-drop="false" data-target="#editModal" type="button"
                                           class="btn btn-outline-success btn-sm">
                                        <i class="fas fa-plus"></i>
                                    </label>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header row d-flex justify-content-between">
        <div class="col-6">
            <h3 class="card-title">Groups Section</h3>
        </div>
        <div class="col-6 text-end">
            <div id="groups-status-switch" class="
                @if(isset($post->meta->home_groups_active_status) &&
                $post->meta->home_groups_active_status =='Y') custom-control custom-switch
                custom-switch-on-success @else custom-control custom-switch custom-switch-off-danger
                  @endif">
                <input name="meta[home_groups_active_status]"
                       @if(isset($post->meta->home_groups_active_status) && $post->meta->home_groups_active_status =='Y') checked @endif
                       @if(isset($post->meta->home_groups_active_status) && $post->meta->home_groups_active_status =='Y') value="Y" @else value="N" @endif
                       type="checkbox" id="home_groups_active_status" class="custom-control-input changeActiveStatus">
                <label class="custom-control-label" for="home_groups_active_status"  data-toggle="tooltip" title="Status"></label>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="form-group col-sm-6">
                <label for="excerpt">Title</label>
                <input type="text" class="form-control"
                       name="meta[home_group_title]"
                       placeholder="Enter title"
                       value="{{ isset($post->meta->home_group_title) ?
                        $post->meta->home_group_title :
                         old('meta.home_group_title') }}">
            </div>
            <div class="row">
                <div class="form-group col-sm-6">
                    <label for="excerpt">Button Label</label>
                    <input type="text" class="form-control"
                           name="meta[home_group_button_name]"
                           placeholder="Enter button name"
                           value="{{ isset($post->meta->home_group_button_name) ?
                                $post->meta->home_group_button_name :
                                 old('meta.home_group_button_name') }}">
                </div>
                <div class="form-group col-sm-6">
                    <label for="excerpt">Button URL</label>
                    <input type="text" class="form-control"
                           name="meta[home_group_button_url]"
                           placeholder="Enter url"
                           value="{{ isset($post->meta->home_group_button_url) ?
                            $post->meta->home_group_button_url :
                            old('meta.home_group_button_url') }}">
                </div>
                <div class="form-group col-sm-12">
                    <label for="excerpt">Description</label>
                    <textarea name="meta[home_group_description]"
                              class="form-control" cols="40" rows="4"
                              placeholder="Enter description">{{ isset($post->meta->home_group_description) ? $post->meta->home_group_description : old('meta.home_group_description') }}</textarea>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12">
                <label for="groups">Groups</label>
                <select id="groups" name="meta[home_groups][]"
                        multiple class="form-control select2">
                    @foreach($groups as $group)
                        <option value="{{$group->id}}" {{ isset($post->meta->home_groups) && in_array($group->id,
                        json_decode($post->meta->home_groups ?? [])) ? 'selected' : '' }}>
                            {{$group->title}}</option>
                    @endforeach
                </select>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header row d-flex justify-content-between">
        <div class="col-6">
            <h3 class="card-title">Footprint Section</h3>
        </div>
        <div class="col-6 text-end">
            <div id="footprints-status-switch" class="
                @if(isset($post->meta->home_footprints_active_status) &&
                $post->meta->home_footprints_active_status =='Y') custom-control custom-switch
                custom-switch-on-success @else custom-control custom-switch custom-switch-off-danger
                  @endif">
                <input name="meta[home_footprints_active_status]"
                       @if(isset($post->meta->home_footprints_active_status) && $post->meta->home_footprints_active_status =='Y') checked @endif
                       @if(isset($post->meta->home_footprints_active_status) && $post->meta->home_footprints_active_status =='Y') value="Y" @else value="N" @endif
                       type="checkbox" id="home_footprints_active_status" class="custom-control-input changeActiveStatus">
                <label class="custom-control-label" for="home_footprints_active_status"  data-toggle="tooltip" title="Status"></label>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="form-group col-sm-6">
                <label for="excerpt">Title</label>
                <input type="text" class="form-control"
                       name="meta[home_footprints_title]"
                       placeholder="Enter title"
                       value="{{ isset($post->meta->home_footprints_title) ?
                        $post->meta->home_footprints_title :
                         old('meta.home_footprints_title') }}">
            </div>
            <div class="row">
                <div class="form-group col-sm-6">
                    <label for="excerpt">Button Label</label>
                    <input type="text" class="form-control"
                           name="meta[home_footprints_button_name]"
                           placeholder="Enter button name"
                           value="{{ isset($post->meta->home_footprints_button_name) ?
                                $post->meta->home_footprints_button_name :
                                 old('meta.home_footprints_button_name') }}">
                </div>
                <div class="form-group col-sm-6">
                    <label for="excerpt">Button URL</label>
                    <input type="text" class="form-control"
                           name="meta[home_footprints_button_url]"
                           placeholder="Enter url"
                           value="{{ isset($post->meta->home_footprints_button_url) ?
                            $post->meta->home_footprints_button_url :
                            old('meta.home_footprints_button_url') }}">
                </div>
                <div class="form-group col-sm-12">
                    <label for="excerpt">Description</label>
                    <textarea name="meta[home_footprints_description]"
                              class="form-control" cols="40" rows="4"
                              placeholder="Enter description">{{ isset($post->meta->home_footprints_description) ? $post->meta->home_footprints_description : old('meta.home_footprints_description') }}</textarea>
                </div>
            </div>

            <div class="row">
                <div class="form-group col-sm-12">
                    @php
                        $roleImages = null;
                        if ( isset($post->meta->home_footprints_image) || old('meta.home_footprints_image')) {
                            $roleimg = $post->meta->home_footprints_image ?? old('meta.home_footprints_image');
                            $roleImages = \App\Models\Medias::where('id', $roleimg ?? '')->first();
                        }
                        if ($roleImages && isset($roleImages->file_url)) {
                            $roleImages->file_url = \App\Http\Helpers::asset($roleImages->file_url);
                            $roleImages = [$roleImages];
                        }
                    @endphp
                    <div class="row form-group"
                         x-data='__images("box2image", {{ json_encode($roleImages ?? []) }})'>
                        <div class="col-sm-12">

                            <label for="box2image">Image</label>

                            <input type="hidden" name="meta[home_footprints_image]"
                                   :value="images.length ? images[0].id : ''">
                            <div class="border p-3 bg-gray-light d-flex flex-wrap sort-sections">
                                <template x-for="(image, i) in images">
                                    <div class="p-2 position-relative" style="height:200px; width:200px;">
                                        <img loading="lazy"
                                             class="h-100 w-100 shadow-sm rounded border bg-light"
                                             style="object-fit: contain;" :src="image.file_url">
                                        <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                                            <!--- Create Trash Image button shown at hover ---->
                                            <button type="button" class="btn btn-danger btn-sm"
                                                    x-on:click="removeImage(i, 'featured')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                </template>

                                <div x-show="! images.length" class="p-2 d-flex justify-content-center"
                                     :class="{ 'd-flex': !images.length }"
                                     style="min-height: 100px; width: 100%;">
                                    <div
                                        class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                                        <!-- Add Button !-->
                                        <label @click.prevent="openingModal('#editModal')" data-toggle="modal"
                                               data-drop="false" data-target="#editModal" type="button"
                                               class="btn btn-outline-success btn-sm">
                                            <i class="fas fa-plus"></i>
                                        </label>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header row d-flex justify-content-between">
        <div class="col-6">
            <h3 class="card-title">Video Section</h3>
        </div>
        <div class="col-6 text-end">
            <div id="video-status-switch" class="
                @if(isset($post->meta->home_video_active_status) &&
                $post->meta->home_video_active_status =='Y') custom-control custom-switch
                custom-switch-on-success @else custom-control custom-switch custom-switch-off-danger
                  @endif">
                <input name="meta[home_video_active_status]"
                       @if(isset($post->meta->home_video_active_status) && $post->meta->home_video_active_status =='Y') checked @endif
                       @if(isset($post->meta->home_video_active_status) && $post->meta->home_video_active_status =='Y') value="Y" @else value="N" @endif
                       type="checkbox" id="home_video_active_status" class="custom-control-input changeActiveStatus">
                <label class="custom-control-label" for="home_video_active_status"  data-toggle="tooltip" title="Status"></label>
            </div>
        </div>
    </div>
{{--    <div class="card-body">--}}
{{--        <div class="row">--}}
{{--            <div class="form-group col-sm-6">--}}
{{--                <label for="excerpt">Title</label>--}}
{{--                <input type="text" class="form-control"--}}
{{--                       name="meta[home_group_title]"--}}
{{--                       placeholder="Enter title"--}}
{{--                       value="{{ isset($post->meta->home_group_title) ?--}}
{{--                        $post->meta->home_group_title :--}}
{{--                         old('meta.home_group_title') }}">--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </div>--}}
</div>


<div class="card">
    <div class="card-header row d-flex justify-content-between">
        <div class="col-6">
            <h3 class="card-title">News Section</h3>
        </div>
        <div class="col-6 text-end">
            <div id="news-status-switch" class="
                @if(isset($post->meta->home_news_active_status) &&
                $post->meta->home_news_active_status =='Y') custom-control custom-switch
                custom-switch-on-success @else custom-control custom-switch custom-switch-off-danger
                  @endif">
                <input name="meta[home_news_active_status]"
                       @if(isset($post->meta->home_news_active_status) && $post->meta->home_news_active_status =='Y') checked @endif
                       @if(isset($post->meta->home_news_active_status) && $post->meta->home_news_active_status =='Y') value="Y" @else value="N" @endif
                       type="checkbox" id="home_news_active_status" class="custom-control-input changeActiveStatus">
                <label class="custom-control-label" for="home_news_active_status"  data-toggle="tooltip" title="Status"></label>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
           <div class="form-group col-sm-6">
              <label for="excerpt">Title</label>
              <input type="text" class="form-control"
                     name="meta[home_news_title]"
                     placeholder="Enter title"
                     value="{{ isset($post->meta->home_news_title) ?
                        $post->meta->home_news_title :
                         old('meta.home_news_title') }}">
          </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <label for="title">News</label>
                <select name="meta[home_news][]"
                        multiple class="form-control select2">
                    @foreach($news as $newsData)
                        <option value="{{$newsData->id}}" {{ isset($post->meta->home_news) && in_array($newsData->id,
                        json_decode($post->meta->home_news ?? [])) ? 'selected' : '' }}>
                            {{$newsData->title}}</option>
                    @endforeach
                </select>
            </div>
        </div>
  </div>
</div>
