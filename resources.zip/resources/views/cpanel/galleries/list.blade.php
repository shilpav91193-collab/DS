@extends('layouts.cpanel')

@section('content')
@php

  $user=Auth::user();
  $can_any_action=\App\Http\Helpers::getAccess($user, 'galleries', 'update,delete');

  $can_create=\App\Http\Helpers::getAccess($user, 'galleries', 'create');
  $can_update=\App\Http\Helpers::getAccess($user, 'galleries', 'update');
  $can_delete=\App\Http\Helpers::getAccess($user, 'galleries', 'delete');

@endphp

    <div class="content-header">
      <div class="container-fluid">
        <div class="row my-2">
          <div class="col-sm-12">
            <h1 class="m-0 text-dark"><small class="fa fa-list"></small> All Galleries
              @if($can_create)
                <a href="{{route('galleries.create')}}" class="btn btn-default"><i class="fa fa-plus"></i> Add New</a>
              @endif
            </h1>
          </div>
          <!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        @include('layouts.common.messages')
        <div class="row">
          <div class="col-md-12">
             <div class="card">
                 <div class="card-header">
                      <div class="row">
                          <div class="col-sm-9"></div>
                            <div class="col-sm-3">
                               <div class="card-tools">
                                      <div class="input-group input-group-sm">
                                        <input type="text" name="s" value="{{Request::input('s')}}" class="form-control float-right" placeholder="Search">

                                        <div class="input-group-append">
                                          <button type="submit" class="btn btn-default">
                                            <i class="fas fa-search"></i>
                                          </button>
                                        </div>
                                      </div>
                                  </div>
                            </div>
                      </div>
                 </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">

                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th width="3%">#.</th>
                      @if($can_any_action)
                        <th width="20%">Action</th>
                      @endif
                      <th width="55%">Name</th>
                      <th width="25%">Published on</th>

                    </tr>
                  </thead>
                  <tbody>
                    @forelse ($galleries as $i=>$result)
                    <tr>
                        <td>{{($limit = $filter['limit'] ?? 0)*(($page = app('request')->input('page') ?? 1) - 1 )+$loop->iteration}}</td>
                      @if($can_any_action)
                        <td>
                          <ul class="list-inline m-0">
                            @if($can_update)
                              <li class="list-inline-item"><a href="{{ route("galleries.edit",['galleries'=>$result->id, 's'=>Request::input("s"),'limit'=>Request::input("limit"),'page'=>Request::input("page")]) }}" data-toggle="tooltip" title="Edit" class="text-primary"><i class="far fa-edit"></i></a></li>
                            @endif
                            @if($can_delete)
                                @if((isset($result->id) && config('settings._front_page_id') != $result->id )|| empty($result->id) )
                              <li class="list-inline-item"><a onclick="return confirm('Are you sure you want to delete this menu item?')" href="{{route("galleries.delete",['galleries'=>$result->id])}}" data-toggle="tooltip" title="Delete" class="text-danger"><i class="far fa-trash-alt"></i></a></li>
                                @endif
                            @endif
                            @if($can_update)
                              <li class="list-inline-item">
                                    <div class="custom-control custom-switch custom-switch-off-danger custom-switch-on-success" data-toggle="tooltip" title="Status">
                                        <input type="checkbox" class="custom-control-input changeStatus" data-id="{{$result->id}}" data-status-type="galleries" data-status="{{$result->status}}" {{ $result->status=='Y' ? 'checked' : '' }} id="customSwitch_{{$loop->iteration }}">
                                          <label class="custom-control-label" for="customSwitch_{{$loop->iteration}}"></label>
                                    </div>
                              </li>
                            @endif
                          </ul>
                        </td>
                      @endif
                      <td>
                      @if($can_update)
                          <a href="{{ route("galleries.edit",['galleries'=>$result->id, 's'=>Request::input("s"),'limit'=>Request::input("limit"),'page'=>Request::input("page")]) }}" class="text-dark">{{ $result->title }}</a>
                      @else
                      {{ $result->title }}
                      @endif
                      </td>
                      <td>{{ date("d M, Y", strtotime($result->created_at)) }}</td>
                      </tr>
                    @empty
                    <tr>
                      <td colspan="3">
                        No records found!
                      </td>
                    </tr>
                    @endforelse
                  </tbody>
                </table>
              </div>
              @if($galleries->total() > 0 )
              <div class="card-footer clearfix">
              <div class="row">
                  <div class="col-md-1">
                      {{ Form::select('limit', ['5'=>5,'10'=>10,'25'=>25,'50'=>50,'100'=>100],
                            request()->limit ? request()->limit :request()->limit, array(
                                        'class' => 'form-control input-sm page-limit',
                                        'id' => 'page_limit'
                       )) }}
                  </div>
                  <div class="col-md-11">
                      <div class="d-flex justify-content-end">

                          <span class="mr-3">Showing {{(($galleries->currentPage()-1)*$galleries->perPage())+1}} to {{((($galleries->currentPage()-1)*$galleries->perPage())==0)?$galleries->perPage():($galleries->currentPage())*$galleries->perPage()}} of {{$galleries->total()}} entries </span>

                          {{ $galleries->appends(request()->except('page'))->links('pagination::bootstrap-4') }}
                        </div>
                  </div>

                  </div>
                @endif
              </div>
            </div>
            <!-- /.card -->
          </div>

        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->


<script>
 //****** Common click funtion ***//
   $(document).ready(function(e) {

    $('.check_all').click(function(e) {
        if($(this).is(':checked') == true){
			$('.bulk').prop('checked',true);
		}
		else{
			$('.bulk').prop('checked',false);
		}
    });

    /**** Bulk action ****/
    $('#bulkactionConfirm').click(function(){
		if($('#bulkaction').val() == ''){
			alert('Please select any action.!');
		}
		else if($('#bulkaction').val() == 'trash'){
			if($('.bulk:checked').length > 0 ){
				if(confirm("Are you sure to trash selected product(s)?")){
                                   $('#postsFrm').attr('action',"{!!asset('galleries/destroy')!!}").submit();
				}
			}
			else{
				alert('Please select at least one record.!');
				return false;
			}
		}
                else if($('#bulkaction').val() == 'restore'){
			if($('.bulk:checked').length > 0 ){
				if(confirm("Are you sure to restore selected product(s)?")){
                                   $('#postsFrm').attr('action',"{!!asset('galleries/restore')!!}").submit();
				}
			}
			else{
				alert('Please select at least one record.!');
				return false;
			}
		}
                else if($('#bulkaction').val() == 'delete'){
			if($('.bulk:checked').length > 0 ){
				if(confirm("Are you sure to delete permanently selected product(s)?")){
                                   $('#postsFrm').attr('action',"{!!asset('galleries/delete')!!}").submit();
				}
			}
			else{
				alert('Please select at least one record.!');
				return false;
			}
		}


	});
 });
 </script>


@endsection

