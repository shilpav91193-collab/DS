@extends('layouts.cpanel')

@section('content')
@php

$user=Auth::user();
$can_any_action=\App\Http\Helpers::getAccess($user, 'galleries', 'update,delete');

$can_create=\App\Http\Helpers::getAccess($user, 'galleries', 'create');
$can_update=\App\Http\Helpers::getAccess($user, 'galleries', 'update');
$can_delete=\App\Http\Helpers::getAccess($user, 'galleries', 'delete');

@endphp
<script>
    @php
        $gallery_images = old('images', $gallery->images ?? null) ?? '[]';
        try {
            $gallery_images = json_decode($gallery_images);
        } catch (\Exception $e) {
            $gallery_images = [];
        }
        if (!is_array($gallery_images)) {
            $gallery_images = [];
        }
        if (count($gallery_images) > 0) {
            $gallery_images = App\Models\Medias::whereIn('id', $gallery_images)->orderByRaw(
                "FIELD(id, " . implode(',', $gallery_images) . ")"
            )->get();
        }
    @endphp
    window.images = {!! json_encode($gallery_images) !!};
</script>
<div x-data="__images('images', window.images, true)">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row my-2">
                <div class="col-sm-6">
                    <h3 class="m-0 text-dark">Add/Edit Gallery @if(isset($gallery)) - {{ $gallery->title }} @endif
                        @if($can_create)
                        <a href="{{route('galleries.create')}}" class="btn btn-default ml-2"><i class="fa fa-plus"></i>
                            Add New</a>
                        @endif
                    </h3>
                </div>
                <div class="col-sm-6">
                    <a href="{{ route('galleries.list',['s'=>Request::input('s'),'limit'=>Request::input('limit'),'page'=>Request::input('page')])
                        }}" class="btn btn-secondary float-right"><i class="fas fa-angle-left"></i> Back to Listing</a>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content-header -->
    <section class="content">
        <div class="container-fluid">
            @include('layouts.common.messages')
            <form method="post" autocomplete="off" action="{{ route('galleries.edit.post') }}" id="gallery">
                @csrf
                <div class="row">
                    <div class="col-md-9">
                        <div class="card card-warning card-outline card-outline-tabs">
                            <div class="card-body">
                                <div class="row">
                                    <div class="form-group col-sm-12">
                                        <label for="title">Title<span class="text-danger">*</span></label>
                                        <input data-meta="title" data-indep type="text" required id="title" name="title"
                                            class="form-control {{$errors->has('title') ? 'is-invalid': ''}}"
                                            value="{{ isset($gallery->title)?$gallery->title:old('title') }}" />
                                           @if(isset($gallery->id))
                                                 <span id="short_code"> <strong> Templating text:  </strong> [dacc_gallery:{{ $gallery->id }}]  </span>
                                           @endif

                                    </div>
                                    <div class="form-group col-sm-12">
                                        <label for="description">Description</label>
                                        <textarea data-meta="description" data-indep type="text" id="description"
                                            name="description"
                                            class="form-control {{$errors->has('description') ? 'is-invalid': ''}}">{{ isset($gallery->description)?$gallery->description:old('description') }}</textarea>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="border p-3 bg-gray-light d-flex flex-wrap sort-sections"
                                            id="sort_sections" x-ref="sorters">

                                            <template x-for="(image, i) in images">
                                                <div :data-id="image.id" class="sortable-item p-2 position-relative"
                                                    :style="'height:' + $refs.sorters.querySelectorAll('.sortable-item')[i].offsetWidth + 'px'"
                                                    style="width: 25%;">
                                                    <img loading="lazy"
                                                        class="h-100 w-100 shadow-sm rounded border bg-white"
                                                        style="object-fit: contain;" :src="image.file_url">
                                                    <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                                                        <!--- Create Trash Image button shown at hover ---->
                                                        <button type="button" class="btn btn-danger btn-sm"
                                                            x-on:click="removeImage(i, 'images')">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </template>

                                            <div class="no-sort p-2 d-flex justify-content-center"
                                                style="min-height: 100px; width: 25%;">
                                                <div
                                                    class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                                                    <!-- Add Button !-->
                                                    <label @click.prevent="openingModal('#editModal')"
                                                        data-toggle="modal" data-drop="false" data-target="#editModal"
                                                        type="button" class="btn btn-outline-success btn-sm">
                                                        <i class="fas fa-plus"></i>
                                                    </label>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="col-md-3">
                        <div class="sticky-top mb-3">
                            @if($can_update)
                            <div class="card">
                                <div class="card-body">
                                    <!-- the events -->
                                    <div class="row">
                                        <button type="submit" class="btn btn-primary btn-block"><i
                                                class="fas fa-save"></i> Save</button>
                                        <a href="{{ route('galleries.list',['s'=>Request::input('s'),'limit'=>Request::input('limit'),'page'=>Request::input('page')])
                                            }}" class="btn btn-default btn-block"><i class="fas fa-times"></i>
                                            Cancel</a>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                            </div>

                            @endif
                        </div>
                    </div>
                </div>
                <input type="hidden" data-meta="id" data-indep name="id" id="id"
                    value="{{isset($gallery->id)?$gallery->id:old('id')}}" />
                <input type="hidden" name="images" id="images" :value="imagesData()">
            </form>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>


</div>
@include('layouts.common.media-multi', ['multiple' => true])
@endsection
