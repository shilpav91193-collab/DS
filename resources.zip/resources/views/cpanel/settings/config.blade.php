@extends('layouts.cpanel')
@section('content')
<form class="form-horizontal uploadform" role="form" method="POST" action="" enctype="multipart/form-data">

    <div class="content-header">
        <div class="container-fluid">
            <div class="row my-2">
                <div class="col-sm-12">
                    <h1 class="m-0 text-dark"><small class="fa fa-list"></small> General Configs</h1>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <section class="content">
        <div class="container-fluid">
        @include('layouts.common.messages')
            <div class="card">                
                <div class="card-header p-0 border-bottom-0">
                    <ul class="nav nav-tabs w-100 mb-4" id="custom-tabs-sections" role="tablist">
                        @foreach ($tabs as $key => $tab)
                        @php 
                        $slug = Str::slug($key);              
                        @endphp
                        <li class="nav-item d-flex items-center">
                            <a class="nav-link text-center d-flex align-items-center @if($loop->first) active @endif"
                                id="custom-tabs-{{ $slug }}-tab" data-toggle="tab" href="#custom-tabs-{{ $slug }}" role="tab"
                                aria-controls="custom-tabs-{{ $slug }}" aria-selected="true">{!! $key !!}</a>
                        </li>
                        @endforeach
                    </ul>
                </div>
                <div class="card-body">
                {{ csrf_field() }}
                    <div class="tab-content">
                    @foreach ($tabs as $key => $configs)
                    @php 
                        $slug = Str::slug($key);              
                    @endphp
                        <div class="tab-pane fade show   @if($loop->first) active @endif"
                            id="custom-tabs-{{ $slug }}" style="min-height: 250px;">                    
                                @if(isset($configs))
                                <div class="row">
                                    @foreach($configs as $config)
                                    <div class="form-group col-md-6">
                                        <label for="{{$config->name}}">{{ucwords($config->title)}}</label>
                                        <div>
                                            @switch($config->type)
                                            @case('text')
                                            <input id="{{$config->name}}" type="text" class="form-control" name="{{$config->name}}"
                                                value="{!! $config->value  !!}">
                                            @break
                                            @case('select')
                                            <select class="form-control" name="{{$config->name}}" id="{{$config->name}}">
                                                @php
                                                $options = explode(',', $config->options);
                                                @endphp
                                                @foreach($options as $opt)
                                                <option value="{{$opt}}" @if($config->value == $opt) selected="selected" @endif
                                                    >{{$opt}}</option>
                                                @endforeach
                                            </select>
                                            @break
                                            @case('textarea')
                                            <textarea name="{{$config->name}}" id="{{$config->name}}" rows="5"
                                                class="form-control">{!! $config->value  !!}</textarea>
                                            @break
                                            @case('tokenfield')
                                            <input id="{{$config->name}}" type="text" class="form-control tokenfield"
                                                name="{{$config->name}}" value="{!! $config->value  !!}">
                                            @break
                                            @case('textEditor')
                                            <textarea name="{{$config->name}}" id="{{$config->name}}" rows="5"
                                                class="form-control textEditor">{!! $config->value  !!}</textarea>
                                            @break

                                            @endswitch
                                            @if($config->note)
                                                 <span>Note:{{$config->note}}</span>
                                            @endif
                                        </div>
                                        <div class="clearfix"><br /></div>
                                    </div>
                                    @if($config->row == 1)
                                        </div><div class="row">
                                    @endif
                                    @endforeach
                                   
                                </div>
                                @endif
                        </div>
                    @endforeach
                    </div>
                </div>
            </div>

        </div>
    </section>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <button type="submit" class="editor-submit btn btn-primary float-right">Update</button>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>

</form>
@endsection