@extends('layouts.cpanel')

@section('content')
    <section class="content">
        <div class="container-fluid">
            <!-- Small boxes (Stat box) -->
            <div class="row">

            </div>
        </div>
    </section>
@endsection
