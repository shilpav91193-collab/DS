@extends('layouts.cpanel')
@php

  $user=Auth::user();
  $can_any_action=\App\Http\Helpers::getAccess($user, 'registrations', 'update,delete');

  $can_create=\App\Http\Helpers::getAccess($user, 'registrations', 'create');
  $can_update=\App\Http\Helpers::getAccess($user, 'registrations', 'update');
  $can_delete=\App\Http\Helpers::getAccess($user, 'registrations', 'delete');

@endphp
@section('content')
<script src="{{ asset('cpanel/js/alpine.min.js') }}" defer></script>
<section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-12">
         <h3 class="m-0 text-dark">File Manager

            </h3>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
<section class="content">
      <div class="container-fluid">
        @include('layouts.common.messages')
        <div class="row" x-data="file_manager()">
          <div class="col-12">
            <div class="card" style="user-select: none;">
              <div class="card-header">
                  <input readonly class="form-control no-grey" :value="'Documents/' + current_item.path">
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <div x-html="treeTemplate()"></div>
                        </div>
                        <div class="col-md-9 px-2 border-left text-gray">
                            <div class="row">
                                <div class="col-md-12 bg-gray-light py-2 border">
                                    <a :disabled="current_item == directories" class="current_item btn btn-default btn-lg mr-3" href="javascript:void(0)" @click.prevent="changeToBack()"><i class="fa fa-arrow-left"></i></a>
                                    <button class="btn btn-default btn-lg mr-3">
                                        <label for="upload" class="current_item font-weight-normal mb-0" title="Upload new document">
                                            <input @change.prevent="uploadFile()" accept="{{ $mimes }}" type="file" name="file" id="upload" class="d-none">
                                            <i class="fa fa-upload"></i>
                                        </label>
                                    </button>

                                    <div @click.prevent="show_folder_create" class="current_item font-weight-normal d-inline-block mb-0" title="Create new folder">
                                        <button class="btn btn-default btn-lg text-gray mr-2">
                                            <i class="fa fa-folder"></i>
                                        </button>
                                        <input type="text" name="folder_name" class="d-none text-folder-create">
                                        <button @click="createFolder()" class="btn btn-default btn-sm text-gray ml-2 d-none create_button">
                                            Create
                                        </button>
                                    </div>

                                </div>
                            </div>
                            <div class="row mt-4">
                                <template x-for="(item, i) in current_item.children || []" :key="i">
                                    <div class="col-md-2 text-center mb-2">
                                        <div class="p-3 border h-100">
                                        <a href="javascript:void(0)" @dblclick.prevent="changeItem(item.hash)" class="current_item">
                                            <i class="fas fa-2xl" :class="{ 'fa-folder': item.type == 'folder', 'fa-file': item.type == 'file' }"></i>
                                            <p class="mt-1" x-text="item.name"></p>
                                            <p class="m-0">
                                                <small x-show="item.type == 'file'">
                                                    <!-- copy url -->
                                                    <a href="javascript:void(0)" @click="$dispatch('notice', item)" data-toggle="modal" data-target="#details_print_area" class="btn btn-sm btn-default mt-0"><i class="fa fa-info-circle"></i></a>
                                                </small>
                                                <small>
                                                    <!-- delete item -->
                                                    <a href="javascript:void(0)" @click.prevent="deleteItem(item)" class="btn btn-sm btn-default mt-0"><i class="fa fa-trash"></i></a>
                                                </small>
                                            </p>
                                        </a>
                                        </div>
                                    </div>
                                </template>
                                <template x-if="!(current_item.children || []).length">
                                    <div class="d-block mx-auto text-center" x-text="loadingFiles ? 'Loading...' : 'No Folder or File!'"></div>
                                </template>
                            </div>
                        </div>
                     </div>

              </div>
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
</section>

<div x-data="viewer()" @notice.window="show($event.detail)" class="modal fade modal-entry-view" id="details_print_area" role="dialog" aria-labelledby="batch" aria-hidden="true" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" x-text="title"></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <template x-if="item">
                <section class="modal-entry-view content-header">
                    <div class="container">
                    <div class="row">
                                    <table class="table">
                                        <tr>
                                            <td class="font-weight-bold" width="20%">Name :</td>
                                            <td x-text="item.name"></td>
                                        </tr>
                                        <tr>
                                            <td class="font-weight-bold" width="20%">Type :</td>
                                            <td x-text="item.type"></td>
                                        </tr>
                                        <tr>
                                            <td class="font-weight-bold" width="20%">Size :</td>
                                            <td x-text="readable_size(item.size)"></td>
                                        </tr>
                                        <tr>
                                            <td class="font-weight-bold" width="20%">Last Modified :</td>
                                            <td x-text="item.date_modified"></td>
                                        </tr>
                                        <tr>
                                            <td class="font-weight-bold" width="20%">URL :</td>
                                            <td>
                                                <span x-text="item.url"></span>
                                                <button class="btn btn-sm btn-default ml-2" @click="copyUrl(item.url)"><i class="fa fa-copy"></i></button>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                    </div><!-- /.container-fluid -->



                </section>
            </template>

        </div>
      </div>
    </div>
  </div>

<script>

    function viewer() {
        return {
            init() {
                $('#details_print_area').on('show.bs.modal', () => {

                });
            },
            item: null,
            title: '',
            show(item) {
                this.item = item;
                this.title = item.type == 'folder' ? 'Folder Details' : 'File Details';
                $('#details_print_area').modal('show');
            },
            copyUrl(url) {
                var $temp = $("<input>");
                $("body").append($temp);
                $temp.val(url).select();
                document.execCommand("copy");
                $temp.remove();
                alert('Copied!');
            },
            readable_size(size) {
                var i = Math.floor( Math.log(size) / Math.log(1024) );
                return ( size / Math.pow(1024, i) ).toFixed(2) * 1 + ' ' + ['B', 'kB', 'MB', 'GB', 'TB'][i];
            }
        }
    }

    function file_manager() {
        return {
            init() {
                //Initialization of treeviews
                this.$nextTick(() => {
                    this.current_item = this.directories;
                    this.changeItem(this.current_item.hash);
                    $('.current_item input[name="folder_name"]').on('keyup', (e) => {
                        if (e.keyCode == 13) {
                            this.createFolder(e.target.value);
                        }
                    });
                    $(document).on('contextmenu', '.clickable_area', (e) => {
                        e.preventDefault();
                        $('#contextMenu').css({
                            display: 'block',
                            left: e.pageX,
                            top: e.pageY
                        });
                        return false;
                    });
                });
            },
            createFolder(name = $('.current_item input[name="folder_name"]').val()) {
                if (name && name != '') {
                    $.ajax({
                        url: '{{ route('filemanager.create_directory') }}',
                        type: 'POST',
                        data: {
                            folder_name: name,
                            path: this.current_item.path
                        },
                        success: (res) => {
                            if (res) {
                                this.current_item.children = res;
                                $('.current_item input[name="folder_name"]').val('');
                                $('.current_item input[name="folder_name"]').addClass('d-none');
                                $('.current_item .btn.create_button').addClass('d-none');
                            }
                        }
                    });
                }
            },
            uploadFile() {
                let formData = new FormData();
                var file = $('#upload')[0].files[0];
                var supported_mimes = '{{ $mimes }}'.split(',');
                if (supported_mimes.length) {
                    var ext = file.name.split('.').pop();
                    if (supported_mimes.indexOf('.' + ext) == -1) {
                        console.log(supported_mimes, ext);
                        alert('File Type Not Supported!');
                        return;
                    }
                }
                formData.append('file', file);
                formData.append('path', this.current_item.path);
                $.ajax({
                    url: '{{ route('filemanager.upload_file') }}',
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: (res) => {
                        if (res) {
                            this.current_item.children = res;
                        }
                    }
                });
            },
            current_item: {},
            directories: @json($directories),
            treeTemplateBase(html) {
                return`<ul class="tree" id="tree2">${html}</ul>`;
            },
            treeTemplate() {
                return this.treeTemplateBase(this.treeTemplateLoop(this.directories.children));
            },
            show_folder_create() {
                $('.current_item .btn.create_button').removeClass('d-none')
                $('.current_item input[name="folder_name"]').removeClass('d-none').focus();
            },
            deleteItem(item) {
                if (confirm(`Are you sure to delete ${item.type == 'file' ? 'this file' : 'all files and folders in this directory'}? Files used in the website might get broken.`)) {
                    $.ajax({
                        url: '{{ route('filemanager.destroy') }}',
                        type: 'POST',
                        data: {
                            path: this.current_item.path.replace('/' + item.name, ''),
                            name: item.name,
                            type: item.type
                        },
                        success: (res) => {
                            if (res) {
                                this.current_item.children = res;
                            }
                        }
                    });
                }
            },
            treeTemplateLoop(data) {
                let html = '';
                data.filter((item) => item.type == 'folder').forEach((item) => {
                    var chlds = item.children ? item.children.filter((item) => item.type == 'folder') : [];
                    html += `<li class="branch"><i @click="toggleChildren('${item.hash}')" class="indicator fa fa-folder${!chlds ? '-open' : ''}"></i>`;
                    html += `<a :class="{ 'active': current_item.hash == '${item.hash}' }" href="javascript:void(0)" @click="changeItem('${item.hash}')">${item.name}</a>`;
                    if (chlds.length) {
                        html += `<ul x-show="getItemOpen('${item.hash}')">` + this.treeTemplateLoop(chlds) + '</ul>';
                    }
                    html += '</li>';
                });
                return html;
            },
            changeItem(hash) {
                // get item from hash
                let item = this.getItemByHash(hash);
                if (item.type != 'folder') {
                    return false;
                }
                item.open = true;
                var item_parents = this.getItemParents(item);
                item_parents.forEach((item) => {
                    item.open = true;
                });
                this.current_item = item;
                this.getFilesFromPath(item.path);
            },
            loadingFiles: false,
            getFilesFromPath(path) {
                // get files from path
                this.current_item.children = [];
                this.loadingFiles = true;
                fetch(`{{ route('filemanager.files') }}?path=${path}`)
                    .then(response => response.json())
                    .then(data => {
                        this.current_item.children = this.current_item.children || [];
                        this.current_item.children = this.current_item.children.concat(data.filter((item) => {
                            return !this.current_item.children.find((i) => i.path == item.path);
                        }));
                        this.current_item.children.forEach((item) => {
                            item.open = true;
                        });
                        this.loadingFiles = false;
                    }).catch((error) => {
                        this.loadingFiles = false;
                        console.error('Error:', error);
                    });
            },
            changeToBack() {
                var parent = this.getParent(this.current_item);
                if (parent) {
                    this.changeItem(parent.hash);
                }
            },
            getParent(item) {
                dir = this.directories;
                var parent = this.getItemParent(item, dir);
                return parent;
            },
            getItemParent(item, dir) {
                var parent = null;
                if (dir.children) {
                    dir.children.forEach((child) => {
                        if (child.hash == item.hash) {
                            parent = dir;
                        } else {
                            var chld = this.getItemParent(item, child);
                            if (chld) {
                                parent = chld;
                            }
                        }
                    });
                }
                return parent;
            },
            getItemParents(item) {
                var parents = [];
                var parent = this.getParent(item);
                while (parent) {
                    parents.push(parent);
                    parent = this.getParent(parent);
                }
                return parents;
            },
            getItemByHash(hash) {
                // flatten directories into hash name as key and item as value
                let flat = this.flatten(this.directories);
                return flat[hash];
            },
            flatten(item) {
                let flat = {};
                flat[item.hash] = item;
                if (item.children) {
                    item.children.forEach((child) => {
                        flat = {...flat, ...this.flatten(child)};
                    });
                }
                return flat;
            },
            toggleChildren(hash) {
                var item = this.getItemByHash(hash);
                if (item && item.children) {
                    item.children.forEach((child) => {
                        child.open = !child.open;
                    });
                }
            },
            getItemOpen(hash) {
                var item = this.getItemByHash(hash);
                if (item && item.children) {
                    return item.children.some((child) => child.open);
                }
                return false;
            },
            copyUrl(url) {
                var $temp = $("<input>");
                $("body").append($temp);
                $temp.val(url).select();
                document.execCommand("copy");
                $temp.remove();
                alert('Copied!');
            },
        }
    }
</script>
<style>
    .tree, .tree ul {
    margin:0;
    padding:0;
    list-style:none;
    margin-left:10px;
}
.tree ul {
    margin-left:.5em;
    position:relative
}
.tree ul:before {
    content:"";
    display:block;
    width:0;
    position:absolute;
    top:0;
    bottom:0;
    left:0;
    border-left:1px solid
}
.tree li {
    margin:0;
    padding:0 1em;
    line-height:2em;
    color:#bc8715;
    font-weight:600;
    position:relative;
    cursor: pointer;
}
.tree ul li:before {
    content:"";
    display:block;
    width:10px;
    height:0;
    border-top:1px solid;
    margin-top:-1px;
    position:absolute;
    top:1em;
    left:0
}
.tree ul li:last-child:before {
    background:#fff;
    height:auto;
    top:1em;
    bottom:0
}
.indicator {
    margin-right:5px;
}
.tree li a {
    text-decoration: none;
    color:#bc8715;
    font-weight: normal;
}
.tree li a:hover, .tree li i:hover, .tree li a.active, .tree li i.active {
    color: #f5b52c;
}
.tree li a:active, .tree li i:active {
    color:#8f6710;
}

.fa-2xl {
    font-size: 2em;
    line-height: .03125em;
    vertical-align: -.1875em;
}

.current_item {
    cursor: pointer;
    color: #6c757d;
}
.current_item[disabled] {
    cursor: not-allowed;
    color: #bababa;
}
.current_item:not([disabled]):hover, .current_item .btn-default:hover {
    color: #f5b52c !important;
}
.current_item:not([disabled]):active {
    color: #e4a317;
}
input.form-control.no-grey {
    background-color: #fff;
}
.text-folder-create{ border:1px solid #ccc; height:30px;}
</style>
@endsection
