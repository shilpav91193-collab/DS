@extends('layouts.cpanel')
@php
    $user = Auth::user();
    $can_any_action = \App\Http\Helpers::getAccess($user, 'group-types', 'update,delete');

    $can_create = \App\Http\Helpers::getAccess($user, 'group-types', 'create');
    $can_update = \App\Http\Helpers::getAccess($user, 'group-types', 'update');
    $can_delete = \App\Http\Helpers::getAccess($user, 'group-types', 'delete');

@endphp
@section('content')
    <!-- Content Header (Page header) -->

    <section class="content-header">
        <div class="container-fluid">
            <div class="row my-2">
                <div class="col-sm-6">
                    <h3 class="m-0 text-dark">Add/Edit Group Type
                        @if ($can_create)
                            <a href="{{ route('group-types.create') }}" class="btn btn-default ml-2"><i class="fa fa-plus"></i>
                                Add New</a>
                        @endif
                    </h3>
                </div>
                <div class="col-sm-6">
                    <a href="{{ route('group-types.list', ['s' => Request::input('s'), 'limit' => Request::input('limit'), 'events' => Request::input('events'), 'page' => Request::input('page')]) }}" class="btn btn-secondary float-right"><i class="fas fa-angle-left"></i> Back to Listing</a>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content-header -->
    <section class="content">
        <div class="container-fluid">
            @include('layouts.common.messages')
            <form method="post" autocomplete="off" enctype="multipart/form-data">
                @csrf
                <div class="row">
                    <div class="col-md-9">
                        <div class="card card-warning card-outline card-outline-tabs">
                            <div class="card-body">
                                <div class="row">
                                    <div class="form-group col-sm-12">
                                        <label for="name">Title<span class="text-danger">*</span></label>
                                        <input type="text" id="name" name="title"
                                               class="form-control event-title {{ $errors->has('title') ? 'is-invalid' : '' }}"
                                               value="{{ isset($result->title) ? $result->title : old('title') }}" />


{{--                                        <div class="pt-2" id="event_slug_area"> <strong>slug:</strong>--}}
{{--                                            <span id="event_url">{{ old('slug', $result->slug ?? \App\Http\Helpers::getSlug('group_types', 'slug', $result->title ?? '', $result->id ?? 0)) }}</span>--}}
{{--                                            <input type="hidden" name="slug"--}}
{{--                                                   value="{{ old('slug', $result->slug ?? \App\Http\Helpers::getSlug('group_types', 'slug', $result->title ?? '', $result->id ?? 0)) }}"--}}
{{--                                                   id="slug" style="width:200px;">--}}
{{--                                            <button class="btn d-none btn-default btn-sm" type="button"--}}
{{--                                                    id="save_eventname">Ok</button>--}}
{{--                                            <button class="btn btn-default btn-sm" type="button"--}}
{{--                                                    id="edit_eventname">Edit</button>--}}
{{--                                        </div>--}}

                                    </div>

                                    <div class="form-group col-sm-12">
                                        <label for="description">Description</label>
                                        <textarea id="description" name="description"
                                                  class="form-control textEditor event-description {{ $errors->has('description') ? 'is-invalid' : '' }}">{{ old('description', $result->description ?? '') }}</textarea>
                                    </div>

                                </div>
                            </div>
                        </div>
                        @include('layouts.common.activity', ['result' => $result, 'activities' => $activities ?? []])
                    </div>

                    <div class="col-md-3">
                        <div class="sticky-top mb-3">
                            @if ($can_update)
                                <div class="card">
                                    <div class="card-body">
                                        <!-- the events -->
                                        <button type="submit" class="btn btn-block btn-primary"><i class="fas fa-save"></i>
                                            Save</button>
                                        <a href="{{ route('group-types.list', ['s' => Request::input('s'), 'limit' => Request::input('limit'), 'events' => Request::input('events'), 'page' => Request::input('page')]) }}" class="btn btn-block btn-default"><i class="fas fa-times"></i> Cancel</a>

                                    </div>
                                    <!-- /.card-body -->
                                </div>
                            @endif

                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Media</h3>
                                </div>
                                <div class="card-body">
                                    @php
                                        $images = null;
                                        if (isset($result->image) && $img = old('image', $result->image)) {
                                            $images = \App\Models\Medias::where('id', $img ?? '')->first();
                                        }
                                        if ($images && $images->file_url) {
                                            $images->file_url = \App\Http\Helpers::asset($images->file_url);
                                            $images = [$images];
                                        }
                                    @endphp
                                    <div class="row form-group"
                                         x-data='__images("featured", {{ json_encode($images ?? []) }})'>
                                        <div class="col-sm-12">
                                            <input type="hidden" name="image"
                                                   :value="images.length ? images[0].id : ''">
                                            <label for="featured_image">Featured Image</label>
                                            <div class="border p-3 bg-gray-light d-flex flex-wrap sort-sections">
                                                <template x-for="(image, i) in images">
                                                    <div class="p-2 position-relative">
                                                        <img loading="lazy"
                                                             class="h-100 w-100 shadow-sm rounded border bg-white"
                                                             style="object-fit: contain;" :src="image.file_url">
                                                        <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                                                            <!--- Create Trash Image button shown at hover ---->
                                                            <button type="button" class="btn btn-danger btn-sm"
                                                                    x-on:click="removeImage(i, 'featured')">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </template>

                                                <div x-show="! images.length" class="p-2 d-flex justify-content-center"
                                                     :class="{ 'd-flex': !images.length }"
                                                     style="min-height: 100px; width: 100%;">
                                                    <div
                                                         class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                                                        <!-- Add Button !-->
                                                        <label @click.prevent="openingModal('#editModal')"
                                                               data-toggle="modal" data-drop="false"
                                                               data-target="#editModal" type="button"
                                                               class="btn btn-outline-success btn-sm">
                                                            <i class="fas fa-plus"></i>
                                                        </label>
                                                    </div>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="">
                                            Banner
                                        </label>
                                        @php
                                            $banners = \App\Models\Banner::where('status', 'Y')->get();
                                        @endphp
                                        <select name="meta[banner_id]" id="banner_id" class="form-control">
                                            <option value="">Select Banner</option>
                                            @foreach ($banners as $banner)
                                                @php
                                                    $old_bannerid = isset($result->meta->banner_id) ? $result->meta->banner_id : old('meta.banner_id');
                                                @endphp
                                                <option value="{{ $banner->id }}" {{ $old_bannerid == $banner->id ? 'selected' : '' }}>{{ $banner->title }}</option>
                                            @endforeach
                                        </select>
                                    </div>

                                    @php
                                        $images = null;
                                        if (isset($result->thumbnail) && ($img = old('image', $result->thumbnail))) {
                                            $images = \App\Models\Medias::where('id', $img ?? '')->first();
                                        }
                                        if ($images && $images->file_url) {
                                            $images->file_url = \App\Http\Helpers::asset($images->file_url);
                                            $images = [$images];
                                        }
                                    @endphp
                                    <div class="row form-group" x-data='__images("thumbnail", {{ json_encode($images ?? []) }})'>
                                        <div class="col-sm-12">
                                            <input type="hidden" name="thumbnail" :value="images.length ? images[0].id : ''">
                                            <label for="thumbnail_image">Thumbnail</label>
                                            <div class="border p-3 bg-gray-light d-flex flex-wrap sort-sections">
                                                <template x-for="(image, i) in images">
                                                    <div class="p-2 position-relative">
                                                        <img loading="lazy" class="h-100 w-100 shadow-sm rounded border bg-white"
                                                             style="object-fit: contain;" :src="image.file_url">
                                                        <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                                                            <!--- Create Trash Image button shown at hover ---->
                                                            <button type="button" class="btn btn-danger btn-sm"
                                                                    x-on:click="removeImage(i)">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </template>

                                                <div x-show="! images.length" class="p-2 d-flex justify-content-center"
                                                     :class="{ 'd-flex': !images.length }" style="min-height: 100px; width: 100%;">
                                                    <div
                                                         class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                                                        <!-- Add Button !-->
                                                        <label @click.prevent="openingModal('#editModal')" data-toggle="modal"
                                                               data-drop="false" data-target="#editModal" type="button"
                                                               class="btn btn-outline-success btn-sm">
                                                            <i class="fas fa-plus"></i>
                                                        </label>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">SEO Content</h3>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="excerpt">Page Title</label>
                                        <input type="text" name="meta[meta_title]"
                                            value="{{ isset($result->meta->{'meta_title'})?$result->meta->{'meta_title'}:old('meta.meta_title') }}"
                                            id="meta_title" class="form-control" placeholder="Enter the SEO title" />
                                    </div>
                                    <div class="form-group">
                                        <label for="excerpt">Keywords</label>
                                        <textarea name="meta[meta_keyword]" id="meta_keyword" class="form-control"
                                            cols="40" rows="4"
                                            placeholder="Enter the SEO keywords">{{ isset($result->meta->{'meta_keyword'})?$result->meta->{'meta_keyword'}:old('meta.meta_keyword') }}</textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="excerpt">Description</label>
                                        <textarea name="meta[meta_description]" id="meta_description"
                                            class="form-control" cols="40" rows="4"
                                            placeholder="Enter the SEO description">{{ isset($result->meta->{'meta_description'})?$result->meta->{'meta_description'}:old('meta.meta_description') }}</textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <input type="hidden" name="id" id="id" value="{{ isset($result->id) ? $result->id : old('id') }}" />
            </form>
            <!-- /.row -->
        </div><!-- /.container-fluid -->

        @include('layouts.common.media-multi', ['multiple' => false])
    </section>
@endsection
