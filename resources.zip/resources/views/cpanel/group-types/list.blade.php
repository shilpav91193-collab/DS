@extends('layouts.cpanel')
@php

$user=Auth::user();
$can_any_action=\App\Http\Helpers::getAccess($user, 'group-types', 'update,delete');

$can_create=\App\Http\Helpers::getAccess($user, 'group-types', 'create');
$can_update=\App\Http\Helpers::getAccess($user, 'group-types', 'update');
$can_delete=\App\Http\Helpers::getAccess($user, 'group-types', 'delete');

@endphp
@section('content')
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-12">
                <h3 class="m-0 text-dark">Group Types
                    @if($can_create)
                    <a href="{{route('group-types.create')}}"
                       class="btn btn-default ml-2"><i class="fa fa-plus"></i>
                        Add New</a>
                    @endif
                </h3>
            </div>
        </div>
    </div>
</section>
<section class="content">
    <div class="container-fluid">
        @include('layouts.common.messages')
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <form name="group-types" action=""
                              method="get" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-7">

                                </div>
                                <div class="col-sm-2">
                                    <div class="input-group input-group-sm">
                                        <select name="status" id="filter2" class="form-control pull-right">
                                            <option @if(request()->input('status') == 'all' ) selected="selected" @endif value="all">-- All Status --</option>
                                            <option value="Y" @if(request()->input('status') == 'Y' ) selected="selected" @endif>Active</option>
                                            <option value="N" @if(request()->input('status') =='N' ) selected="selected" @endif>InActive</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="card-tools">
                                        <div class="input-group input-group-sm">
                                            <input type="text" name="s"
                                                   value="{{Request::input('s')}}"
                                                class="form-control float-right"
                                                   placeholder="Search">

                                            <div class="input-group-append">
                                                <button type="submit"
                                                        class="btn btn-default">
                                                    <i class="fas fa-search"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover"  id="table-sort">
                            <thead>
                                <tr>
                                    <th width="3%">#.</th>
                                    @if($can_any_action)
                                        <th width="12%">Action</th>
                                    @endif
                                    <th width="55%">Name</th>
                                    <th width="30%">Created At</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($groupTypes as $groupType)
                                <tr class="data" data-id="{{$groupType->id}}">
                                    <td>{{($limit = $filter['limit'] ?? 0) * (($page = app('request')->input('page') ?? 1)
                                        - 1 )+$loop->iteration}}</td>
                                    @if($can_any_action)
                                    <td>
                                        <ul class="list-inline m-0">
                                            @if($can_update)
                                            <li class="list-inline-item sorting_1 dragHandle">
                                                <a href="javascript:"
                                                   title="Drag to change order" class="gray">
                                                    <i
                                                class="fa fa-ellipsis-v"></i>
                                                    <i class="fa fa-ellipsis-v"></i></a>
                                            </li>

                                            <li class="list-inline-item">
                                                <a href="{{ route('group-types.edit',
                                                        ['id'=>$groupType->id,
                                                            's'=>Request::input('s'),
                                                            'limit'=>Request::input('limit'),
                                                            'page'=>Request::input('page')])
                                                    }}" data-toggle="tooltip" title="Edit"
                                                   class="text-primary"><i
                                                        class="far fa-edit"></i></a></li>
                                            @endif
                                            @if($can_delete)
                                            <li class="list-inline-item"><a
                                                    onclick="return confirm('Are you sure you want to delete this item?')"
                                                    href="{{route('group-types.destroy',
                                                                ['id'=>$groupType->id])}}"
                                                    data-toggle="tooltip" title="Delete"
                                                    class="text-danger"><i
                                                        class="far fa-trash-alt"></i></a></li>
                                            @endif
                                            @if($can_update)
                                            <li class="list-inline-item">
                                                <div class="custom-control  custom-switch
                                                custom-switch-off-danger custom-switch-on-success"
                                                    data-toggle="tooltip" title="Status">
                                                    <input type="checkbox"
                                                           class="custom-control-input
                                                           changeStatus"
                                                        data-id="{{$groupType->id}}"
                                                           data-status-type="group_types"
                                                        data-status="{{$groupType->status}}"
                                                           {{ $groupType->status=='Y' ?
                                                    'checked' : '' }}
                                                           id="customSwitch_{{$loop->iteration }}">
                                                    <label class="custom-control-label"
                                                        for="customSwitch_{{$loop->iteration}}"></label>
                                                </div>
                                            </li>
                                            @endif
                                        </ul>
                                    </td>
                                    @endif

                                    <td>
                                        @if($can_update)
                                        <a href="{{route('group-types.edit',['id'=>$groupType->id])}}"
                                            class="text-dark">{{$groupType->title}}</a>
                                        @else
                                        {{$groupType->title}}
                                        @endif
                                    </td>
                                    <td>{{ date("d M, Y h:i A", strtotime($groupType->created_at)) }}</td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="4" class="text-center">No records found!</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                </div>
                <div class="col-sm-12 text-left">
                    <button class="btn btn-danger" id="update_order">
                        Update Order
                    </button>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
    $(document).ready(function () {

        $('.page-limit').on('change', function () {
            $(this).closest('form').submit();
        });

        $('#table-sort').tableDnD({
            onDragStart: function(table, row) {
                $(row).closest('tr').addClass('bg-dark text-white border shadow');
            },
            onDragStop: function(table, row) {
                $(row).closest('tr').removeClass('bg-dark text-white border shadow');
            },
            dragHandle: ".sort-handler"
        });

        $('#update_order').click(function(){

            if($('#table-sort tr.data').length > 0){
                var ids = [];
                $('#table-sort tr.data').each(function(){
                    ids.push(parseInt($(this).attr('data-id')));
                })
                  if(ids.length > 0 ){
                       $.ajax({
                            url: "{{url('d-admin/ajax/changeOrder')}}",
                            method: 'POST',
                            dataType: 'json',
                            data: {
                                action: 'sort_order',
                                ids: ids,
                                statusType: 'group_types'
                            },
                            error: function(){
                                alert('Internal server error.!!');
                                location.reload();
                            },
                            success: function (data) {
                                if (data.status == 'success') {
                                   alert('Order has been updated');
                                   location.reload(true);
                                } else {
                                    alert(data.message);
                                    location.reload();
                                }
                            }
                       });
                  }
            }
        });
    });
</script>
@endsection
