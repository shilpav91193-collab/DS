@extends('layouts.cpanel')

@section('content')
    @php
        $user = Auth::user();
        $can_any_action = \App\Http\Helpers::getAccess($user, 'teams', 'update,delete');
        $can_create = \App\Http\Helpers::getAccess($user, 'teams', 'create');
        $can_update = \App\Http\Helpers::getAccess($user, 'teams', 'update');
        $can_delete = \App\Http\Helpers::getAccess($user, 'teams', 'delete');
    @endphp

    <div class="content-header">
        <div class="container-fluid">
            <div class="row my-2">
                <div class="col-sm-12">
                    <h1 class="m-0 text-dark"><small class="fa fa-list"></small> All Teams
                        @if($can_create)
                        <a href="{{route('teams.create')}}" class="btn btn-default"><i class="fa fa-plus"></i> Add New</a>
                        @endif
                    </h1>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            @include('layouts.common.messages')
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <form class="result" name="forms" action="" method="get" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-sm-7">
                                    </div>
                                    <div class="col-sm-2">
                                        <div class="input-group input-group-sm">
                                            <select name="status" id="filter2" class="form-control pull-right">
                                                <option @if(request()->input('status') == 'all' ) selected="selected" @endif value="all">-- All Status --</option>
                                                <option value="Y" @if(request()->input('status') == 'Y' ) selected="selected" @endif>Active</option>
                                                <option value="N" @if(request()->input('status') =='N' ) selected="selected" @endif>InActive</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="card-tools">
                                            <div class="input-group input-group-sm">
                                                <input type="text" name="s" value="{{Request::input('s')}}"
                                                    class="form-control float-right" placeholder="Search">

                                                <div class="input-group-append">
                                                    <button type="submit" class="btn btn-default">
                                                        <i class="fas fa-search"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover" id="table-sort">
                                <thead>
                                    <tr>
                                    <th width="5%"></th>
                                    @if($can_any_action)
                                        <th width="20%">Action</th>
                                    @endif
                                    <th width="35%">Name</th>
                                    <th width="35%">Profession</th>
                                    <th width="30%">Type</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse ($results as $i=>$result)

                                    <tr class="data" id="{{$result->id}}">
                                        <td class="sorting_1 dragHandle">
                                            <a href="javascript:" title="Drag to change order" class="gray"><i
                                                    class="fa fa-ellipsis-v"></i>&nbsp;<i class="fa fa-ellipsis-v"></i></a>

                                        </td>
                                        @if($can_any_action)
                                        <td>
                                            <ul class="list-inline m-0">
                                                @if($can_update)
                                                <li class="list-inline-item"><a href="{{ route('teams.edit',['id'=>$result->id,
                                                        's'=>Request::input('s'),'limit'=>Request::input('limit'),'page'=>Request::input(" page")])
                                                        }}" data-toggle="tooltip" title="Edit" class="text-primary"><i
                                                            class="far fa-edit"></i></a></li>
                                                @endif
                                                @if($can_delete)
                                                <li class="list-inline-item"><a
                                                        onclick="return confirm('Are you sure you want to delete this teams?')"
                                                        href="{{route('teams.delete',['id'=>$result->id])}}"
                                                        data-toggle="tooltip" title="Delete" class="text-danger"><i
                                                            class="far fa-trash-alt"></i></a></li>
                                                @endif
                                                @if($can_update)
                                                <li class="list-inline-item">
                                                    <div class="custom-control custom-switch custom-switch-off-danger custom-switch-on-success"
                                                        data-toggle="tooltip" title="Status">
                                                        <input type="checkbox" class="custom-control-input changeStatus"
                                                            data-id="{{$result->id}}" data-status-type="teams"
                                                            data-status="{{$result->status}}" {{ $result->status=='Y' ?
                                                        'checked' : '' }} id="customSwitch_{{$loop->iteration }}">
                                                        <label class="custom-control-label"
                                                            for="customSwitch_{{$loop->iteration}}"></label>
                                                    </div>
                                                </li>
                                                @endif
                                            </ul>
                                        </td>
                                        @endif
                                        <td>
                                            @if($can_update)
                                            <a href="{{ route('teams.edit',['id'=>$result->id,
                                                's'=>Request::input('s'),'limit'=>Request::input('limit'),'page'=>Request::input('page')]) }}"
                                                class="text-dark">{{ $result->name }}</a>
                                            @else
                                            {{ $result->name }}
                                            @endif
                                        </td>
                                        <td>
                                            {{ $result->profession }}
                                        </td>
                                        <td>
                                            {{ \Illuminate\Support\Str::title($result->type) }}
                                        </td>
                                    </tr>
                                    @empty
                                    <tr>
                                        <td colspan="4" class="text-center">
                                            No records found!
                                        </td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>

                        <div class="card-footer clearfix">
                            <div class="col-sm-2">
                                <button type="button" name="update_order" id="update_order" class="btn btn-danger pull-right">Update Order</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <script>
        $(document).ready(function(e) {

            $('#filter1').change(function(e) {
                $('form.result').submit();
            });

            $('.check_all').click(function(e) {
                if ($(this).is(':checked') == true) {
                    $('.bulk').prop('checked', true);
                } else {
                    $('.bulk').prop('checked', false);
                }
            });

            $('#bulkactionConfirm').click(function() {
                if ($('#bulkaction').val() == '') {
                    alert('Please select any action.!');
                } else if ($('#bulkaction').val() == 'trash') {
                    if ($('.bulk:checked').length > 0) {
                        if (confirm("Are you sure to trash selected degree(s)?")) {
                            $('#postsFrm').attr('action', "{!!asset('teams/destroy')!!}").submit();
                        }
                    } else {
                        alert('Please select at least one record.!');
                        return false;
                    }
                } else if ($('#bulkaction').val() == 'restore') {
                    if ($('.bulk:checked').length > 0) {
                        if (confirm("Are you sure to restore selected degree(s)?")) {
                            $('#postsFrm').attr('action', "{!!asset('teams/restore')!!}").submit();
                        }
                    } else {
                        alert('Please select at least one record.!');
                        return false;
                    }
                } else if ($('#bulkaction').val() == 'delete') {
                    if ($('.bulk:checked').length > 0) {
                        if (confirm("Are you sure to delete permanently selected degree(s)?")) {
                            $('#postsFrm').attr('action', "{!!asset('teams/delete')!!}").submit();
                        }
                    } else {
                        alert('Please select at least one record.!');
                        return false;
                    }
                }

            });

            $('#update_order').click(function() {
               if ($('#table-sort tr.data').length > 0) {
                   var ids = []; var statusType="teams";

                   $('#table-sort tr.data').each(function(){
                        ids.push(parseInt($(this).attr('id')))
                   })

                   if (ids.length > 0 ) {
                        $.ajax({
                             url: "{{url('d-admin/ajax/changeOrder')}}",
                             method: 'POST',
                             dataType: 'json',
                             data:{ action: 'sort_order',ids:ids, statusType: statusType },
                             error: function(){
                                 alert('Internal server error.!!');
                                 location.reload();
                             },
                             success: function (data) {
                                 if (data.status == 'success') {
                                    alert('Order has been updated');
                                    location.reload(true);
                                 } else{
                                         alert(data.message);
                                         location.reload();
                                 }
                             }
                        });
                   }
               }
           });
        });
    </script>
@endsection
