@extends('layouts.cpanel')

@section('content')
    @php
        $user = Auth::user();
        $can_any_action = \App\Http\Helpers::getAccess($user, 'teams', 'update,delete');
        $can_create = \App\Http\Helpers::getAccess($user, 'teams', 'create');
        $can_update = \App\Http\Helpers::getAccess($user, 'teams', 'update');
        $can_delete = \App\Http\Helpers::getAccess($user, 'teams', 'delete');
    @endphp
<div class="content-header">
    <div class="container-fluid">
        <div class="row my-2">
            <div class="col-sm-12">
                <h1 class="m-0 text-dark">Create Teams
                    <a href="{{route('teams.create')}}" class="btn btn-default"><i class="fa fa-plus"></i> Add new</a>
                    <a href="{{ route('teams.list',['s'=>Request::input('s'),'limit'=>Request::input('limit'),'page'=>Request::input('page')]) }}"
                        class="btn btn-secondary float-right"><i class="fas fa-angle-left"></i> Back to
                        Listing</a>
                </h1>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        @include('layouts.common.messages')
        <form method="post" autocomplete="off" enctype="multipart/form-data">
            @csrf
            <div class="row">
                <div class="col-md-9">
                    <div class="card card-primary">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name">Name<span class="text-danger">*</span></label>
                                        <input id="name" type="text" class="form-control post-title" name="name"
                                            required
                                            placeholder="Enter name">
                                    </div>
                                </div>
                                @if($can_create)
                                    <div class="form-group col-sm-12">
                                        <button type="submit" class="btn btn-primary float-right"><i
                                                class="fas fa-arrow-right"></i> Next</button>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>

@endsection
