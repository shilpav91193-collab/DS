@extends('layouts.cpanel')

@section('content')
    @php
        $user = Auth::user();
        $can_any_action = \App\Http\Helpers::getAccess($user, 'teams', 'update,delete');
        $can_create = \App\Http\Helpers::getAccess($user, 'teams', 'create');
        $can_update = \App\Http\Helpers::getAccess($user, 'teams', 'update');
        $can_delete = \App\Http\Helpers::getAccess($user, 'teams', 'delete');
        $can_approve = \App\Http\Helpers::getAccess($user, 'teams', 'approve');
    @endphp

    <div>
        <div class="content-header">
            <div class="container-fluid">
                <div class="row my-2">
                    <div class="col-sm-12">
                        <h1 class="m-0 text-dark">Edit Teams
                            <a href="{{route('teams.create')}}" class="btn btn-default"><i class="fa fa-plus"></i> Add
                                new</a>
                            <a href="{{route('teams.list')}}" class="btn btn-secondary float-right"><i
                                    class="fas fa-angle-left"></i> Back to Listing</a>
                        </h1>
                    </div>
                </div>
            </div>
        </div>

        <section class="content">
            <div class="container-fluid">
                @include('layouts.common.messages')
                <form method="post" autocomplete="off" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="id" id="id" value="{{ isset($result->id)?$result->id:'' }}" />
                    <div class="row">
                        <div class="col-md-9">
                            <div class="card card-primary">
                                <div class="card-body">
                                    <div class="row">

                                        <div class="form-group col-sm-12">
                                            <label for="name">Name<span class="text-danger">*</span></label>
                                            <input id="name" type="text" class="form-control post-title" name="name"
                                                value="{{ isset($result->name)?$result->name:old('name')}}" required
                                                placeholder="Enter name">
                                        </div>

                                        <div class="form-group col-sm-12">
                                            <label for="description">Description<span class="text-danger">*</span></label>
                                            <textarea id="description" name="description" class="form-control textEditor" cols="40" rows="4"
                                                      placeholder="">{{ isset($result->description) ? $result->description : old('description')}}</textarea>
                                        </div>


                                        <div class="form-group col-sm-12">
                                            <label for="profession">Profession</label>
                                            <input id="profession" type="text" class="form-control post-title"
                                                name="profession"
                                                value="{{ isset($result->profession)?$result->profession:old('profession')}}"
                                                placeholder="Enter Profession">
                                        </div>

                                        <div class="form-group col-sm-12">

                                            <div class="icheck-primary d-inline">
                                                <input type="radio" id="leaders" name="type" value="leaders"
                                                    class="team_type" @if((old('type') ?? $result->type ?? '') == 'leaders'
                                                || (old('type') ?? $result->type ?? '') == '') checked @endif>
                                                <label for="leaders">
                                                    Leaders
                                                </label>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="sticky-top mb-3">
                                @if($can_update)
                                <div class="card">
                                    <div class="card-body">
                                        <button type="submit" class="btn btn-block btn-primary"><i class="fas fa-save"></i>
                                            Update</button>
                                        <a href="{{ route('teams.list',['s'=>Request::input('s'),'limit'=>Request::input('limit'),'page'=>Request::input('page')])
                                            }}" class="btn btn-block btn-default"><i class="fas fa-times"></i> Cancel</a>
                                    </div>
                                </div>
                                @endif

                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title">Media</h3>
                                    </div>
                                    <div class="card-body">

                                        @php
                                        $images = null;
                                        if (($img = old('image', $result->image))) {
                                        $images = \App\Models\Medias::where('id', $img ?? '')->first();
                                        }
                                        if ($images && $images->file_url) {
                                        $images->file_url = \App\Http\Helpers::asset($images->file_url);
                                        $images = [$images];
                                        }
                                        @endphp
                                        <div class="row form-group"
                                            x-data='__images("featured", {{ json_encode($images ?? []) }})'>
                                            <div class="col-sm-12">
                                                <input type="hidden" name="image"
                                                    :value="images.length ? images[0].id : ''">
                                                <label for="featured_image">Profile Picture</label>
                                                <div class="border p-3 bg-gray-light d-flex flex-wrap sort-sections">
                                                    <template x-for="(image, i) in images">
                                                        <div class="p-2 position-relative">
                                                            <img loading="lazy"
                                                                class="h-100 w-100 shadow-sm rounded border bg-white"
                                                                style="object-fit: contain;" :src="image.file_url">
                                                            <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                                                                <!--- Create Trash Image button shown at hover ---->
                                                                <button type="button" class="btn btn-danger btn-sm"
                                                                    x-on:click="removeImage(i, 'featured')">
                                                                    <i class="fas fa-trash"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </template>

                                                    <div x-show="! images.length" class="p-2 d-flex justify-content-center"
                                                        :class="{ 'd-flex': !images.length }"
                                                        style="min-height: 100px; width: 100%;">
                                                        <div
                                                            class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                                                            <!-- Add Button !-->
                                                            <label @click.prevent="openingModal('#editModal')"
                                                                data-toggle="modal" data-drop="false"
                                                                data-target="#editModal" type="button"
                                                                class="btn btn-outline-success btn-sm">
                                                                <i class="fas fa-plus"></i>
                                                            </label>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>


                                        <div class="d-none">
                                            <div class="mb-2 text-center">
                                                <strong>Or</strong>
                                            </div>

                                            <div class="form-group">
                                                <label for="">
                                                    Gallery
                                                </label>
                                                <select name="meta[gallery_id]" id="gallery_id" class="form-control">
                                                    <option value="">Select Gallery</option>
                                                    @foreach($galleries as $gallery)
                                                    @php
                                                    $old_galleryid = isset($result->meta->gallery_id) ?
                                                    $result->meta->gallery_id :
                                                    old('meta.gallery_id');
                                                    @endphp
                                                    <option value="{{$gallery->id}}" {{ $old_galleryid==$gallery->id ?
                                                        'selected':'' }}>{{$gallery->title}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </section>

        <div class="full-screen-modal modal fade select-section-popup" id="select-section-popup" role="dialog"
            aria-labelledby="batch" aria-hidden="true" data-keyboard="false" data-backdrop="static">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Select Section</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                    </div>
                </div>
            </div>
        </div>

        @include('layouts.common.media-multi', ['multiple' => false])
    </div>

@endsection
