@extends('layouts.cpanel')

@section('content')
    @php

        $user = Auth::user();
        $can_any_action = \App\Http\Helpers::getAccess($user, 'banners', 'update,delete');

        $can_create = \App\Http\Helpers::getAccess($user, 'banners', 'create');
        $can_update = \App\Http\Helpers::getAccess($user, 'banners', 'update');
        $can_delete = \App\Http\Helpers::getAccess($user, 'banners', 'delete');

    @endphp
    <script>
        @php
            $contents = old('images', $banner->contents ?? null) ?? '[]';
            try {
                $contents = json_decode($contents, true);
                $banner_images = array_merge(array_column($contents, 'id'), array_column($contents, 'mobile'));
                $banner_images = array_unique(array_values($banner_images));
            } catch (\Exception $e) {
                $banner_images = [];
            }
            if (!is_array($banner_images)) {
                $banner_images = [];
            }
            if (count($banner_images) > 0) {
                $banner_images = App\Models\Medias::whereIn('id', $banner_images)
                    ->orderByRaw('FIELD(id, ' . implode(',', $banner_images) . ')')
                    ->get();
            }
        @endphp
        window.images = {!! json_encode($banner_images) !!};

        function banners() {
            return {
                contents: {!! json_encode($contents) !!},
                temp_images: window.images,
                frontend_images(index) {
                    return this.contents.filter((item, i) => {
                        return i === index;
                    }).map((item) => {
                        return this.temp_images.find((image) => {
                            return image.id == item.id;
                        });
                    }).filter((item) => {
                        return item;
                    });
                },
                mobile_images(index) {
                    return this.contents.filter((item, i) => {
                        return i === index;
                    }).map((item) => {
                        return this.temp_images.find((image) => {
                            return image.id == item.mobile;
                        });
                    }).filter((item) => {
                        return item;
                    });
                },
                removeContent(index) {
                    confirm('Are you sure you want to remove this content?') &&
                        this.contents.splice(index, 1);
                },
                addContent() {
                    this.contents.push({
                        id: null,
                        mobile: null,
                        meta_description: null,
                        meta_url: null,
                        target: null,
                    });
                    this.$nextTick(() => {
                        $(".textEditor").summernote({
                            height: 200,
                            disableDragAndDrop: false,
                            toolbar: TOOLBAR,
                            styleTags: STYLETAGS,
                        });
                    });
                },
            };
        }
    </script>
    <div>
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row my-2">
                    <div class="col-sm-6">
                        <h3 class="m-0 text-dark">Add/Edit Banner @if (isset($banner))
                                - {{ $banner->title }}
                            @endif
                            @if ($can_create)
                                <a href="{{ route('banners.create') }}" class="btn btn-default ml-2"><i class="fa fa-plus"></i> Add New</a>
                            @endif
                        </h3>
                    </div>
                    <div class="col-sm-6">
                        <a href="{{ route('banners.list', ['s' => Request::input('s'), 'limit' => Request::input('limit'), 'page' => Request::input('page')]) }}" class="btn btn-secondary float-right"><i class="fas fa-angle-left"></i> Back to Listing</a>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content-header -->
        <section class="content">
            <div class="container-fluid">
                @include('layouts.common.messages')
                <form x-data="banners()" method="post" autocomplete="off" action="{{ route('banners.edit.post') }}" id="banner">
                    @csrf
                    <div class="row">
                        <div class="col-md-9">
                            <div class="card card-warning card-outline card-outline-tabs">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-sm-12">
                                            <label for="title">Title <span class="text-danger">*</span></label>
                                            <input data-meta="title" data-indep type="text" required id="title" name="title" class="form-control {{ $errors->has('title') ? 'is-invalid' : '' }}" value="{{ isset($banner->title) ? $banner->title : old('title') }}" />
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="border p-3 bg-gray-light " id="sort_sections" x-ref="sorters">

                                                <template x-for="(content, c) in contents">
                                                    <div class="sortable-item card col-12">
                                                        <div class="card-body">
                                                            <div class="row">
                                                                <div class="px-2 col-4">
                                                                    <div x-data="__images('images' + c, frontend_images(c), false)">
                                                                        <label>Desktop Image</label>
                                                                        <template x-if="images[0]">
                                                                            <div class="position-relative">
                                                                                <img loading="lazy" class="w-100 rounded" :src="images[0].file_url" :style="'height:175px;object-fit: cover;'">
                                                                                <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                                                                                    <!--- Create Trash Image button shown at hover ---->
                                                                                    <button type="button" class="btn btn-danger btn-sm" x-on:click="removeImage(0)">
                                                                                        <i class="fas fa-trash"></i>
                                                                                    </button>
                                                                                </div>
                                                                                <input type="hidden" :name="'contents[' + c + '][id]'" :value="images[0].id">
                                                                            </div>
                                                                        </template>
                                                                        <template x-if="!images[0]">
                                                                            <div class="no-sort d-flex justify-content-center"
                                                                                 style="height: 200px; width: 100%;">
                                                                                <div
                                                                                     class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                                                                                    <label @click.prevent="openingModal('#editModal')"
                                                                                           data-toggle="modal" data-drop="false" data-target="#editModal"
                                                                                           type="button" class="btn btn-outline-success btn-sm">
                                                                                        <i class="fas fa-plus"></i>
                                                                                    </label>
                                                                                </div>
                                                                            </div>
                                                                        </template>
                                                                    </div>

                                                                    <div class="mt-3" x-data="__images('images' + c + '_mob', mobile_images(c), false)">
                                                                        <label>Mobile Image</label>
                                                                        <template x-if="images[0]">
                                                                            <div class="position-relative">
                                                                                <img loading="lazy" class="w-100 rounded" :src="images[0].file_url" :style="'height:175px;object-fit: cover;'">
                                                                                <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                                                                                    <!--- Create Trash Image button shown at hover ---->
                                                                                    <button type="button" class="btn btn-danger btn-sm" x-on:click="removeImage(0)">
                                                                                        <i class="fas fa-trash"></i>
                                                                                    </button>
                                                                                </div>
                                                                                <input type="hidden" :name="'contents[' + c + '][mobile]'" :value="images[0].id">
                                                                            </div>
                                                                        </template>
                                                                        <template x-if="!images[0]">
                                                                            <div class="no-sort d-flex justify-content-center"
                                                                                 style="height: 200px; width: 100%;">
                                                                                <div
                                                                                     class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                                                                                    <label @click.prevent="openingModal('#editModal')"
                                                                                           data-toggle="modal" data-drop="false" data-target="#editModal"
                                                                                           type="button" class="btn btn-outline-success btn-sm">
                                                                                        <i class="fas fa-plus"></i>
                                                                                    </label>
                                                                                </div>
                                                                            </div>
                                                                        </template>
                                                                    </div>
                                                                </div>
                                                                <div class="col-8">
                                                                    <div class="form-group">
                                                                        <label>Description</label>
                                                                        <textarea class="form-control textEditor" rows="3" :name="'contents[' + c + '][meta_description]'" :value="content.meta_description"></textarea>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>Url</label>
                                                                        <input type="text" :name="'contents[' + c + '][meta_url]'" class="form-control" :value="content.meta_url" />
                                                                    </div>
                                                                    <!-- check box for new window -->
                                                                    <div class="form-group">
                                                                        <div class="custom-control custom-checkbox">
                                                                            <input :checked="content.target == '_blank'" class="custom-control-input" type="checkbox" :id="'new_window' + c" :name="'contents[' + c + '][target]'" value="_blank">
                                                                            <label :for="'new_window' + c" class="custom-control-label">Open in new window</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>Sort order</label>
                                                                        <input type="number" :name="'contents[' + c + '][meta_sort_order_banner]'" class="form-control" :value="content.meta_sort_order_banner" />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="text-right float-right">
                                                                <button type="button" class="btn btn-danger btn-sm" x-on:click="removeContent(c)">
                                                                    <i class="fas fa-trash"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </template>

                                                <div class="no-sort col-12 p-2 d-flex justify-content-center" style="min-height: 100px;">
                                                    <div class="bg-white border flex-fill justify-content-center shadow-sm rounded d-flex align-items-center">
                                                        <!-- Add Button !-->
                                                        <button @click.prevent="addContent()" type="button" class="btn btn-outline-success btn-sm mx-2">
                                                            <i class="fas fa-plus"></i>
                                                        </button>
                                                        <!-- <label @click="addVideo($event.target)" type="button" class="btn btn-outline-success btn-sm mx-2">
                                                                                                                                                                                                                                                                                                                                                                                                                                        <i class="fas fa-video"></i>
                                                                                                                                                                                                                                                                                                                                                                                                                                    </label> -->
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="col-md-3">
                            <div class="sticky-top mb-3">
                                @if ($can_update)
                                    <div class="card">
                                        <div class="card-body">
                                            <!-- the events -->
                                            <div class="row">
                                                <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-save"></i> Save</button>
                                                <a href="{{ route('banners.list', ['s' => Request::input('s'), 'limit' => Request::input('limit'), 'page' => Request::input('page')]) }}" class="btn btn-default btn-block"><i class="fas fa-times"></i> Cancel</a>
                                            </div>
                                        </div>
                                        <!-- /.card-body -->
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                    <input type="hidden" data-meta="id" data-indep name="id" id="id" value="{{ isset($banner->id) ? $banner->id : old('id') }}" />
                </form>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>


    </div>
    @include('layouts.common.media-multi', ['multiple' => false])
@endsection
