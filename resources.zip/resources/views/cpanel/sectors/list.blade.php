@extends('layouts.cpanel')
@php
    $user=Auth::user();
    $can_any_action=\App\Http\Helpers::getAccess($user, 'sectors', 'update,delete');

    $can_create=\App\Http\Helpers::getAccess($user, 'sectors', 'create');
    $can_update=\App\Http\Helpers::getAccess($user, 'sectors', 'update');
    $can_delete=\App\Http\Helpers::getAccess($user, 'sectors', 'delete');
@endphp
@section('content')
    <form method="GET" action="">
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-3">
            <div class="col-sm-12">
                <h3 class="m-0 text-dark">Sectors
                    @if($can_create)
                    <a href="{{route('sectors.create')}}" class="btn btn-default ml-2">
                        <i class="fa fa-plus"></i>
                        Add New</a>
                    @endif
                </h3>
            </div>
        </div>
    </div>
</section>
<section class="content">
    <div class="container-fluid">
        @include('layouts.common.messages')
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <form name="sectors" action="" method="get" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6">

                                </div>
                                <div class="col-md-3">

                                </div>
                                <div class="col-md-3">
                                    <div class="card-tools">
                                        <div class="input-group input-group-sm">
                                            <input type="text" name="s" value="{{Request::input('s')}}"
                                                class="form-control float-right" placeholder="Search">

                                            <div class="input-group-append">
                                                <button type="submit" class="btn btn-default">
                                                    <i class="fas fa-search"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover"  id="table-sort">
                            <thead>
                                <tr>
                                    <th width="3%">#.</th>
                                    @if($can_any_action)
                                    <th width="12%">Action</th>
                                    @endif
                                    <th width="40%">Name</th>
                                    <th width="30%">Slug</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($sectors as $sector)
                                <tr class="data" id="{{$sector->id}}">

                                    <td>{{($limit = $filter['limit'] ?? 0) * (($page = app('request')->input('page') ?? 1)
                                        - 1 )+$loop->iteration}}</td>
                                    @if($can_any_action)
                                    <td>
                                        <ul class="list-inline m-0">
                                            @if($can_update)
                                            <li class="list-inline-item sorting_1 dragHandle">
                                                <a href="javascript:" title="Drag to change order"
                                                   class="gray"><i
                                                class="fa fa-ellipsis-v"></i>&nbsp;
                                                    <i class="fa fa-ellipsis-v"></i></a></li>

                                            <li class="list-inline-item">
                                                <a href="{{ route('sectors.edit',['id'=>$sector->id,
                                                    's'=>Request::input('s'),
                                                    'limit'=>Request::input('limit'),
                                                    'page'=>Request::input('page')])
                                                    }}" data-toggle="tooltip" title="Edit"
                                                   class="text-primary"><i
                                                        class="far fa-edit"></i></a></li>
                                            @endif
                                            @if($can_delete)
                                            <li class="list-inline-item"><a
                                                    onclick="return confirm('Are you sure you want to delete this item?')"
                                                    href="{{route('sectors.destroy',
                                                            ['id'=>$sector->id])}}"
                                                    data-toggle="tooltip" title="Delete"
                                                    class="text-danger"><i
                                                        class="far fa-trash-alt"></i></a></li>
                                            @endif
                                            @if($can_update)
                                            <li class="list-inline-item">
                                                <div class="custom-control custom-switch
                                                custom-switch-off-danger custom-switch-on-success"
                                                    data-toggle="tooltip" title="Status">
                                                    <input type="checkbox" class="custom-control-input
                                                     changeStatus"
                                                        data-id="{{$sector->id}}"
                                                           data-status-type="sectors"
                                                        data-status="{{$sector->status}}"
                                                           {{ $sector->status=='Y' ?
                                                    'checked' : '' }} id="customSwitch_{{$loop->iteration }}">
                                                    <label class="custom-control-label"
                                                        for="customSwitch_{{$loop->iteration}}"></label>
                                                </div>
                                            </li>
                                            @endif
                                        </ul>
                                    </td>
                                    @endif
                                    <td>
                                        @if($can_update)
                                            <a href="{{route('sectors.edit',['id'=>$sector->id])}}"
                                                class="text-dark">{{$sector->title}}
                                            </a>
                                        @else
                                        {{$sector->title}}
                                        @endif
                                    </td>
                                    <td>{{$sector->slug}}</td>

                                </tr>
                                @empty
                                <tr>
                                    <td colspan="4" class="text-center">No records found!</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer clearfix">
                        <div class="row">
                            <div class="col-md-1">
                                <form action="{{ url()->full() }}">
                                    {{ Form::select('limit', ['5'=>5,'10'=>10,'25'=>25,'50'=>50,'100'=>100],
                                            request()->limit ? request()->limit :request()->limit, array(
                                        'class' => 'form-control input-sm page-limit',
                                        'id' => 'page_limit'
                                       ))
                                    }}
                                </form>
                            </div>
                            <div class="col-md-11">
                                <div class="d-flex justify-content-end">
                                    <span class="mr-3">Showing {{(($sectors->currentPage()-1)*$sectors->perPage())+1}}
                                        to
                                        {{((($sectors->currentPage()-1)*$sectors->perPage())==0)?$sectors->perPage():($sectors->currentPage())*$sectors->perPage()}}
                                        of {{$sectors->total()}} entries </span>
                                    {{ $sectors->appends(request()->except('page'))->links('pagination::bootstrap-4') }}
                                </div>
                            </div>
                            <div class="row mt-2">
                            <div class="col-sm-12 text-left">
                                <button class="btn btn-danger" id="update_order">
                                    Update Order
                                </button>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
    $(document).ready(function () {
        $('.page-limit').on('change', function () {
            $(this).closest('form').submit();
        });

        $('#table-sort').tableDnD({
            onDragStart: function(table, row) {
                $(row).closest('tr').addClass('bg-dark text-white border shadow');
            },
            onDragStop: function(table, row) {
                $(row).closest('tr').removeClass('bg-dark text-white border shadow');
            },
            dragHandle: ".sort-handler"
        });

        $('#update_order').click(function(){
        if ($('#table-sort tr.data').length > 0) {
            var ids = []; var statusType="sectors";
            $('#table-sort tr.data').each(function() {
                ids.push(parseInt($(this).attr('id')));
            });
            if (ids.length > 0 ){
                $.ajax({
                    url: "{{url('d-admin/ajax/changeOrder')}}",
                    method: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'sort_order',
                        ids:ids,
                        statusType: statusType
                    },
                    error: function(){
                        alert('Internal server error.!!');
                        location.reload();
                    },
                    success: function (data) {
                        if (data.status == 'success'){
                            alert('Order has been updated');
                            location.reload(true);
                        } else {
                            alert(data.message);
                            location.reload();
                        }
                    }
                });
            }
        }
    });
});
</script>
@endsection
