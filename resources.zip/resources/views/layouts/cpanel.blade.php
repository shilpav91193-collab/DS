<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dubai Aviation City Corporation</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{ asset('cpanel/css/bootstrap.min.css') }}">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{ asset('plugins/fontawesome-free/css/all.min.css') }}">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet"
          href="{{ asset('plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css') }}">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="{{ asset('plugins/icheck-bootstrap/icheck-bootstrap.min.css') }}">
    <!-- daterange picker -->
    <link rel="stylesheet" href="{{ asset('plugins/daterangepicker/daterangepicker.css') }}">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="{{ asset('plugins/overlayScrollbars/css/OverlayScrollbars.min.css') }}">
    <!-- summernote -->
    <link rel="stylesheet" href="{{ asset('plugins/summernote/summernote-bs4.min.css') }}">
    <!-- select2 -->
    <link rel="stylesheet" href="{{ asset('plugins/select2/css/select2.min.css') }}">
    <!-- select2 bootstrap4 -->
    <link rel="stylesheet" href="{{ asset('plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css') }}">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{ asset('cpanel/css/adminlte.min.css') }}">

    <!-- jQuery -->
    <script src="{{ asset('cpanel/js/jquery.min.js') }}"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="{{ asset('plugins/jquery-ui/jquery-ui.min.js')}}"></script>
    <!-- Summernote -->
    <script src="{{ asset('plugins/summernote/summernote-bs4.min.js')}}"></script>
    <script>
        var TOOLBAR =  [
            ['style', ['style','ul', 'ol',  'bold', 'italic', 'underline', 'clear']],
            ['view', ['link','fullscreen', 'codeview']]
        ];
        var STYLETAGS = [ 'p','h1', 'h2', 'h3', 'h4', 'h5', 'h6' ];
    </script>
    <!-- sortable -->
    <script src="{{ asset('plugins/sortable/jquery.sortable.min.js') }}"></script>
    @yield('head')
</head>

<body class="sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Preloader -->
    <!--  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="{{ asset('cpanel/img/AdminLTELogo.png') }}" alt="AdminLTELogo" height="60" width="60">
  </div>-->

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-dark sticky-top">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
{{--            @if(Auth::user()->roleid == 1)--}}
{{--                <li class="nav-item">--}}
{{--                    <a href="{{url('d-admin/posts/edit/116')}}" class="nav-link text-nowrap  checkSession" data-session="N">--}}
{{--                        <p>Home</p>--}}
{{--                    </a>--}}
{{--                </li>--}}

{{--                <li class="nav-item">--}}
{{--                    <a href="{{ route('posts.list',['post_type'=>'page']) }}" class="nav-link text-nowrap  checkSession" data-session="N">--}}
{{--                        <p>Pages</p>--}}
{{--                    </a>--}}
{{--                </li>--}}
{{--            @endif--}}
        </ul>

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">
            <!-- Navbar Search -->
            <li class="nav-item">
                <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                    <i class="fas fa-expand-arrows-alt"></i>
                </a>
            </li>
{{--            @if(Auth::user()->roleid == 1)--}}
{{--                <li class="nav-item">--}}
{{--                    <a class="nav-link" href="{{ route('settings.config') }}" role="button">--}}
{{--                        <i class="fas fa-cogs"></i>--}}
{{--                    </a>--}}
{{--                </li>--}}
{{--            @endif--}}
            <li class="nav-item">
                <div class="user-panel d-flex">
                    <div class="image">
                        <img src="{{ asset('cpanel/img/default-150x150.png')}}" class="img-circle" alt="User Image">
                    </div>
                    <div class="info">
                        <a href="#" class="d-block text-white"> {{ Auth::user()->name }}</a>
                    </div>
                </div>
            </li>
            <!-- Notifications Dropdown Menu -->

            <li class="nav-item">
                <a class="nav-link" href="{{ route('logout') }}" role="button" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                    @csrf
                </form>
            </li>
        </ul>
    </nav>
    <!-- /.navbar -->
    @include('layouts.common.left-side')
    <div class="content-wrapper">
        @yield('content')
    </div>

    <!-- /.content-wrapper -->
    <footer class="main-footer">
        <strong>Copyright &copy; {{date("Y")}} </strong>
        All rights reserved.
        <div class="float-right d-none d-sm-inline-block">
            <b>Dubai Aviation City Corporation</b>
        </div>
    </footer>
</div>
</body>

<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
    $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="{{ asset('plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<!-- Sparkline -->
<script src="{{ asset('plugins/sparklines/sparkline.js')}}"></script>
<!-- jQuery Knob Chart -->
<script src="{{ asset('plugins/jquery-knob/jquery.knob.min.js')}}"></script>
<!-- daterangepicker -->
<script src="{{ asset('plugins/moment/moment.min.js')}}"></script>
<!-- daterange picker -->
<script src="{{ asset('plugins/daterangepicker/daterangepicker.js')}}"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="{{ asset('plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')}}"></script>


<!-- select2 -->
<script src="{{ asset('plugins/select2/js/select2.full.min.js')}}"></script>
<!-- overlayScrollbars -->
<script src="{{ asset('plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')}}"></script>
<!-- AdminLTE App -->
<script src="{{ asset('cpanel/js/adminlte.min.js?v='.config('settings._version'))}}"></script>
<script src="{{ asset('cpanel/js/app.js?v='.config('settings._version'))}}"></script>
<script src="{{ asset('cpanel/js/pagebuilder.js?v='.config('settings._version'))}}"></script>
<script src="{{ asset('cpanel/js/webform.js?v='.config('settings._version'))}}"></script>
<script type="text/javascript" src="{{ asset('cpanel/js/jquery.tablednd.js')}}">
    <script src="{{ asset('cpanel/js/jquery.sortable.min.js')}}"></script>
<script type="text/javascript">
    $(document).ready(function(){

        $().customScript({
            baseUrl : "{!!URL::asset('d-admin')!!}/",
            apiUrl : "{!!URL::asset('api')!!}",
        });
        $().pagebuilder({
            url : "{!!URL::asset('d-admin/posts')!!}/",
        });
        $().webform({
            url : "{!!URL::asset('d-admin/webforms')!!}/",
        });

        $('#table-sort').tableDnD({
            onDragStart: function (table, row) {
                console.log(row);
            },
            onDrop: function (table, row) {
                console.log($.tableDnD);
            },
            dragHandle: ".dragHandle"
        });
    });
</script>
@if (Str::contains(Route::currentRouteName(), 'degree'))
    <script src="{{ asset('cpanel/js/degreebuilder.js?v='.config('settings._version'))}}"></script>
    <script>
        $(document).ready(function(){
            $().degreebuilder({
                url : "{!!URL::asset('d-admin/degrees')!!}/",
            });


        });
    </script>
@endif

@if (Str::contains(Route::currentRouteName(), 'events'))
    <script src="{{ asset('cpanel/js/eventbuilder.js?v='.config('settings._version'))}}"></script>
    <script>
        $(document).ready(function(){
            $().eventbuilder({
                url : "{!!URL::asset('d-admin/events')!!}/",
            });


        });
    </script>
    @endif
    </body>

</html>
