<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ config('app.name', 'Dubai Aviation City Corporation') }}</title>
    <link rel="icon" type="image/x-icon" href="{{asset('images/favicon.png')}}">

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{ asset('plugins/fontawesome-free/css/all.min.css') }}">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="{{ asset('plugins/icheck-bootstrap/icheck-bootstrap.min.css') }}">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{ asset('cpanel/css/adminlte.min.css') }}">
</head>

<body class="hold-transition login-page custom">
    <div class="login-box">
        <div class="login-logo">
            @if (file_exists('cpanel/img/admin-logo.png'))
            <img class="brand-image" style="opacity: .8; width:240px;" src="{{asset('cpanel/img/admin-logo.png')}}"
                alt="Logo">
            @else
            <a href="{{ url('/') }}"><b>{{ config('app.name', 'Dubai Aviation City Corporation') }}</b></a>
            @endif

        </div>
        @yield('content')

    </div>
    <!-- /.login-box -->

    <!-- jQuery -->
    <script src="{{ asset('cpanel/js/jquery.min.js') }}"></script>
    <!-- Bootstrap 4 -->
    <script src="{{ asset('plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <!-- AdminLTE App -->
    <script src="{{ asset('cpanel/js/adminlte.min.js') }}"></script>
</body>

</html>
