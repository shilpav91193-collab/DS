<link rel="stylesheet" href="{{ asset('cpanel/css/cropper.min.css') }}">
<script src="{{ asset('cpanel/js/cropper.min.js') }}"></script>
<script src="{{ asset('cpanel/js/jquery-cropper.min.js') }}"></script>
<style>
/* Ensure the size of the image fit the container perfectly */
.jquery-cropper-wrapper img {
  display: block;
  /* This rule is very important, please don't ignore this */
  max-width: 100%;
}
.sortable-placeholder {
    padding: 0.5rem!important;
    background: transparent !important;
    border: 0 !important;
    min-height: 100px;
    width: auto;
}
#images_shown > div, #sort_sections > div:not(.col-12) {
    width: 25% !important;
}
</style>
<div class="modal fade" tabindex="-1" role="dialog" id="editModal" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title">Add Image</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <div class="modal-body">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                  <a class="nav-link active"href="#existingImg" data-toggle="tab" aria-expanded="false">Select Image</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#newImg" data-toggle="tab" id="croTab" aria-expanded="false">Upload New</a>
                </li>
              </ul>
              <div class="tab-content">
                <div role="tabpanel" class="tab-pane fade container" id="newImg">
                    <div class="d-flex flex-column align-items-center" style="min-height: 100px;">
                        <div class="justify-content-center rounded p-3 mb-3 d-flex align-items-center">
                            <!-- Add Button !-->
                            <label x-show="!ajaxLoading"  for="imageAdder" type="button" class="btn btn-light border btn-sm mb-0">
                                <span x-text="imageCropping ? 'Change Image' : 'Upload Local File'"></span>
                                <input type="file" accept="image/*" name="" class="d-none" id="imageAdder" x-on:change="addImage($event.target)">
                            </label>
                            <button x-show="!ajaxLoading && imageCropping" class="btn btn-danger btn-sm ml-3" @click.prevent="uncropImage()">Remove</button>
                            <button x-show="!ajaxLoading && imageCropping" class="btn btn-success btn-sm ml-3" @click.prevent="uploadImage()">Upload Cropped</button>
                            <i x-show="ajaxLoading" :class="{ 'd-block': ajaxLoading }" class="fa fa-spinner fa-spin fa-lg text-success"></i>
                        </div>
                        <div class="jquery-cropper-wrapper">
                            <img id="imageCropped" alt="">
                        </div>
                    </div>
                </div>
                <div role="tabpanel" class="tab-pane fade show active container" id="existingImg">
                    <div class="row bg-gray-light">

                        <div class="col-12">
                            <div x-show="shownImages().length" id="images_shown" :class="{ 'd-flex': shownImages().length }" class="border p-3 bg-gray-light flex-wrap" x-ref="sortable_images_selected">
                                <template x-if="imagesShouldbeShownNow">
                                    <template x-for="(image, i) in shownImages()">
                                        <div class="p-2 position-relative" :style="'height:' + $refs.sortable_images_selected.querySelectorAll('.position-relative')[i].offsetWidth + 'px'" style="width: 25%;">
                                            <img loading="lazy" @click="addImageTo(image)" role="button" class="h-100 w-100 shadow-sm rounded border bg-white hover-gray" style="object-fit: contain;" :src="image.file_url">
                                            <div class="position-absolute p-2" style="right: 0; bottom: 0;">
                                                <!--- Create Trash Image button shown at hover ---->
                                                <button type="button" class="btn btn-primary btn-sm" x-on:click="editImage(i)">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button type="button" class="btn btn-danger btn-sm" x-on:click="confirm('Deleting this from here might cause deleting it from everywhere it is used previously! Are you sure?') && deleteImage(i)">
                                                    <i x-show="deleteLoading != image.id" class="fas fa-trash"></i>
                                                    <i x-show="deleteLoading == image.id" class="fas fa-spinner fa-spin"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </template>
                                </template>
                            </div>

                        <template x-if="!shownImages().length">
                            <div class="col-12 p-3">
                                <div class="alert alert-light">
                                    No Images! Please Add Image from the Upload New tab.
                                </div>
                            </div>
                        </template>
                        </div>
                    </div>
                </div>
              </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Discard Changes & Close</button>
        </div>
    </div>
    </div>
</div>
<script src="{{ asset('cpanel/js/alpine.min.js') }}" defer></script>
<script>
    window.images___list = [];
    window.multipleImages____ = {{ $multiple ? 'true' : 'false' }};
    function images() {
    var allImages = {!! $images->toJson() !!};
    
    var images = window.images___list;
    var featuredImages = {!! json_encode([($post->image ?? false)]) !!}.filter(i => i);
    @if(old('image'))
        images = {!! json_encode([(old('image') ?? false)]) !!}.filter(i => i);
    @endif
    return {
        init(imagesProps = false) {
            images = imagesProps || images;
            var self = this;
            this.$watch('images', (images) => {
                $( "#sort_sections" ).sortable('refresh');
            });
            $('.nav-tabs a:first').on('shown.bs.tab', function (e) {
                self.imagesShouldbeShownNow = true;
            });
            $('.nav-tabs a:first').on('hide.bs.tab', function (e) {
                self.imagesShouldbeShownNow = false;
            });
            $('#editModal').on('shown.bs.modal', function (e) {
                if ($('.nav-tabs a:first').is('.active'))
                    self.imagesShouldbeShownNow = true;
                else
                self.imagesShouldbeShownNow = false;
            });
            $('#editModal').on('hide.bs.modal', function (e) {
                self.imagesShouldbeShownNow = false;
            });
        },
        imagesShouldbeShownNow: false,
        images: window.images___list.map(id => allImages.find(image => image.id == id)),
        featuredImages: featuredImages.map(id => allImages.find(image => image.id == id)),
        allImages: allImages,
        imageDrop: false,
        shownImages() {
            var imagesList = 'images';
            if (this.imageDrop == 'featured') {
                imagesList = 'featuredImages';
            }
            var images_ = this.allImages.filter(image => {
                return !this[imagesList].map(img => img.id).includes(image.id);
            });
            return images_;
        },
        removeImage(index, featured = false) {
            var imagesList = 'images';
            if (this.imageDrop == 'featured' || featured) {
                imagesList = 'featuredImages';
            }
            this[imagesList].splice(index, 1);
        },
        deleteLoading: false,
        deleteImage(index) {
            if (this.deleteLoading) {
                return;
            }
            var id = this.shownImages()[index].id;
            var link = this.shownImages()[index].file_url;
            $.ajax({
                url: "{{ route('galleries.removeImage') }}",
                type: "POST",
                data: {
                    id: id,
                    _token: "{{ csrf_token() }}",
                    link: link,
                },
                beforeSend: function () {
                    this.deleteLoading = id;
                }.bind(this),
                success: function(response) {
                    console.log(response)
                    if (response.status) {
                        this.allImages = this.allImages.filter(image => id != image.id);
                    }
                }.bind(this),
                error: function(response) {}.bind(this),
                complete: function() {
                    this.deleteLoading = false;
                }.bind(this)
            });
        },
        adding: false,
        addImageTo(image) {
            var imagesList = 'images';
            if (this.imageDrop == 'featured') {
                imagesList = 'featuredImages';
            }
            var id = image.id;
            if (this.adding || this.images.map(i => i.id).includes(id)) {
                return;
            }
            this.adding = true;
            if (window.multipleImages____) {
                this[imagesList].push(image);
            } else {
                this[imagesList] = [image];
            }
            this.$nextTick(() => {
                this.adding = false;
            });
            $('#editModal').modal('hide');
        },
        uncropImage(force = false) {
            if(this.cropper) {
                this.cropper.destroy();
            }
            this.$nextTick(() => {
                $('#imageCropped').removeAttr('src');
                this.imageCropping = false;
                this.cropper = false;
                this.ajaxLoading = false;
            });
        },
        cropper: false,
        imageCropping: false,
        initCropper(url) {
            var $image = document.getElementById('imageCropped');
            var new_image = new Image();
            new_image.src = url;
            $image.src = url;
            new_image.onload = () => {

                if(this.cropper) {
                    this.cropper.replace(url);
                    this.$nextTick(() => this.ajaxLoading = false);
                    return true;
                }

                this.cropper = new Cropper($image, {
                    viewMode: 3,
                    autoCropArea: 1,
                    crop: function(event) {
                        // do nothing
                    }
                });

                // Get the Cropper.js instance after initialized
                // this.cropper = $image.data('cropper');
                this.ajaxLoading = false;
                this.imageCropping = $image;
            };
        },
        ajaxLoading: false,
        addImage(input) {
            var files = input.files;
            if (!files.length || this.ajaxLoading || input.value === '') {
                return;
            }
            if (files[0].size > 2048 * 1024) {
                input.value = '';
                alert('Image should be less than 2MB');
                return false;
            }

            this.ajaxLoading = true;

            let reader = new FileReader();
            reader.readAsDataURL(files[0]);
            reader.onload = () => {
                this.initCropper(reader.result);
            };
        },
        editImage(i) {
            var aa = $('.nav-tabs a:last').tab('show');
            console.log(aa);
            this.$nextTick(()=>{
                this.initCropper(this.shownImages()[i].file_url);
            });
        },
        uploadImage() {
            if (this.cropper && !this.ajaxLoading) {
                this.ajaxLoading = true;
                this.cropper.getCroppedCanvas().toBlob((blob) => {
                    var formData = new FormData();

                    formData.append('_token', "{{ csrf_token() }}");
                    formData.append('image', blob);
                    $.ajax({
                        url: "{{ route('galleries.uploadImage') }}",
                        type: "POST",
                        data: formData,
                        processData: false,
                        contentType: false,
                        beforeSend: function() {
                            this.ajaxLoading = true;
                        }.bind(this),
                        success: function(response) {
                            if (response.status == 'success') {
                                this.allImages.unshift(response.image);
                                this.uncropImage();
                                $('.nav-tabs a:first').tab('show');
                            }
                        }.bind(this),
                        error: function(response) {
                            alert('Something went wrong, please try again!');
                        }.bind(this),
                        complete: function() {
                            this.ajaxLoading = false;
                        }.bind(this)
                    });
                }, 'image/jpeg');
            } else {
                alert('Error');
            }
        },
        imagesData() {
            return JSON.stringify(this.images.map(img => img.id));
        }
    };
}
</script>
