<div class="form-group col-sm-6">
    <label for="featured_homepage">Show on top</label><br />
    <div class="icheck-primary d-inline-block">
        <input type="radio" id="featured_homepage_1" name="featured" value="Y" {{ (($result->featured ?? null) == 'Y') ? 'checked' : ''}}>
        <label for="featured_homepage_1">
            Yes &nbsp;&nbsp;&nbsp;
        </label>
      </div>
      <div class="icheck-danger d-inline-block">
        <input type="radio" id="featured_homepage_2" name="featured" value="N" {{ (($result->featured ?? null) == 'N'  || ($result->featured ?? null)==null) ? 'checked' : ''}}>
        <label for="featured_homepage_2">
          No
        </label>
      </div>
  </div>
