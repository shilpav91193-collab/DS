<div class="card mt-4" id="{{ $id }}">

    <div class="card-header p-0 border-bottom-0">
        <div>
            @if ($title ?? 0)
                <div class="px-3 my-3 border-bottom">
                    <h5 class="h5 mb-3">{{ $title }}</h5>
                </div>
            @endif
            <ul class="nav nav-tabs" id="custom-tabs-sections-{{ $id }}" role="tablist">
                @foreach ($tabs as $key => $tab)
                    @php
                        if (!empty($prefix)) {
                            $key = $prefix . $key;
                        }
                        if (!empty($suffix)) {
                            $key = $key . $suffix;
                        }
                        $key_name = $key;
                        if (!empty($is_meta)) {
                            $key = 'meta[' . $key . ']';
                        }
                    @endphp
                    <li class="nav-item d-flex items-center">
                        <a class="nav-link text-center d-flex align-items-center {{ $loop->first ? 'active' : '' }}"
                           id="custom-tabs-{{ $key_name }}-tab-{{ $id }}" data-toggle="tab" href="#custom-tabs-{{ $key_name }}-{{ $id }}"
                           role="tab" aria-controls="custom-tabs-{{ $key_name }}" aria-selected="true">
                            @if (count($tabs) > 6)
                                {!! implode('<br>', explode(' ', $tab)) !!}
                            @else
                                {{ $tab }}
                            @endif
                        </a>
                    </li>
                @endforeach
            </ul>
        </div>
    </div>

    <div class="card-body">
        <div class="row">
            <div class="form-group col-sm-12">
                <div class="tab-content">
                    @foreach ($tabs as $key_ => $tab)
                        @php
                            $copy_key=$key_;
                            $old_value = old($key_, $data->$key_ ?? '');
                            if (!empty($prefix)) {
                                $key_ = $prefix . $key_;
                            }
                            if (!empty($suffix)) {
                                $key_ = $key_ . $suffix;
                            }
                            $key_name = $key_;
                            if (!empty($is_meta)) {
                                $key_ = 'meta[' . $key_ . ']';
                                $old_value = old('meta.' . $key_name, $data->meta->$key_name ?? '');
                            }
                        @endphp
                        <div class="tab-pane fade show {{ $loop->first ? 'active' : '' }}"
                             id="custom-tabs-{{ $key_name }}-{{ $id }}" style="min-height: 250px;">
                            <div class="section mb-4 p-0 h-100">
                                <div class="form-group">
                                    <label>{{ ucfirst($contents_text ?? 'Content') }}</label>
                                    <textarea name="{{ $key_ }}" class="form-control textEditor" cols="40" rows="4"
                                              placeholder="">{{ $old_value }}</textarea>
                                </div>
                                @if($seo ?? false)
                                        @php $meta_title="meta_title_".$copy_key; 
                                        $meta_keyword="meta_keyword_".$copy_key; 
                                        $meta_description="meta_description_".$copy_key; 
                                        $old_seo_title = old('meta.' . $meta_title, $data->meta->$meta_title ?? ''); 
                                        $old_seo_keyword = old('meta.' . $meta_keyword, $data->meta->$meta_keyword ?? ''); 
                                        $old_seo_description = old('meta.' . $meta_description, $data->meta->$meta_description ?? ''); 
                                    @endphp
                                      <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">SEO Content</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="form-group">
                                                <label for="excerpt">Page Title</label>
                                                <input type="text" name="meta[meta_title_{{$copy_key}}]"
                                                    value="{{$old_seo_title}}"
                                                    id="meta_title" class="form-control" placeholder="Enter the SEO title" />
                                            </div>
                                            <div class="form-group">
                                                <label for="excerpt">Keywords</label>
                                                <textarea name="meta[meta_keyword_{{$copy_key}}]" id="meta_keyword" class="form-control"
                                                    cols="40" rows="4"
                                                    placeholder="Enter the SEO keywords">{{$old_seo_keyword}}</textarea>
                                            </div>
                                            <div class="form-group">
                                                <label for="excerpt">Description</label>
                                                <textarea name="meta[meta_description_{{$copy_key}}]" id="meta_description"
                                                    class="form-control" cols="40" rows="4"
                                                    placeholder="Enter the SEO description">{{$old_seo_description}}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                @endif

                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>

</div>
