<!-- Main Sidebar Container -->
<aside class="main-sidebar elevation-4">
    <div class="py-2 navbar-white">
        @if (file_exists('cpanel/img/admin-logo.png'))
        <img class="brand-image ml-3" style="opacity: .8; height:40px;"
            src="{{asset('cpanel/img/admin-logo.png')}}" alt="Logo">
        @else
        <img class="brand-image ml-3" style="opacity: .8; height:40px;"
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAACkCAMAAAApKatmAAAANlBMVEX////Pz8/z8/Pn5+fv7+/Dw8P7+/vBwcG/v7/f39/Ly8vHx8fX19f39/fj4+Pr6+vT09Pb29uNqvcgAAACZ0lEQVR42u2c2XKcMBAAAR1BnMv//2xAWl0su45fnCHpfjFMQZmukWYklctNAwAAAAAAAAAAAAAAAPfk1wf+5i/HDTfcbugmsLzhhhtuuOGGG2644YYbbrjhhhtuuOEm+ZMAAAAAACChF+eW7jqsX8Kdcs5pK0yh33HnqHWm94zuMmxcpaHGEO6nWbxb91Q4GPLndmMRzim1bQ6bVbhbqbZ/rv0ctkMZ7lfRbtY7jIvWm79qn+GQtcmpbSzCjc+a2bRefNjMkt0eXqHIifLXzhv7oWinHFZ+hIYk+vBDsJsuk9J5oZRNE2fZkCTGMlc+c51ct6maNY94t1QPrsddStuUCmZ1J8/N56d5+Vo/rXLlb53SyT31O5vSLNKtK4dk08x+Ou0X8ecJExOYx2o/S3VTp0AfPr57UyZOynUapbm5U2AIY/F6/VIXnvj2che3NmSieM5F9Bs3d1+3tARx/4Sb/Zab2DG5fqgl7YvbvWrJqQfYsgeEzqUP4munHtCK7gGn3r3G3l13LhtfOyWqr14WvuaartdcqQvea82lyymU18pzuWkL+x2XFiZzGRa8Vg5zZiq2oypnMGxm7CPVklAZn+HhVDUluGXaJLTvTdepLz529mEzKbWZXCefE/HYm4awtL1p7RZmTT4ZseVkSg+O0a0+ahDTAN64NcpcqFVyg13SUC6PiEzXCHdr5ul5P6rqkCieaG326ALui6M9qVi9L4bVSxbmdQ+v9k+PZAEAAAAA4Kfh78xxww033HDDDTfccMMNN9xwww033HDD7QZu/N9Q3HDDDQAAAAAAAAAAAAAA/nN+A8sjPnLYr00zAAAAAElFTkSuQmCC"
            alt="Logo">
        @endif
    </div>

    <!-- Sidebar -->
    <div class="sidebar">

        <!-- Sidebar Menu -->
        <nav class="mt-3">
            <ul class="nav nav-pills nav-sidebar flex-column nav-compact" data-widget="treeview" role="menu"
                data-accordion="false">
                <li class="nav-item">
                    <a href="{{route('dashboard')}}" class="nav-link text-nowrap  checkSession" data-session="N">
                        <i class="fas fa-tachometer-alt"></i>
                        <p>My Dashboard</p>
                    </a>
                </li>

                @php
                    if (!\Illuminate\Support\Facades\Auth::check()) {
                            header("Location: " . url('admin'), true, 302);
                            exit();
                    }
                    $current_outlet = '';

                    $modules = \App\Models\Module::where('modules.requireSession','N')
                                ->whereStatus('Y')
                                ->orderBy('display_order')
                                ->get();

                    $object_access = \App\Models\UserRole::select('access')
                                       ->whereId(\Illuminate\Support\Facades\Auth::user()->roleid)
                                       ->first();

                    $module_access= (isset($object_access->access)) ?
                     (array) json_decode($object_access->access) :
                      null;

                    $data_access = isset($module_access['module_access']) ?
                     array_keys((array) $module_access['module_access']) :
                      [];

                    $full_url = url()->full();
                    $base_url = url('/');
                    $request_path = str_replace($base_url.'/',"",$full_url);
                @endphp

                @if($modules)
                    @foreach($modules as $module)
                        @php
                            $module_id = $module->id;
                            $show = \App\Http\Helpers::checkModule($module_id,$data_access);
                        @endphp
                        @php
                            $sub_modules = \App\Models\ModuleItem::select('module_items.*')
                            ->join('modules as m', function($join) use ($module_id){
                                $join->on('module_items.module_id','=','m.id')
                                    ->where('module_items.module_id','=', $module_id);
                            })
                            ->where('module_items.status','=','Y')
                            ->orderBy('module_items.display_order')
                            ->get();

                            $has_treeview = count($sub_modules)? 'has-treeview' : '';
                        @endphp

                        @if(count($sub_modules))
                            @if($show)
                                <li class="nav-item {{ $has_treeview }}" id="{{$module->slug}}">
                                    <a href="{{url($module->link)}}" class="nav-link text-nowrap">
                                        <i class="{{$module->icon}}"></i>
                                        <p>{{$module->name}} &nbsp
                                            &nbsp;<em class="badge badge-danger"></em>
                                            <i class="right fas fa-angle-left"></i>
                                        </p>
                                    </a>
                                    @if($has_treeview)
                                        <ul class="nav nav-treeview">
                                            @foreach($sub_modules as $sub_item)
                                                @if(in_array($sub_item->slug,$data_access))
                                                    <li class="nav-item">
                                                        <a href="{{url($sub_item->link)}}"
                                                            class="nav-link
                                                            {{( $request_path == $sub_item->link ) ? 'active' : '' }}
                                                            checkSession"
                                                            data-session="{{$sub_item->requireSession}}">
                                                            &nbsp;&nbsp;<i class="{{$sub_item->icon}}"></i>
                                                            <p>{{$sub_item->name}}</p>
                                                        </a>
                                                    </li>
                                                @endif
                                            @endforeach
                                        </ul>
                                   @endif
                                </li>
                            @endif
                        @else
                            @php
                                $independent_module = \App\Http\Helpers::checkParentModule($module_id,$data_access);
                            @endphp
                            @if ($independent_module)

                                <li class="nav-item">
                                    <a href="{{url($module->link)}}"
                                        class="nav-link text-nowrap
                                         {{ stripos($request_path,$module->slug)!==false ? 'active' : '' }}
                                         checkSession"
                                        data-session="{{$module->requireSession}}">
                                        <i class="{{$module->icon}}"></i>
                                        <p>{{$module->name}}</p>
                                    </a>
                                </li>
                            @endif
                        @endif
                    @endforeach
                @endif
            </ul>
        </nav>
    </div>
</aside>
