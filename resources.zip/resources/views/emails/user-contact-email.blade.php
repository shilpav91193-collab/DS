

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <style type="text/css">
        body {
            margin: 0;
            padding: 0;
        }

        table, td, tr {
            vertical-align: top;
        }

        * {
            line-height: inherit;
        }

        .table td {
            padding: 0px !important;
            margin: 0px !important;
        }

        .w100 {
            width: 100%;
        }
    </style>
    <style type="text/css" id="media-query">
        @media (max-width: 670px) {
            .block-grid, .col {
                min-width: 320px !important;
                max-width: 100% !important;
                display: block !important;
            }

            .block-grid {
                width: 100% !important;
            }
        }
    </style>
</head>
<body bgcolor="#ffffff" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<br>
<div class="block-grid three-up"
     style="margin: 0 auto; min-width: 320px; max-width: 650px; overflow-wrap: break-word; word-wrap: break-word; word-break: break-word; background-color: #ffffff;">
    <div style="display: table;width: 100%;background-color:#ffffff;">
        <!--[if (mso)|(IE)]>
        <table width="650" border="0" cellspacing="0" cellpadding="0" align="center">
            <tr>
                <td align="center" valign="top" bgcolor="#FFFFFF"><![endif]-->
        <table width="100%" border="0" cellspacing="0" cellpadding="1">
            <tr>
                <td bgcolor="#004169">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF">
                        <tr>
                            <td  valign="middle" style="padding: 0 30px; " bgcolor="#004169">
                                <table width="100%" border="0"  cellpadding="0" cellspacing="0"
                                       bgcolor="#004169">
                                    <tr>
                                        <td  valign="top">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td  valign="top">
                                            <img src="{{ $logoImage }}" width="200"
                                                 style="margin:0; padding:0; display:block; line-height:0;">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td  valign="top">&nbsp;</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td  valign="top" style="padding:0 30px;">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td  valign="top">
                                            <br/>
                                            Dear {{$attributes['first_name']}} {{$attributes['last_name']}},
                                            <br />
                                            <br />
                                            Thank you for visiting our website and making an enquiry.
                                            This email is to confirm that we have received the same and shall get back to you within 3 working days.
                                            </a>

                                            <br />
                                            <br />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td  valign="top">
                                            <br/>
                                                Thank you, <br> Team – DACC
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td height="30"  valign="top">&nbsp;</td>
                        </tr>
                        <tr>
                            <td  valign="bottom"
                                style="padding: 0px 30px; background-color: #004169;">
                                <table width="50%" border="0"  cellpadding="0" cellspacing="0">
                                    <tr>
                                        <td  valign="top">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td  valign="top">
                                            <p style="color:#fff; font-size:14px; line-height: 18px; margin: 0; padding: 0; font-family: Arial, Helvetica, sans-serif;">
                                                <a href="https://www.dacc.com" target="_blank"
                                                   style="color: #fff; text-decoration: none;">www.dacc.com</a>
                                            </p></td>
                                    </tr>
                                    <tr>
                                        <td  valign="top">&nbsp;</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>


                </td>
            </tr>
        </table>
        <!--[if (mso)|(IE)]></td></tr></table><![endif]-->
    </div>
</div>
<br>
</body>
</html>


