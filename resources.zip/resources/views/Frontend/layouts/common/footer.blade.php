<footer>
    <div class="container-fluid bg-dblue text-white pb-4 pb-md-0">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-11">
                <div class="row pt-5">
                    <div class="col-md-12 col-lg-4 mb-3">
                        <h4><strong>{{config('settings._footer_text') ?? 'About DACC'}}</strong></h4>
                        <p class="mt-2">{{config('settings._footer_text_content') ?? ''}}</p>

                    </div>
                    <div class="col-md-6 col-md-4 col-lg-4 mb-3 ps-lg-5">
                        <h4><strong>{{config('settings._address') ?? 'Office Address'}}</strong></h4>
                        @if(config('settings._address_content'))
                                {!! config('settings._address_content') !!}
                        @endif
                        <h4><strong>{{config('settings._office_hours_text') ?? 'Office Hours'}}</strong></h4>
                        @if(config('settings._office_hours_content'))
                            {!! config('settings._office_hours_content') !!}
                        @endif
                    </div>
                    <div class="col-md-6 col-lg-4 mb-3 footer-map">
                        <h4><strong>{{ __('label.location') }}</strong></h4>
                        <iframe class="mt-2"
                                src="{{config('settings._google_map') ?? 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2151.654932510982!2d55.117788107908794!3d24.910337211357565!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f0ca11145b885%3A0x4ce897a92c258fd7!2sDubai%20South%20Office%20Headquarters!5e0!3m2!1sen!2sae!4v1693220825605!5m2!1sen!2sae'}}"
                                width="100%" style="border:0;" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                        <p class="mt-2">{{ __('label.location_us_on') }}</p>
                    </div>
                    <div class="col-12">
                        <hr />
                    </div>
                    <div class="col-sm-7 mb-3 copyrights">
                        {{ __('label.copy-right') }}
                    </div>
                    <div class="col-sm-5 mb-3 copyrights ar-text-align">
                        <a href="javascrip:void(0);">{{ __('label.privacy_policy') }}</a> |
                        <a href="javascrip:void(0);">{{ __('label.terms-and-condition') }}</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
