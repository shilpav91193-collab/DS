<div class="row justify-content-center banner">
    <div class="col-12 p-0">
        <div class="slider banner-slider">
            @foreach($banners as $banner)
                <div>
                    <figure>
                        <img src="{{isset($banner['file_url_desktop']) ?
                        $banner['file_url_desktop'] : ''}}" class="d-none d-md-block" alt="">
                        <img src="{{isset($banner['file_url_mobile']) ?
                        $banner['file_url_mobile'] : ''}}" class="d-md-block d-md-none">
                    </figure>
                    @if(isset($banner['meta_description']))
                        <figcaption>
                            <div class="row justify-content-center">
                                <div class="col-11">
                                    {!! $banner['meta_description'] !!}
                                </div>
                            </div>
                        </figcaption>
                    @endif
                </div>
            @endforeach
        </div>
        <a href="#tab-diversified" class="scroll-down js-scroll-trigger">
            <img src="{{ asset('frontend/images/scroll-2.png') }}" alt="">{{ __('label.scroll') }}</a>
    </div>
</div>
