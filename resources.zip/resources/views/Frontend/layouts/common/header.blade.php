<header>
    @php
        $locale = App::getLocale() ? App::getLocale() : 'en';
    @endphp
    <div class="container-fluid" id="top">
        <div class="row justify-content-center">
            <div class="col-lg-11">
                <div class="row">
                    <div class="col-sm-3 text-center">
                        <div class="logo">
                            <a href="{{ url("/".$locale) }}">
                                <img src="{{ asset('frontend/images/logo-w2.png') }}" alt="logo">
                            </a>
                        </div>
                    </div>
                    <div class="col-sm-9 column-reverse">
                        <div class="upper-menu">
                            <a href="#" data-bs-toggle="modal" data-bs-target="#search-panel">
                                <img src="{{ asset('frontend/images/search.png') }}">
                            </a>
                            <div class="dropdown accessibility">
                                <a class="nav-link dropdown-toggle" href="#" id="Accessibility" role="button"
                                   data-bs-toggle="dropdown" aria-expanded="false">
                                    <img src="{{ asset('frontend/images/accesssibility.png') }}"> Accessibility
                                </a>
                                <ul class="dropdown-menu shadow dropdown-menu-end" aria-labelledby="language"
                                    style="min-width: unset;">
                                    <li><a class="dropdown-item" href="javascript:void(0)"
                                           id="increase">A<sup>+</sup></a></li>
                                    <li><a class="dropdown-item" href="javascript:void(0)" id="normal">A</a></li>
                                    <li><a class="dropdown-item" href="javascript:void(0)"
                                           id="decrease">A<sup>-</sup></a></li>
                                    <li><a class="dropdown-item" href="javascript:void(0)" id="greyscale">
                                            <img src="{{ asset('frontend/images/bw_icon.png') }}"></a></li>
                                </ul>
                            </div>

                            <div class="dropdown language">
                                <a class="nav-link dropdown-toggle" href="#" id="language" role="button"
                                   data-bs-toggle="dropdown"
                                   aria-expanded="false">
                                    <strong>EN</strong>
                                </a>
                                <ul class="dropdown-menu shadow dropdown-menu-end" aria-labelledby="language"
                                    style="min-width: unset;">
                                    <li><a class="dropdown-item" href="#">AR</a></li>
                                </ul>
                            </div>

                        </div>


                        <nav class="navbar navbar-expand-xl">

                            <button class="navbar-toggler custom-toggler" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown"
                                    aria-expanded="false"
                                    aria-label="Toggle navigation">
                                <i class="fa-solid fa-bars"></i>
                            </button>


                            <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
                                <ul class="navbar-nav">
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink"
                                           role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            Who We Are
                                        </a>
                                        <div class="row justify-content-center dropdown-menu animate slideIn">
                                            <div class="col-lg-12">
                                                <div class="row">
                                                    <div class="col-lg-5 px-5 my-lg-4 border-menu">
                                                        <h3 class="text-white text-uppercase"><strong>Who We
                                                                Are</strong></h3>
                                                    </div>
                                                    <div class="col-lg-5 my-lg-4">
                                                        <ul class="" aria-labelledby="navbarDropdownMenuLink">
                                                            <li>
                                                                <a class="dropdown-item" href="{{ url($locale."/about-us") }}">About DACC</a>
                                                            </li>
                                                            <li>
                                                                <a class="dropdown-item" href="{{ url($locale."/our-leadership") }}">Our Leadership</a>
                                                            </li>
                                                            <li>
                                                                <a class="dropdown-item" href="{{ url($locale.'/our-roles') }}">Our Roles</a>
                                                            </li>
                                                            <li>
                                                                <a class="dropdown-item" href="{{ url($locale."/our-groups") }}">Our Groups</a>
                                                            </li>
                                                            <li>
                                                                <a class="dropdown-item" href="{{ url($locale.'/our-footprint') }}">Our Footprint</a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </li>

                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink"
                                           role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            What We Do</a>

                                        <div class="row justify-content-center dropdown-menu animate slideIn">
                                            <div class="col-lg-12">
                                                <div class="row">

                                                    <div class="col-lg-5 px-5 my-lg-4 border-menu">
                                                        <h3 class="text-white text-uppercase"><strong>What We
                                                                Do</strong></h3>
                                                    </div>
                                                    <div class="col-lg-5 my-lg-4 menu-grid">
                                                        <ul class="" aria-labelledby="navbarDropdownMenuLink">
                                                            @foreach(Helpers::getAllSectors() as $sector)
                                                                @php
                                                                    $sector->meta = $sector->meta();
                                                                @endphp
                                                                <li>
                                                                    <a class="dropdown-item"
                                                                       href="{{ url("/$locale/sectors/$sector->slug") }}"><span
                                                                            class="{{ isset($sector->meta->icon_class) ? $sector->meta->icon_class : '' }}"></span>{{$sector->title}}
                                                                    </a>
                                                                </li>
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </li>


                                    <li class="nav-item dropdown">

                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink"
                                           role="button" data-bs-toggle="dropdown" aria-expanded="false">Our
                                            Districts</a>

                                        <div class="row justify-content-center dropdown-menu animate slideIn">
                                            <div class="col-lg-12">
                                                <div class="row">
                                                    <div class="col-lg-5 my-lg-4 px-5 border-menu">
                                                        <h3 class="text-white  text-uppercase"><strong>Our
                                                                Districts</strong></h3>
                                                    </div>
                                                    <div class="col-lg-5 my-lg-4">
                                                        <ul class="" aria-labelledby="navbarDropdownMenuLink">
                                                            @foreach(Helpers::getAllDistricts() as $district)
                                                                <li>
                                                                    <a class="dropdown-item"
                                                                       href="{{ url("/$locale/districts/$district->slug") }}">{{$district->title}}
                                                                    </a>
                                                                </li>
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                    </li>
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink"
                                           role="button" data-bs-toggle="dropdown" aria-expanded="false">Our Airports</a>

                                        <div class="row justify-content-center dropdown-menu animate slideIn">
                                            <div class="col-lg-12">
                                                <div class="row">
                                                    <div class="col-lg-5 my-lg-4 px-5 border-menu">
                                                        <h3 class="text-white  text-uppercase"><strong>
                                                                Our Airports</strong></h3>
                                                    </div>
                                                    <div class="col-lg-5 my-lg-4">
                                                        <ul class="" aria-labelledby="navbarDropdownMenuLink">
                                                            @foreach(Helpers::getAllAirports() as $airport)
                                                                <li>
                                                                    <a class="dropdown-item"
                                                                       href="{{ url("/$locale/airports/$airport->slug") }}">{{$airport->title}}
                                                                    </a>
                                                                </li>
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url($locale.'/newsroom') }}">Newsroom</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ url($locale.'/contact-us') }}">Contact Us</a>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
