<section class="section">
<div class="container py-5">
@php
$tabs = $sections->pluck('title')->toArray();
@endphp
<div class="d-flex flex-wrap">
    <ul class="nav nav-pill list-inline themeTab" role="tablist">
        @foreach ($tabs as $tab)
        @php
        $slug = Str::slug($tab . '_' . $loop->index);
        @endphp
        <li class="nav-item list-inline-item">
            <a class="nav-link @if($loop->first) active @endif" href="#{{ $slug }}_tab" role="tab" data-bs-toggle="tab">{{ $tab }}</a>
        </li>
        @endforeach
        </ul>
</div>
<div class="tab-content py-4 content">
    @foreach ($sections as $section)

    @php
    if ($section->allBlocks->isEmpty()) {
    continue;
    }
    $section->meta = (object) $section->metas->pluck('meta_value', 'meta_key')->all();
    @endphp

    @php
    $slug = Str::slug(($section->title ?? '') . '_' . $loop->index);
    @endphp
    <div role="tabpanel" class="tab-pane fade show @if($loop->first) active @endif" id="{{ $slug }}_tab"> 
    @include('Frontend.layouts.common.pagebuilder.section_blocks', ['section' => $section])
    </div>

    @endforeach
</div>

</div>
</section>
