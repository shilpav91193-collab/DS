@php
    if ($result->allSections->isEmpty()) {
        return;
    }
    $first_section_type = $result->allSections->first()->type ?? 'plain';
    $section_types = ['plain', 'accordion', 'tabs'];

    $section_types = array_merge([$first_section_type], array_diff($section_types, [$first_section_type]));
@endphp
@foreach ($section_types as $section_type)
    @if(!$result->allSections->where('type', $section_type)->isEmpty())
        @include('Frontend.layouts.common.pagebuilder.section_' . $section_type, ['sections' =>
        $result->allSections->where('type', $section_type)])
    @endif
@endforeach
