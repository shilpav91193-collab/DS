{{--<div class="row">--}}
@foreach ($section->allBlocks as $block)
    @php
        $block->meta = (object) $block->metas->pluck('meta_value', 'meta_key')->all();
        $block_type = $block->meta->block_type ?? 'all';

        $views_in_order = [
            'Frontend.pagebuilder.pages.custom.' . $result->slug . '_' .($block_type),
            'Frontend.pagebuilder.pages.' . ($block_type),
            'Frontend.pagebuilder.' . ($block_type),
        ];
        $first_existing_view = collect($views_in_order)->first(function($view) {
        return View::exists($view);
        });

        $show_block_title = !empty($block->title) && (($block->meta->show_title ?? false) == 'Y' ||
        ($block->meta->hide_title ?? false) == 'N');
    @endphp
    @if($first_existing_view)
        @php
//        $columns = $block->meta->cols ?? 12;
//        $calsses = '';
//        $calsses .= ' col-lg-'.($columns);
//        $calsses .= ' col-md-'.($columns);
          $calsses =  $block->meta->custom_class ?? '';
        @endphp
{{--        <div class="row {{$block->meta->custom_class }}">--}}
            @include($first_existing_view, ['block' => $block, 'show_block_title' => $show_block_title])
{{--        </div>--}}
    @endif
@endforeach
{{--</div>--}}
