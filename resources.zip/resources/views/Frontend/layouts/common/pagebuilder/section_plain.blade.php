@foreach ($sections as $section)

    @php
        if ($section->allBlocks->isEmpty()) {
            continue;
        }
        $section->meta = (object) $section->metas->pluck('meta_value', 'meta_key')->all();
    @endphp
    <div class="@if(isset($section->meta->custom_class)){{ $section->meta->custom_class}}  @endif">
        <div class="col-12 col-xl-11">
            @include('Frontend.layouts.common.pagebuilder.section_blocks', ['section' => $section])
        </div>
    </div>
@endforeach
