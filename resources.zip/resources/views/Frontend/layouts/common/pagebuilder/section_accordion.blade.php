@php
$accordions = $sections->pluck('title')->toArray();
$random_id = Str::random(10);
@endphp
<section class="section">
    <div class="container">
        <div class="accordion accordion-100 mt-3"  id="id1_{{$random_id}}">
        @foreach ($sections as $section)
             @php   $slug = Str::slug($section->title . '_' . $loop->index);  @endphp                
            <div class="accordion-item mb-3">
                <h2 class="accordion-header rounded overflow-hidden" id="flush-heading{{ $slug}}">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse{{ $slug}}" aria-expanded="false" aria-controls="flush-collapse{{ $slug}}">
                    {{$section->title}}
                    </button>
                </h2>
                <div id="flush-collapse{{ $slug}}" class="accordion-collapse collapse" aria-labelledby="flush-heading{{ $slug}}"
                    data-bs-parent="#id_{{$random_id}}" >
                    <div class="accordion-body">
                        <div class="tab-content"> 
                        @include('Frontend.layouts.common.pagebuilder.section_blocks', ['section' => $section])                        
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        @endforeach
        </div>
    </div>
</section>
