<!DOCTYPE html>
<html lang="en" id="tab-home">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="{{ asset('frontend/favicon.png') }}" type="image/x-icon">

    @yield('title')

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="{{ asset('frontend/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('frontend/css/all.css') }}" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/slick.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/slick-theme.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/fancybox.min.css') }}"/>
    <link rel="stylesheet" type="text/css" href="{{ asset('frontend/css/aos.css') }}">
    <link href="{{ asset('frontend/css/styles.css') }}" rel="stylesheet">
    <!-- <link href="css/styles-ar.css" rel="stylesheet"> -->
</head>
<body>
<div class="modal fade" id="search-panel" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="exampleModalLabel">TYPE HERE TO SEARCH</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="input-group">
                    <input type="text" class="form-control" aria-label="Dollar amount (with dot and two decimal places)"
                           placeholder="Search ...">
                    <span class="input-group-text">
              <a href="javascrip:void(0);"><img src="{{ asset('frontend/images/search.png') }}"></a>
            </span>
                </div>
            </div>

        </div>
    </div>
</div>

<a href="#" id="scroll" class="" style="display: none;"><span></span>Top</a>

<div class="preLoader">
    <div class="preLoaderContent">
        <img src="{{ asset('frontend/images/DACC_logo.svg') }}" width="300" />
        <div class="lds-ellipsis">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</div>

@include('Frontend.layouts.common.header')

@yield('content')

@include('Frontend.layouts.common.footer')

<script src="{{ asset('frontend/js/jquery-3.6.0.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('frontend/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('frontend/js/jquery.easing.js') }}"></script>
<script src="{{ asset('frontend/js/fancybox.min.js') }}"></script>
<script src="{{ asset('frontend/js/custom.js') }}"></script>
<script src="{{ asset('frontend/js/smooth-scroll.js') }}"></script>
<script src="{{ asset('frontend/js/slick.js') }}" type="text/javascript" charset="utf-8"></script>
<script src="{{ asset('frontend/js/aos.js') }}" type="text/javascript" charset="utf-8"></script>

<script type="text/javascript">
    $(document).ready(function () {

        $(".switch-language").on("click", function (e) {
            var newLang = $(this).data("lang");
            $("#language").html(newLang.toUpper);

            var currentURL = window.location.href;
            var urlParts = currentURL.split('/');
            if (urlParts.length >= 4) {
                // Update the language segment of the URL
                urlParts[3] = newLang;
                var newURL = urlParts.join('/');

                // Redirect to the new URL
                window.location.href = newURL;
            }
        });


        var a = 0;
        $(window).scroll(function () {
            var oTop = $('#counter').offset().top - window.innerHeight;
            if (a == 0 && $(window).scrollTop() > oTop) {
                $('.counter').each(function () {
                    $(this).prop('Counter', 0).animate({
                        Counter: $(this).text()
                    }, {
                        duration: 4000,
                        easing: 'swing',
                        step: function (now) {
                            $(this).text(Math.ceil(now));
                        }
                    });
                });
                a = 1;
            }
        });
    });
</script>

@stack('js')

</body>

</html>
