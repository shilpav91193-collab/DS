<ul class="press-list">
    @foreach($news as $item)
        <li>
            <figure><img src="{{ isset($item->featured_image->file_url) ? $item->featured_image->file_url : '' }}"/></figure>
            <aside>
                <p>@if($item->created_at) {{ \Carbon\Carbon::parse($item->created_at)->format('jS F, Y') }} @endif</p>
                <h4 class="my-3">{{$item->title}}</h4>
                <a href="{{ url("$locale/newsroom/$item->slug") }}">Read more <i class="fa-solid fa-arrow-right"></i></a>
            </aside>
        </li>
    @endforeach
</ul>
<a href="{{ url("$locale/newsroom") }}" class="text-decoration-none float-end">View All <i
        class="ms-2 fa-solid fa-arrow-right"></i></a>
