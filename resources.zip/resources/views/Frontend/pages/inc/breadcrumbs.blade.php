<div class="row justify-content-center pb-0 pb-md-0">
    <div class="col-12 col-xl-11">
        <div class="row">
            <div class="col-12 my-3 pb-md-5">
                <div class="breadCrumbs">
                    <ul class="list-inline m-0">
                        <li class="list-inline-item"><a href="/">Home</a></li>
                        @php
                            $parents = \App\Http\Helpers::parentPostWithSlug($result->id);
                            $breadcrumbs = array_reverse($parents,true);
                            $url = '';
                        @endphp
                        @foreach($breadcrumbs as $index=>$val)
                            @php
                                $url = $url.'/'.$index;
                            @endphp
                            @if($val == end($breadcrumbs))
                                <li class="list-inline-item">{{$val}}</li>
                            @else
                                <li class="list-inline-item"><a href="{{ route('page.show', ['slug' => $url]) }}">{{$val}}</a></li>
                            @endif
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
