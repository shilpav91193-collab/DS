@foreach($documents as $document)
    <div class="col">
        <div class="pdf-box">
            <h4>{{$document->title}}</h4>
            <a href="{{$document->url}}" target="_blank" class="btn">Download Now <i
                    class="fa-solid fa-arrow-right-long"></i></a>
            <figure>
                <img src="{{ asset('frontend/images/globe.png') }}" class="w-100"/>
            </figure>
        </div>
    </div>
@endforeach
