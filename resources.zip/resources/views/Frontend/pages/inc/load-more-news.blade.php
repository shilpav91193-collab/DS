@foreach($news as $newsData)
    <div class="col">
        <div class="press-box ">
            <figure>
                <img src="{{ isset($newsData->featured_image->file_url) ? $newsData->featured_image->file_url  : '' }}" class="" />
            </figure>
            <aside>
                <span>{{$newsData->created_at ? \Carbon\Carbon::parse($newsData->created_at)->format('M d, Y') : '' }}</span>
                <h3>{{ $newsData->title ?? '' }}</h3>
                <p>{{ $newsData->content ?? '' }}</p>

            </aside>
            <a href="press-release-detail.html" class="">Read More <i class="fa-solid fa-arrow-right-long"></i></a>
        </div>
    </div>
@endforeach
