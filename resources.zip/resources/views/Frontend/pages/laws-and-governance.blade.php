@extends('Frontend.layouts.main')

@section('title')
    <title>Dubai Aviation City Corporation</title>
@endsection

@section('content')
    @php
        $locale = App::getLocale() ? App::getLocale() : 'en';
    @endphp

    <content>

        <div class="container-fluid">

            <div class="row justify-content-center">
                <div class="col-12 p-0">

                    <div class="subpag-banner">
                        <figure>
                        </figure>
                    </div>
                </div>
            </div>

            @include('Frontend.pages.inc.breadcrumbs')

            <div class="row justify-content-center">
                <div class="col-12 col-xl-11">
                    <div class="row">

                        <div class="col-md-6">
                            <h2 class="text-blue text-uppercase">
                                <strong>{{ isset($result->title) ? $result->title : ''  }}</strong></h2>
                            <p class="my-4">Find the list below for Laws & Governance under DACC.</p>
                        </div>

                        @if(count($documents) > 0)
                            <div class="col-12 mt-3 mb-4">

                                <div class="row g-4 row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4" id="laws-container">
                                    @include('Frontend.pages.inc.laws-and-governance-lists')
                                </div>
                                @if(count($documents)>0 && $documents->currentPage() != $documents->lastPage())
                                    <div class="row">
                                        <div class="col-12 py-5 text-center">
                                            <a href="#" class="btn btn-primary" id="load-more-laws">Load More</a>
                                        </div>
                                    </div>
                                @endif
                            </div>
                        @endif
                    </div>
                </div>
            </div>


        </div>


        </div>
        </div>
    </content>
@endsection

@push('js')
    <script>
        $(document).ready(function () {
            let currentPage = {{ $documents->currentPage() }};
            let locale = "{{ $locale }}";

            $("#load-more-laws").click(function (e){
                e.preventDefault();
                $.ajax({
                    url:'{{ url("${locale}/load-more-laws")  }}',
                    type: 'GET',
                    data : {
                        currentPage: currentPage,
                    },
                    success: function(response) {
                        console.log(response);
                        if(response.data && response.data.current_page ==  response.data.last_page) {
                            $("#load-more-laws").addClass('d-none');
                        }

                        currentPage = response.data.current_page;

                        $("#laws-container").append(response.body);
                    },
                    error: function(xhr, status, error) {
                        console.error(status, error);
                    }
                });

            });
        });
    </script>
@endpush
