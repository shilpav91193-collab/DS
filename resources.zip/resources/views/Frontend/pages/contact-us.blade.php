@extends('Frontend.layouts.main')

@section('title')
    <title>Dubai Aviation City Corporation</title>
@endsection

@section('content')
    @php
        $locale = App::getLocale() ? App::getLocale() : 'en';
    @endphp

    <content>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-12 p-0">
                    <div class="subpag-banner">
                        <figure></figure>
                    </div>
                </div>
            </div>
            @include('Frontend.pages.inc.breadcrumbs',['result'=>$result])


            @php
                $views_in_order = [
                    'Frontend.layouts.common.pagebuilder.custom.' . $result->slug .'_sections',
                    'Frontend.layouts.common.pagebuilder.sections',
                ];

                $first_existing_view = collect($views_in_order)->first(function($view) {
                    return View::exists($view);
                });
            @endphp

            @include($first_existing_view)

            @if($result->children->count())
                <section class="section">
                    <div class="container">

                        <div class="row row-cols-2 row-cols-sm-3 row-cols-md-4 row-cols-lg-5 g-3 g-md-5 my-0">
                            @foreach($result->children as $child)
                                <div class="col">
                                    <div class="ratio ratio-1x1 position-relative hvr-grow">
                                        <div class="box box-900">
                                            <div class="imgHolder">
                                                <img class="mt-auto"
                                                     src="{{ ($child->thumbnail_image)?->file_url ?? asset('images/about-dubai.png') }}"
                                                     onerror="this.onerror=null;this.src='{{ ($child->thumbnail_image)?->file_url ?? asset('images/about-dubai.png') }}';"/>
                                            </div>
                                            <h6>{{ $child->title}}</h6>
                                        </div>
                                        @php
                                            $current_route = request()->path().'/';
                                        @endphp
                                        <a class="stretched-link"
                                           href="{{ route('page.show', ['slug' => $current_route.$child->slug]) }}"><span
                                                class="sr-only">{{ $child->title}}</span></a>
                                    </div>
                                </div>
                            @endforeach

                        </div>

                    </div>
                </section>
            @endif

            <div class="row justify-content-center">
                <div class="col-12 col-xl-11">
                    <div class="row">
                        <div class="w-100"></div>
                        <div class="col-md-6 my-5">
                            @if(session('success'))
                                <div class="alert alert-success">
                                    {{ session('success') }}
                                </div>
                            @endif

                            <form method="POST" id="contact-us-form" action="{{ url($locale."/store-contact") }}">
                                <div class="row g-3 row-cols-1 row-cols-lg-2">

                                    @csrf
                                    <div class="col form-floating mb-3">
                                        <input type="text"
                                               class="form-control @error('first_name') is-invalid @enderror"
                                               name="first_name"
                                               id="first_name"
                                               placeholder=""
                                               value="{{ old('first_name') }}"
                                               aria-label="First Name*">
                                        <label for="first_name">First Name*</label>
                                        @error('first_name')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>

                                    <div class="col form-floating mb-3">
                                        <input type="text"
                                               class="form-control @error('last_name') is-invalid @enderror"
                                               name="last_name"
                                               id="last_name"
                                               placeholder=""
                                               value="{{ old('last_name') }}"
                                               aria-label="Last Name*">
                                        <label for="last_name">Last Name*</label>
                                        @error('last_name')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>

                                    <div class="col form-floating mb-3">
                                        <input type="text"
                                               class="form-control @error('company') is-invalid @enderror"
                                               name="company"
                                               id="company"
                                               placeholder=""
                                               value="{{ old('company') }}"
                                               aria-label="Company">
                                        <label for="company">Company</label>
                                        @error('company')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>

                                    <div class="col form-floating mb-3">
                                        <select class="form-select @error('sector_id') is-invalid @enderror"
                                                id="sector_id"
                                                name="sector_id"
                                                aria-label="Floating label select example">
                                            @foreach($sectors as $sector)
                                                <option @if(old('sector_id') == $sector->id ) selected @endif value="{{$sector->id}}">{{$sector->title}}</option>
                                            @endforeach
                                        </select>
                                        <label for="sector_id">Area of Interest</label>
                                        @error('sector_id')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>


                                    <div class="col form-floating mb-3">
                                        <input type="text" name="phone"
                                               class="form-control @error('phone') is-invalid @enderror"
                                               id="phone"
                                               value="{{ old('phone') }}"
                                               placeholder="" aria-label="Phone*">
                                        <label for="phone">Phone*</label>
                                        @error('phone')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>

                                    <div class="col form-floating mb-3">
                                        <input type="email"
                                               class="form-control @error('email') is-invalid @enderror"
                                               id="email"
                                               value="{{ old('email') }}"
                                               name="email"
                                               placeholder="" aria-label="Email*">
                                        <label for="email">Email*</label>

                                        @error('email')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>

                                    <div class="col form-floating mb-3">

                                        <select class="form-select @error('preferred_way') is-invalid @enderror"
                                                id="preferred_way" name="preferred_way"
                                                aria-label="Floating label select example">
                                            <option @if(old('preferred_way' == 'email')) selected @endif value="email">Email</option>
                                            <option @if(old('preferred_way' == 'phone')) selected @endif value="phone">Phone</option>
                                            <option @if(old('preferred_way' == 'visit')) selected @endif value="visit">Visit</option>
                                        </select>
                                        @error('preferred_way')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        <label for="preferred_way">Preferred way of contact*</label>
                                    </div>

                                    <div class="col form-floating mb-3">
                                        <input type="text"
                                               class="form-control @error('time_to_call') is-invalid @enderror"
                                               id="time_to_call" name="time_to_call"
                                               value="{{ old('time_to_call') }}"
                                               placeholder="" aria-label="Time to Call*">
                                        <label for="time_to_call">Time to Call*</label>
                                        @error('time_to_call')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                    <div class="row">
                                        <div class="col-12 form-floating mb-3">
                                            <textarea class="form-control @error('message') is-invalid @enderror"
                                                      placeholder=""
                                                      name="message"
                                                      id="message"
                                                      style="height: 150px">{{ old('message') }}</textarea>
                                            <label for="message">Your message*</label>
                                            @error('message')
                                            <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <div class="col-12 form-floating mb-3">
                                            <input type="hidden" name="g-recaptcha-token" id="g-recaptcha-token">
                                            <div class="g-recaptcha" data-sitekey="{{ config('settings.google_recaptcha_key') }}" data-size="invisible"></div>

                                            @error('g-recaptcha-response')
                                            <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>

                            </form>

                        </div>

                        @if($result->featured_image && $result->featured_image->file_url)
                            <div class="col-md-6 my-5">
                                <img src="{{ $result->featured_image->file_url }}"
                                     alt="" class="w-100">
                            </div>
                        @endif

                    </div>
                </div>
            </div>
        </div>
    </content>
@endsection

@push('js')
    <script src="https://www.google.com/recaptcha/api.js?render=6LdfFTcpAAAAAPzFiK3pmtbuRyRQhLrTESYaHwJB"></script>
    <script>
        $(document).ready(function () {
            $('#contact-us-form').on('submit', function (event) {
                event.preventDefault();
                grecaptcha.ready(function () {
                    grecaptcha.execute('{{ config('settings.google_recaptcha_key') }}', { action: 'submit' })
                        .then(function (token) {
                            $("#g-recaptcha-token").val(token);
                            $('#contact-us-form')[0].submit();
                        });
                });
            });
        });
        $(function (){

            $('input').on('input', function() {
                $(this).removeClass('is-invalid');
                $(this).closest('div').find('span.text-danger').remove();
            });

            $('textarea').on('input', function() {
                $(this).removeClass('is-invalid');
                $(this).closest('div').find('span.text-danger').remove();
            });
        });
    </script>

@endpush
