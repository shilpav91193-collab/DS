@extends('Frontend.layouts.main')

@section('title')
    <title>Dubai Aviation City Corporation</title>
@endsection

@section('content')
    @php
        $locale = App::getLocale() ? App::getLocale() : 'en';
    @endphp
    <content>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-12 p-0">

                    <div class="subpag-banner">
                        <figure>
                        </figure>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-12 col-xl-11">

                    <div class="row">

                        <div class="col-12 my-3 pb-md-4">
                            <div class="breadCrumbs">
                                <ul class="list-inline m-0">
                                    <li class="list-inline-item"><a href="{{ url("$locale/") }}">Home</a></li>
                                    <li class="list-inline-item"><a href="{{ url("$locale/newsroom") }}">Newsroom</a></li>
                                    @php
                                        $parents = \App\Http\Helpers::parentPostWithSlug($result->id);
                                        $breadcrumbs = array_reverse($parents,true);
                                        $url = '';
                                    @endphp
                                    @foreach($breadcrumbs as $index=>$val)
                                        @php
                                            $url = $url.'/'.$index;
                                        @endphp
                                        @if($val == end($breadcrumbs))
                                            <li class="list-inline-item">{{$val}}</li>
                                        @else
                                            <li class="list-inline-item"><a
                                                    href="{{ route('page.show', ['slug' => $url]) }}">{{$val}}</a></li>
                                        @endif
                                    @endforeach
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-12 col-xl-11">
                    <div class="row">


                        <div class="col-7 mb-4">
                            <h2 class="text-blue text-uppercase"><strong>{{isset($result->title) ? $result->title : ''}}</strong></h2>
                        </div>
                        <div class="col-md-6 col-lg-7 mb-5 vline-right pe-md-4">
                            <div class="mb-4">
                                <figure><img src="{{isset($result->featured_image->file_url) ? $result->featured_image->file_url : ''}}" class="w-100"/></figure>
                            </div>
                            <p class="mb-4 text-grey text-uppercase">Released on Dated : @if(isset($result->created_at)) {{\Carbon\Carbon::parse($result->created_at)->format('M d, Y')}} @endif </p>
                            {!! isset($result->content) ? $result->content : ''  !!}
                        </div>

                        @if(count($news) > 0)
                            <div class="col-md-6 col-lg-5 ps-md-4">
                                <h2 class="text-blue text-uppercase">More from Newsroom</h2>
                                @include('Frontend.pages.inc.news-lists')
                            </div>
                        @endif

                    </div>
                </div>
            </div>
        </div>
    </content>

@endsection
