@extends('Frontend.layouts.main')

@section('title')
    <title>Dubai Aviation City Corporation</title>
@endsection

@section('content')
    @php
        $locale = App::getLocale() ? App::getLocale() : 'en';
    @endphp
    <content>
        <div class="container-fluid">

            @if(isset($banners))
                @include('Frontend.layouts.common.banner')
            @endif

            @if(isset($postData->meta->home_sector_active_status) &&
                          $postData->meta->home_sector_active_status =='Y' && count($sectors) >0)
                    <div class="row justify-content-center d-block d-xl-none">
                        <div class="col-md-11 diversified-title">
                            <h3 class="m-0">{{ isset($postData->meta->home_diversified_sector_title) ?
                                    $postData->meta->home_diversified_sector_title :
                                     'Our Diversified Sectors' }}</h3>
                        </div>
                    </div>


                    <div class="row justify-content-center bg-dblue text-white diversified-sectors" id="tab-diversified">
                        <div class="col-xl-11">
                            <div class="row">
                                <div class="col-12">
                                    <div class="slidePlaceholder" onclick="$(this).hide()">
                                        <img src="{{ asset('frontend/images/swipe.gif') }}">
                                    </div>
                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                        @foreach($sectors as $sector)
                                            <li class="nav-item" role="presentation">
                                                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#{{$sector->slug}}" type="button" role="tab"
                                                        aria-selected="true">
                                                    {{$sector->title ?? ''}}</button>
                                            </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row justify-content-center text-white diversified-sectors open-up"
                         id="tab-diversified">
                        <div class="col-md-11 diversified-title d-none d-xl-block">
                            <h3 class="m-0" onclick="$('#myTab li:first').find('button').click()">Our<strong> Diversified sectors</strong></h3>
                        </div>

                        <div class="col-xl-11">
                            <div class="row">
                                <div class="col-12">
                                    <div class="tab-content" id="myTabContent">
                                        @foreach($sectors as $sector)
                                            <div class="tab-pane" id="{{$sector->slug}}" role="tabpanel">
                                                <div class="row">
                                                    <div class="col-sm-5 col-md-4">
                                                        <img src="{{isset($sector->featured_image->file_url) ? $sector->featured_image->file_url : ''}}" class="w-100" alt="">
                                                    </div>
                                                    <div class="col-sm-7 col-md-8 text-white px-md-5 align-self-center">
                                                        <aside>
                                                            <h3>{{$sector->sub_title}}</h3>
                                                            <p class="my-4">{{$sector->content}}</p>
                                                            <a href="{{ url("/$locale/sectors/$sector->slug") }}" class="btn btn-primary">Explore</a>
                                                        </aside>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                        <a href="javascript:void(0);" class="" id="hideBtn"><i class="fa-solid fa-xmark"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            @endif

            @if(isset($postData->meta->home_who_we_active_status) &&
                          $postData->meta->home_who_we_active_status =='Y')
                    <div class="row justify-content-center py-3 py-md-5 gradient-right mb-md-5">
                        <div class="globe">
                            <img src="{{ asset('frontend/images/globe-2.png') }}" class="w-100" alt="">
                        </div>

                        <div class="col-12 col-lg-11">
                            <div class="row">
                                <div class="col-md-6 py-5 align-self-center pe-lg-5" data-aos="fade-left" data-aos-duration="600"
                                     data-aos-offset="200">
                                    <h2 class="text-uppercase text-blue">
                                        <strong>{{ isset($postData->meta->home_who_we_are_title) ?
                                            $postData->meta->home_who_we_are_title :
                                            'Who We Are' }}
                                        </strong>
                                    </h2>
                                    <p class="my-4">
                                        {{ isset($postData->meta->home_who_we_are_description) ?
                                            $postData->meta->home_who_we_are_description :
                                            null
                                        }}
                                    </p>
                                    <a href="{{ isset($postData->meta->home_who_we_are_button_url) ?
                                            $postData->meta->home_who_we_are_button_url :
                                             '#' }}" class="btn btn-primary my-2">
                                        {{ isset($postData->meta->home_who_we_are_button_name) ?
                                    $postData->meta->home_who_we_are_button_name :
                                     'Read More' }}</a>
                                </div>

                                <div class="col-md-6 ps-lg-5 " data-aos="fade-right" data-aos-duration="600" data-aos-offset="200">

                                    <div class="zoom ">
                                        @php
                                            $images = null;
                                            $img = $postData->meta->home_who_we_are_image;
                                            $image = \App\Models\Medias::where('id', $img)->first();
                                        @endphp
                                        @if($image)
                                            <figure>
                                                <img src="{{ $image->file_url }}" class="w-100" alt="">
                                            </figure>
                                        @endif
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                @endif

            @if(isset($postData->meta->home_counter_active_status) &&
                          $postData->meta->home_counter_active_status =='Y')
                    <div class="row justify-content-center pt-5 pb-3 py-md-3">
                        <div class="col-12 col-xl-11">
                            @php
                                $data = Helpers::getCounters();
                            @endphp
                            @include('templates.counter_section', ['datas' => $data])
                        </div>
                    </div>

            @endif

            @if(isset($postData->meta->home_leaders_active_status) &&
                                      $postData->meta->home_leaders_active_status =='Y')
                    <div class="row justify-content-center pb-3">
                        <div class="col-12 col-lg-11">
                            <div class="row">
                                <div class="col-12">
                                    <hr class="my-5">
                                    <h2 class="text-uppercase text-blue my-3 my-md-5">
                                        <strong>Our Leadership</strong>
                                    </h2>
                                </div>
                                @if(count($teamLeaders) >0 )
                                    @foreach($teamLeaders as $leader)
                                        @if($loop->odd)
                                        <div class="col-lg-7 mb-4" data-aos="zoom-in" data-aos-duration="400" data-aos-offset="200">
                                            <div class="row leader-box">
                                                <div class="col-sm-5">
                                                    <figure>
                                                        <img src="{{$leader->featured_image->file_url}}" class="w-100" />
                                                    </figure>
                                                </div>
                                                <div class="col-sm-7 align-self-center ps-md-4 pe-md-5 py-3">
                                                    <h3 class="text-blue"><strong>{!! $leader->name !!}</strong></h3>
                                                    <p class="text-uppercase">{{$leader->profession}}</p>
                                                    <p class="small">{!! (strlen(strip_tags($leader->description)) > 180) ? substr(strip_tags($leader->description), 0, 180) . '...' : strip_tags($leader->description) !!}</p>
                                                    <a href="{{ url("/$locale/our-leadership") }}" class="btn btn-primary mt-1">
                                                        {{
                                                            isset($postData->meta->home_our_leaders_button_name) ?
                                                            $postData->meta->home_our_leaders_button_name :
                                                            'Read More'
                                                        }}
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        @else
                                            <div class="col-lg-5 mb-4" data-aos="zoom-in" data-aos-duration="600" data-aos-offset="200">
                                                <div class="row leader-box">
                                                    <div class="col-sm-4">
                                                        <figure>
                                                            <img src="{{$leader->featured_image->file_url}}" class="w-100" />
                                                        </figure>
                                                    </div>
                                                    <div class="col-sm-7 col-lg-12 align-self-center py-3">
                                                        <h3 class="text-blue"><strong>{!! $leader->name !!}</strong></h3>
                                                        <p class="text-uppercase">{{$leader->profession}}</p>
                                                        <p class="small">{!! (strlen(strip_tags($leader->description)) > 180) ? substr(strip_tags($leader->description), 0, 180) . '...' : strip_tags($leader->description) !!}</p>

                                                        <a href="{{ url("/teams/$leader->slug") }}" class="btn btn-primary mt-1">
                                                            {{
                                                                isset($postData->meta->home_our_leaders_button_name) ?
                                                                $postData->meta->home_our_leaders_button_name :
                                                                'Read More'
                                                            }}
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        @endif
                                    @endforeach
                                @endif
                            </div>
                        </div>
                    </div>
            @endif


            @if(isset($postData->meta->home_roles_active_status) &&
                                         $postData->meta->home_roles_active_status =='Y')

                <div class="row justify-content-center py-3 py-md-5 gradient-right mb-4">
                    <div class="col-12 col-lg-11">
                        <div class="row">
                            <div class="col-md-6 py-3 align-self-center" data-aos="fade-left" data-aos-duration="600"
                                 data-aos-offset="200">
                                <h2 class="text-uppercase text-blue">
                                    <strong>
                                        {{ isset($postData->meta->home_our_role_title) ?
                                            $postData->meta->home_our_role_title :
                                             'Our Roles' }}
                                    </strong>
                                </h2>
                                <p class="my-4">
                                    {{ isset($postData->meta->home_our_role_description) ?
                                            $postData->meta->home_our_role_description :
                                             null }}
                                </p>
                                <a href="{{ isset($postData->meta->home_our_role_button_url) ?
                                                    $postData->meta->home_our_role_button_url :
                                                     '#' }}" class="btn btn-primary mt-2">
                                    {{ isset($postData->meta->home_our_role_button_name) ?
                                            $postData->meta->home_our_role_button_name :
                                             'Read More' }}
                                </a>
                            </div>

                            <div class="col-md-6 ps-md-5" data-aos="fade-right" data-aos-duration="600" data-aos-offset="200">
                                <div class="zoom ">
                                    <figure>
                                        @php
                                            $images = null;
                                            $img = $postData->meta->home_our_role_image;
                                            $image = \App\Models\Medias::where('id', $img)->first();
                                        @endphp
                                        @if($image)
                                            <img src="{{ $image->file_url }}" class="w-100" alt="">
                                        @endif
                                    </figure>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endif

            @if(isset($postData->meta->home_groups_active_status) &&
                                        $postData->meta->home_groups_active_status =='Y')
                    <div class="row justify-content-center py-3 py-md-5">
                        <div class="col-12 col-lg-11">
                            <hr class="d-block d-md-none mt-3 mb-0">
                            <div class="row justify-content-between">
                                <div class="col-md-6 py-5 align-self-center pe-lg-5"
                                     data-aos="fade-left" data-aos-duration="600"
                                 data-aos-offset="200">
                                <h2 class="text-uppercase text-blue"><strong>
                                        {{ isset($postData->meta->home_group_title) ?
                                            $postData->meta->home_group_title :
                                             'Our Groups' }}
                                    </strong></h2>
                                <p class="my-4">
                                    {{ isset($postData->meta->home_group_description) ?
                                             $postData->meta->home_group_description :
                                              null }}
                                </p>
                                <a href="{{ isset($postData->meta->home_group_button_url) ?
                                                    $postData->meta->home_group_button_url :
                                                     '#' }}"
                                   class="btn btn-primary mt-2">
                                    {{ isset($postData->meta->home_group_button_name) ?
                                            $postData->meta->home_group_button_name :
                                             'Read More' }}</a>
                            </div>
                                <div class="col-md-6 col-xl-5" data-aos="fade-right"
                                 data-aos-duration="600" data-aos-offset="200">
                                <div class="groups">
                                    @foreach($groups as $group)
                                        <div><img src="{{$group->featured_image->file_url}}" /></div>
                                    @endforeach
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
            @endif


                @if(isset($postData->meta->home_footprints_active_status) &&
                                       $postData->meta->home_footprints_active_status =='Y')
                    <div class="row justify-content-center py-3 py-md-5">
                        <div class="col-12 col-lg-11">
                            <hr class="d-block d-md-none mt-3 mb-0">
                            <div class="row justify-content-between">
                                <div class="col-md-6 py-5 align-self-center pe-lg-5"
                                     data-aos="fade-left" data-aos-duration="600"
                                     data-aos-offset="200">
                                    <h2 class="text-uppercase text-blue"><strong>
                                            {{ isset($postData->meta->home_footprints_title) ?
                                                $postData->meta->home_footprints_title :
                                                 'Our Footprints' }}
                                        </strong></h2>
                                    <p class="my-4">
                                        {{ isset($postData->meta->home_footprints_description) ?
                                                 $postData->meta->home_footprints_description :
                                                  null }}
                                    </p>
                                    <a href="{{ isset($postData->meta->home_footprints_button_url) ?
                                                    $postData->meta->home_footprints_button_url :
                                                     '#' }}"
                                       class="btn btn-primary mt-2">
                                        {{ isset($postData->meta->home_footprints_button_name) ?
                                                $postData->meta->home_footprints_button_name :
                                                 'Read More' }}</a>
                                </div>
                                <div class="col-md-6 ps-md-5" data-aos="fade-right" data-aos-duration="600" data-aos-offset="200">
                                    <div class="zoom ">
                                        <figure>
                                            @php
                                                $images = null;
                                                $img = $postData->meta->home_footprints_image;
                                                $image = \App\Models\Medias::where('id', $img)->first();
                                            @endphp
                                            @if($image)
                                                <img src="{{ $image->file_url }}" class="w-100" alt="">
                                            @endif
                                        </figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif

            @if(isset($postData->meta->home_video_active_status) &&
                            $postData->meta->home_video_active_status =='Y')

                    <div class="row justify-content-center text-white">
                        <div class="col-12 p-0 text-center">
                            <video width="100%" loop="true" autoplay="true" controls muted>
                                <source src="{{ asset('frontend/videos/Comp.mp4') }}" type="video/mp4">
                                <source src="{{ asset('frontend/videos/Comp.mp4') }}" type="video/ogg">
                                Your browser does not support the video tag.
                            </video>
                        </div>
                    </div>
            @endif

            @if(isset($postData->meta->home_news_active_status) &&
                $postData->meta->home_news_active_status =='Y')

                    <div class="row justify-content-center press-section">
                        <div class="col-12 col-lg-11">
                            <div class="row">
                                <div class="col-12 ">
                                    <h2 class="my-5 text-blue"><strong>{{ isset($postData->meta->home_news_title) ?
                        $postData->meta->home_news_title :
                         'NEWSROOM' }}</strong></h2>
                                </div>
                                <div class="col-12">

                                    <div class="slider press-slider mb-5">
                                        @foreach($news as $newsData)
                                            <div>
                                                <figure>
                                                    <img src="{{$newsData->featured_image ? $newsData->featured_image->file_url: '' }}" class="" />
                                                </figure>
                                                <aside>
                                                    <span>{{$newsData->created_at ? \Carbon\Carbon::parse($newsData->created_at)->format('M d, Y') : '' }}</span>
                                                    <h3>{{ $newsData->title ?? '' }}</h3>
                                                    <p>{{ $newsData->content ?? '' }}</p>

                                                </aside>
                                                <a href="{{ url("$locale/newsroom/$newsData->slug") }}" class="">Read More <i
                                                        class="fa-solid fa-arrow-right-long"></i></a>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            @endif
        </div>
    </content>
@endsection
