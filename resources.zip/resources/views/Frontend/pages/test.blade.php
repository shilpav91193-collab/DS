<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>reCAPTCHA Example</title>
</head>
<body>
<form action="#" method="POST">
    @csrf
    <div class="g-recaptcha" data-sitekey="6LdfFTcpAAAAAPzFiK3pmtbuRyRQhLrTESYaHwJB" data-size="invisible"></div>
    <input type="hidden" name="recaptcha_token" id="recaptcha_token">
    <button type="button" id="submitButton">Submit</button>
</form>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<script src="https://www.google.com/recaptcha/api.js?render=6LdfFTcpAAAAAPzFiK3pmtbuRyRQhLrTESYaHwJB"></script>

<script>
    $(document).ready(function () {
        var form = document.querySelector('form');

        form.addEventListener('submit', function (event) {
            event.preventDefault();
            grecaptcha.ready(function () {
                grecaptcha.execute('{{ config('settings.google_recaptcha_key') }}', { action: 'submit' })
                    .then(function (token) {
                        document.getElementById('recaptcha_token').value = token;
                        form.submit();
                    });
            });
        });
    });
</script>
</body>
</html>
