@extends('Frontend.layouts.main')

@section('title')
    <title>Dubai Aviation City Corporation</title>
@endsection

@section('content')
    @php
        $locale = App::getLocale() ? App::getLocale() : 'en';
    @endphp
    <content>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-12 p-0">
                    <div class="subpag-banner">
                        <figure>
                        </figure>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-12 col-xl-11">
                    <div class="row">
                        <div class="col-12 my-3 pb-md-4">
                            <div class="breadCrumbs">
                                <ul class="list-inline m-0">
                                    <li class="list-inline-item"><a href="/">Home</a></li>
                                    <li class="list-inline-item"><a href="#">Our Airports</a></li>
                                    <li class="list-inline-item">{{ $result->title }}</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-12 col-xl-11 mb-4">
                    <div class="row">
                        <div class="col-12 my-4">
                            <h2 class="text-blue text-uppercase">
                                <strong>{{ $result->title }}</strong>
                            </h2>
                        </div>

                        <div class="col-md-8">
                            {!! isset($result->meta->notes) ? $result->meta->notes : '' !!}
                        </div>

                        @if(isset($result->featured_image->file_url))
                            <div class="col-12 my-4">
                                <figure><img src="{{ $result->featured_image->file_url }}" class="w-100"/></figure>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </content>
@endsection
