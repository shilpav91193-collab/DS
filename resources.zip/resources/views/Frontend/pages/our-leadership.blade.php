@extends('Frontend.layouts.main')

@section('title')
    <title>Dubai Aviation City Corporation</title>
@endsection

@section('content')
    @php
        $locale = App::getLocale() ? App::getLocale() : 'en';
    @endphp

    <content>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-12 p-0">
                    <div class="subpag-banner">
                        <figure></figure>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center pb-3 pb-md-5">
                <div class="col-12 col-xl-11">

                    <div class="row">

                        <div class="col-12 my-3 pb-md-5">
                            <div class="breadCrumbs">
                                <ul class="list-inline m-0">
                                    <li class="list-inline-item"><a href="{{ url("/$locale") }}">Home</a></li>
                                    @php
                                        $parents = \App\Http\Helpers::parentPostWithSlug($result->id);
                                        $breadcrumbs = array_reverse($parents,true);
                                        $url = '';
                                    @endphp
                                    @foreach($breadcrumbs as $index=>$val)
                                        @php
                                            $url = $url.'/'.$index;
                                        @endphp
                                        @if($val == end($breadcrumbs))
                                            <li class="list-inline-item">{{$val}}</li>
                                        @else
                                            <li class="list-inline-item"><a href="{{ route('page.show', ['slug' => $url]) }}">{{$val}}</a></li>
                                        @endif
                                    @endforeach
                                </ul>
                            </div>
                        </div>

                    </div>

                    @foreach($teams as $team)
                        @if($loop->odd)
                            <div class="row pb-4">

                                <div class="col-12 mb-3">
                                    <h2 class="text-uppercase text-blue"><strong>Our Leadership</strong></h2>
                                </div>

                                <div class="col-sm-4 pe-md-5" data-aos="fade-left" data-aos-duration="600" data-aos-offset="200">
                                    <div class="zoom">
                                        <figure>
                                            <img src="{{$team->featured_image->file_url}}" class="w-100" alt="" >
                                        </figure>
                                    </div>
                                </div>

                                <div class="col-sm-8 align-self-center py-5 ps-lg-5" data-aos="fade-right" data-aos-duration="600" data-aos-offset="200">
                                    <h2 class="text-uppercase text-blue">
                                        <strong>{!! $team->name !!}</strong>
                                    </h2>

                                    <p class="large mt-2 text-uppercase">
                                        {!! $team->profession !!}
                                    </p>

                                    {!! $team->description !!}

                                </div>

                            </div>
                        @else
                            <div class="row">

                                <div class="col-sm-4 ps-md-5 order-sm-last" data-aos="fade-right" data-aos-duration="600" data-aos-offset="200">
                                    <div class="zoom">
                                        <figure>
                                            <img src="{{$team->featured_image->file_url}}" class="w-100" alt="" >
                                        </figure>
                                    </div>
                                </div>

                                <div class="col-sm-8 align-self-center py-5 pe-lg-5" data-aos="fade-left" data-aos-duration="600" data-aos-offset="200">

                                    <h2 class="text-uppercase text-blue">
                                        <strong>{!! $team->name !!}</strong>
                                    </h2>
                                    <p class="large mt-2 text-uppercase"> {!! $team->profession !!}</p>
                                    {!! $team->description !!}

                                </div>

                            </div>
                        @endif
                    @endforeach


                </div>
            </div>
        </div>
    </content>
@endsection

@push('js')
    <script>
        $(document).ready(function () {

        });
    </script>
@endpush
