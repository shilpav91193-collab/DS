@extends('Frontend.layouts.main')

@section('title')
    <title>Dubai Aviation City Corporation</title>
@endsection

@section('content')
    @php
        $locale = App::getLocale() ? App::getLocale() : 'en';
    @endphp

    <content>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-12 p-0">
                    <div class="subpag-banner">
                        <figure></figure>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-12 col-xl-11">
                    <div class="row">
                        <div class="col-12 my-3 pb-md-4">
                            <div class="breadCrumbs">
                                <ul class="list-inline m-0">
                                    <li class="list-inline-item"><a href="home.html">Home</a></li>
                                    @php
                                        $parents = \App\Http\Helpers::parentPostWithSlug($result->id);
                                        $breadcrumbs = array_reverse($parents,true);
                                        $url = '';
                                    @endphp
                                    @foreach($breadcrumbs as $index=>$val)
                                        @php
                                            $url = $url.'/'.$index;
                                        @endphp
                                        @if($val == end($breadcrumbs))
                                            <li class="list-inline-item">{{$val}}</li>
                                        @else
                                            <li class="list-inline-item"><a href="{{ route('page.show', ['slug' => $url]) }}">{{$val}}</a></li>
                                        @endif
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-12 col-xl-11">
                    <div class="row">
                        <div class="col-12 col-md-6 col-lg-9 my-sm-4">
                            <h2 class="text-blue text-uppercase"><strong>{{$result->title ? $result->title : ''}}</strong></h2>
                        </div>

                        <div class="col-12 my-4">
                            <div class="row g-3 g-lg-5 row-cols-1 row-cols-sm-2 row-cols-md-3" id="news-container">
                                @foreach($news as $newsData)
                                    <div class="col">
                                        <div class="press-box ">
                                            <figure>
                                                <img src="{{ isset($newsData->featured_image->file_url) ? $newsData->featured_image->file_url  : '' }}" class="" />
                                            </figure>
                                            <aside>
                                                <span>{{$newsData->created_at ? \Carbon\Carbon::parse($newsData->created_at)->format('M d, Y') : '' }}</span>
                                                <h3>{{ $newsData->title ?? '' }}</h3>
                                                <p>{{ $newsData->content ?? '' }}</p>

                                            </aside>
                                            <a href="{{ url("$locale/newsroom/$newsData->slug") }}" class="">Read More <i class="fa-solid fa-arrow-right-long"></i></a>
                                        </div>
                                    </div>
                                @endforeach

                            </div>
                            @if(count($news)>0 && $news->currentPage() != $news->lastPage())
                                <div class="row">
                                    <div class="col-12 py-5 text-center">
                                        <a href="#" class="btn btn-primary" id="load-more-news">Load More</a>
                                    </div>
                                </div>
                            @endif

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </content>
@endsection

@push('js')
    <script>
        $(document).ready(function () {
            let currentPage = {{ $news->currentPage() }};
            let locale = "{{ $locale }}";

            $("#load-more-news").click(function (e){
                e.preventDefault();
                $.ajax({
                    url:'{{ url("${locale}/load-more-news")  }}',
                    type: 'GET',
                    data : {
                        currentPage: currentPage,
                    },
                    success: function(response) {
                        console.log(response);
                        if(response.data && response.data.current_page ==  response.data.last_page) {
                            $("#load-more-news").addClass('d-none');
                        }

                        currentPage = response.data.current_page;

                        $("#news-container").append(response.body);
                    },
                    error: function(xhr, status, error) {
                        console.error(status, error);
                    }
                });

            });
        });
    </script>
@endpush
