@extends('Frontend.layouts.main')

@section('title')
    <title>Dubai Aviation City Corporation</title>
@endsection

@section('content')
    <content>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-12 p-0">
                    <div class="subpag-banner">
                        <figure></figure>
                    </div>
                </div>
            </div>

            @include('Frontend.pages.inc.breadcrumbs',['result'=>$result])
            <div class="row justify-content-center ">
                <div class="col-12 col-xl-11">
                    <div class="col-6 mb-3 custom-strong">
                        <h2 class="text-blue">{{$result->title}}</h2>
                        <p class="my-4">{{$result->content}}</p>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center bg-dblue text-white diversified-sectors" id="tab-diversified">
                <div class="col-xl-11">
                    <div class="row">
                        <div class="col-12">
                            <div class="slidePlaceholder" onclick="$(this).hide()">
                                <img src="{{ asset('frontend/images/swipe.gif') }}">
                            </div>
                            @php
                                if ($result->allSections->isEmpty()) {
                                    return;
                                }
                                $first_section_type = $result->allSections->first()->type ?? 'plain';
                                $section_types = ['plain', 'accordion', 'tabs'];

                                $section_types = array_merge([$first_section_type], array_diff($section_types, [$first_section_type]));
                            @endphp

                            @foreach ($section_types as $section_type)
                                @if(!$result->allSections->where('type', $section_type)->isEmpty())
                                    @php
                                        $sections = $result->allSections->where('type', $section_type);
                                        $sectionsBlocks = $sections[0]->allBlocks;
                                    @endphp
                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                        @foreach ($sectionsBlocks as $key => $block)

                                            <li class="nav-item" role="presentation">
                                                    <button class="nav-link @if($key == 0) active @endif" data-bs-toggle="tab" data-bs-target="#block{{$key}}" type="button" role="tab"
                                                            aria-selected="true">
                                                        {{$block->title}}</button>
                                                </li>
                                        @endforeach
                                    </ul>
                                @endif
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center text-white diversified-sectors mb-5 open-down"
                 id="tab-diversified">

                <div class="col-xl-11">
                    <div class="row">
                        <div class="col-12">
                            <div class="tab-content" id="myTabContent">
                                @foreach ($section_types as $section_type)
                                    @if(!$result->allSections->where('type', $section_type)->isEmpty())
                                        @php
                                            $sections = $result->allSections->where('type', $section_type);
                                            $sectionsBlocks = count($sections) > 0 ? $sections[0]->allBlocks : [];
                                        @endphp
                                        @foreach ($sectionsBlocks as $key => $block)
                                            <div class="tab-pane @if($key == 0) active show @endif" id="block{{$key}}" role="tabpanel">
                                                <div class="row">
                                                    <div class="col-sm-5 col-md-4">
                                                        <img src="{{ isset($block->featured_image->file_url) ? $block->featured_image->file_url : '' }}" class="w-100" alt="">
                                                    </div>
                                                    <div class="col-sm-7 col-md-8 text-white px-md-5 align-self-center">
                                                        <aside>
                                                            <h3>{{ $block->title }}</h3>
                                                            {!! \App\Http\Helpers::solveTemplates($block->content) !!}
                                                        </aside>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    @endif
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </content>
@endsection
