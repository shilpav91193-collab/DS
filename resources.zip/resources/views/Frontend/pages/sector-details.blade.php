@extends('Frontend.layouts.main')

@section('title')
    <title>Dubai Aviation City Corporation</title>
@endsection

@section('content')
    @php
        $locale = App::getLocale() ? App::getLocale() : 'en';
    @endphp
    <content>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-12 p-0">

                    <div class="subpag-banner">
                        <figure>
                        </figure>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center pb-0 pb-md-0">
                <div class="col-12 col-xl-11">
                    <div class="row">
                        <div class="col-12 my-3 pb-md-5">
                            <div class="breadCrumbs">
                                <ul class="list-inline m-0">
                                    <li class="list-inline-item"><a href="/">Home</a></li>
                                    <li class="list-inline-item"><a href="#">What We Do</a></li>
                                    @php
                                        $parents = \App\Http\Helpers::parentPostWithSlug($result->id);
                                        $breadcrumbs = array_reverse($parents,true);
                                        $url = '';
                                    @endphp
                                    @foreach($breadcrumbs as $index=>$val)
                                        @php
                                            $url = $url.'/'.$index;
                                        @endphp
                                        @if($val == end($breadcrumbs))
                                            <li class="list-inline-item">{{$val}}</li>
                                        @else
                                            <li class="list-inline-item"><a href="{{ route('page.show', ['slug' => $url]) }}">{{$val}}</a></li>
                                        @endif
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-12 col-xl-11">
                    <div class="row">
                        <div class="col-12 my-4 content">
                            <h2 class="text-blue large"><strong>{{ isset($result->title) ? $result->title : '' }}</strong></h2>
                        </div>
                        <div class="col-md-5">
                            <h2 class="text-blue text-uppercase">
                                <strong>{{ isset($result->sub_title) ? $result->sub_title : '' }}</strong>
                            </h2>
                        </div>

                        <div class="col-md-7">
                            <p>
                                {{ isset($result->content) ? $result->content : '' }}
                            </p>
                        </div>


                        <div class="col-12">
                            <div class="row">

                                @if(isset($result->featured_image->file_url))
                                    <div class="col-sm-12 align-self-center py-5" >
                                        <div>
                                            <figure>
                                                <img src="{{ $result->featured_image->file_url }}" class="w-100" />
                                            </figure>
                                        </div>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            @php
                $views_in_order = [
                    'Frontend.layouts.common.pagebuilder.custom.' . $result->slug .'_sections',
                    'Frontend.layouts.common.pagebuilder.sections',
                ];

                $first_existing_view = collect($views_in_order)->first(function($view) {
                    return View::exists($view);
                });
            @endphp

            @include($first_existing_view)
        </div>
    </content>

@endsection
