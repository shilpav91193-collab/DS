@php
    $ids = isset($block->meta->faculties) ? json_decode($block->meta->faculties) : [];
    $faculty_datas = Helpers::getFacultiesList($ids);
@endphp
@if($faculty_datas->count() > 0)
    @if($show_block_title)
        <h2>{{ $block->title }}</h2>
    @endif

    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-3 g-lg-5 my-0">
        @foreach($faculty_datas as $team)
            @include('Frontend.pages.inc.team-block',['data'=>$team])
        @endforeach
    </div>
@endif
