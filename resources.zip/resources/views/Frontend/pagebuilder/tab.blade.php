<div class="container">
    <div class="row">

        @if($show_block_title)
        <div class="col-12 position-relative" >
            <h2 class="mb-4">{{ $block->title }}</h2>
        </div>
        @endif
        @php
        $tabs = (object) json_decode($block->meta->tabs ?? '[]');
        @endphp
        
            <div class="d-flex flex-wrap">
                    <ul class="nav nav-pill list-inline themeTab" role="tablist">
                    @foreach ($tabs as $tab)
                    @php
                    $block->title = $block->title ?? '';
                    $block->content = $block->content ?? '';
                    $slug = Str::slug($block->title . '_' . $tab->title . '_' . $loop->index);
                    @endphp
                    <li class="nav-item list-inline-item">
                        <a class="nav-link @if($loop->first) active @endif" href="#{{ $slug }}_tab" role="tab"
                         data-bs-toggle="tab">{!! $tab->title ?? 'Tab - '.$loop->index !!}</a>
                    </li>
                    @endforeach
                    </ul>
            </div>
            <div class="tab-content py-4 content">
                @foreach ($tabs as $tab)
                @php
                $block->title = $block->title ?? '';
                $tab->title = $tab->title ?? '';
                $slug = Str::slug($block->title . '_' . $tab->title . '_' . $loop->index);
                @endphp
                <div role="tabpanel" class="tab-pane fade show @if($loop->first) active @endif" id="{{ $slug }}_tab"> 
                    {!! Helpers::solveTemplates($tab->content ?? '') !!}
                </div>
                @endforeach
            </div>
    </div>
</div>