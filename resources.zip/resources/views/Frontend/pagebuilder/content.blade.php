<?php
    $content_width = isset($block->meta->cols) ? $block->meta->cols : 12;
    $customClass = isset($block->meta->custom_class) ? $block->meta->custom_class : null;
?>

<div class="col-{{$content_width}} {{$customClass}}">
    @if($show_block_title)
        <h2 class="text-blue">{{ $block->title }}</h2>
    @endif
    @if($block->content)
        {!! \App\Http\Helpers::solveTemplates($block->content) !!}
    @endif
    @if (($block->meta->button_text ?? false) && ($block->meta->button_url ?? false) && $block->meta->button_text != 'null')
            <a href="{{ $block->meta->button_url }}"
               class="btn btn-primary mt-3 mt-md-5">{{ $block->meta->button_text }}</a>
    @endif
</div>
