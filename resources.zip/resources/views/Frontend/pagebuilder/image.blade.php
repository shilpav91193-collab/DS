{{--@if($block->image && $block->featured_image)--}}

{{--<?php--}}
{{--    $img_full = ($block->meta->media_full_width ?? 'N') == 'Y';--}}
{{--    if(request()->segment(2)  && (request()->segment(2)=='about-dubai'))--}}
{{--    {--}}
{{--        $class_div='ratio ratio-4x3 overflow-hidden ';--}}
{{--    }else{--}}
{{--        $class_div='mb-3 media-area';--}}
{{--    }--}}
{{--?>--}}

{{--@if(!$img_full)--}}
{{--<div class="container ">--}}
{{--@endif --}}
{{--        @if($show_block_title && !$img_full)--}}
{{--            <h2 class="mb-3">{{ $block->title }}</h2>--}}
{{--        @endif--}}
{{--       --}}
{{--            @if ($block->featured_image->content_type == 'video')--}}
{{--                <!-- embed youtube video to fit the given space automatically -->--}}
{{--                <div style="max-height: 500px;"--}}
{{--                    onclick="document.getElementById('video_iframe').src = 'https:\/\/www.youtube.com\/embed\/{{ $block->featured_image->video_id }}'"--}}
{{--                    class="aboutVideoThumb position-relative cursor-pointer mb-3 overflow-hidden "--}}
{{--                    data-bs-toggle="modal" data-bs-target="#videoModal">--}}
{{--                    <img style="max-height: 500px; object-fit: cover;" src="{{ $block->featured_image->video_thumbnail }}"--}}
{{--                    onerror="this.onerror=null;this.src='{{ $block->featured_image->video_thumbnail }}';"--}}
{{--                        class="imageInline pointer @if(!$img_full) rounded @endif" alt="amity">--}}
{{--                    <div class="overlay flex-column text-white grow">--}}
{{--                        <i class="fa-4x far fa-play-circle"></i>--}}
{{--                        @if($block->meta->image_text ?? false)--}}
{{--                        <h4 class="mt-4">{{ $block->meta->image_text }}</h4>--}}
{{--                        @endif--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            @else--}}
{{--                @if($block->meta->image_external_url ?? false)--}}
{{--                <a href="{{ $block->meta->image_external_url }}">--}}
{{--                    @endif--}}
{{--                    <div class="{{ $class_div}} "> --}}
{{--                        <img src="{{ $block->featured_image->file_url }}"--}}
{{--                        onerror="this.onerror=null;this.src='{{ $block->featured_image->file_url }}';"--}}
{{--                        class="img-fluid pointer @if(!$img_full) rounded @endif"--}}
{{--                            alt="{{ $block->featured_image->file_name }}">--}}
{{--                    </div>--}}
{{--                    @if ($block->meta->image_external_url ?? false)--}}
{{--                </a>--}}
{{--                @endif--}}
{{--                @if(($block->meta->image_text ?? false) && !$img_full)--}}
{{--                @if($block->meta->image_external_url ?? false)--}}
{{--                <a href="{{ $block->meta->image_external_url }}">--}}
{{--                @endif--}}
{{--                    <h6 class="fw-bold">{{ $block->meta->image_text }}</h6>--}}
{{--                @if ($block->meta->image_external_url ?? false)--}}
{{--                </a>--}}
{{--                @endif--}}
{{--                @endif--}}
{{--            @endif--}}

{{--            --}}
{{--@if(!$img_full)--}}
{{--</div>--}}
{{--@endif--}}

{{--@endif--}}
@if($block->image && $block->featured_image)
    <div class="col-md-{{$block->meta->cols}} align-self-center" data-aos="fade-right" data-aos-duration="600" data-aos-offset="200">
        @if($show_block_title && !$img_full)
            <h2 class="mb-3">{{ $block->title }}</h2>
        @endif
        <div class="zoom">
            <figure>
                <img src="{{ $block->featured_image->file_url }}" class="w-100" alt="" >
            </figure>
        </div>
    </div>
@endif
