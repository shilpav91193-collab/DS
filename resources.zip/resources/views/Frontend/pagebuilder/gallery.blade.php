<div class="galley-block">
@php
$show_block_title = !empty($block->title) && (($block->meta->show_title ?? false) == 'Y' ||
            ($block->meta->hide_title ?? false) == 'N');
@endphp
@if($show_block_title)
    <h2 class="mb-4">{{ $block->title }}</h2>
@endif
    @php 
    $content='[amity_gallery:'.$block->meta->gallery.']';
    $gallery_display = array(
    'gallery_display_type' =>$block->meta->gallery_display_type ?? '',
    'gallery_display_col' =>$block->meta->gallery_image_col ?? 4,
    'gallery_image_title' =>$block->meta->gallery_image_title ?? '',
);
    $block->gallery=  Helpers::solveTemplates($content ?? '', $gallery_display);                                         
@endphp
{!! $block->gallery !!}   
</div>
