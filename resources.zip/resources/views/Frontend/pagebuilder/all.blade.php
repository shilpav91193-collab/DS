<div class="row {{$block->meta->custom_class }}">
<?php
    $img_pos = $block->meta->image_position ?? 'bottom';
    $ratio = $block->meta->content_media_ratio ?? '6:6';

    $imageInlineClass="";
    if($block->meta->image_position =="left_inline" || $block->meta->image_position =="right_inline")
    {
       $imageInlineClass="imageInline";
       if($block->meta->image_position =="left_inline"){
        $imageInlineClass = "imageInline float-start ps-0 pe-5";
       }
    }
    $ratio = explode(':', $ratio);
    $content_width = $ratio[0];
    $content_width2 = $ratio[1];

//    if ($content_width > 10 || $content_width < 2) {
//        $content_width = 6;
//    }
//    $media_width = 12 - $content_width;
//    $col_width = ($block->image && $block->featured_image && in_array($img_pos, ['right', 'left'])) ? 6 : 12;
//    if ($col_width == 12) {
//        $content_width = 12;
//        $media_width = 12;
//    }
//    $order = ($block->image && $block->featured_image && in_array($img_pos, ['top', 'left'])) ? 'order-first' : '';
//    $img_pos = $img_pos == 'bottom' ? 'down' : ($img_pos == 'top' ? 'up' : $img_pos);
//    $opposites = [
//        'left' => 'right',
//        'right' => 'left',
//        'up' => 'down',
//        'down' => 'up'
//    ];
?>

    @if($block->meta->image_position =="left_inline" || $block->meta->image_position =="right_inline")
        <div  class="col-md-{{ $content_width }} align-items-center content-area">
        @if(($block->meta->image_external_url ?? false) && $block->meta->image_external_url !='null')
            <a href="{{ $block->meta->image_external_url }}" target="_blank">
                <img src="{{ isset($block->featured_image->file_url)?$block->featured_image->file_url:'' }}"
                     onerror="this.onerror=null;this.src='{{ isset($block->featured_image->file_url)? $block->featured_image->file_url:'' }}';"
                     class="{{$imageInlineClass}} rounded"
                     alt="{{ isset($block->featured_image->file_name)?$block->featured_image->file_name:'' }}">
            </a>
        @else
            <img src="{{ isset($block->featured_image->file_url)?$block->featured_image->file_url:'' }}"
                 onerror="this.onerror=null;this.src='{{ isset($block->featured_image->file_url)? $block->featured_image->file_url:'' }}';"
                 class="{{$imageInlineClass}} rounded"
                 alt="{{ isset($block->featured_image->file_name)?$block->featured_image->file_name:'' }}">
        @endif
            {!! Helpers::solveTemplates($block->content) !!}

            @if (($block->meta->button_text ?? false) && ($block->meta->button_url ?? false) && ($block->meta->button_url !='null' ?? false))
                <a href="{{ $block->meta->button_url }}" class="btn btn-sm btn-tertiary mt-2">{{
                $block->meta->button_text
                }}</a>
            @endif
        </div>
    @endif

    <div  class="col-md-{{ $content_width2 }} py-5  @if ($block->meta->image_position == 'right')
     order-sm-first pe-lg-5 @else order-sm-last ps-lg-5 @endif align-self-center" @if ($block->meta->image_position == 'right')
              data-aos="fade-left" @else data-aos="fade-right" @endif data-aos-duration="600" data-aos-offset="200">
                @if($show_block_title)
                    <h2 class="text-uppercase text-blue mb-4"><strong>{{ $block->title }}</strong></h2>
                @endif

                @if($block->content)

                 {!! \App\Http\Helpers::solveTemplates($block->content) !!}

                @endif

                @if (($block->meta->button_text ?? false) && ($block->meta->button_url ?? false) &&
                        ($block->meta->button_url !='null' ?? false))
                    <a href="{{ $block->meta->button_url }}" class="btn btn-sm btn-tertiary mt-2">{{
                        $block->meta->button_text
                        }}</a>
                @endif

    </div>


    @if($block->image && $block->featured_image)
        <div  class="col-md-{{ $content_width }}
            @if($block->meta->image_position == 'right') order-sm-last
                @else order-sm-first
            @endif align-self-center"
              @if ($block->meta->image_position == 'right')
                  data-aos="fade-right"
              @else data-aos="fade-left"
              @endif  data-aos-duration="600" data-aos-offset="200">

            @if ($block->featured_image->content_type == 'video')
            <div onclick="document.getElementById('video_iframe').src = 'https:\/\/www.youtube.com\/embed\/{{ $block->featured_image->video_id }}'"
                class="aboutVideoThumb position-relative rounded cursor-pointer mb-3" data-bs-toggle="modal"
                data-bs-target="#videoModal">
                <img src="{{ $block->featured_image->video_thumbnail }}"
                onerror="this.onerror=null;this.src='{{ $block->featured_image->video_thumbnail }}';"
                class="img-fluid w-100 imageInline rounded" alt="AMITY">
                <div class="overlay flex-column text-white grow">
                    <i class="fa-4x far fa-play-circle"></i>
                    @if($block->meta->image_text ?? false)
                        <h4 class="mt-4">{{ $block->meta->image_text }}</h4>
                    @endif
                </div>
            </div>
        @else
                @if(($block->meta->image_text ?? false) && ($block->meta->image_text !='null' ?? false))
                    <div class="col-12 mb-3">
                        <h2 class="text-uppercase text-blue"><strong>Our Leadership</strong></h2>
                    </div>
                @endif

                @if($block->meta->image_position !="left_inline" &&
                        $block->meta->image_position !="right_inline")
                        <div class="zoom ">
                            <figure>
                                <img src="{{ $block->featured_image->file_url }}"
                                     onerror="this.onerror=null;this.src='{{ $block->featured_image->file_url }}';"
                                     class="{{$imageInlineClass}} w-100"
                                     alt="{{ $block->featured_image->file_name }}">
                            </figure>
                        </div>
                @endif
            @endif
        </div>
    @endif
</div>

