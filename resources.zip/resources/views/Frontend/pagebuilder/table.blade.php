

    
    @php 
        $content='[amity_tables:'.$block->meta->table.']';
        $block->table=  Helpers::solveTemplates($content ?? '');
            
    @endphp
    {!! $block->table !!}                                      
