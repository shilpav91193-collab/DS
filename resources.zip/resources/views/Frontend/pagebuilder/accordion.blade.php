@php
    $tabs = (object) json_decode($block->meta->tabs ?? '[]');
    $random_id = Str::random(10);
@endphp

<div class="col-md-{{$block->meta->cols}} py-3 align-self-center pe-lg-5" data-aos="fade-left" data-aos-duration="600" data-aos-offset="200">
    <h2 class="text-uppercase text-blue"><strong>Our Objectives</strong></h2>
    <div class="accordion" id="accordionExample">
        @foreach ($tabs as $tabKey => $tab)
            @php
                $block->title = $block->title ?? '';
                $tab->title = $tab->title ?? '';
                $slug = Str::slug($block->title . '_' . $tab->title . '_' . $loop->index);
            @endphp
            <div class="accordion-item">
                <h2 class="accordion-header" id="heading-{{$tabKey}}">
                    <button class="accordion-button @if($tabKey != 0) collapsed @endif" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-{{$tabKey}}" aria-expanded="true" aria-controls="collapse-{{$tabKey}}">
                        {{ $tab->title }}
                    </button>
                </h2>
                <div id="collapse-{{$tabKey}}" class="accordion-collapse collapse @if($tabKey == 0)  show @endif" aria-labelledby="heading-{{$tabKey}}" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        {!! Helpers::solveTemplates($tab->content)!!}
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>

