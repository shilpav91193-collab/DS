<div class="row {{$block->meta->custom_class }}">

<?php
$img_pos = $block->meta->image_position ?? 'bottom';
$ratio = $block->meta->content_media_ratio ?? '6:6';

$imageInlineClass="";
if($block->meta->image_position =="left_inline" || $block->meta->image_position =="right_inline")
{
    $imageInlineClass="imageInline";
    if($block->meta->image_position =="left_inline"){
        $imageInlineClass = "imageInline float-start ps-0 pe-5";
    }
}
$ratio = explode(':', $ratio);
$content_width = $ratio[0];
$content_width2 = $ratio[1];
?>

@if($block->image && $block->featured_image)

    @if($block->meta->image_text)
        <div class="col-12 mb-3">
            <h2 class="text-uppercase text-blue"><strong>{{$block->meta->image_text}}</strong></h2>
        </div>
    @endif

    <div class="col-md-{{ $content_width }}
            @if($block->meta->image_position == 'right') ps-lg-5
            @else  pe-lg-5 @endif" @if($block->meta->image_position == 'right')
              data-aos="fade-right"
          @else data-aos="fade-left"
          @endif  data-aos-duration="600" data-aos-offset="200">

        @if ($block->featured_image->content_type == 'video')
            <div onclick="document.getElementById('video_iframe').src = 'https:\/\/www.youtube.com\/embed\/{{ $block->featured_image->video_id }}'"
                 class="aboutVideoThumb position-relative rounded cursor-pointer mb-3" data-bs-toggle="modal"
                 data-bs-target="#videoModal">
                <img src="{{ $block->featured_image->video_thumbnail }}"
                     onerror="this.onerror=null;this.src='{{ $block->featured_image->video_thumbnail }}';"
                     class="img-fluid w-100 imageInline rounded" alt="AMITY">
                <div class="overlay flex-column text-white grow">
                    <i class="fa-4x far fa-play-circle"></i>
                    @if($block->meta->image_text ?? false)
                        <h4 class="mt-4">{{ $block->meta->image_text }}</h4>
                    @endif
                </div>
            </div>
        @else
            @if($block->meta->image_position !="left_inline" &&
                    $block->meta->image_position !="right_inline")
                <div class="zoom ">
                    <figure>
                        <img src="{{ $block->featured_image->file_url }}"
                             onerror="this.onerror=null;this.src='{{ $block->featured_image->file_url }}';"
                             class="{{$imageInlineClass}} w-100"
                             alt="{{ $block->featured_image->file_name }}">
                    </figure>
                </div>
            @endif
        @endif
    </div>
@endif

<div  class="col-md-{{ $content_width2 }} @if ($block->meta->image_position == 'right')
     order-sm-first pe-lg-4 @else ps-lg-5 order-sm-last @endif align-self-center py-5 " @if ($block->meta->image_position == 'right')
    data-aos="fade-left" @else data-aos="fade-right" @endif data-aos-duration="600" data-aos-offset="200">
    @if($show_block_title)
        <h2 class="text-uppercase text-blue"><strong>{{ $block->title }}</strong></h2>
    @endif

    @if($block->content)

        {!! \App\Http\Helpers::solveTemplates($block->content) !!}

    @endif

    @if (($block->meta->button_text ?? false) && ($block->meta->button_url ?? false) &&
            ($block->meta->button_url !='null' ?? false))
        <a href="{{ $block->meta->button_url }}" class="btn btn-sm btn-tertiary mt-2">{{
                        $block->meta->button_text
                        }}</a>
    @endif

</div>
</div>
