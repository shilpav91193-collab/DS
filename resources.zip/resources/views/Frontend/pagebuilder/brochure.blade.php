<section class="section">
    <div class="container py-5">
        @php
        $content='[amity_brochures:'.$block->meta->brochure.']';
        $block->brochure= Helpers::solveTemplates($content ?? '');
        @endphp
        {!! $block->brochure !!}
    </div>
</section>