
        @if($show_block_title)
        <div class="col-12 position-relative" data-aos="fade-down">
            <h2 class="mb-4">{{ $block->title }}</h2>
        </div>
        @endif

        @php
        $buttons = (object) json_decode($block->meta->tabs ?? '[]');
        @endphp
        @if($buttons)
        <div class="@if(isset($block->meta->custom_class)){{ $block->meta->custom_class}}  @endif " role="group" aria-label="Button Group">
            @foreach($buttons as $button)
            <a href="{{ $button->content ?? 'javascript:void()' }}" class="btn btn-primary"
                target="{{ $button->target ?? '' }}">{{ $button->title
                }}</a>
            @endforeach
        </div>
        @endif


