@extends('Frontend.layouts.main')

@section('title')
    <title>Dubai Aviation City Corporation</title>
@endsection

@section('content')
    <content>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-12 p-0">
                    <div class="subpag-banner">
                        <figure></figure>
                    </div>
                </div>
            </div>

            @include('Frontend.pages.inc.breadcrumbs',['result'=>$result])

            @php
                $views_in_order = [
                    'Frontend.layouts.common.pagebuilder.custom.' . $result->slug .'_sections',
                    'Frontend.layouts.common.pagebuilder.sections',
                ];

                $first_existing_view = collect($views_in_order)->first(function($view) {
                    return View::exists($view);
                });
            @endphp

            @include($first_existing_view)

            @if($result->children->count())
            <section class="section">
                <div class="container">

                    <div class="row row-cols-2 row-cols-sm-3 row-cols-md-4 row-cols-lg-5 g-3 g-md-5 my-0">
                        @foreach($result->children as $child)
                            <div class="col">
                                <div class="ratio ratio-1x1 position-relative hvr-grow">
                                    <div class="box box-900">
                                        <div class="imgHolder">
                                            <img class="mt-auto" src="{{ ($child->thumbnail_image)?->file_url ?? asset('images/about-dubai.png') }}"
                                                 onerror="this.onerror=null;this.src='{{ ($child->thumbnail_image)?->file_url ?? asset('images/about-dubai.png') }}';" />
                                        </div>
                                        <h6>{{ $child->title}}</h6>
                                    </div>
                                    @php
                                        $current_route = request()->path().'/';
                                    @endphp
                                    <a class="stretched-link" href="{{ route('page.show', ['slug' => $current_route.$child->slug]) }}"><span class="sr-only">{{ $child->title}}</span></a>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </section>
        @endif
        </div>
    </content>
@endsection
