<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'scroll' => 'Scroll',
    'view_all' => 'View All',
    'home' => 'Home',
    'location' => 'Location',
    'location_us_on' => 'Locate us on Google Maps',
    'privacy_policy' => 'Privacy Policy',
    'terms-and-condition' => 'Terms & Conditions',
    'copy-right' => 'Copyright © 2023 Dubai Aviation City Corporation. All Rights Reserved.',

];
