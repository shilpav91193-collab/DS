$(function () {  
  
  $('.collapse').on('shown.bs.collapse', function(e) {
    if ($(".slideShow:visible").length) {
      $(".slideShow:visible")
        .not(".slick-initialized")
        .slick({
          infinite: true,
          autoplaySpeed: 9000,
          speed: 500,
          rtl: $("html").attr("lang") == "ar" ? true : false,
          pauseOnFocus: false,
          dots: false,
          arrows: true,
          autoplay: true,
          adaptiveHeight:true,
          prevArrow:
            '<a href="javascript:void(0);" class="btnPrev hvr-grow"><i class="fas fa-arrow-left" aria-hidden="true"></i></a>',
          nextArrow:
            '<a href="javascript:void(0);" class="btnNext hvr-grow"><i class="fas fa-arrow-right" aria-hidden="true"></i></a>',
          responsive: [
            {
              breakpoint: 767,
              settings: {
                arrows: false,
                dots: true,
              },
            },
          ],
        });
    }
  });



  $('img[data-src]').lazy({
    effect: "fadeIn",
    effectTime: 250,
    threshold: 500
  });

  $("ul.dropdown-menu [data-bs-toggle='dropdown']").on(
    "click",
    function (event) {
      event.preventDefault();
      event.stopPropagation();
    }
  );

  $("#hamburgerButton").on("click", function () {
    $(".hamburger").toggleClass("open");
    if ($(".hamburger").hasClass("open")) {
      $("body").addClass("modal-open");
    } else {
      $("body").removeClass("modal-open");
    }
  });

  $(document).on("click",".slidePlaceholder",function(){
    $(this).css("display","none");
  });
    
  $(document).on("hover",".slidePlaceholder",function(){
    $(this).css("display","none");
  });

  $.fn.hasScrollBar = function () {
    return this.get(0).scrollWidth > this.innerWidth()+1;
  };

  if ($(".themeTab").length) {
    $(".themeTab").each(function () {
      console.log($(this).hasScrollBar());
      if ($(this).hasScrollBar()) {
        $(this).parent().find(".slidePlaceholder").css("display", "block");
      }
    });
  }
  /*iska*/

  if ($(window).width() > 767) {
    $('[data-bs-toggle="tooltip"]').tooltip({
      html: true,
      trigger: "hover",
    });
  }

  $('[data-bs-toggle="popover"]').popover({
    html: true,
  });
  $("a.fancybox, a[data-fancybox]").fancybox({
    loop: true,
    thumbs: {
      autoStart: true,
      axis: "x",
    },
    transitionEffect: "circular",
    buttons: ["counter", "close", "thumbs"],
  });

  $(document).on("click", ".viewTable", function () {
    if ($(this).find("i").hasClass("fa-plus-circle")) {
      $(this).closest(".table-responsive").css("height", "auto");
      $(this).closest(".table-responsive").addClass("expanded");
      $(this).html('<i class="fas fa-minus-circle fa-2x"></i>');
    } else {
      $(this).closest(".table-responsive").css("height", "750px");
      $(this).closest(".table-responsive").removeClass("expanded");
      $(this).html('<i class="fas fa-plus-circle fa-2x"></i>');
    }

 

    if ($(".projectNavDetails").length) {
      var height = $(
        ".projectNavDetails .slick-current.slick-active"
      ).outerHeight(true);
      $(".projectNavDetails .slick-list.draggable").animate({ height: height });
    }
  });

  makeTableResponsive();
  if ($(".select2").length) {
    $(".select2").select2({
      bootstrapVersion: 4,
      theme: "bootstrap4",
    });
  }


  if ($(".newsTicker").length) {
    $(".newsTicker")
      .not(".slick-initialized")
      .slick({
        rtl: $("html").attr("lang") == "ar" ? true : false,
        dots: false,
        infinite: true,
        speed: 500,
        autoplaySpeed: 5000,
        autoplay: false,
        arrows: true,
        prevArrow:
          $("html").attr("lang") == "ar"
            ? '<a href="javascript:void(0);" class="btnPrev"><i class="fa fa-angle-right" aria-hidden="true"></i></a>'
            : '<a href="javascript:void(0);" class="btnPrev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>',
        nextArrow:
          $("html").attr("lang") == "ar"
            ? '<a href="javascript:void(0);" class="btnNext"><i class="fa fa-angle-left" aria-hidden="true"></i></a>'
            : '<a href="javascript:void(0);" class="btnNext"><i class="fa fa-angle-right" aria-hidden="true"></i></a>',
      });
  }

  if ($(".slideShow:visible").length) {
    $(".slideShow:visible")
      .not(".slick-initialized")
      .slick({
        infinite: true,
        autoplaySpeed: 9000,
        speed: 500,
        rtl: $("html").attr("lang") == "ar" ? true : false,
        pauseOnFocus: false,
        dots: false,
        arrows: true,
        autoplay: true,
        adaptiveHeight:true,
        prevArrow:
          '<a href="javascript:void(0);" class="btnPrev hvr-grow"><i class="fas fa-arrow-left" aria-hidden="true"></i></a>',
        nextArrow:
          '<a href="javascript:void(0);" class="btnNext hvr-grow"><i class="fas fa-arrow-right" aria-hidden="true"></i></a>',
        responsive: [
          {
            breakpoint: 767,
            settings: {
              arrows: false,
              dots: true,
            },
          },
        ],
      });
  }

  var cardClearer, cardslider;
  if ($(".careerSlider").length) {
    cardslider = $(".careerSlider")
      .cardslider({
        dots: false,
        loop: true,
        direction:'right'
      })
      .data("cardslider");
  }

  var tempCard, currentCard;
  $(".cardslider-nav-next").on("click", function () {
    tempCard = currentCard;
    currentCard = $(".cardslider-card[aria-hidden='false']").index();
    console.log(tempCard + "==" + currentCard);
    if (tempCard == currentCard) {
      cardslider.changeCardTo("first");
      currentCard = 0;
    }
  });

  tempCard = null;
  currentCard = 0;
  $(".cardslider-nav-prev").on("click", function () {
    tempCard = currentCard;
    currentCard = $(".cardslider-card[aria-hidden='false']").index();
    console.log(tempCard + "==" + currentCard);
    if (tempCard == currentCard) {
      cardslider.changeCardTo("last");
      currentCard = 0;
    }
  });

  function gotoNextCard(gotoFirst) {
    if (gotoFirst) {
      cardslider.changeCardTo("first");
    } else {
      cardslider.nextCard();
    }
  }

  
  if ($(".verticalSlider").length) {
    $(".verticalSlider")
      .not(".slick-initialized")
      .slick({
        infinite: false,
        autoplaySpeed: 5000,
        speed: 500,
        pauseOnFocus: false,
        dots: true,
        arrows: true,
        autoplay: false,
        prevArrow:
          '<a href="javascript:void(0);" class="btnPrev hvr-grow"><i class="fas fa-arrow-left" aria-hidden="true"></i></a>',
        nextArrow:
          '<a href="javascript:void(0);" class="btnNext hvr-grow"><i class="fas fa-arrow-right" aria-hidden="true"></i></a>',
      });
  }

  if ($(".thumbnailTabs").length) {
    $(".thumbnailTabs")
      .not(".slick-initialized")
      .slick({
        infinite: false,
        autoplaySpeed: 5000,
        speed: 500,
        rtl: $("html").attr("lang") == "ar" ? true : false,
        pauseOnFocus: false,
        dots: false,
        arrows: true,
        autoplay: false,
        slidesToShow: 6,
        prevArrow:
          '<a href="javascript:void(0);" class="btnPrev"><i class="fas fa-arrow-left" aria-hidden="true"></i></a>',
        nextArrow:
          '<a href="javascript:void(0);" class="btnNext"><i class="fas fa-arrow-right" aria-hidden="true"></i></a>',
        responsive: [
          {
            breakpoint: 991,
            settings: {
              slidesToShow: 5,
            },
          },
          {
            breakpoint: 767,
            settings: {
              slidesToShow: 4,
            },
          },
          {
            breakpoint: 575,
            settings: {
              slidesToShow: 3,
            },
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 2,
            },
          },
        ],
      });
  }

  $("marquee")
    .mouseover(function () {
      $(this).attr("scrollamount", 0);
    })
    .mouseout(function () {
      $(this).attr("scrollamount", 5);
    });

  $(window).on("show.bs.modal", function () {
    $(".modal").modal("hide");
  });

  $(".modal").appendTo("body") 

  $(document).on("hidden.bs.modal", function () {
    if ($(".modal").hasClass("show")) {
      $("body").addClass("modal-open");
    }
  });

  $(document).on("click", ".thumbnailTabs button[role='tab']", function (e) {
    window.location.hash = this.id.replace("-tab", "");
    setTimeout(function () {
      makeTableResponsive();
    }, 500);
  });

  $(document).on("click", ".themeTab a[role='tab']", function () {
    setTimeout(function () {
      makeTableResponsive();
    }, 500);
  });

  $(document).on("click", "a[data-bs-toggle='collapse']", function () {
    setTimeout(function () {
      makeTableResponsive();
    }, 500);
  });

  if(window.location.hash){
    setTimeout(()=>$(window.location.hash+"-tab").click(),100);
  }

  $(window).on("load resize", function () {

    if ($(window).width() <= 1199) {
      if ($(".courseDetailsTab").length) {
        $(".nav-tabs").scrollingTabs("refresh");
      }
    }
  });

  if ($(window).width() <= 1199) {
    if ($(".courseDetailsTab").length) {
      $(".nav-tabs").scrollingTabs("destroy");
      $(".nav-tabs").scrollingTabs({
        enableSwiping: true,
        handleDelayedScrollbar: true,
        scrollToTabEdge: true,
        disableScrollArrowsOnFullyScrolled: true,
        bootstrapVersion: 4,
      });
    }
  }

});

function makeTableResponsive() {
  $(".table-responsive:visible").each(function () {
    if ($(this).find(".viewTable").length == 0 && $(this).outerHeight() > 850) {
      $(this).append(
        '<a href="javascript:void(0)" class="viewTable"><i class="fas fa-plus-circle fa-2x"></i></a>'
      );
      $(this).css("height", "750px");

      $.fn.scrollWidth = function () {
        return this.get(0).scrollWidth;
      };
      $(this)
        .find(".viewTable")
        .css({
          width: $(this).scrollWidth() + "px",
        });

    } else {
      if ($(this).outerHeight() < 400) {
        $(this).addClass("expanded");
      }
    }
  });
}


$(document).on("click", ".career-modal", function () {
  $('#staticBackdrop').modal('show'); 
  $(".modalData").html('<dic class="d-block text-center align-items-stretch"><img class="mx-auto" src="https://beta3.timesworld.datasight.biz/amity-website/public/images/ajax-loader.gif" /> </div>');

  $.ajax({
    url: $(this).data('url'),
    method: 'GET',
    data: { id: $(this).data('id')},
    success: function (response) {
        $(".modalData").html(response);
    },
    error: function (error) {
        console.error(error);
    }
});
});



jQuery.extend(jQuery.easing, {
  easeInOutCubic: function (x, t, b, c, d) {
    if ((t /= d / 2) < 1) return (c / 2) * t * t * t + b;
    return (c / 2) * ((t -= 2) * t * t + 2) + b;
  },
});

$(document).ready(function() {
  $(".galleryAlbumBlock").on("click", function() {
    var urlf=$(this)+' '+'img';
    var url= $(this).find("img").attr("src");   
      data_images = new Array({
        src: url,
        opts: {
            thumb: url
        }
    });
      $.fancybox.open(data_images, {
          loop: true,
          thumbs: {
              autoStart: true,
              axis: 'x'
          },
          transitionEffect: 'circular',
          buttons: [
              'counter', 'close', 'thumbs'
          ]
      });
  });
  
});


$(document).ready(function() {
  $('#formSubmission').submit(function() {
    // Get the submit button element
    var submitBtn = $('#submitBtn');
    
    // Change the button text to "Loading"
    submitBtn.val('Loading...');
    
    // Disable the button to prevent multiple submissions
    submitBtn.prop('disabled', true);
  });
});

