<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ContactMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct($email, $template, $data, $subject, $language)
    {
        $this->template = $template;
        $this->data = $data;
        $this->subject = $subject;
        $this->language = $language;
        $this->email = $email;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $template = 'emails.'.$this->template;
        $logoImage = asset('frontend/images/logo-w2.png');

        return $this->to($this->email)
            ->subject($this->subject)
            ->view($template)
            ->with(['attributes' => $this->data, 'logoImage' => $logoImage]);
    }
}
