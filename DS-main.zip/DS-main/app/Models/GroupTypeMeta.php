<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * App\Models\GroupTypeMeta
 *
 * @property int $id
 * @property int|null $group_type_id
 * @property string|null $meta_key
 * @property string|null $meta_value
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @method static \Illuminate\Database\Eloquent\Builder|GroupTypeMeta newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|GroupTypeMeta newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|GroupTypeMeta onlyTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|GroupTypeMeta query()
 * @method static \Illuminate\Database\Eloquent\Builder|GroupTypeMeta whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupTypeMeta whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupTypeMeta whereGroupTypeId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupTypeMeta whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupTypeMeta whereMetaKey($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupTypeMeta whereMetaValue($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupTypeMeta whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupTypeMeta withTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|GroupTypeMeta withoutTrashed()
 * @mixin \Eloquent
 */
class GroupTypeMeta extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'group_type_metas';

    protected $fillable = ['group_type_id', 'meta_key', 'meta_value', 'created_at'];
}
