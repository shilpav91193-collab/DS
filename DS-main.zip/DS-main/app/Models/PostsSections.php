<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\PostsSections
 *
 * @property int $id
 * @property string|null $title
 * @property string|null $type
 * @property int|null $post_id
 * @property int|null $blocks
 * @property int|null $sort_order
 * @property string|null $status
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $deleted_at
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\PostsBlocks> $allBlocks
 * @property-read int|null $all_blocks_count
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\PostsSectionsMeta> $metas
 * @property-read int|null $metas_count
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSections newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSections newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSections query()
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSections whereBlocks($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSections whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSections whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSections whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSections wherePostId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSections whereSortOrder($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSections whereStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSections whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSections whereType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSections whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class PostsSections extends Model
{
    protected $table = 'posts_sections';

    protected $fillable = ['title', 'post_id', 'blocks', 'sort_order', 'created_at', 'status', 'type'];

    public function meta()
    {
        $results = $this->hasMany('App\Models\PostsSectionsMeta', 'section_id')->pluck('meta_value', 'meta_key')->toArray();

        return  (object) $results;
    }

    public function blockItems()
    {
        $results = $this->belongsTo('App\Models\PostsBlocks', 'id', 'section_id')
            ->select('posts_blocks.*')
            ->with('featured_image')
            ->orderBy('posts_blocks.sort_order', 'ASC')
            ->get();

        return $results;
    }

    public function blockItem($no)
    {
        $result = $this->belongsTo('App\Models\PostsBlocks', 'id', 'section_id')
            ->where('sort_order', $no)->first();

        return $result;
    }

    public function metas()
    {
        return $this->hasMany(PostsSectionsMeta::class, 'section_id')->select('id', 'meta_key', 'meta_value', 'section_id');
    }

    public function allBlocks()
    {
        return $this->hasMany(PostsBlocks::class, 'section_id')->orderBy('sort_order', 'ASC');
    }

    public function getTypeAttribute($value)
    {
        return $value ?? 'plain';
    }
}
