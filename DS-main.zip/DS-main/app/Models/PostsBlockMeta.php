<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\PostsBlockMeta
 *
 * @property int $id
 * @property int|null $block_id
 * @property string|null $meta_key
 * @property string|null $meta_value
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $deleted_at
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlockMeta newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlockMeta newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlockMeta query()
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlockMeta whereBlockId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlockMeta whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlockMeta whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlockMeta whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlockMeta whereMetaKey($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlockMeta whereMetaValue($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlockMeta whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class PostsBlockMeta extends Model
{
    //
    protected $table = 'posts_blocks_meta';

    protected $fillable = ['block_id', 'meta_key', 'meta_value', 'created_at'];
}
