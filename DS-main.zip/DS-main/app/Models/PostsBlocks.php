<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\PostsBlocks
 *
 * @property int $id
 * @property int|null $post_id
 * @property int|null $section_id
 * @property string|null $title
 * @property string|null $content
 * @property string|null $image
 * @property string|null $status
 * @property int|null $sort_order
 * @property int|null $added_by
 * @property int|null $updated_by
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $deleted_at
 * @property-read \App\Models\Medias|null $featured_image
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\PostsBlockMeta> $metas
 * @property-read int|null $metas_count
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks query()
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks whereAddedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks whereContent($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks whereImage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks wherePostId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks whereSectionId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks whereSortOrder($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks whereStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsBlocks whereUpdatedBy($value)
 * @mixin \Eloquent
 */
class PostsBlocks extends Model
{
    protected $table = 'posts_blocks';

    protected $fillable = ['post_id', 'section_id', 'title', 'content', 'image', 'status', 'added_by', 'updated_by', 'created_at', 'sort_order'];

    public function meta()
    {
        $results = $this->hasMany('App\Models\PostsBlockMeta', 'block_id')->pluck('meta_value', 'meta_key')->toArray();

        return  (object) $results;
    }

    public function featured_image()
    {
        return $this->hasOne(Medias::class, 'id', 'image');
    }

    public function metas()
    {
        return $this->hasMany(PostsBlockMeta::class, 'block_id')->select('id', 'meta_key', 'meta_value', 'block_id');
    }
}
