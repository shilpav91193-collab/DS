<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\GroupCategory
 *
 * @method static \Illuminate\Database\Eloquent\Builder|GroupCategory newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|GroupCategory newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|GroupCategory query()
 * @mixin \Eloquent
 */
class GroupCategory extends Model
{
    use HasFactory;
}
