<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\MenuAccess
 *
 * @method static \Illuminate\Database\Eloquent\Builder|MenuAccess newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|MenuAccess newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|MenuAccess query()
 * @mixin \Eloquent
 */
class MenuAccess extends Model
{
    use HasFactory;
}
