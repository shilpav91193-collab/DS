<?php

namespace App\Models;

use App\Http\Helpers;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\Medias
 *
 * @property int $id
 * @property int|null $objectID
 * @property string|null $content_type
 * @property string|null $file_name
 * @property string|null $file_title
 * @property string|null $file_url
 * @property string|null $is_default Y,N
 * @property int|null $sort_order
 * @property int|null $created_by
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $deleted_at
 * @property-read mixed $video_id
 * @property-read mixed $video_thumbnail
 * @method static \Illuminate\Database\Eloquent\Builder|Medias newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Medias newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Medias query()
 * @method static \Illuminate\Database\Eloquent\Builder|Medias whereContentType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Medias whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Medias whereCreatedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Medias whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Medias whereFileName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Medias whereFileTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Medias whereFileUrl($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Medias whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Medias whereIsDefault($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Medias whereObjectID($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Medias whereSortOrder($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Medias whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class Medias extends Model
{
    use HasFactory;

    public function getFileUrlAttribute($value)
    {
        return Helpers::asset($value);
    }

    public function getVideoIdAttribute()
    {
        $regex = '/https?:\/\/(?:[0-9A-Z-]+\.)?(?:youtu\.be\/|youtube(?:-nocookie)?\.com\S*?[^\w\s-])([\w-]{11})(?=[^\w-]|$)(?![?=&+%\w.-]*(?:[\'"][^<>]*>|<\/a>))[?=&+%\w.-]*/i';
        // return id of youtube video
        preg_match($regex, $this->file_url, $matches);
        if (isset($matches[1])) {
            return $matches[1];
        }

        return null;
    }

    public function getVideoThumbnailAttribute()
    {
        $regex = '/https?:\/\/(?:[0-9A-Z-]+\.)?(?:youtu\.be\/|youtube(?:-nocookie)?\.com\S*?[^\w\s-])([\w-]{11})(?=[^\w-]|$)(?![?=&+%\w.-]*(?:[\'"][^<>]*>|<\/a>))[?=&+%\w.-]*/i';
        // return id of youtube video
        preg_match($regex, $this->file_url, $matches);
        if (isset($matches[1])) {
            return 'https://img.youtube.com/vi/'.$matches[1].'/maxresdefault.jpg';
        }

        return null;
    }
}
