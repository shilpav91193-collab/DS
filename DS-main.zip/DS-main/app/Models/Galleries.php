<?php

namespace App\Models;

use App\Http\Helpers;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\Galleries
 *
 * @property int $id
 * @property string|null $title
 * @property string|null $description
 * @property string|null $images
 * @property int|null $sort_order
 * @property string|null $status Y,N
 * @property int|null $created_by
 * @property int|null $updated_by
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $deleted_at
 * @method static \Illuminate\Database\Eloquent\Builder|Galleries newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Galleries newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Galleries query()
 * @method static \Illuminate\Database\Eloquent\Builder|Galleries whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Galleries whereCreatedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Galleries whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Galleries whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Galleries whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Galleries whereImages($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Galleries whereSortOrder($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Galleries whereStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Galleries whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Galleries whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Galleries whereUpdatedBy($value)
 * @mixin \Eloquent
 */
class Galleries extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'description',
        'status',
        'created_by',
        'updated_by',
        'sort_order',
        'images',
    ];

    public function getWithImages($one = false)
    {
        $medias = Medias::get(['id', 'file_url', 'file_title', 'is_default']);

        if (! $one) {
            $galleries = Galleries::where('status', 'Y')
                ->get()
                ->map(function ($gallery) use ($medias) {
                    $images_list = (array) json_decode($gallery->images);
                    $new_content = [];

                    foreach ($images_list as $image_list) {
                        $media = $medias->firstWhere('id', $image_list);
                        $media->file_url = Helpers::asset($media->file_url);
                        $new_content[] = $media;
                    }

                    $gallery->images = $new_content;

                    return $gallery;
                });
        } else {
            $images_list = (array) json_decode($this->images);
            $new_content = [];

            foreach ($images_list as $image_list) {
                $media = $medias->firstWhere('id', $image_list);
                $media->file_url = Helpers::asset($media->file_url);
                $new_content[] = $media;
            }

            $this->images = $new_content;

            return $this;
        }

        return $galleries;
    }
}
