<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * App\Models\Sector
 *
 * @property int $id
 * @property string|null $title
 * @property string|null $sub_title
 * @property string|null $slug
 * @property int|null $image
 * @property string|null $short_description
 * @property string|null $content
 * @property string|null $status Y for yes, N for no
 * @property int|null $sort_order
 * @property int|null $created_by
 * @property int|null $updated_by
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @property-read \App\Models\Medias|null $featured_image
 * @method static \Illuminate\Database\Eloquent\Builder|Sector newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Sector newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Sector onlyTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|Sector query()
 * @method static \Illuminate\Database\Eloquent\Builder|Sector whereContent($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Sector whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Sector whereCreatedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Sector whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Sector whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Sector whereImage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Sector whereShortDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Sector whereSlug($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Sector whereSortOrder($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Sector whereStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Sector whereSubTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Sector whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Sector whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Sector whereUpdatedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Sector withTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|Sector withoutTrashed()
 * @mixin \Eloquent
 */
class Sector extends Model
{
    use HasFactory;
    use SoftDeletes;

    public function featured_image()
    {
        return $this->hasOne(Medias::class, 'id', 'image');
    }
}
