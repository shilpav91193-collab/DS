<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\MenuItems
 *
 * @method static \Illuminate\Database\Eloquent\Builder|MenuItems newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|MenuItems newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|MenuItems query()
 * @mixin \Eloquent
 */
class MenuItems extends Model
{
    use HasFactory;
}
