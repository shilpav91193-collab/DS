<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\PostTranslation
 *
 * @property int $id
 * @property string|null $language_code
 * @property int|null $post_id
 * @property string|null $title
 * @property string|null $content
 * @property string|null $subtitle
 * @property string|null $status Y for yes, N for no
 * @property int|null $created_by
 * @property int|null $updated_by
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $deleted_at
 * @method static \Illuminate\Database\Eloquent\Builder|PostTranslation newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PostTranslation newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PostTranslation query()
 * @method static \Illuminate\Database\Eloquent\Builder|PostTranslation whereContent($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostTranslation whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostTranslation whereCreatedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostTranslation whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostTranslation whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostTranslation whereLanguageCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostTranslation wherePostId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostTranslation whereStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostTranslation whereSubtitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostTranslation whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostTranslation whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostTranslation whereUpdatedBy($value)
 * @mixin \Eloquent
 */
class PostTranslation extends Model
{
    use HasFactory;
}
