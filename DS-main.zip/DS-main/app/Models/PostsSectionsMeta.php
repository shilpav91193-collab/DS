<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\PostsSectionsMeta
 *
 * @property int $id
 * @property int|null $section_id
 * @property string|null $meta_key
 * @property string|null $meta_value
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $deleted_at
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSectionsMeta newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSectionsMeta newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSectionsMeta query()
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSectionsMeta whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSectionsMeta whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSectionsMeta whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSectionsMeta whereMetaKey($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSectionsMeta whereMetaValue($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSectionsMeta whereSectionId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostsSectionsMeta whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class PostsSectionsMeta extends Model
{
    protected $table = 'posts_sections_meta';

    protected $fillable = ['section_id', 'meta_key', 'meta_value', 'created_at'];
}
