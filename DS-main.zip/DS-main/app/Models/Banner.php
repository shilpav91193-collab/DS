<?php

namespace App\Models;

use App\Http\Helpers;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * App\Models\Banner
 *
 * @property int $id
 * @property string|null $title
 * @property string|null $contents
 * @property string|null $status Y, N
 * @property int|null $created_by
 * @property int|null $updated_by
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @method static \Illuminate\Database\Eloquent\Builder|Banner newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Banner newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Banner onlyTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|Banner query()
 * @method static \Illuminate\Database\Eloquent\Builder|Banner whereContents($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Banner whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Banner whereCreatedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Banner whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Banner whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Banner whereStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Banner whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Banner whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Banner whereUpdatedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Banner withTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|Banner withoutTrashed()
 * @mixin \Eloquent
 */
class Banner extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = [
        'title', 'status', 'created_by', 'updated_by', 'sort_order', 'contents',
    ];

    public function getWithImages($one = false, $fields = ['*'])
    {
        $medias = Medias::get(['id', 'file_url', 'file_title', 'is_default']);

        if (! $one) {
            $galleries = Banner::where('status', 'Y')->get($fields)->map(function ($gallery) use ($medias) {
                $images_list = json_decode($gallery->contents);
                $new_content = [];
                foreach ($images_list as $image_list) {
                    if (($image_list->type ?? '') != 'video') {
                        $media = $medias->firstWhere('id', $image_list->id);
                        $media->file_url = Helpers::asset($media->file_url);
                        $new_content[] = array_merge((array) $media->toArray(), (array) $image_list);
                    } else {
                        $new_content[] = (array) $image_list;
                    }
                }
                $gallery->contents = $new_content;

                return $gallery;
            });
        } else {
            $images_list = json_decode($this->contents);
            $new_content = [];
            foreach ($images_list as $image_list) {
                if (($image_list->type ?? '') != 'video') {
                    $media = $medias->firstWhere('id', $image_list->id);
                    if ($media) {
                        $media->file_url = Helpers::asset($media->file_url);
                        $new_content[] = array_merge((array) $media->toArray(), (array) $image_list);
                    }
                } else {
                    $new_content[] = (array) $image_list;
                }
            }
            $this->contents = $new_content;

            return $this;
        }

        return $galleries;
    }

    public function getResponsiveImages()
    {
        try {
            // $contents = json_decode($this->contents, true);
            $contents = $this->contents;
            if (! is_array($contents)) {
                $contents = json_decode($this->contents, true);
            }
            $banner_images = array_merge(array_column($contents, 'id'), array_column($contents, 'mobile'));
            $banner_images = array_unique(array_values($banner_images));
        } catch (\Exception $e) {
            $banner_images = [];
            $contents = [];
        }

        if (! is_array($banner_images)) {
            $banner_images = [];
        }
        if (count($banner_images) > 0) {
            $banner_images = Medias::whereIn('id', $banner_images)
                ->orderByRaw('FIELD(id, '.implode(',', $banner_images).')')
                ->get();
        }
        $contents = array_map(function ($content) use ($banner_images) {
            $media = $banner_images->firstWhere('id', $content['id'] ?? null);
            if ($media) {
                $content['file_url_desktop'] = Helpers::asset($media->file_url);
            }
            $media = $banner_images->firstWhere('id', $content['mobile'] ?? null);
            if ($media) {
                $content['file_url_mobile'] = Helpers::asset($media->file_url);
            } else {
                $content['file_url_mobile'] = $content['file_url_desktop'] ?? '';
            }
            $content['file_link'] = $content['meta_url'] ?? '';
            $content['target'] = $content['target'] ?? '';

            return $content;
        }, $contents);

        return $contents;
    }
}
