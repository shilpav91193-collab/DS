<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * App\Models\Posts
 *
 * @property int $id
 * @property int|null $parent_id
 * @property string|null $title
 * @property string|null $content
 * @property string|null $slug
 * @property string|null $image
 * @property int|null $thumbnail
 * @property string|null $post_type
 * @property string|null $content_type
 * @property int|null $service_id
 * @property string|null $status
 * @property int|null $sort_order
 * @property int|null $created_by
 * @property int|null $updated_by
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\PostsSections> $allSections
 * @property-read int|null $all_sections_count
 * @property-read \App\Models\Banner|null $banner
 * @property-read \Illuminate\Database\Eloquent\Collection<int, Posts> $children
 * @property-read int|null $children_count
 * @property-read \App\Models\User|null $createdby
 * @property-read \App\Models\Medias|null $featured_image
 * @property-read \App\Models\Galleries|null $gallery
 * @property-read mixed $sub_title
 * @property-read \Illuminate\Database\Eloquent\Collection<int, Posts> $pages
 * @property-read int|null $pages_count
 * @property-read Posts|null $parent
 * @property-read \Illuminate\Database\Eloquent\Collection<int, Posts> $posts
 * @property-read int|null $posts_count
 * @property-read \Illuminate\Database\Eloquent\Collection<int, Posts> $services
 * @property-read int|null $services_count
 * @property-read \App\Models\Medias|null $thumbnail_image
 * @method static \Illuminate\Database\Eloquent\Builder|Posts active()
 * @method static \Illuminate\Database\Eloquent\Builder|Posts mainPages()
 * @method static \Illuminate\Database\Eloquent\Builder|Posts newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Posts newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Posts onlyTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|Posts query()
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereContent($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereContentType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereCreatedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereImage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereParentId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts wherePostType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereServiceId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereSlug($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereSortOrder($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereThumbnail($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts whereUpdatedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Posts withTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|Posts withoutTrashed()
 * @mixin \Eloquent
 */
class Posts extends Model
{
    use SoftDeletes;

    protected $fillable = ['parent_id', 'title', 'content', 'slug', 'image', 'thumbnail', 'post_type', 'content_type', 'created_by', 'updated_by', 'status', 'created_at', 'sort_order'];

    protected $appends = [
        'sub_title',
    ];

    public function subtitle()
    {
        $result = $this->belongsTo('App\Models\PostMeta', 'id', 'post_id')
            ->where('meta_key', DB::raw("'subtitle'"))->first();

        return isset($result->meta_value) ? $result->meta_value : '';
    }

    public function getSubTitleAttribute()
    {
        $result = $this->belongsTo('App\Models\PostMeta', 'id', 'post_id')
            ->where('meta_key', DB::raw("'subtitle'"))->first();

        return isset($result->meta_value) ? $result->meta_value : '';
    }

    public function excerpt()
    {
        $result = $this->belongsTo('App\Models\PostMeta', 'id', 'post_id')
            ->where('meta_key', DB::raw("'excerpt'"))->first();

        return isset($result->meta_value) ? $result->meta_value : '';
    }

    public function banner()
    {
        return $this->hasOneThrough(
            Banner::class,
            PostMeta::class,
            'post_id', // Foreign key on the users table...
            'id', // Foreign key on the posts table...
            'id', // Local key on the countries table...
            'meta_value' // Local key on the users table...
        )->where('post_meta.meta_key', 'banner_id');
    }

    public function gallery()
    {
        return $this->hasOneThrough(
            Galleries::class,
            PostMeta::class,
            'post_id', // Foreign key on the users table...
            'id', // Foreign key on the posts table...
            'id', // Local key on the countries table...
            'meta_value' // Local key on the users table...
        )->where('post_meta.meta_key', 'gallery_id');
    }

    public function meta_title()
    {
        $result = $this->belongsTo('App\Models\PostMeta', 'id', 'post_id')
            ->where('meta_key', DB::raw("'meta_title'"))->first();

        return isset($result->meta_value) ? $result->meta_value : '';
    }

    public function meta_keyword()
    {
        $result = $this->belongsTo('App\Models\PostMeta', 'id', 'post_id')
            ->where('meta_key', DB::raw("'meta_keyword'"))->first();

        return isset($result->meta_value) ? $result->meta_value : '';
    }

    public function meta_description()
    {
        $result = $this->belongsTo('App\Models\PostMeta', 'id', 'post_id')
            ->where('meta_key', DB::raw("'meta_description'"))->first();

        return isset($result->meta_value) ? $result->meta_value : '';
    }

    public function og_image()
    {
        $result = $this->belongsTo('App\Models\PostMeta', 'id', 'post_id')
            ->where('meta_key', DB::raw("'og_image'"))->first();

        return isset($result->meta_value) ? $result->meta_value : '';
    }

    public function view_type()
    {
        $result = $this->belongsTo('App\Models\PostMeta', 'id', 'post_id')
            ->where('meta_key', DB::raw("'view_type'"))->first();

        return isset($result->meta_value) ? $result->meta_value : '';
    }

    public function meta()
    {
        $results = $this->hasMany('App\Models\PostMeta', 'post_id')->pluck('meta_value', 'meta_key')->toArray();

        return  (object) $results;
    }

    public function sections($no = '')
    {
        $results = $this->belongsTo('App\Models\PostsSections', 'id', 'post_id')
            ->when($no, function ($query) use ($no) {
                $query->where('sort_order', $no);
            })
            ->orderBy('sort_order', 'ASC')
            ->get();

        return $results;
    }

    public function sections_api($no = '')
    {
        $results = $this->belongsTo('App\Models\PostsSections', 'id', 'post_id')
            ->when($no, function ($query) use ($no) {
                $query->where('sort_order', $no);
            })
            ->where('status', 'Y')
            ->orderBy('sort_order', 'ASC')
            ->get();

        return $results;
    }

    public function allSections()
    {
        return $this->hasMany(PostsSections::class, 'post_id', 'id')->orderBy('sort_order', 'ASC');
    }

    public function featured_image()
    {
        return $this->hasOne(Medias::class, 'id', 'image');
    }

    public function thumbnail_image()
    {
        return $this->hasOne(Medias::class, 'id', 'thumbnail');
    }

    public function service()
    {
        return $this->hasOne(Services::class, 'id', 'service_id');
    }

    public function services()
    {
        return $this->hasMany(Posts::class, 'parent_id', 'id')->where('post_type', 'contents');
    }

    public function serviceSlug()
    {
        return $this->hasOne(Services::class, 'id', 'service_id')->select('id', 'slug');
    }

    public function createdby()
    {
        return $this->hasOne(User::class, 'id', 'created_by');
    }

    public function contactBlocks()
    {
        return $this->hasMany('App\Models\ContactBlock', 'object_id', 'id')->where('object_type', 'posts')->orderBy('sort_order', 'ASC');
    }

    public function parent()
    {
        return $this->hasOne(Posts::class, 'id', 'parent_id')->select('posts.*', 'services.title as service_title')
            ->leftjoin('services', 'services.id', '=', 'posts.service_id');
    }

    public function children()
    {
        return $this->hasMany(Posts::class, 'parent_id')->where('status', 'Y')->orderBy('sort_order')->orderBy('id');
    }

    public function taxonomies()
    {
//        return $this->belongsToMany(Taxonomies::class, 'taxonomies_posts_map', 'post_id', 'taxonomy_id')
//            ->using(TaxonomyPostMap::class);
    }

    public function posts()
    {
        return $this->hasMany(Posts::class, 'post_type', 'slug');
    }

    public function pages()
    {
        return $this->hasMany(Posts::class, 'parent_id', 'id')->where('post_type', 'page')->orderBy('sort_order');
    }

    public function scopeMainPages($q)
    {
        return $q->where('post_type', 'page')->where(function ($query) {
            $query->where('parent_id', 0)->orWhereNull('parent_id');
        });
    }

    public function scopeActive($q)
    {
        return $q->where('status', 'Y');
    }
}
