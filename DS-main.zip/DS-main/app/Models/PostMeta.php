<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\PostMeta
 *
 * @property int $id
 * @property int|null $post_id
 * @property string|null $meta_key
 * @property string|null $meta_value
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $deleted_at
 * @method static \Illuminate\Database\Eloquent\Builder|PostMeta newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PostMeta newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|PostMeta query()
 * @method static \Illuminate\Database\Eloquent\Builder|PostMeta whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostMeta whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostMeta whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostMeta whereMetaKey($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostMeta whereMetaValue($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostMeta wherePostId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|PostMeta whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class PostMeta extends Model
{
    protected $table = 'post_meta';

    protected $fillable = ['post_id', 'meta_key', 'meta_value', 'created_at'];

    public static function getMeta($id)
    {
        $results = PostMeta::where('post_id', '=', $id)->get()->toArray();
        $meta = [];
        array_map(function ($item) use (&$meta) {
            $meta[$item['meta_key']] = $item['meta_value'];
        }, $results);

        return (! empty($meta)) ? (object) $meta : false;
    }
}
