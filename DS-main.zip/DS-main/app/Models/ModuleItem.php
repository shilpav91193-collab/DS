<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * App\Models\ModuleItem
 *
 * @property int $id
 * @property string|null $name
 * @property string|null $slug
 * @property int|null $display_order
 * @property string|null $icon
 * @property string|null $link
 * @property int|null $module_id
 * @property string|null $requireSession Y, N
 * @property string|null $status Y, N
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem onlyTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem query()
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem whereDisplayOrder($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem whereIcon($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem whereLink($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem whereModuleId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem whereRequireSession($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem whereSlug($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem whereStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem withTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|ModuleItem withoutTrashed()
 * @mixin \Eloquent
 */
class ModuleItem extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = ['name', 'slug', 'module_id', 'link', 'icon', 'requireSession', 'status'];
}
