<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\Form
 *
 * @property int $id
 * @property int|null $dept_id
 * @property int|null $user_role
 * @property string|null $title
 * @property string|null $slug
 * @property string|null $description
 * @property string|null $version
 * @property string|null $code
 * @property string|null $status Y, N
 * @property string|null $featured Y, N
 * @property string|null $interactive
 * @property string|null $form_type
 * @property string|null $webform_id
 * @property string|null $form_doc
 * @property string|null $form_url
 * @property int|null $sort_order
 * @property string|null $last_update
 * @property int|null $added_by
 * @property int|null $updated_by
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $deleted_at
 * @method static \Illuminate\Database\Eloquent\Builder|Form newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Form newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Form query()
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereAddedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereDeptId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereFeatured($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereFormDoc($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereFormType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereFormUrl($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereInteractive($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereLastUpdate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereSlug($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereSortOrder($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereUpdatedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereUserRole($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereVersion($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Form whereWebformId($value)
 * @mixin \Eloquent
 */
class Form extends Model
{
    use HasFactory;
}
