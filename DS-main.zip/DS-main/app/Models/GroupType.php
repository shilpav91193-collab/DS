<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\GroupType
 *
 * @property int $id
 * @property string|null $title
 * @property string|null $slug
 * @property string|null $description
 * @property int|null $image
 * @property int|null $thumbnail
 * @property int|null $sort_order
 * @property string|null $status Y,N
 * @property int|null $created_by
 * @property int|null $updated_by
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property string|null $deleted_at
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Group> $groups
 * @property-read int|null $groups_count
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\GroupTypeMeta> $meta
 * @property-read int|null $meta_count
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType query()
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType whereCreatedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType whereImage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType whereSlug($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType whereSortOrder($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType whereStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType whereThumbnail($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|GroupType whereUpdatedBy($value)
 * @mixin \Eloquent
 */
class GroupType extends Model
{
    use HasFactory;

    protected $fillable = ['title', 'slug', 'description', 'image', 'sort_order'];

    public function meta()
    {
        return $this->hasMany(GroupTypeMeta::class);
    }

    public function groups()
    {
        return $this->hasMany(Group::class)->orderBy('sort_order');
    }
}
