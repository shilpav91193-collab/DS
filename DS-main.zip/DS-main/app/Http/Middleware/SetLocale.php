<?php

namespace App\Http\Middleware;

use App;
use Closure;

class SetLocale
{
    public function handle($request, Closure $next)
    {
        $locale = $request->segment(1) ? $request->segment(1) : 'en';

        if ($locale != 'ar' && $locale != 'en') {
            $locale = 'en';
        }

        App::setLocale($locale);

        return $next($request);
    }
}
