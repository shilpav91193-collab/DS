<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

class CheckAccess
{
    public function handle($request, Closure $next, $module)
    {
        $curret_action = Route::currentRouteAction();
        $data_action = explode('@', $curret_action);

        $data_update = ['edit', 'resetPassword', 'ajax', 'migrate'];
        $data_create = ['store', 'copy'];
        $data_view = ['index'];
        $data_delete = ['destroy', 'sync'];

        if (in_array($data_action[1], $data_update)) {
            $action = 'update';
        } elseif (in_array($data_action[1], $data_create)) {
            $action = 'create';
        } elseif (in_array($data_action[1], $data_view)) {
            $action = 'view';
        } elseif (in_array($data_action[1], $data_delete)) {
            $action = 'delete';
        } elseif ($data_action[1] == 'view') {
            $action = 'list';
        } else {
            $action = $data_action[1];
        }

        $check_access = \App\Http\Helpers::getAccess(Auth::user(), $module, $action);
        if ($check_access) {
            return $next($request);
        }

        abort(403);
    }
}
