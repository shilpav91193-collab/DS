<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Document;
use App\Models\Posts;
use App\Models\Sector;
use App\Models\Team;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Str;

class PostController extends Controller
{
    public function showPage($locale = null, $slug = null)
    {
        $segments = explode('/', $slug);
        $page_name = end($segments) ?? '';

        $result = Posts::with('thumbnail_image')->active()
            ->where('slug', $page_name)
            ->firstOrFail();

        if (! $result) {
            abort(404);
        }

        $result->meta = $result->meta();

        if (isset($result->meta->use_external_url) && isset($result->meta->external_url)) {
            if ($result->meta->open_in_new_window == 'Y') {
                return redirect($result->meta->external_url)->with('target', '_blank');
            } else {
                return redirect($result->meta->external_url);
            }
        }

        $result->load(['allSections' => function ($q) {
            return $q->with(['metas', 'allBlocks.metas', 'allBlocks.featured_image']);
        }]);

        $data = [
            'result' => $result,
            'title' => $result->title,
            'banner' => ($result->banner ??
                ($result->parent ? $result->parent->banner : null))?->getWithImages(true),
        ];

        $method_name = preg_replace(
            '/[^a-zA-Z0-9_\- ]/',
            '',
            'addTo_'.$result->slug);

        $custom_method = Str::camel($method_name);

        if (method_exists($this, $custom_method)) {
            $data = $this->$custom_method($data);
        }

        $views_in_order = [
            'Frontend.pages.'.$result->slug,
            'Frontend.page',
        ];

        $first_existing_view = collect($views_in_order)->first(function ($view) {
            return View::exists($view);
        });

        return view($first_existing_view, $data);
    }

    private function addToContactUs($data)
    {
        $sectors = Sector::query()
            ->get();

        $data['sectors'] = $sectors;

        return $data;
    }

    private function addToNewsroom($data)
    {
        $pageLimit = config('settings.pagination_limit')
            ? config('settings.pagination_limit')
            : 25;

        $news = Posts::query()
            ->where('post_type', 'news')
            ->paginate($pageLimit);

        $data['news'] = $news;

        return $data;
    }

    private function addToOurLeadership($data)
    {
        $teams = Team::query()
            ->where('type', 'leaders')
            ->get();

        $data['teams'] = $teams;

        return $data;
    }

    private function addToLawsAndGovernance($data)
    {
//        $pageLimit = config('settings.pagination_limit')
//            ? config('settings.pagination_limit')
//            : 8;

        $pageLimit = 16;

        $documents = Document::query()
            ->where('type', Document::DOCUMENT_TYPE_LAW_AND_GOVERNANCE)
            ->paginate($pageLimit);

        $data['documents'] = $documents;

        return $data;
    }

    public function loadMoreNews(Request $request)
    {
        $pageLimit = config('settings.pagination_limit')
            ? config('settings.pagination_limit')
            : 25;

        $nextPage = $request->currentPage + 1;

        $news = Posts::query()
            ->where('post_type', 'news')
            ->paginate($pageLimit, ['*'], 'page', $nextPage);

        return response()->json([
            'data' => $news,
            'body' => view('Frontend.pages.inc.load-more-news', compact('news'))->render(),
        ]);
    }

    public function loadMoreLawsAndGovernance(Request $request)
    {
//        $pageLimit = config('settings.pagination_limit')
//            ? config('settings.pagination_limit')
//            : 8;

        $pageLimit = 16;

        $nextPage = $request->currentPage + 1;

        $documents = Document::query()
            ->where('type', Document::DOCUMENT_TYPE_LAW_AND_GOVERNANCE)
            ->paginate($pageLimit, ['*'], 'page', $nextPage);

        return response()->json([
            'data' => $documents,
            'body' => view('Frontend.pages.inc.laws-and-governance-lists', compact('documents'))->render(),
        ]);
    }
}
