<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Posts;

class DistrictsController extends Controller
{
    public function show($locale = null, $slug = null)
    {
        $result = Posts::with('thumbnail_image')
            ->where('slug', $slug)
            ->firstOrFail();

        if (! $result) {
            abort(404);
        }

        $result->meta = $result->meta();

        $sectors = Posts::with('thumbnail_image')
            ->where('post_type', 'sectors')
            ->where('slug', '!=', $slug)
            ->orderByRaw('RAND()')
            ->paginate(10);

        $data = [
            'result' => $result,
            'title' => $result->title,
            'sectors' => $sectors,
        ];

        return view('Frontend.pages.districts-details', $data);
    }
}
