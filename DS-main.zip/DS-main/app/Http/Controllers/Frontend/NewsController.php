<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Posts;

class NewsController extends Controller
{
    public function newsDetails($locale = null, $slug = null)
    {
        $result = Posts::with('thumbnail_image')
            ->where('slug', $slug)
            ->firstOrFail();

        if (! $result) {
            abort(404);
        }

        $result->meta = $result->meta();

        $news = Posts::with('thumbnail_image')
            ->where('post_type', 'news')
            ->where('slug', '!=', $slug)
            ->orderByRaw('RAND()')
            ->paginate(10);

        $data = [
            'result' => $result,
            'title' => $result->title,
            'news' => $news,
        ];

        return view('Frontend.pages.news-details', $data);
    }
}
