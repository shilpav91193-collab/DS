<?php

namespace App\Http\Controllers\Frontend;

use App;
use App\Http\Controllers\Controller;
use App\Models\Group;
use App\Models\Posts;
use App\Models\Team;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(Request $request, $locale)
    {
        $lang_code = App::getLocale();

        $postData = Posts::where('slug', 'home')
             ->first();

        $teamLeaders = [];
        $groups = [];
        $news = [];
        $banners = [];
        $sectors = [];

        if ($postData) {
            $postData->meta = $postData->meta();

            if (isset($postData->meta->home_our_leaders)) {
                $leaderIds = json_decode($postData->meta->home_our_leaders);
                $teamLeaders = Team::with('featured_image')
                    ->whereIn('id', $leaderIds)
                    ->where('status', 'Y')
                    ->get();
            }

            if (isset($postData->meta->home_groups)) {
                $groupIds = json_decode($postData->meta->home_groups);
                $groups = Group::with('featured_image')
                    ->whereIn('id', $groupIds)
                    ->where('status', 'Y')
                    ->get();
            }

            if (isset($postData->meta->home_news)) {
                $newsIds = json_decode($postData->meta->home_news);

                $news = Posts::with('featured_image')
                    ->where('post_type', 'news')
                    ->where('status', 'Y')
                    ->whereIn('id', $newsIds)
                    ->get();
            }

            $banners = ($postData->banner ?? ($postData->parent ? $postData->parent->banner : null));

            if ($banners) {
                $banners = $banners->getResponsiveImages();
            }

            if (isset($postData->meta->home_diversified_sectors)) {
                $sectorIds = json_decode($postData->meta->home_diversified_sectors);

                $sectors = Posts::with('featured_image')
                    ->where('post_type', 'sectors')
                    ->where('status', 'Y')
                    ->whereIn('id', $sectorIds)
                    ->orderBy('sort_order')
                    ->get();
            }
        }

        return view('Frontend.pages.home', compact('postData',
            'teamLeaders', 'groups', 'news', 'banners', 'sectors'));
    }
}
