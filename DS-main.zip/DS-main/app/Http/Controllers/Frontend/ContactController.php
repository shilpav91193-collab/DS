<?php

namespace App\Http\Controllers\Frontend;

use App;
use App\Http\Controllers\Controller;
use App\Mail\ContactMail;
use App\Models\Contact;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ContactController extends Controller
{
    public function storeContact(Request $request)
    {
        $locale = APP::getLocale() ? APP::getLocale() : 'en';

        $request->validate([
            'first_name' => 'required|regex:/^[a-zA-Z _]+$/u|max:255|min:2',
            'last_name' => 'required|regex:/^[a-zA-Z _]+$/u|max:255|min:1',
            'company' => 'nullable|regex:/^[a-zA-Z _]+$/u|max:255|min:1',
            'phone' => 'required|regex:/^[0-9+]+$/|min:8|max:15',
            'email' => 'required|email:rfc,dns|regex:/^[\w\.-]+@[\w\.-]+(?:\.[A-Za-z]{2,})+$/|regex:/^[^-_].*@.*\..*$/',
            'preferred_way' => 'required',
            'time_to_call' => 'required',
            'message' => 'required|min:25|max:500',
            'sector_id' => 'required|exists:sectors,id',
            'g-recaptcha-token' => 'required',
        ], [
            'first_name.regex' => 'Please enter a valid first name',
            'last_name.regex' => 'Please enter a valid last name',
            'g-recaptcha-token.required' => 'Please confirm you are not a robot',
        ]);

        $inputs = $request->all();

        $captcha = $request->input('g-recaptcha-token');
        $secret = config('settings.google_recaptcha_secret');

        $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$captcha);
        $responseData = json_decode($verifyResponse);

        if ($captcha && $responseData->success) {
            $contact = Contact::create($inputs);

            $adminEmail = config('settings.contactus_email_to');
            $template = 'admin-contact-email';
            $emailSubject = 'DACC | Contact Enquiry';

            try {
                Mail::send(new ContactMail($adminEmail, $template, $contact, $emailSubject, $locale));
            } catch (\Exception $e) {
                info('Error sending contact email: '.$e->getMessage());
            }

            $template = 'user-contact-email';
            $emailSubject = 'DACC | Enquiry Submitted';

            try {
                Mail::send(new ContactMail($request->email, $template, $contact, $emailSubject, $locale));
            } catch (\Exception $e) {
                info('Error sending contact email: '.$e->getMessage());
            }

            return redirect()->back()->with('success', 'Thank you for making an enquiry. The team will contact you as soon as possible');
        } else {
            return redirect()->back()->withErrors([
                'g-recaptcha-response' => 'Invalid captcha',
            ]);
        }
    }
}
