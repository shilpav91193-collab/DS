<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Document;

class DocumentController extends Controller
{
    public function downloadDocument($locale = null, $slug = null)
    {
        $document = Document::where('slug', $slug)->first();

        if (! $document) {
            return response()->json(['message' => 'Document not found'], 404);
        }

        $downloadUrl = $document->url;
    }
}
