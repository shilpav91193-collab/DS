<?php

namespace App\Http\Controllers\Cpanel;

use App\Http\Controllers\Controller;
use App\Http\Helpers;
use App\Models\Galleries;
use App\Models\Medias;
use App\Traits\HasUploadImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class GalleryController extends Controller
{
    use HasUploadImage;

    public function __construct()
    {
        $this->middleware(['auth']);
    }

    public function list()
    {
        $s = request()->input('s');

        $galleries = Galleries::query()
            ->when($s, function ($query, $s) {
                return $query->where('title', 'like', "%$s%");
            })
            ->paginate(25);

        return view('cpanel.galleries.list', compact('galleries'));
    }

    public function create()
    {
        $medias = Medias::latest()->get();
        foreach ($medias as $media) {
            $media->file_url = Helpers::asset($media->file_url);
        }

        return view('cpanel.galleries.edit',
            ['gallery' => null, 'images' => $medias]);
    }

    public function edit(Galleries $galleries)
    {
        $medias = Medias::latest()->get();
        foreach ($medias as $media) {
            $media->file_url = Helpers::asset($media->file_url);
        }

        return view('cpanel.galleries.edit',
            ['gallery' => $galleries, 'images' => $medias]);
    }

    public function update(Request $request)
    {
        if ($id = $request->input('id')) {
            $galleries = Galleries::findOrFail($id);
        }

        $request->validate([
            'title' => 'required|min:5|max:255',
            'description' => 'nullable',
            'images' => 'required|json',
        ]);

        $images = json_decode($request->images);

        if (! count($images)) {
            return back()
                ->withErrors(['images' => 'Please select at least one image'])
                ->withInput();
        }

        foreach ($images as $image) {
            Validator::make(['image' => $image], [
                'image' => 'required|exists:medias,id',
            ])->validate();
        }

        if ($id) {
            $request->updated_by = Auth::id();
            $galleries->update($request->all());
        } else {
            $request->created_by = Auth::id();
            $galleries = Galleries::create($request->all());
        }

        return redirect()
            ->route('galleries.edit', ['galleries' => $galleries->id])
            ->with('success', 'Gallery saved successfully');
    }

    public function destroy(Galleries $galleries)
    {
        $galleries->delete();

        return redirect()
            ->route('galleries.list')
            ->with('success', 'Gallery deleted successfully');
    }
}
