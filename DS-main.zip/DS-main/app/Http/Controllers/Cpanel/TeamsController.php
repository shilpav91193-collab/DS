<?php

namespace App\Http\Controllers\Cpanel;

use App\Http\Controllers\Controller;
use App\Http\Helpers;
use App\Models\Banner;
use App\Models\Galleries;
use App\Models\Team;
use Illuminate\Http\Request;

class TeamsController extends Controller
{
    public function __construct(Request $request)
    {
        $this->middleware('auth');
        $this->middleware('checkaccess:teams');
    }

    public function list(Request $request)
    {
        $s = $request->input('s');
        $type = $request->input('type');
        $status = $request->input('status') == 'all' ? null : $request->input('status');

        $filter = [
            'status' => ['Y', 'N'],
            's' => $s, 'type' => $type,
        ];

        $results = Team::query()
            ->when($s, function ($query) use ($filter) {
                $query->where('name', 'LIKE', "%$filter[s]%");
            })
            ->when($type, function ($query) use ($type) {
                $query->where('type', $type);
            })
            ->when($status, function ($query) use ($status) {
                return $query->where('status', $status);
            })
            ->when($status === null, function ($query) use ($filter) {
                $query->whereIn('status', $filter['status']);
            })
            ->orderBy('sort_order', 'asc')
            ->orderBy('created_at', 'desc')
            ->get();

        return view('cpanel.teams.list', compact('results', 'filter'));
    }

    public function create(Request $request)
    {
        $banners = Banner::where('status', 'Y')
            ->get();

        return view('cpanel.teams.create', compact('banners'));
    }

    public function store(Request $request)
    {
        $user = $request->user();

        $request->validate([
            'name' => 'required',
        ]);

        $result = new Team();
        $result->name = $request->name;
        $result->slug = Helpers::getSlug('teams', 'slug', $request->name);
        $result->status = 'Y';
        $result->sort_order = Team::max('sort_order') + 1;
        $result->created_by = $user->id;
        $result->updated_by = $user->id;
        $result->save();

        return redirect()->route('teams.edit', ['id' => $result->id, 's' => $request->input('s'), 'page' => $request->input('page')])
            ->with('success', 'Team has been created.');
    }

    public function edit(Request $request, $id)
    {
        $result = Team::findOrFail($id);
        $galleries = Galleries::where('status', 'Y')->get();

        return view('cpanel.teams.edit', compact('galleries', 'result'));
    }

    public function update(Request $request, $id = '')
    {
        $request->validate([
            'name' => 'required',
            'description' => 'required',
        ]);

        $input = $request->all();

        $result = Team::findOrFail($id);

        $input['slug'] = Helpers::getSlug('teams', 'slug', $request->name);

        $result->update($input);

        return redirect()->route('teams.edit', ['id' => $id, 's' => $request->input('s'), 'page' => $request->input('page')])
            ->with('success', 'Team has been updated.');
    }

    public function delete(Request $request, $id)
    {
        $ids = $request->input('ids', [$id]);
        Team::where('id', $ids)->delete();

        return redirect()->route('teams.list')->with('success', 'Team deleted successfully.');
    }
}
