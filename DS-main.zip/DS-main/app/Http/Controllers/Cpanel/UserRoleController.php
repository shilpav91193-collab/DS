<?php

namespace App\Http\Controllers\Cpanel;

use App\Http\Controllers\Controller;
use App\Models\Module;
use App\Models\Service;
use App\Models\UserRole;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class UserRoleController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function list(Request $request)
    {
        $s = $request->input('q');
        $limit = $request->input('limit', config('settings.pagination_limit', 25));
        $filter = ['limit' => $limit, 's' => $s];

        $results = UserRole::query()
            ->when($s, function ($query, $s) {
                return $query->where('name', 'like', "%$s%");
            })
            ->orderBy('id', 'ASC')
            ->paginate($limit);

        return view('cpanel.user_roles.list',
            compact('results', 's', 'filter'));
    }

    public function create()
    {
        $modules = Module::query()
            ->orderBy('display_order')
            ->get();

        return view('cpanel.user_roles.create', compact('modules'));
    }

    public function store(Request $request)
    {
        $v = Validator::make($request->all(), [
            'name' => 'required|min:5',
        ]);

        if ($v->fails()) {
            return redirect()->back()->withInput()->withErrors($v->errors());
        }

        $insertid = UserRole::insertGetId(
            [
                'name' => $request->input('name'),
                'status' => 'Y',
                'access' => json_encode($request->except('name', '_token')),
                'created_at' => date('Y-m-d H:i:s'),
                'added_by' => Auth::id(),
            ]
        );

        return redirect()->route('roles.list')
                        ->with('success', '"New user role has been created.');
    }

    public function edit($id)
    {
        $result = UserRole::findOrFail($id);

        $modules = Module::query()
            ->orderBy('display_order')
            ->get();

        $services = Service::query()
            ->where('status', 'Y')
            ->get();

        return view('cpanel.user_roles.edit',
            compact('result', 'modules', 'services'));
    }

    public function update(Request $request, $id = '')
    {
        $v = Validator::make($request->all(), [
            'name' => 'required|min:5',
        ]);

        if ($v->fails()) {
            return redirect()->back()->withInput()->withErrors($v->errors());
        }
        if ($id > 0) {
            UserRole::where('id', $id)->update(
                [
                    'name' => $request->input('name'),
                    'access' => json_encode($request->except('name', '_token')),
                    'updated_at' => date('Y-m-d H:i:s'),
                    'updated_by' => Auth::id(),
                ]
            );
        } else {
            UserRole::create(
                [
                    'name' => $request->input('name'),
                    'access' => json_encode($request->except('name', '_token')),
                    'created_at' => date('Y-m-d H:i:s'),
                    'added_by' => Auth::id(),
                ]
            );
        }

        return redirect()->route('roles.list')
                        ->with('success', '"New user role has been updated.');
    }

    public function destroy($id)
    {
        if (! $id) {
            return redirect()
                ->back()
                ->withInput()
                ->withErrors(['error', 'Invalid id!!']);
        }

        UserRole::where('id', $id)->delete();

        return redirect()
            ->route('roles.list')
            ->with('status', 'User role has been deleted.');
    }

    public function restore($id)
    {
        if (! $id) {
            return redirect()->back()->withInput()->withErrors(['error', 'Invalid id!!']);
        }

        UserRole::withTrashed()->where('id', $id)->restore();

        return redirect()->route('roles.list')->with('status', 'User role has been restored.');
    }
}
