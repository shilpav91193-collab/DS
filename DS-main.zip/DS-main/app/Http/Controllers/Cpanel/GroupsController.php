<?php

namespace App\Http\Controllers\Cpanel;

use App\Http\Controllers\Controller;
use App\Http\Helpers;
use App\Models\Group;
use App\Models\GroupType;
use App\Traits\HasUploadImage;
use Illuminate\Http\Request;

class GroupsController extends Controller
{
    use HasUploadImage;

    public function __construct()
    {
        $this->middleware(['auth']);
    }

    public function list(Request $request)
    {
        $s = request()->input('s');
        $group_type_id = $request->group_type_id;
        $status = $request->input('status') == 'all' ? null : $request->input('status');

        $filter = [
            'status' => ['Y', 'N'],
            's' => $request->s,
            'group_type_id' => $request->group_type_id,
        ];

        $groupTypes = GroupType::where('status', 'Y')
            ->cursor();

        $groups = Group::query()
            ->with('groupType')
            ->when($s, function ($query, $s) {
                return $query->where('title', 'like', "%$s%");
            })
            ->when($status, function ($query) use ($status) {
                return $query->where('status', $status);
            })
            ->when($group_type_id, function ($query, $group_type_id) {
                return $query->where('group_type_id', $group_type_id);
            })
            ->orderBy('sort_order')
            ->paginate(25);

        return view('cpanel.groups.list',
            compact('groups', 'filter', 'groupTypes'));
    }

    public function create()
    {
        $groupTypes = GroupType::cursor();

        return view('cpanel.groups.edit', ['result' => null, 'groupTypes' => $groupTypes]);
    }

    public function edit($id = null)
    {
        $result = null;

        if ($id) {
            $result = Group::find($id);
        }

        $groupTypes = GroupType::cursor();

        return view('cpanel.groups.edit', ['result' => $result, 'groupTypes' => $groupTypes]);
    }

    public function update(Request $request, $id = null)
    {
        $request->validate([
            'title' => 'required|min:5|max:255',
            'group_type_id' => 'required',
            'sub_title' => 'nullable',
        ]);

        $group = Group::find($id);
        if (! $group) {
            $group = new Group();
        }

        $group->title = $request->title;
        $group->description = $request->description;
        $group->group_type_id = $request->group_type_id;
        $group->slug = Helpers::getSlug('groups', 'slug', $request->slug, $id);
        $group->image = $request->image;
        $group->url = $request->url;
        $group->save();

        return redirect()
            ->route('groups.list')
            ->with('success', 'Groups updated successfully.');
    }

    public function delete(Request $request, $id)
    {
        $ids = $request->input('ids', [$id]);

        Group::query()
            ->where('id', $ids)
            ->delete();

        return redirect()
            ->route('groups.list')
            ->with('success', 'Group deleted successfully.');
    }
}
