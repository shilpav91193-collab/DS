<?php

namespace App\Http\Controllers\Cpanel;

use App\Http\Controllers\Controller;
use App\Http\Helpers;
use App\Models\Banner;
use App\Models\Galleries;
use App\Models\Group;
use App\Models\Medias;
use App\Models\PostMeta;
use App\Models\Posts;
use App\Models\PostsBlockMeta;
use App\Models\PostsBlocks;
use App\Models\PostsSections;
use App\Models\PostsSectionsMeta;
use App\Models\Service;
use App\Models\Team;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class PostsController extends Controller
{
    protected $post;

    public function __construct(Request $request)
    {
        $this->middleware('auth');

        $post_type = $request->post_type ? $request->post_type : 'contents';

        if ($post_type) {
            $this->middleware('checkaccess:'.$post_type);
        }
    }

    public function list(Request $request)
    {
        $post_type = $request->input('post_type', 'contents');

        $s = $request->input('s');
        $status = $request->input('status') == 'all' ? null : $request->input('status');

        if ($post_type == '' || ! array_key_exists($post_type, config('content_type'))) {
            abort(404);
        }

        $service_id = $post_type != 'contents' ? null : $request->service_id;

        $service = false;

        if ($post_type == 'contents') {
            $service_id = $request->service_id ?? 0;
            $service = Service::findOrFail($service_id);
        }

        $limit = $request->input('limit', config('settings.pagination_limit', 25));
        $filter = ['limit' => $limit, 'status' => ['Y', 'N', 'D'], 's' => $s];

        $results = Posts::query()
            ->where('post_type', $post_type)
            ->when($s, function ($query) use ($filter) {
                $query->where('title', 'LIKE', "%$filter[s]%");
            })
            ->when($service_id, function ($query, $service_id) {
                return $query->where('service_id', $service_id);
            })
            ->when($status, function ($query) use ($status) {
                return $query->where('status', $status);
            })
            ->when($status === null, function ($query) use ($filter) {
                $query->whereIn('status', $filter['status']);
            })
            ->when($post_type == 'page', function ($query) use ($s) {
                if (! $s) {
                    return $query->where(function ($q) {
                        $q->where('parent_id', 0)->orWhereNull('parent_id');
                    })->with('pages');
                }
            })
            ->orderBy('sort_order')
            ->paginate($filter['limit']);

        return view('cpanel.posts.list', compact(
            'post_type',
            'results',
            'filter',
            'service_id',
            'service'));
    }

    public function create(Request $request)
    {
        $post_type = $request->input('post_type') ? $request->input('post_type') : 'contents';
        $service_id = $post_type != 'contents' ? null : $request->service_id;
        $service = false;
        if ($post_type == 'contents') {
            $service_id = $request->service_id ?? 0;
            $service = Service::findOrFail($service_id);
        }

        $teamsLeaders = Team::query()
            ->where('status', 'Y')
            ->orderBy('sort_order')
            ->get();

        $groups = Group::query()
            ->where('status', 'Y')
            ->orderBy('sort_order')
            ->get();

        $news = Posts::query()
            ->where('post_type', 'news')
            ->where('status', 'Y')
            ->orderBy('sort_order')
            ->get();

        $banners = Banner::query()
            ->where('status', 'Y')
            ->get();

        $sectors = Posts::query()
            ->where('post_type', 'sectors')
            ->where('status', 'Y')
            ->orderBy('sort_order')
            ->get();

        return view('cpanel.posts.create',
            compact(
                'post_type',
                'service_id',
                'service',
                'banners',
                'teamsLeaders',
                'groups',
                'news',
                'banners',
                'sectors'
            ));
    }

    public function edit(Request $request, $id = '')
    {
        $post = [];
        $services = [];

        $post = Posts::findOrFail($id);
        $service = null;

        $post_type = $post->post_type;

        $service_id = $post_type != 'contents' ? null : ($request->service_id ?? false);
        if ($post_type == 'contents') {
            $service_id = $post->service_id ?? 0;
            $service = Service::find($service_id);
            $services = Posts::where([
                'post_type' => 'contents',
                'service_id' => $service_id,
            ])->whereIn('status', ['Y', 'P'])
                ->whereNull('parent_id')
                ->where('id', '<>', $id)
                ->get();
        }
        $pages = [];
        if ($post_type == 'page') {
            $pages = Posts::where('post_type', 'page')
                ->where('id', '<>', $id)
                ->where('status', 'Y')
                ->get();
        }
        if (! empty($post)) {
            $post_type = $post->post_type;
            $post->meta = $post->meta();
            $post->sections = $post->sections();

            if (config('content_type.'.$post_type)->enable_fotos == true) {
                $post->photos = Medias::where('objectID', $id)->where('content_type', 'page_fotos')->where('input', 'file')->get();
            }
            if (config('content_type.'.$post_type)->enable_foto_url == true) {
                $foto_url = Medias::where('objectID', $id)->where('input', 'url')->first();
                $post->photo_url = isset($foto_url) ? $foto_url->filename : '';
            }
            $this->post = $post;
        }
        if (! $post_type) {
            abort(404);
        }

        $galleries = Galleries::where('status', 'Y')->get();

        $teamsLeaders = Team::query()
            ->where('status', 'Y')
            ->orderBy('sort_order')
            ->get();

        $groups = Group::query()
            ->where('status', 'Y')
            ->orderBy('sort_order')
            ->get();

        $news = Posts::query()
            ->where('post_type', 'news')
            ->where('status', 'Y')
            ->orderBy('sort_order')
            ->get();

        $banners = Banner::query()
            ->where('status', 'Y')
            ->get();

        $sectors = Posts::query()
            ->where('post_type', 'sectors')
            ->where('status', 'Y')
            ->orderBy('sort_order')
            ->get();

        return view('cpanel.posts.edit', compact(
            'post_type',
            'services',
            'pages', 'galleries', 'post', 'service_id', 'banners',
            'service',
            'teamsLeaders',
            'groups',
            'news',
            'banners',
            'sectors'
        ));
    }

    public function store(Request $request)
    {
        $user = Auth::user();
        $post_type = $request->input('post_type') ? $request->input('post_type') : 'contents';
        $service_id = $post_type != 'contents' ? null : ($request->service_id ?? false);
        if ($post_type == 'contents') {
            $service_id = $request->service_id ?? 0;
            Service::findOrFail($service_id);
        }

        $v = Validator::make($request->all(), [
            'title' => 'required',
        ]);

        if ($v->fails()) {
            return redirect()->back()->withInput()->withErrors($v->errors());
        } else {
            $values['title'] = $request->input('title') ? $request->input('title') : '';
            $values['post_type'] = $request->input('post_type') ? $request->input('post_type') : 'contents';
            $values['service_id'] = $request->input('service_id') ? $request->input('service_id') : null;
            $values['content_type'] = 'builder';
            $slug = $request->input('slug') ? $request->input('slug') : $request->input('title');
            $values['slug'] = Helpers::postSlug($slug, '');
            $values['created_at'] = $request->input('created_at') ? $request->input('created_at') : date('Y-m-d H:i:s');

            $values['created_by'] = $user->id;
            $id = Posts::insertGetId($values);

            return redirect()->route('posts.edit', ['id' => $id, 's' => $request->input('s'), 'limit' => $request->input('limit'), 'page' => $request->input('page')])
                ->with('success', config('content_type.'.$post_type)->singular.' has been created.');
        }
    }

    public function update(Request $request, $id)
    {
        $post_type = $request->input('post_type') ?
            $request->input('post_type') :
            'contents';

        $service_id = $post_type != 'contents' ?
            null :
            ($request->service_id ?? false);

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $v = Validator::make($request->all(), [
                'title' => 'required',
                'taxonomies' => 'nullable|array',
            ]);

            if ($v->fails()) {
                return redirect()->back()->withInput()->withErrors($v->errors());
            } else {
                $user = Auth::user();
                $meta = $request->input('meta') ? $request->input('meta') : [];
                $values['title'] = $request->input('title') ? $request->input('title') : '';
                $values['post_type'] = $request->input('post_type') ? $request->input('post_type') : 'contents';
                $values['service_id'] = $request->input('service_id') ? $request->input('service_id') : null;
                $values['content_type'] = 'builder';
                $slug = $request->input('slug') ? $request->input('slug') : $request->input('title');
                $values['slug'] = Helpers::postSlug($slug, $id);
                $values['content'] = $request->input('content') ? $request->input('content') : '';
                $values['created_at'] = $request->input('created_at') ? $request->input('created_at') : date('Y-m-d H:i:s');
                $values['image'] = $request->input('image') ? $request->input('image') : '';
                $values['thumbnail'] = $request->input('thumbnail') ? $request->input('thumbnail') : '';
                $values['status'] = $request->input('status') ? $request->input('status') : 'N';

                $values['parent_id'] = $request->parent ?? null;

                if ($post_type == 'contents') {
                    if (! Helpers::getAccess($user, $post_type, 'approve')) {
                        $values['status'] = 'D';
                    }
                }
                if ($values['content_type'] == 'tabs' || $values['content_type'] == 'accordion') {
                    $tab = [];
                    $tab['hide_title'] = $request->input('hide_title') ? $request->input('hide_title') : 'N';
                    $tab_titles = $request->input('tab_title') ? $request->input('tab_title') : [];
                    $tab_contents = $request->input('tab_content') ? $request->input('tab_content') : [];
                    foreach ($tab_titles as $i => $tab_title) {
                        $tab['tabs'][$i]['title'] = $tab_titles[$i];
                        $tab['tabs'][$i]['content'] = $tab_contents[$i];
                    }
                    $values['content'] = $tab ? json_encode($tab) : [];
                }

                if ($id > 0) {
                    $values['updated_at'] = date('Y-m-d H:i:s');
                    $values['updated_by'] = $user->id;
                    $post = Posts::findOrFail($id);
                    $data__ = $post->toArray();
                    $data__['meta'] = $post->meta();
                    if ($id == 1 && $post_type == 'page') {
                        $values['slug'] = 'home';
                    }
                    $values['status'] = $post->status;
                    $update = $post->update($values);
                    $meta['use_external_url'] = $meta['use_external_url'] ?? 'N';
                    $values['meta'] = $meta;
                } else {
                    if ($post_type == 'contents' && ! isset($values['status'])) {
                        $values['status'] = $request->input('status') ?
                            $request->input('status') :
                            'N';
                    }
                    $values['created_by'] = $user->id;
                    $id = Posts::insertGetId($values);
                }

                $meta['use_external_url'] = $meta['use_external_url'] ?? 'N';
                foreach ($meta as $key => $value) {
                    $value = is_array($value) ? json_encode($value) : $value;
                    PostMeta::updateOrCreate(
                        ['post_id' => $id, 'meta_key' => $key],
                        [
                            'post_id' => $id,
                            'meta_key' => $key,
                            'meta_value' => $value,
                        ]
                    );
                }

                return redirect()->route('posts.edit', [
                    'id' => $id, 's' => $request->input('s'),
                    'limit' => $request->input('limit'),
                    'page' => $request->input('page'),
                ])->with('success', config('content_type.'.$post_type)->singular.' has been updated.');
            }
        }
    }

    public function destroy(Request $request, $id = '')
    {
        $ids = $request->input('id') ? $request->input('id') : $id;
        $post_type = $request->input('post_type') ? $request->input('post_type') : 'contents';

        $service_id = $post_type != 'contents' ? null : ($request->service_id ?? false);

        if ($post_type == 'contents') {
            $service_id = $request->service_id ?? 0;
            Service::findOrFail($service_id);
        }

        if (! is_array($ids)) {
            $ids = [$ids];
        }

        if (in_array(1, $ids)) {
            return redirect()->back()->withInput()->withErrors(['error', 'You cannot Delete Home Page']);
        }

        if (empty($ids)) {
            return redirect()->back()->withInput()->withErrors(['error', 'Invalid id!!']);
        }
        $arr = ['status' => 'T'];
        Posts::whereIn('id', $ids)->update($arr);

        return redirect()->back()->with('success', config('content_type.'.$post_type)->plural.' has been trashed.');
    }

    public function restore(Request $request, $id = '')
    {
        $ids = $request->input('id') ? $request->input('id') : $id;
        $post_type = $request->input('post_type') ? $request->input('post_type') : 'contents';
        $service_id = $post_type != 'contents' ? null : ($request->service_id ?? false);
        if ($post_type == 'contents') {
            $service_id = $request->service_id ?? 0;
            Service::findOrFail($service_id);
        }
        if (! is_array($ids)) {
            $ids = [$ids];
        }
        //echo "<pre>"; print_r($ids); exit;
        if (empty($ids)) {
            return redirect()->back()->withInput()->withErrors(['error', 'Invalid id!!']);
        }
        $arr = ['status' => 'Y'];
        Posts::whereIn('id', $ids)->update($arr);

        return redirect()->route('posts.list', ['post_type' => $post_type, 'service_id' => $service_id, 's' => $request->input('s'), 'limit' => $request->input('limit'), 'page' => $request->input('page')])
            ->with('success', config('content_type.'.$post_type)->plural.' has been restored.');
    }

    public function delete(Request $request, $id = '')
    {
        $ids = $request->input('id') ? $request->input('id') : $id;
        $post_type = $request->input('post_type') ? $request->input('post_type') : 'contents';
        $service_id = $post_type != 'contents' ? null : ($request->service_id ?? false);
        if ($post_type == 'contents') {
            $service_id = $request->service_id ?? 0;
            Service::findOrFail($service_id);
        }
        if (! is_array($ids)) {
            $ids = [$ids];
        }
        if (in_array(1, $ids)) {
            return redirect()->back()->withInput()->withErrors(['error', 'You cannot Delete Home Page']);
        }
        //echo "<pre>"; print_r($ids); exit;
        if (empty($ids)) {
            return redirect()->back()->withInput()->withErrors(['error', 'Invalid id!!']);
        }
        foreach ($ids as $id) {
            $post = Posts::find($id);
            if (Posts::destroy($id)) {
                Helpers::removeFile(storage_path('app/public/posts/'), $post->image);
            }
        }

        return redirect()->route('posts.list', ['post_type' => $post_type, 'service_id' => $service_id, 's' => $request->input('s'), 'limit' => $request->input('limit'), 'page' => $request->input('page')])
            ->with('success', config('content_type.'.$post_type)->plural.' has been deleted.');
    }

    public function ajax(Request $request)
    {
        $action = $request->input('action');

        switch ($action) {
            case 'remove_image':
                $id = $request->input('id');
                $post = Posts::find($id);
                $arr = ['image' => ''];
                if ($post->image != '' && Storage::disk('public')->exists('posts/'.$post->image)) {
                    unlink(storage_path('app/public/posts/'.$post->image));
                    Posts::where('id', $id)->update($arr);
                }
                $json['status'] = 'success';
                echo json_encode($json);
                exit;

                break;
            case 'status':
                $status = $request->input('status');
                $id = $request->input('id');

                if ($id == 1) {
                    $json['status'] = 'error';
                    echo json_encode($json);
                    exit;
                }

                $arr = ['status' => $status == 'Y' ? 'N' : 'Y'];
                Posts::where('id', $id)->update($arr);
                $json['status'] = 'success';
                echo json_encode($json);
                exit;

                break;

            case 'check_name':
                $id = $request->input('id');
                $name = $request->input('name');
                $name = Helpers::postSlug($name, $id);
                $json['value'] = $name;
                echo json_encode($json);
                exit;

                break;

            case 'remove_image_contact':
                $id = $request->input('id');
                $data = ContactBlock::find($id);
                if (! empty($data->image) && ($image = str_replace(asset('storage/posts/contacts/'), '', $data->image)) && Storage::disk('public')->exists('contents/contacts/'.$image)) {
                    unlink(storage_path('app/public/posts/contacts/'.$image));
                    $data->image = null;
                    $data->save();
                }
                $json['status'] = 'success';
                echo json_encode($json);
                exit;

                break;

            case 'featured':

                $id = $request->input('id');
                $post_type = $request->input('post_type', 'contents');
                if (config('content_type.'.$post_type)->enable_featured == true) {
                    if (config('content_type.'.$post_type)->featured_posts == 'single') {
                        $arr = ['featured' => 0];
                        Posts::where('post_type', $post_type)->update($arr);
                    }
                    Posts::where('id', $id)->update(['featured' => 1]);
                }

                $json['status'] = 'success';
                echo json_encode($json);
                exit;

                break;
            case 'sort_order':
                $ids = $request->input('ids');
                for ($i = 0; $i < count($ids); $i++) {
                    $id = $ids[$i];
                    Posts::where('id', $id)->update(['sort_order' => $i + 1]);
                }

                $json['status'] = 'success';
                echo json_encode($json);
                exit;

                break;
            case 'load-pagebuilder':
                $content_type = $request->input('content_type') ? $request->input('content_type') : 'normal';
                $id = $request->input('id');
                $post = Posts::find($id);
                $post->sections = $post->sections();
                if ($content_type == 'builder') {
                    return response()->json([
                        'body' => view('cpanel.posts.pagebuilder.sections', compact('post'))->render(),
                        'status' => 'success',
                    ], 200, [], JSON_UNESCAPED_UNICODE);
                } else {
                    return response()->json([
                        'body' => view('cpanel.posts.pagebuilder.normal', compact('post'))->render(),
                        'status' => 'success',
                    ], 200, [], JSON_UNESCAPED_UNICODE);
                }

                break;

            case 'list-section-type':
                $post_id = $request->input('id');

                return response()->json([
                    'body' => view('cpanel.posts.pagebuilder.list-section-type', compact('post_id'))->render(),
                    'status' => 'success',
                ], 200, [], JSON_UNESCAPED_UNICODE);

                break;
            case 'add-section-wrap':
                $post_id = $request->input('post_id');
                $blocks = $request->input('blocks');
                $sort_order = PostsSections::where('post_id', $post_id)->max('sort_order');
                $section = PostsSections::create([
                    'post_id' => $post_id,
                    'blocks' => $blocks,
                    'sort_order' => ($sort_order + 1),
                    'type' => 'plain',
                ]);
                $section->meta = $section->meta();

                $html = '<div class="section section-'.$section->id.' mb-3 p-0" style="min-height: 200px;">';
                $html .= view('cpanel.posts.pagebuilder.add-section-wrap', compact('section'))->render();
                $html .= '</div>';

                return response()->json([
                    'body' => $html,
                    'status' => 'success',
                ], 200, [], JSON_UNESCAPED_UNICODE);

                break;
            case 'edit-content-block':

                $post_id = $request->input('post_id');
                $column = $request->input('column');
                $section = $request->input('section');
                $block_id = $request->input('block_id');
                $block_type = $request->input('block_type');
                $block = PostsBlocks::find($block_id);

                if (! empty($block)) {
                    $block->meta = $block->meta();
                }

                return response()->json([
                    'body' => view('cpanel.posts.pagebuilder.section-block', compact('column', 'section', 'block', 'post_id', 'block_type'))->render(),
                    'status' => 'success',
                ], 200, [], JSON_UNESCAPED_UNICODE);

                break;
            case 'copy-content-block':

                $block_id = $request->input('block_id');
                $block = PostsBlocks::find($block_id);

                if (! empty($block)) {
                    $new_block = $block->replicate([
                        'id',
                        'created_at',
                        'updated_at',
                    ]);
                    $new_block->fill([
                        'title' => 'Copy of - '.$block->title,
                    ])->save();
                    $metas = $block->metas;
                    foreach ($metas as $meta) {
                        $new_meta = $meta->replicate([
                            'id',
                            'created_at',
                            'updated_at',
                        ]);
                        $new_meta->fill([
                            'block_id' => $new_block->id,
                        ])->save();
                    }
                } else {
                    return response()->json([
                        'body' => '',
                        'status' => 'error',
                    ], 200, [], JSON_UNESCAPED_UNICODE);
                }
                $section = PostsSections::find($block->section_id);
                $section->meta = $section->meta();

                return response()->json([
                    'body' => view('cpanel.posts.pagebuilder.add-section-wrap', compact('section'))->render(),
                    'status' => 'success',
                    'section' => $section,
                ], 200, [], JSON_UNESCAPED_UNICODE);

                break;
            case 'save-content-block':
                //$post = $request->all();
                //echo "<pre>"; print_r($post);echo "</pre>"; exit;

                $user = Auth::user();
                $id = $request->input('id') ? $request->input('id') : '';
                $post_id = $request->input('post_id') ? $request->input('post_id') : '';
                $value['post_id'] = $post_id;
                $value['title'] = $request->input('title');
                $value['content'] = $request->input('content');
                $image = $request->input('image');
                $value['sort_order'] = $request->input('sort_order');
                $value['section_id'] = $request->input('section_id');
                $value['image'] = $image;
                $meta = $request->input('meta') ? $request->input('meta') : [];
                $section = PostsSections::find($value['section_id']);

                $validator = Validator::make($request->all(), [
                    'image' => 'nullable|exists:medias,id',
                ]);

                if ($validator->fails()) {
                    unset($value['image']);
                }

                // if($image != '' && file_exists(public_path('temp').'/'.$image)){
                    //     if(copy('temp/'.$image, storage_path('app/public/posts').'/'.$image)){
                    //         unlink ('temp/'.$image);
                    //     }
                // }
                if ($id > 0) {
                    $value['updated_by'] = $user->id;
                    $block = PostsBlocks::findOrFail($id);
                    $data__ = $block->toArray();
                    $data__['meta'] = $block->meta();
                    $block->update($value);
                } else {
                    $value['added_by'] = $user->id;
                    $value['updated_by'] = $user->id;
                    $block = PostsBlocks::create($value);
                    $section->update(['blocks' => $section->blocks + 1]);
                }

                if ($meta['block_type'] == 'tab' || $meta['block_type'] == 'accordion') {
                    $tab = [];
                    $tab_titles = $request->input('tab_title') ? $request->input('tab_title') : [];
                    $tab_contents = $request->input('tab_content') ? $request->input('tab_content') : [];
                    foreach ($tab_titles as $i => $tab_title) {
                        $tab[$i]['title'] = $tab_titles[$i];
                        $tab[$i]['content'] = $tab_contents[$i];
                    }
                    $meta['tabs'] = $tab ? json_encode($tab) : [];
                }

                foreach ($meta as $key => $value) {
                    PostsBlockMeta::updateOrCreate(
                        ['block_id' => $block->id, 'meta_key' => $key],
                        [
                            'block_id' => $block->id,
                            'meta_key' => $key,
                            'meta_value' => is_string($value ?? '') ? $value : json_encode($value),
                        ]
                    );
                }

                $section->meta = $section->meta();

                return response()->json([
                    'body' => view('cpanel.posts.pagebuilder.add-section-wrap', compact('section'))->render(),
                    'status' => 'success',
                    'section' => $section,
                ], 200, [], JSON_UNESCAPED_UNICODE);

                break;
            case 'delete-tmp-image':
                $name = $request->input('name');
                if ($name != '' && file_exists(public_path('temp/'.$name))) {
                    unlink(public_path('temp/'.$name));
                }

                return response()->json([
                    'body' => 'Image removed successfully.',
                    'status' => 'success',
                ], 200, [], JSON_UNESCAPED_UNICODE);

                break;
            case 'delete-org-image':
                $name = $request->input('name');
                if ($name != '' && file_exists(storage_path('app/public/posts/'.$name))) {
                    unlink(storage_path('app/public/posts/'.$name));
                }

                return response()->json([
                    'body' => 'Image removed successfully.',
                    'status' => 'success',
                ], 200, [], JSON_UNESCAPED_UNICODE);

                break;
            case 'delete-content-section':
                $post_id = $request->input('post_id');
                $section = $request->input('section');

                $section = PostsSections::find($section);
                $blocks = PostsBlocks::where('section_id', $section)->where('post_id', $post_id)->get();
                $data__ = $section->toArray();
                $data__['meta'] = $section->meta();
                $section->delete();
                foreach ($blocks as $block) {
                    Helpers::removeFile(storage_path('app/public/posts/'), $block->image);
                }

                return response()->json([
                    'body' => 'Section removed successfully.',
                    'status' => 'success',
                ], 200, [], JSON_UNESCAPED_UNICODE);

                break;
            case 'delete-content-block':
                $post_id = $request->input('post_id');
                $section = $request->input('section');
                $id = $request->input('id');

                $block = PostsBlocks::findOrFail($id);
                $data__ = $block->toArray();
                $data__['meta'] = $block->meta();
                $section = PostsSections::find($block->section_id);
                $section->update(['blocks' => ($section->blocks - 1)]);
                PostsBlocks::destroy($id);
                Helpers::removeFile(storage_path('app/public/posts/'), $block->image);

                return response()->json([
                    'body' => 'Block removed successfully.',
                    'status' => 'success',
                ], 200, [], JSON_UNESCAPED_UNICODE);

                break;
            case 'section-status-update':
                $id = $request->input('id');
                $status = ($request->input('status') == 'N') ? 'Y' : 'N';
                PostsSections::where('id', $id)->update(['status' => $status]);
                if ($status == 'Y') {
                    $body = '<i class="fa fa-eye" aria-hidden="true"></i>';
                } else {
                    $body = '<i class="fa fa-eye-slash" aria-hidden="true"></i>';
                }

                return response()->json([
                    'body' => $body,
                    'status' => 'success',
                    'status_value' => $status,
                ], 200, [], JSON_UNESCAPED_UNICODE);

                break;
            case 'section-order-update':
                $sectionids = $request->input('sectionids');
                $ids = explode(',', $sectionids);
                $i = 1;
                foreach ($ids as $id) {
                    PostsSections::where('id', $id)->update(['sort_order' => $i]);
                    $i++;
                }

                return response()->json([
                    'body' => 'Sort order updated.',
                    'status' => 'success',
                ], 200, [], JSON_UNESCAPED_UNICODE);

                break;
            case 'block-order-update':
                $sectionids = $request->input('sectionids');
                $ids = explode(',', $sectionids);
                $i = 1;
                foreach ($ids as $id) {
                    PostsBlocks::where('id', $id)->update(['sort_order' => $i]);
                    $i++;
                }

                return response()->json([
                    'body' => 'Sort order updated.',
                    'status' => 'success',
                ], 200, [], JSON_UNESCAPED_UNICODE);

                break;

            case 'section-settings':
                $post_id = $request->input('post_id');
                $id = $request->input('section');
                $section = PostsSections::findOrFail($id);
                $section->meta = $section->meta();

                return response()->json([
                    'body' => view('cpanel.posts.pagebuilder.section-settings', compact('section'))->render(),
                    'status' => 'success',
                ], 200, [], JSON_UNESCAPED_UNICODE);

                break;
            case 'save-section-settings':
                $user = Auth::user();
                $id = $request->input('id') ? $request->input('id') : '';
                $section = PostsSections::findOrFail($id);
                $value['title'] = $request->input('title');
                $value['sort_order'] = $request->input('sort_order');
                $value['type'] = $request->input('type', 'plain');
                $meta = $request->input('meta') ? $request->input('meta') : [];

                    //                if($image != '' && file_exists(public_path('temp').'/'.$image)){
                    //                    if(copy('temp/'.$image, storage_path('app/public/posts').'/'.$image)){
                    //                        unlink ('temp/'.$image);
                    //                    }
                    //                }
                $section->update($value);

                foreach ($meta as $key => $value) {
                    PostsSectionsMeta::updateOrCreate(
                        ['section_id' => $section->id, 'meta_key' => $key],
                        [
                            'section_id' => $section->id,
                            'meta_key' => $key,
                            'meta_value' => $value,
                        ]
                    );
                }

                $section->meta = $section->meta();

                return response()->json([
                    'body' => view('cpanel.posts.pagebuilder.add-section-wrap', compact('section'))->render(),
                    'status' => 'success',
                    'section' => $section,
                ], 200, [], JSON_UNESCAPED_UNICODE);

                break;
            case 'temp-upload-image':
                $i = 0;
                $items = [];
                $files = $request->file('files');
                $size_error = $request->input('size_error') ? $request->input('size_error') : [];

                if (! empty($files)) {
                    foreach ($files as $file) {
                        $extension = $file->getClientOriginalExtension();
                        $fileMime = $file->getClientMimeType();
                        if ($fileMime == 'image/jpg' || $fileMime == 'image/jpeg') {
                            $ext = 'jpg';
                        } elseif ($fileMime == 'image/png') {
                            $ext = 'png';
                        } elseif ($fileMime == 'image/gif') {
                            $ext = 'gif';
                        } elseif ($fileMime == 'image/webp') {
                            $ext = 'webp';
                        }

                        $random = time();

                        if (
                            $fileMime == 'image/jpg' || $fileMime == 'image/jpeg'
                            || $fileMime == 'image/png' || $fileMime == 'image/gif' || $fileMime == 'image/webp'
                        ) {
                            $name = $file->getClientOriginalName();
                            $name_without_extension = pathinfo($name, PATHINFO_FILENAME);
                            $filename = preg_replace('/[^a-zA-Z0-9\']/', '', $name_without_extension);
                            $filename = str_replace("'", '', $filename);

                            $filename = $random.'-'.$filename.'.'.$ext;
                            Storage::disk('temp')->put($filename, File::get($file));
                            $image_url = asset('temp').'/'.$filename;
                            $items[$i]['status'] = 'success';
                            $items[$i]['filename'] = $filename;
                            $items[$i]['url'] = $image_url;
                            $items[$i]['type'] = $ext;
                            $items[$i]['size'] = $file->getSize();
                            $items[$i]['name'] = $file->getClientOriginalName();
                        } else {
                            $json[$i]['status'] = 'fail';
                            $json[$i]['message'] = 'File type should be .png, gif, jpg or jpeg';
                        }
                        $i++;
                    }
                } else {
                    if ($size_error) {
                        $message = implode(',', $size_error).' This file(s) are too large to upload. The maximum supported file size are 5MB';
                    } else {
                        $message = 'Please select one file.';
                    }

                    $json['status'] = 'fail';
                    $json['message'] = $message;

                    return response()->json($json, 200, [], JSON_UNESCAPED_UNICODE);
                }

                return response()->json([
                    'body' => view('cpanel.posts.pagebuilder.upload-image-list', compact('items', 'size_error'))->render(),
                    'status' => 'success',
                ], 200, [], JSON_UNESCAPED_UNICODE);

                break;
            default:
                break;
        }
    }
}
