<?php

namespace App\Http\Controllers\Cpanel;

use App\Http\Controllers\Controller;
use App\Http\Helpers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AjaxController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

     public function changeStatus(Request $request)
     {
         $status = $request->input('status');
         $statusType = $request->input('statusType');
         $id = $request->input('id');

         $arr = [
             'status' => $status == 'Y' ? 'N' : 'Y',
             'updated_by' => Auth::id(),
             'updated_at' => date('Y-m-d H:i:s'),
         ];

         if (DB::table($statusType)->where('id', $id)->update($arr)) {
             $json['status'] = 'success';
             $json['message'] = 'Status has been updated.';
             echo json_encode($json);
         } else {
             $json['status'] = 'error';
             $json['message'] = 'Something went wrong.';
             echo json_encode($json);
         }
     }

    public function generatePassword()
    {
        $password = Helpers::generatePassword();

        return json_encode(['status' => 'success', 'password' => $password]);
    }

    public function changeOrder(Request $request)
    {
        $ids = $request->ids;
        $statusType = $request->statusType;

        foreach ($ids as $index => $id) {
            DB::table($statusType)
                ->where('id', (int) $id)
                ->update([
                    'sort_order' => $index + 1,
                ]);
        }

        $json['status'] = 'success';
        echo json_encode($json);
        exit;
    }
}
