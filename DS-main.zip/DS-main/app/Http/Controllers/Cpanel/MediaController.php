<?php

namespace App\Http\Controllers\Cpanel;

use App\Http\Controllers\Controller;
use App\Http\Helpers;
use App\Models\Medias;
use App\Traits\HasUploadImage;

class MediaController extends Controller
{
    use HasUploadImage;

    public function __construct()
    {
        $this->middleware(['auth']);
    }

    public function list()
    {
        return view('cpanel.media.list');
    }

    public function ajax()
    {
        if (! request()->ajax()) {
            return abort(404);
        }

        $s = request()->input('s');
        $limit = request()->input('limit', 40);

        $medias = Medias::query()
            ->latest()
            ->when($s, function ($query) use ($s) {
                $query->where('file_title', 'LIKE', "%$s%");
            })
            ->simplePaginate($limit);

        foreach ($medias as $media) {
            $media->file_url = Helpers::asset($media->file_url);
        }

        return response()->json($medias);
    }
}
