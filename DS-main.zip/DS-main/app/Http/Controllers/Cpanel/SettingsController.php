<?php

namespace App\Http\Controllers\Cpanel;

use App\Http\Controllers\Controller;
use App\Models\MenuAccess;
use App\Models\MenuItems;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class SettingsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function config(Request $request)
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            Cache::flush();

            foreach ($_POST as $key => $value) {
                $values = ['value' => $request->input($key)];
                Setting::where('name', $key)->update($values);
            }

            return redirect()->back()->with('success', 'Config values has been updated.');
        }

        $configs = Setting::where('can_edit', 'Y')
            ->orderBy('sort_order', 'ASC')
            ->get();

        $results = Setting::where('can_edit', 'Y')
            ->orderBy('type', 'asc')
            ->get();

        $tabs = [];

        foreach ($results as $result) {
            $tabs[$result->config_group][] = $result;
        }

        return view('cpanel.settings.config', compact('configs', 'tabs'));
    }

    public function access(Request $request)
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            MenuAccess::truncate();

            foreach ($_POST['access'] as $role => $value) {
                foreach ($value as $id => $stat) {
                    $input = [
                        'role' => $role,
                        'menu_item' => $id,
                        'access' => $stat,
                    ];
                    MenuAccess::insert($input);
                }
            }

            return redirect()->back()->with('success', 'Module access has been updated.');
        }

        $roles = config('settings.user_roles') ?
            array_map('trim', explode(PHP_EOL, config('settings.user_roles'))) :
            ['Super Admin', 'Administrator'];

        $menuitems = [];

        $results = MenuItems::select('menu_items.*', 'm.label as menu')
                ->leftJoin('menus as m', 'm.id', '=', 'menu_items.menu_id')
                ->where('m.menu', 'admin')
                ->where('menu_items.status', 'Y')
                ->orderBy('menu_items.menu_id', 'ASC')
                ->orderBy('menu_items.sort', 'ASC')
                ->get()->toArray();

        array_map(function ($item) use (&$menuitems) {
            $menuitems[$item['menu']][] = $item;
        }, $results);

        $menuaccess = [];

        array_map(function ($item) use (&$menuaccess) {
            $menuaccess[$item['role']][] = $item['menu_item'];
        }, MenuAccess::where('access', 'Y')->get()->toArray());

        if (empty($menuaccess)) {
            foreach ($roles as $role) {
                $menuaccess[$role] = [];
            }
        }

        return view('cpanel.settings.access', compact('menuitems', 'menuaccess', 'roles'));
    }

    public function access_change(Request $request)
    {
        $json = [];

        $json['status'] = 'fail';

        $role = $request->input('role') ? $request->input('role') : '';

        $item = $request->input('item') ? $request->input('item') : '';

        $access = $request->input('access') ? $request->input('access') : 'N';

        $inputs = ['access' => $access];

        if (MenuAccess::where('role', $role)->where('menu_item', $item)->get()) {
            MenuAccess::where('role', $role)->where('menu_item', $item)->update($inputs);

            $json['status'] = 'success';
        } else {
            $input = ['role' => $role, 'menu_item' => $item, 'access' => $access, 'created_at' => date('Y-m-d H:i:s')];

            MenuAccess::insert($input);

            $json['status'] = 'success';
        }

        echo json_encode($json);
        exit;
    }

    public function menus(Request $request)
    {
        $results = MenuItems::select('menu_items.*', 'mi.label as parent')
            ->leftJoin('menu_items as mi', 'mi.id', '=', 'menu_items.parent_id')
            ->get()
            ->toArray();

        $menuitems = [];

        array_map(function ($item) use (&$menuitems) {
            $menuitems[$item['parent'] ? $item['parent'] : 'Default'][] = (object) $item;
        }, $results);

        return view('cpanel.settings.menus', compact('menuitems'));
    }
}
