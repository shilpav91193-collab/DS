<?php

namespace App\Http\Controllers\Cpanel;

use App\Http\Controllers\Controller;
use App\Http\Helpers;
use App\Models\Sector;
use App\Traits\HasUploadImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SectorsController extends Controller
{
    use HasUploadImage;

    public function __construct()
    {
        $this->middleware(['auth']);
    }

    public function list(Request $request)
    {
        $s = request()->input('s');

        $filter = [
            'status' => ['Y', 'N'],
            's' => $request->s,
            'group_type_id' => $request->group_type_id,
        ];

        $sectors = Sector::query()
            ->when($s, function ($query, $s) {
                return $query->where('title', 'like', "%$s%");
            })
            ->orderBy('sort_order')
            ->paginate(25);

        return view('cpanel.sectors.list',
            compact('sectors', 'filter'));
    }

    public function create()
    {
        return view('cpanel.sectors.edit', ['result' => null]);
    }

    public function edit($id = null)
    {
        $result = null;

        if ($id) {
            $result = Sector::find($id);
        }

        return view('cpanel.sectors.edit', ['result' => $result]);
    }

    public function update(Request $request, $id = null)
    {
        $request->validate([
            'title' => 'required|min:5|max:255',
            'sub_title' => 'nullable',
        ]);

        $sector = Sector::find($id);

        if (! $sector) {
            $sector = new Sector();
            $sector->created_by = Auth::id();
        }

        $sector->title = $request->title;
        $sector->sub_title = $request->sub_title;
        $sector->slug = Helpers::getSlug('groups', 'slug', $request->slug, $id);
        $sector->short_description = $request->short_description;
        $sector->image = $request->image;
        $sector->save();

        return redirect()
            ->route('sectors.list')
            ->with('success', 'Sector updated successfully.');
    }

    public function delete(Request $request, $id)
    {
        $ids = $request->input('ids', [$id]);

        Sector::query()
            ->where('id', $ids)
            ->delete();

        return redirect()
            ->route('sectors.list')
            ->with('success', 'Sector deleted successfully.');
    }
}
