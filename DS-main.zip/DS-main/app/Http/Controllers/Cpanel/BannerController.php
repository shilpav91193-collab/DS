<?php

namespace App\Http\Controllers\Cpanel;

use App\Http\Controllers\Controller;
use App\Http\Helpers;
use App\Models\Banner;
use App\Models\Medias;
use App\Traits\HasUploadImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BannerController extends Controller
{
    use HasUploadImage;

    public function __construct()
    {
        $this->middleware(['auth']);
    }

    public function list(Request $request)
    {
        $s = request()->input('s');
        $status = $request->input('status') == 'all' ? null : $request->input('status');

        $banners = Banner::query()
            ->when($s, function ($query, $s) {
                return $query->where('title', 'like', "%$s%");
            })
            ->when($status, function ($query) use ($status) {
                return $query->where('status', $status);
            })
            ->paginate(25);

        return view('cpanel.banners.list', compact('banners'));
    }

    public function create()
    {
        $medias = Medias::query()
            ->latest()
            ->get();

        foreach ($medias as $media) {
            $media->file_url = Helpers::asset($media->file_url);
        }

        return view('cpanel.banners.edit', ['banner' => null, 'images' => $medias]);
    }

    public function edit(Banner $banners)
    {
        $medias = Medias::query()
            ->latest()
            ->get();

        foreach ($medias as $media) {
            $media->file_url = Helpers::asset($media->file_url);
        }

        return view('cpanel.banners.edit', ['banner' => $banners, 'images' => $medias]);
    }

    public function update(Request $request)
    {
        if ($id = $request->input('id')) {
            $banners = Banner::findOrFail($id);
        }

        $array = request('contents');

        $validated = $request->validate([
            'title' => 'required|min:5|max:255',
            'description' => 'nullable',
            'contents' => 'required|array',
            'contents.*.id' => 'required|exists:medias,id',
            'contents.*.mobile' => 'nullable|exists:medias,id',
            'contents.*.meta_description' => 'nullable|string',
            'contents.*.meta_url' => 'nullable|string',
            'contents.*.target' => 'nullable|string',
            'contents.*.meta_sort_order_banner' => 'nullable||regex:/^[0-9+]+$/|max:8',
        ]);
        $sortedArray = collect($array)->sortBy('meta_sort_order_banner')->values()->all();

        $validated['contents'] = json_encode($sortedArray);

        if ($id) {
            $validated['updated_by'] = Auth::id();
            $banners->update($validated);
        } else {
            $validated['created_by'] = Auth::id();
            $banners = Banner::create($validated);
        }

        return redirect()
            ->route('banners.edit', ['banners' => $banners->id])
            ->with('success', 'banner saved successfully');
    }

    public function destroy(Banner $banners)
    {
        $banners->delete();

        return redirect()
            ->route('banners.list')
            ->with('success', 'banner deleted successfully');
    }
}
