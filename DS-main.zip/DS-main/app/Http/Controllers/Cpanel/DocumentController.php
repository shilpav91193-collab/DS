<?php

namespace App\Http\Controllers\Cpanel;

use App\Http\Controllers\Controller;
use App\Http\Helpers;
use App\Models\Document;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class DocumentController extends Controller
{
    protected $supported_mimes = [
        'pdf' => 'application/pdf',
        'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'ppt' => 'application/vnd.ms-powerpoint',
        'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'jpeg' => 'image/jpeg',
        'jpg' => 'image/jpg',
        'png' => 'image/png',
    ];

    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('checkaccess:documents');
    }

    public function list(Request $request)
    {
        $limit = $request->input('limit', config('settings.pagination_limit', 25));

        $filter = ['limit' => $limit, 'status' => ['Y', 'N'], 's' => $request->s];
        $results = Document::orderBy('id', 'desc')->paginate($limit);

        return view('cpanel.documents.list', ['results' => $results, 'filter' => $filter]);
    }

    public function edit($id = null)
    {
        $result = $id ? Document::find($id) : null;

        return view('cpanel.documents.edit', ['result' => $result]);
    }

    public function update(Request $request, $id = null)
    {
        $request->validate([
            'title' => 'required',
            'slug' => 'required',
            'url' => 'requiredIf:file,null',
            'file' => 'nullable|max:3062|mimes:'.implode(',', array_keys($this->supported_mimes)),
        ]);

        $slug = Helpers::getSlug('documents', 'slug', $request->slug, $id);

        if ($request->hasFile('file')) {
            $server_path = 'public/public_documents';
            $client_path = asset('storage/public_documents');
            $directory_path = $server_path.'/documents';
            $file = $request->file('file');
            $name = $file->getClientOriginalName();
            $ext = $file->getClientOriginalExtension();
            $file_name = str_replace('.'.$ext, '', $name).'.'.$ext;
            while (Storage::exists($directory_path.'/'.$file_name)) {
                $file_name = str_replace('.'.$ext, '', $name).'-'.rand(1000, 9999).'.'.$ext;
            }

            Storage::putFileAs($directory_path, $file, $file_name);
            $request->merge(['url' => $client_path.'/documents/'.$file_name]);
        }

        if ($id) {
            $document = Document::findOrFail($id);
            $document->type = isset($request->type) ? $request->type : $document->type;
        } else {
            $document = new Document();
            $document->created_by = Auth::id();
            $document->status = 'Y';
            $document->type = Document::DOCUMENT_TYPE_LAW_AND_GOVERNANCE;
        }
        $document->title = $request->title;
        $document->slug = $slug;
        $document->url = $request->url;
        $document->image = $request->image;
        $document->save();

        return redirect()->route('documents.list')->with('success', 'Document updated successfully.');
    }

    public function delete(Request $request, $id)
    {
        $ids = $request->input('ids', [$id]);
        Document::where('id', $ids)->delete();

        return redirect()->route('documents.list')->with('success', 'Document(s) deleted successfully.');
    }
}
