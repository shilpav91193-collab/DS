<?php

namespace App\Http\Controllers\Cpanel;

use App\Http\Controllers\Controller;
use App\Http\Helpers;
use App\Models\User;
use App\Models\UserMeta;
use App\Models\UserRole;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('checkaccess:users');
    }

    public function list(Request $request)
    {
        $is_admin = Helpers::is_admin();

        $limit = $request->input('limit', config('settings.pagination_limit', 25));
        $s = $request->input('q');
        $prefix = DB::getTablePrefix();
        $role = $request->input('role') ? $request->input('role') : '';
        $status = $request->input('status') == 'all' ? '' : ($request->input('status') ? $request->input('status') : '');
        $filter = ['limit' => $limit, 'status' => $status, 'role' => $role, 's' => $s];

        $results = User::select('users.*', 'ur.name as user_role')
            ->leftJoin('user_roles as ur', function ($join) {
                $join->on('users.roleid', '=', 'ur.id');
            })
            ->when(Auth::id() != 1, function ($query) {
                return $query->where('users.id', '<>', 1);
            })
            ->when($s, function ($query, $s) use ($prefix) {
                return $query->where(DB::raw('CONCAT('.$prefix."users.name,' ',".$prefix.'users.lastName)'), 'like', "%$s%")
                    ->orWhere('users.phone', 'like', "%$s%")
                    ->orWhere('ur.name', 'like', "%$s%")
                    ->orWhere('users.email', 'like', "%$s%");
            })
            ->when($status, function ($query, $status) {
                $query->where('users.status', $status);
            })
            ->when($role, function ($query, $role) {
                $query->where('users.roleid', $role);
            })
            ->orderBy('users.created_at', 'DESC')
            ->paginate($limit);

        $roles = UserRole::query()
            ->where('status', 'Y')
            ->get();

        return view('cpanel.users.index', compact(
            'results', 'roles', 'filter'));
    }

    public function create()
    {
        $roleids = UserRole::query()
            ->when(Auth::user()->user_role_id != 1, function ($query) {
                return $query->where('id', '<>', 1);
            })
            ->orderBy('name')
            ->get();

        return view('cpanel.users.create', compact('roleids'));
    }

    public function edit($id = '')
    {
        if ($id == 1) {
            abort(403);
        }

        $result = User::findOrFail($id);
        $result->meta = $result->meta();

        $roleids = UserRole::query()
            ->when(Auth::user()->roleid != 1, function ($query) {
                return $query->where('id', '<>', 1);
            })
            ->orderBy('name')
            ->get();

        return view('cpanel.users.edit', compact(
            'result', 'roleids', 'id'));
    }

    public function update(Request $request, $id = '')
    {
        $v = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email|unique:users,email,'.$id.',id',
            'status' => 'required',
        ]);

        if ($v->fails()) {
            return redirect()->back()->withInput()->withErrors($v->errors());
        }

        $image = $request->file('avatar') ? $request->file('avatar') : '';

        if ($image != '') {
            $extension = $image->getClientOriginalExtension();
            $fileMime = $image->getClientMimeType();

            if ($fileMime == 'image/jpg' || $fileMime == 'image/jpeg') {
                $ext = 'jpg';
            } elseif ($fileMime == 'image/png') {
                $ext = 'png';
            } elseif ($fileMime == 'image/gif') {
                $ext = 'gif';
            }

            $filename = time().'-'.md5(preg_replace('/\s+/', '', $image->getClientOriginalName())).'.'.$ext;

            if (
                $fileMime == 'image/jpg' || $fileMime == 'image/jpeg'
                || $fileMime == 'image/png' | $fileMime == 'image/gif'
            ) {
                Storage::disk('public')->put('profiles/'.$filename, File::get($image));
            } else {
                return redirect()->back()->withInput()->withErrors(['error', 'File type should be .PNG, .GIF or .JPG']);
                //return redirect()->back()
            }
        } else {
            $filename = $request->input('filename') ? $request->input('filename') : '';
        }

        $values = [
            'name' => $request->input('name'),
            'lastname' => $request->input('lastname'),
            'phone' => $request->input('phone'),
            'avatar' => $filename,
            'email' => $request->input('email'),
            'roleid' => $request->input('roleid'),
            'status' => $request->input('status'),
            'updated_at' => date('Y-m-d H:i:s'),
            'updated_by' => Auth::id(),
        ];

        if ($id > 0) {
            $result = User::findOrFail($id);
            $result->update($values);
        } else {
            $password = $request->input('password');
            $values['password'] = Hash::make($password);
            $user = User::create($values);
            $id = $user->id;
        }

        $meta = $request->input('meta') ? $request->input('meta') : [];
        foreach ($meta as $key => $value) {
            UserMeta::updateOrCreate(
                ['user_id' => $id,
                    'meta_key' => $key,
                ],
                [
                    'user_id' => $id,
                    'meta_key' => $key,
                    'meta_value' => $value,
                    'created_at' => date('Y-m-d H:i:s'),
                ]
            );
        }

        return redirect()->route('users.list', [
            's' => $request->input('s'),
            'limit' => $request->input('limit'),
            'page' => $request->input('page'),
        ])->with('success', 'User has been updated.');
    }

    public function destroy($id)
    {
        if (! $id) {
            return redirect()->back()->withInput()->withErrors(['error', 'Invalid id!!']);
        }
        User::where('id', $id)->delete();

        return redirect('d-admin/users')->with('status', 'User has been deleted.');
    }

    public function restore($id)
    {
        if (! $id) {
            return redirect()->back()->withInput()->withErrors(['error', 'Invalid id!!']);
        }
        User::withTrashed()->where('id', $id)->restore();

        return redirect('d-admin/users')->with('status', 'User has been restored.');
    }

    public function resetPassword($id)
    {
        $password = Helpers::generatePassword();
        $user = User::select('name')->find($id);

        User::where('id', $id)->update(
            [
                'password' => Hash::make($password),
                'updated_at' => date('Y-m-d H:i:s'),
                'updated_by' => Auth::id(),
            ]
        );

        return redirect('d-admin/users')->with('reset_password', '<h5>Password has been changed successfully.</h5>New password for <h5 class="d-inline"><strong>'.$user->name.'</strong></h5> is <h5 class="d-inline"><strong>'.$password.'</strong></h5>');
    }
}
