<?php

namespace App\Http\Controllers\Cpanel;

use App\Http\Controllers\Controller;
use App\Http\Helpers;
use App\Models\GroupType;
use App\Models\GroupTypeMeta;
use App\Traits\HasUploadImage;
use Illuminate\Http\Request;

class GroupTypeController extends Controller
{
    use HasUploadImage;

    public function __construct()
    {
        $this->middleware(['auth']);
    }

    public function list(Request $request)
    {
        $s = request()->input('s');
        $status = $request->input('status') == 'all' ? null : $request->input('status');

        $groupTypes = GroupType::query()
            ->when($s, function ($query, $s) {
                return $query->where('title', 'like', "%$s%");
            })
            ->when($status, function ($query) use ($status) {
                return $query->where('status', $status);
            })
            ->orderBy('sort_order')
            ->paginate(25);

        return view('cpanel.group-types.list', compact('groupTypes'));
    }

    public function create()
    {
        return view('cpanel.group-types.edit', ['result' => null]);
    }

    public function edit($id = null)
    {
        $result = null;

        if ($id) {
            $result = GroupType::find($id);
            $result->meta = $result->meta();
        }

        return view('cpanel.group-types.edit', ['result' => $result]);
    }

    public function update(Request $request, $id = null)
    {
        $request->validate([
            'title' => 'required|min:5|max:255',
            'description' => 'nullable',
        ]);

        $groupType = GroupType::find($id);

        if (! $groupType) {
            $groupType = new GroupType();
        }

        $groupType->title = $request->title;
        $groupType->thumbnail = $request->thumbnail;
        $groupType->slug = Helpers::getSlug('group_types',
            'slug', $request->slug, $id);
        $groupType->description = $request->description;
        $groupType->image = $request->image;
        $groupType->save();

        $metaData = $request->has('meta') ? $request->meta : [];
        if (count($metaData) > 0) {
            foreach ($metaData as $key => $meta) {
                $data = [
                    'group_type_id' => $id,
                    'meta_key' => $key,
                    'meta_value' => ! is_array($meta) ? $meta : json_encode($meta),
                ];

                GroupTypeMeta::updateOrCreate([
                    'group_type_id' => $id,
                    'meta_key' => $key,
                ],
                    $data,
                );
            }
        }

        return redirect()
            ->route('group-types.list')
            ->with('success', 'Group type updated successfully.');
    }

    public function delete(Request $request, $id)
    {
        $ids = $request->input('ids', [$id]);

        GroupType::query()
            ->where('id', $ids)
            ->delete();

        return redirect()
            ->route('group-types.list')
            ->with('success', 'Group types deleted successfully.');
    }
}
