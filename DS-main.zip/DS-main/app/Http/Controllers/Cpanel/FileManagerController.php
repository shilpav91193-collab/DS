<?php

namespace App\Http\Controllers\Cpanel;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class FileManagerController extends Controller
{
    protected $server_path;

    protected $client_path;

    protected $temp_tree = [];

    protected $supported_mimes = [
        'pdf' => 'application/pdf',
        'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'ppt' => 'application/vnd.ms-powerpoint',
        'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'jpeg' => 'image/jpeg',
        'jpg' => 'image/jpg',
        'png' => 'image/png',
    ];

    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('checkaccess:public_documents')->except([
            'files', 'createDirectory',
            'deleteDirectory', 'uploadFile', 'deleteFile',
        ]);
        $this->server_path = 'public/public_documents';
        $this->client_path = asset('storage/public_documents');
    }

    public function list()
    {
        $directories = $this->getDirs($this->server_path);
        $client_path = $this->client_path;

        $mimes = array_map(function ($mime) {
            return '.'.str_replace('.', '', $mime);
        }, array_keys($this->supported_mimes));

        $mimes = implode(',', $mimes);

        return view('cpanel.filemanager.index', compact('directories', 'client_path', 'mimes'));
    }

    private function getDirs($path)
    {
        $directories = Storage::allDirectories($path);

        $directories = array_map(function ($dir) {
            $dir = str_replace('\\', '/', $dir);
            $dir = str_replace($this->server_path.'/', '', $dir);
            $last_modified = Carbon::parse(Storage::lastModified($this->server_path.'/'.$dir))->diffForHumans();

            return [
                'path' => $dir,
                'level' => substr_count($dir, '/'),
                'name' => basename($dir),
                'type' => 'folder',
                'date_modified' => $last_modified,
                'size' => '',
                'hash' => md5($this->server_path.'/'.$dir.$last_modified),
                'open' => false,
            ];
        }, $directories);

        $last_modified = Storage::lastModified($this->server_path);

        return [
            'path' => '',
            'level' => -1,
            'name' => 'Documents',
            'type' => 'folder',
            'date_modified' => Carbon::parse(Storage::lastModified($this->server_path))->diffForHumans(),
            'size' => '',
            'children' => $this->buildTree($directories),
            'hash' => md5($this->server_path.'/'.$last_modified),
            'open' => true,
        ];
    }

    private function buildTree($directories)
    {
        foreach ($directories as $directory) {
            $this->temp_tree[$directory['level']][] = $directory;
        }

        return $this->buildTreeRecursive($this->temp_tree);
    }

    private function buildTreeRecursive($directories)
    {
        $tree = [];

        foreach ($directories as $key => $directory) {
            if ($key == 0) {
                $tree = $directory;
            } else {
                foreach ($directory as $dir) {
                    $this->addDirToTree($tree, $dir);
                }
            }
        }

        return $tree;
    }

    private function addDirToTree(&$tree, $dir)
    {
        foreach ($tree as &$node) {
            if ($node['path'] == $dir['path']) {
                return;
            }
            if (strpos($dir['path'], $node['path']) !== false) {
                if (! isset($node['children'])) {
                    $node['children'] = [];
                }
                $this->addDirToTree($node['children'], $dir);

                return;
            }
        }
        $tree[] = $dir;
    }

    public function files(Request $request)
    {
        $file_path = $this->server_path.'/'.$request->path;
        $files = Storage::files($file_path);
        $files = array_map(function ($item) {
            $item = str_replace('\\', '/', $item);
            $item = str_replace($this->server_path.'/', '', $item);
            $last_modified = Carbon::parse(Storage::lastModified($this->server_path.'/'.$item))->diffForHumans();

            return [
                'path' => $item,
                'name' => basename($item),
                'type' => 'file',
                'date_modified' => $last_modified,
                'size' => Storage::size($this->server_path.'/'.$item),
                'hash' => md5($this->server_path.'/'.$item.$last_modified),
                'url' => $this->client_path.'/'.$item,
            ];
        }, array_filter($files, function ($file) {
            return in_array(Storage::mimeType($file), $this->supported_mimes);
        }));
        $folders = Storage::directories($file_path);
        $folders = array_map(function ($item) {
            $item = str_replace('\\', '/', $item);
            $item = str_replace($this->server_path.'/', '', $item);
            $last_modified = Storage::lastModified($this->server_path.'/'.$item);

            return [
                'path' => $item,
                'name' => basename($item),
                'type' => 'folder',
                'date_modified' => $last_modified,
                'size' => '',
                'hash' => md5($this->server_path.'/'.$item.$last_modified),
            ];
        }, $folders);
        $all_items = array_merge($folders, $files);

        return response()->json($all_items);
    }

    public function createDirectory(Request $request)
    {
        $request->validate([
            'path' => 'nullable|string',
            'folder_name' => 'required|string',
        ]);
        $directory_path = $this->server_path.'/'.$request->path;
        $directory_name = $request->folder_name;
        $directory = $directory_path.'/'.$directory_name;
        Storage::makeDirectory($directory);

        return $this->files($request);
    }

    public function deleteDirectory(Request $request)
    {
        $directory_path = $this->server_path.'/'.$request->path;
        Storage::deleteDirectory($directory_path);

        return response()->json(['success' => true]);
    }

    public function uploadFile(Request $request)
    {
        $request->validate([
            'file' => 'required|file|mimes:'.implode(',', array_keys($this->supported_mimes)),
        ]);
        $directory_path = $this->server_path.'/'.$request->path;
        $file = $request->file('file');
        $name = $file->getClientOriginalName();
        $ext = $file->getClientOriginalExtension();
        $file_name = str_replace('.'.$ext, '', $name).'.'.$ext;
        Storage::putFileAs($directory_path, $file, $file_name);

        return $this->files($request);
    }

    public function deleteFile(Request $request)
    {
        $request->validate([
            'path' => 'nullable|string',
            'name' => 'required|string',
            'type' => 'required|in:file,folder',
        ]);
        $file_path = $this->server_path.'/'.$request->path.'/'.$request->name;
        if ($request->type == 'file') {
            Storage::delete($file_path);
        } else {
            Storage::deleteDirectory($file_path);
        }

        return $this->files($request);
    }
}
