<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Mail\ResetPasswordLinkMail;
use App\Models\PasswordReset;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Illuminate\View\View;

class PasswordResetLinkController extends Controller
{
    /**
     * Display the password reset link request view.
     */
    public function create(): View
    {
        return view('auth.forgot-password');
    }

    /**
     * Handle an incoming password reset link request.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'email' => ['required', 'email', 'exists:users'],
        ], ['email.exists' => 'user does not exist']);

        $token = Str::random(16);

        $passwordReset = PasswordReset::query()
            ->where('email', $request->email)
            ->first();

        if (! $passwordReset) {
            $passwordReset = new PasswordReset();
        }

        $passwordReset->email = $request->email;
        $passwordReset->token = $token;
        $passwordReset->save();

        $user = User::where('email', $request->email)->first();

        $attributes['name'] = $user->name;
        $attributes['email'] = $user->email;
        $attributes['reset_url'] = route('password.reset', $token);

        try {
            Mail::send(new ResetPasswordLinkMail($attributes));
        } catch (\Exception $e) {
            info('Error sending password reset email: '.$e->getMessage());

            return back()->withInput($request->only('email'))
                ->withErrors(['email' => 'Failed to send password reset email']);
        }

        return back()->with('status', 'Password reset link has been sent to your email');
    }
}
