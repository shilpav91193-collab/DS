<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\PasswordReset;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules;
use Illuminate\View\View;

class NewPasswordController extends Controller
{
    /**
     * Display the password reset view.
     */
    public function create(Request $request): View
    {
        return view('auth.reset-password', ['request' => $request]);
    }

    /**
     * Handle an incoming new password request.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'token' => ['required'],
            'email' => ['required', 'email', 'exists:users'],
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
        ], [
            'email.exists' => 'user does not exist',
        ]);

        $token = $request->token;
        $email = $request->email;
        $user = User::where('email', $email)->first();

        if (Hash::check($request->password, $user->password)) {
            return back()->withErrors(['password' => 'New password cannot be same as the old one']);
        }

        $passwordReset = PasswordReset::query()
            ->where('email', $request->email)
            ->where('token', $token)
            ->first();

        if (! $passwordReset) {
            return back()->withErrors(['email' => 'Invalid Token']);
        }

        if ($passwordReset->created_at->lt(now()->subMinutes(120))) {
            return back()->withErrors(['email' => 'Token expired']);
        }

        $user->password = Hash::make($request->password);
        $user->remember_token = Str::random(60);
        $user->save();

        return redirect()
            ->route('login')
            ->with('status', 'Successfully updated your password.');
    }
}
