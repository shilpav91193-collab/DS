<?php

namespace App\Http;

use App\Models\Brochure;
use App\Models\Countries;
use App\Models\Degree;
use App\Models\DegreeType;
use App\Models\GroupType;
use App\Models\Medias;
use App\Models\Menu;
use App\Models\Module;
use App\Models\ModuleItem;
use App\Models\Posts;
use App\Models\Teams;
use DB;
use Illuminate\Support\Facades\Auth;

class Helpers
{
    public static function getSlug($slugType, $slugField, $slugString, $id = 0)
    {
        $slug = preg_replace('/[^A-Za-z0-9-]+/', '-', strtolower(trim($slugString)));
        $slug = str_replace('---', '-', $slug);
        $slug = str_replace('--', '-', $slug);
        if ($id) {
            $count = DB::table($slugType)->where([[$slugField, 'like', $slug], ['id', '<>', $id]])
                ->get()->count();
        } else {
            $count = DB::table($slugType)->where($slugField, 'like', $slug)
                ->get()->count();
        }
        //
        if ($count > 0) {
            return $slug.'-'.$count;
        } else {
            return $slug;
        }
    }

    public static function getAccess($user, $type = '', $action = '', $debug = false)
    {
        $data_action = array_filter(explode(',', $action));
        $object_access = \App\Models\UserRole::select('access')->whereId($user->roleid)->first();
        //
        $module_access = (array) json_decode($object_access->access);

        if ($type) {
            $data_access = (array) $module_access['module_access'];

            $data_crud = isset($data_access[$type]) ? $data_access[$type] : [];

            if (count($data_action) > 0) {
                foreach ($data_action as $action_item) {
                    if (in_array($action_item, $data_crud)) {
                        return true;
                    }
                }

                return false;
            } else {
                return isset($data_access[$type]) ? true : false;
            }

            return (! count(array_diff($data_action, $data_crud))) ? true : false;
        } else {
            return (array) $module_access['module_access'];
        }
    }

    public static function checkModule($parent_id, $data_access)
    {
        $modules = \App\Models\ModuleItem::select('slug')->where('module_id', $parent_id)->get()->pluck('slug');

        foreach ($modules as $item) {
            if (in_array($item, $data_access)) {
                return true;
            }
        }

        return false;
    }

    public static function checkParentModule($parent_id, $data_access)
    {
        $modules = \App\Models\Module::select('slug')->whereId($parent_id)->get()->pluck('slug');
        foreach ($modules as $item) {
            if (in_array($item, $data_access)) {
                return true;
            }
        }

        return false;
    }

    public static function generatePassword($password_length = 8)
    {
        $data_chars = str_split('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()\-_=+~\[\]{}?');
        $data_lenght = count($data_chars) - 1;
        $password = '';
        for ($i = 1; $i <= $password_length; $i++) {
            $password .= $data_chars[mt_rand(0, $data_lenght)];
        }

        if (! preg_match("/^(?=.*[!@#$%^&*()\-_=+~\[\]{}?])(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).{8,30}$/", $password)) {
            $password = Helpers::generatePassword(8);
        }

        return $password;
    }

    public static function getMeta($tableName, $fieldName, $value)
    {
        $query = DB::table($tableName);
        $results = $query->where($fieldName, '=', $value)->get();
        $meta = [];
        foreach ($results as $result) {
            $meta[$result->meta_key] = $result->meta_value;
        }

        return (! empty($meta)) ? (object) $meta : [];
    }

    public static function is_admin()
    {
        return Auth::user()->id == 1 || Auth::user()->roleid == 2 ? true : false;
    }

    public static function is_sessionRequired($path)
    {
        $modules = Module::all();
        foreach ($modules as $module) {
            if (stripos($path, $module->link) !== false && $module->link) {
                return ($module->requireSession == 'Y') ? 'Y' : 'N';
            }
        }

        $module_items = ModuleItem::all();
        foreach ($module_items as $module_item) {
            if (stripos($path, $module_item->link) !== false && $module_item->link) {
                return ($module_item->requireSession == 'Y') ? 'Y' : 'N';
            }
        }

        return 'N';
    }

    public static function postSlug($string, $id = '')
    {
        //
        $slug = preg_replace('/[^A-Za-z0-9-]+/', '-', strtolower(trim($string)));
        $slug = str_replace('---', '-', $slug);
        $slug = str_replace('--', '-', $slug);
        if ($id) {
            $posts = Posts::where([['slug', 'like', $slug], ['id', '<>', $id]])->get()->count();
        } else {
            $posts = Posts::where('slug', 'like', $slug)->get()->count();
        }
        //
        if ($posts > 0) {
            return $slug.'-'.$posts;
        } else {
            return $slug;
        }
    }

    public static function removeFile($path, $file = '')
    {
        $file_path = '';
        if ($file) {
            if ($path) {
                $slash = substr($path, -1);
                if ($slash == '/') {
                    $file_path = $path.$file;
                } else {
                    $file_path = $path.'/'.$file;
                }
            } else {
                $file_path = $file;
            }

            @unlink($file_path);

            return true;
        }

        return false;
    }

    public static function getConfigs($general, $setting = [])
    {
        if ($general) {
            foreach ($general as $name => $value) {
                if (! isset($setting[trim($name)])) {
                    $setting[$name] = $value;
                }
            }
        }

        return $setting;
    }

    public static function getDays()
    {
        return [
            '1' => 'Mon',
            '2' => 'Tue',
            '3' => 'Wed',
            '4' => 'Thu',
            '5' => 'Fri',
            '6' => 'Sat',
            '7' => 'Sun',
        ];
    }

    public static function asset($path)
    {
        // if is already a qualified https or https url
        if (preg_match('/^https?:\/\//', $path)) {
            return $path;
        }

        return asset($path);
    }

    public static function getMenu($menu, $class = '', $default = false)
    {
        if ($default) {
            return view('Frontend.layouts.common.navmenu.nav-menu-default')->render();
        } else {
            $data = Menu::where('slug', $menu)->first();
            if ($data) {
                return view('Frontend.layouts.common.navmenu.menu', ['menu' => $data, 'class' => $class])->render();
            }
        }

        return '';
    }

    public static function parentPostWithSlug($id, $output = [])
    {
        $post = Posts::find($id);
        if ($post && $post->parent_id > 0) {
            $output[$post->slug] = $post->title;

            return self::parentPostWithSlug($post->parent_id, $output);
        } elseif ($post) {
            $output[$post->slug] = $post->title;
        }

        return $output;
    }

    public static function getFacultiesList($ids = [])
    {
        $results = Teams::with('featured_image')
            ->where('status', 'Y')
            ->whereIn('id', $ids)
            ->orderBy('sort_order')
            ->get();

        return $results;
    }

    public static function getDegrees()
    {
        $results = Degree::where('status', 'Y')->orderBy('title', 'ASC')->get();

        return $results;
    }

    public static function getDegreeTypes()
    {
        $results = DegreeType::where('status', 'Y')->orderBy('title', 'ASC')->get();

        return $results;
    }

    public static function getCountries()
    {
        $results = Countries::get();

        return $results;
    }

    public static function getBrochure($id)
    {
        $result = Brochure::with('image_item')->find($id);

        return $result;
    }

    public static function getPicture($id)
    {
        $result = Medias::find($id);

        return $result;
    }

    public static function getTermsPosts($template, $limit)
    {
        $results = Posts::select('posts.*')->join('taxonomies_posts_map', 'taxonomies_posts_map.post_id', 'posts.id')
                      ->where('taxonomies_posts_map.taxonomy_id', $template['id'])
                      ->where('post_type', $template['term'])->where('posts.status', 'Y')
                      ->orderByDesc('posts.created_at')->limit($limit)->get();

        return $results;
    }

    public static function getservices($template, $limit)
    {
        $results = Posts::select('posts.*')
                      ->where('service_id', $template['id'])
                       ->where('post_type', 'contents')->where('posts.status', 'Y')
                       ->orderByDesc('posts.created_at')->limit($limit)->get();

        return $results;
    }

    public static function getLocationData()
    {
        if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
        } else {
            $ip = \Request::ip();
        }

        $ip_api_key = env('IP_API_KEY');
        $url = 'https://pro.ip-api.com/php/'.$ip.'?key='.$ip_api_key;

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 1,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
        ]);
        $response = curl_exec($curl);
        $response_arr = unserialize($response);
        $err = curl_error($curl);
        curl_close($curl);

        if ($response_arr['status'] == 'success') {
            $arr = ['country' => $response_arr['country'], 'countryCode' => $response_arr['countryCode'], 'city' => $response_arr['city']];

            return $arr;
        }

        return false;
    }

    public static function getCounters()
    {
        $counterArray = [];

        $homePageData = \App\Models\Posts::where('slug', 'home')->first();
        if ($homePageData) {
            $homePageData->meta = $homePageData->meta();

            if (isset($homePageData->meta->home_total_assets_key) &&
                isset($homePageData->meta->home_total_assets)) {
                $counterArray[$homePageData->meta->home_total_assets_key] = $homePageData->meta->home_total_assets;
            }

            if (isset($homePageData->meta->home_total_area_covered_key) &&
                isset($homePageData->meta->home_total_area_covered)) {
                $counterArray[$homePageData->meta->home_total_area_covered_key] = $homePageData->meta->home_total_area_covered;
            }

            if (isset($homePageData->meta->home_total_air_ports_key) &&
                isset($homePageData->meta->home_total_air_ports)) {
                $counterArray[$homePageData->meta->home_total_air_ports_key] = $homePageData->meta->home_total_air_ports;
            }

            if (isset($homePageData->meta->home_total_subsidiaries_key) &&
                isset($homePageData->meta->home_total_subsidiaries)) {
                $counterArray[$homePageData->meta->home_total_subsidiaries_key] = $homePageData->meta->home_total_subsidiaries;
            }

            if (isset($homePageData->meta->home_total_our_dist_key) &&
                isset($homePageData->meta->home_total_our_dist)) {
                $counterArray[$homePageData->meta->home_total_our_dist_key] = $homePageData->meta->home_total_our_dist;
            }

            if (isset($homePageData->meta->home_total_employees_key) &&
                isset($homePageData->meta->home_total_employees)) {
                $counterArray[$homePageData->meta->home_total_employees_key] = $homePageData->meta->home_total_employees;
            }
        }

        return $counterArray;
    }

    public static function solveTemplates($content, $gallery_display = [])
    {
        $templates = [
            'counter_section' => \App\Models\Posts::class,
            'dacc_groups_structure' => \App\Models\Group::class,
            'dacc_groups' => \App\Models\Group::class,
            'dacc_sectors_structure' => \App\Models\Group::class,
            'video_section' => \App\Models\Posts::class,
        ];

        foreach ($templates as $name => $model) {
            if ($name == 'counter_section' ||
                $name == 'dacc_groups_structure' ||
                $name == 'dacc_sectors_structure' ||
                $name == 'video_section' ||
                $name == 'dacc_groups') {
                $regex = '/\[regex\s*:(\d+) (\w+):(\w+) (\w+):(\w+)\]/';
            } else {
                $regex = '/\[regex\s*:\s*([\w-]+)\]/';
            }

            $regex = str_replace('regex', $name, $regex);
            $content = preg_replace_callback($regex, function ($matches) use ($model, $name, $gallery_display) {
                $id = $matches[1];
                $datas = [];

                if ($name == 'counter_section') {
                    $template = $model::where('slug', 'home')
                        ->first();

                    $datas = self::getCounters();
                } elseif ($name == 'dacc_groups_structure' || $name == 'dacc_groups') {
                    $template = true;

                    $datas = GroupType::with('groups')
                        ->orderBy('title')
                        ->get();

                } elseif ($name == 'dacc_sectors_structure') {
                    $template = true;

                    $datas = Posts::query()
                        ->where('post_type', 'sectors')
                        ->where('status', 'Y')
                        ->get();
                } else {
                    $template = $model::where('status', 'Y')->find($id);
                }

                if ($template) {
                    return view('templates.'.$name,
                        ['template' => $template,
                            'gallery_display' => $gallery_display,
                            'datas' => $datas])
                        ->render();
                } else {
                    return view('templates.'.$name)->render();
                }

                return '';
            }, $content);
        }

        return $content;
    }

    public static function getAllSectors()
    {
        $sectors = Posts::query()
            ->where('post_type', 'sectors')
            ->where('status', 'Y')
            ->get();

        return $sectors;
    }

    public static function getAllDistricts()
    {
        $sectors = Posts::query()
            ->where('post_type', 'districts')
            ->where('status', 'Y')
            ->orderBy('sort_order')
            ->get();

        return $sectors;
    }

    public static function getAllAirports()
    {
        $airports = Posts::query()
            ->where('post_type', 'airports')
            ->where('status', 'Y')
            ->orderBy('sort_order')
            ->get();

        return $airports;
    }
}
