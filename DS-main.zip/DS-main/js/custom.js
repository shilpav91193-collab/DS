$(document).ready(function () {

	$('.banner-slider').slick({
		slidesToShow: 1,
		slidesToScroll: 1,
		autoplay: true,
		autoplaySpeed: 8000,
		speed: 1000,
		arrows: false,
		fade: true,
		dots: true,
		infinite: true,
		adaptiveHeight: false,
		cssEase: 'linear',
		pauseOnHover: false,
		prevArrow: '<a href="javascript:void(0);" class="btnPrev"><i class="fa-solid fa-arrow-left-long"></i></a>',
		nextArrow: '<a href="javascript:void(0);" class="btnNext"><i class="fa-solid fa-arrow-right-long"></i></a>',
		responsive: [{
			breakpoint: 767,
			settings: {
				dots: false,
			}
		}]
	});


	$('.press-slider').slick({
		infinite: true,
		slidesToShow: 3,
		slidesToScroll: 1,
		autoplay: false,
		autoplaySpeed: 4000,
		speed: 1000,
		arrows: true,
		fade: false,
		dots: false,
		infinite: true,
		cssEase: 'linear',
		pauseOnHover: true,
		prevArrow: '<a href="javascript:void(0);" class="btnPrev"><i class="fa-solid fa-arrow-left-long"></i></a>',
		nextArrow: '<a href="javascript:void(0);" class="btnNext"><i class="fa-solid fa-arrow-right-long"></i></a>',
		responsive: [{
				breakpoint: 991,
				settings: {
					slidesToShow: 2,
				}
			},
			{
				breakpoint: 767,
				settings: {
					slidesToShow: 1,
				}
			},
			{
				breakpoint: 576,
				settings: {
					slidesToShow: 1,
				}
			}
		]
	});



	// $(".nav-tabs .nav-item").click(function() {
	// 	$('html,body').animate({
	// 		scrollTop: $("figcaption").offset().top},
	// 		'slow');
	// });

	$('.nav-tabs .nav-item').click(function() {

		$('html,body').animate({scrollTop: '200px'},500);
	 
	 });




	$('.nav-pills > li > a').hover(function () {
		$(this).tab('show');
	});


	$(".preLoader").addClass("animated fadeOut");
	setTimeout(function () {
		$(".preLoader").css("display", "none");
	}, 1500);


	$(window).scroll(function(){ 
		if ($(this).scrollTop() > 500) { 
			$('#scroll').fadeIn(); 
		} else { 
			$('#scroll').fadeOut(); 
		} 
	}); 
	
	$('#scroll').click(function(){ 
		$("html, body").animate({ scrollTop: 0 }, 500); 
		return false; 
	});
	





	AOS.init({
		easing: 'ease-in-out-sine',
		disable: 'mobile'
	});

	AOS.init({
		disable: function () {
			var maxWidth = 1000;
			return window.innerWidth < maxWidth;
		}
	});



	//Fancybox.bind("[data-custombox]", {
	//		  groupAttr: "data-custombox",
	//		});

	Fancybox.bind('[data-fancybox="gallery"]', {
		Thumbs: {
			type: "modern"
		}
	});




	$(window).scroll(function () {

		//$(".nav-diversified").toggleClass("fixed", $(this).scrollTop() > 60);

		if ($(this).scrollTop() > 100) {
			$("header").addClass("fixedTop");
		} else {
			$("header").removeClass("fixedTop");
		}



	});

	




	// var a = 0;
	// $(window).scroll(function () {

	// 	var oTop = $('#counter').offset().top - window.innerHeight;
	// 	if (a == 0 && $(window).scrollTop() > oTop) {


	// 		$('.counter').each(function () {
	// 			$(this).prop('Counter', 0).animate({
	// 				Counter: $(this).text()
	// 			}, {
	// 				duration: 4000,
	// 				easing: 'swing',
	// 				step: function (now) {
	// 					$(this).text(Math.ceil(now));
	// 				}
	// 			});
	// 		});

	// 		a = 1;
	// 	}

	// });


	$("#hideBtn").click(function () {
		$(".tab-pane").removeClass("show");
		$(".tab-pane").removeClass("active");
		$(".nav-link").removeClass("active");

	});




// var $affectedElements = $("body"); // Can be extended, ex. $("div, p, span.someClass")

// 		// Storing the original size in a data attribute so size can be reset
// 		$affectedElements.each( function(){
// 		  var $this = $(this);
// 		  $this.data("orig-size", $this.css("font-size") );
// 		});
		
// 		$("#increase").click(function(){
// 		  changeFontSize(1);
// 		})
		
// 		$("#decrease").click(function(){
// 		  changeFontSize(-1);
// 		})
		
// 		$("#normal").click(function(){
// 		  $affectedElements.each( function(){
// 				var $this = $(this);
// 				$this.css( "font-size" , $this.data("orig-size") );
// 		   });
// 		})
		
// 		function changeFontSize(direction){
// 			$affectedElements.each( function(){
// 				var $this = $(this);
// 				$this.css( "font-size" , parseInt($this.css("font-size"))+direction );
// 			});
// }



//   if(minFont<baseFont){
//   	$("#decrease").removeClass("disabled");
// 	} else {
// 		$("#decrease").addClass("disabled");
// 	}

// 	if(maxFont>baseFont){
// 		$("#increase").removeClass("disabled");
// 	  } else {
// 		  $("#increase").addClass("disabled");
// 	  }

var baseFont=15.2;
var minFont=12;
var maxFont=20;
$("#increase").click(function(){
	if(baseFont<maxFont){
		baseFont=baseFont+1;
		$("html").css("font-size",baseFont);
	}
  });
  
  $("#decrease").click(function(){
	if(baseFont>minFont){
		baseFont=baseFont-1;
		$("html").css("font-size",baseFont);
	}
  });
  
  $("#normal").click(function(){
	$("html").css("font-size",15.2);
	baseFont=15.2;
  });


  



	$('#greyscale').click(function() {
	if ($('html').hasClass('blackTheme')){
		$('html').removeClass('blackTheme');
	} else {
		$('html').addClass('blackTheme');
	}
	});


	$('.accessibility .dropdown-menu li').on('click', function(event){
		event.stopPropagation();
	  });





});