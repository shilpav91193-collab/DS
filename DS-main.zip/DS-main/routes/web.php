<?php

use App\Http\Controllers\Frontend\AirportsController;
use App\Http\Controllers\Frontend\ContactController;
use App\Http\Controllers\Frontend\DistrictsController;
use App\Http\Controllers\Frontend\DocumentController;
use App\Http\Controllers\Frontend\HomeController;
use App\Http\Controllers\Frontend\NewsController;
use App\Http\Controllers\Frontend\PostController;
use App\Http\Controllers\Frontend\SectorsController;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/test-captcha', function () {
    return view('Frontend.pages.test');
});

Route::group(['middleware' => 'language'], function () {
    Route::post('{locale}/store-contact', [ContactController::class, 'storeContact']);

    Route::any('/', function () {
        $locale = App::getLocale() ? App::getLocale() : 'en';
        App::setLocale($locale);

        return redirect('/'.$locale, 301);
    }
    );
    Route::get('{locale}/{slug}/download', [DocumentController::class, 'downloadDocument'])->where(['locale' => '(en|ar)']);

    Route::get('/{locale}', [HomeController::class, 'index'])->where(['locale' => '(en|ar)']);
    Route::get('/{locale}/load-more-news', [PostController::class, 'loadMoreNews'])->where(['locale' => '(en|ar)']);
    Route::get('/{locale}/load-more-laws', [PostController::class, 'loadMoreLawsAndGovernance'])->where(['locale' => '(en|ar)']);
    Route::get('/{locale}/newsroom/{slug}', [NewsController::class, 'newsDetails'])->where(['locale' => '(en|ar)']);
    Route::get('/{locale}/sectors/{slug}', [SectorsController::class, 'show'])->where(['locale' => '(en|ar)']);
    Route::get('/{locale}/districts/{slug}', [DistrictsController::class, 'show'])->where(['locale' => '(en|ar)']);
    Route::get('/{locale}/airports/{slug}', [AirportsController::class, 'show'])->where(['locale' => '(en|ar)']);

    Route::any('/{locale}/{slug}', [PostController::class, 'showPage'])
        ->where('slug', '^(?!d-admin).*$')
        ->where(['locale' => '(en|ar)'])->name('page.show');

    Route::any('{slug}', function ($slug) {
        $locale = App::getLocale() ? App::getLocale() : 'en';
        App::setLocale($locale);

        return redirect('/'.$locale.'/'.$slug, 301);
    }
    )->where('slug', '^(?!d-admin|logout|login|forgot-password).*$')->name('page.show');
});
