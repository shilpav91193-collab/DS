<?php

use App\Http\Controllers\Cpanel\AjaxController;
use App\Http\Controllers\Cpanel\BannerController;
use App\Http\Controllers\Cpanel\DocumentController;
use App\Http\Controllers\Cpanel\FileManagerController;
use App\Http\Controllers\Cpanel\GalleryController;
use App\Http\Controllers\Cpanel\GroupsController;
use App\Http\Controllers\Cpanel\GroupTypeController;
use App\Http\Controllers\Cpanel\HomeController;
use App\Http\Controllers\Cpanel\MediaController;
use App\Http\Controllers\Cpanel\PostsController;
use App\Http\Controllers\Cpanel\SectorsController;
use App\Http\Controllers\Cpanel\SettingsController;
use App\Http\Controllers\Cpanel\TeamsController;
use App\Http\Controllers\Cpanel\UserController;
use App\Http\Controllers\Cpanel\UserRoleController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/dashboard', function () {
    return view('cpanel.dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::namespace('Cpanel')->group(function () {
    Route::get('/', [HomeController::class, 'index']);
    Route::middleware('auth')->group(function () {
        Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
        Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
        Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    });

    Route::prefix('settings')->group(function () {
        Route::get('config', [SettingsController::class, 'config'])
            ->name('settings.config');
        Route::post('config', [SettingsController::class, 'config']);
    });

    Route::prefix('users')->group(function () {
        Route::get('/', [UserController::class, 'list'])->name('users.list');
        Route::get('create', [UserController::class, 'create'])->name('users.create');
        Route::post('create', [UserController::class, 'update'])->name('users.create.post');
        Route::get('edit/{id}', [UserController::class, 'edit'])->name('users.edit');
        Route::post('edit/{id}', [UserController::class, 'update'])->name('users.edit.post');
        Route::get('reset_password/{id}', [UserController::class, 'resetPassword'])->name('users.reset_password');
        Route::get('delete/{id}', [UserController::class, 'destroy'])->name('users.delete');
        Route::post('ajax', [UserController::class, 'ajax'])->name('users.ajax.post');
    });

    Route::prefix('roles')->group(function () {
        Route::get('/', [UserRoleController::class, 'list'])->name('roles.list');
        Route::get('create', [UserRoleController::class, 'create'])->name('roles.create');
        Route::post('create', [UserRoleController::class, 'update'])->name('roles.create.post');
        Route::get('edit/{id}', [UserRoleController::class, 'edit'])->name('roles.edit');
        Route::post('edit/{id}', [UserRoleController::class, 'update'])->name('roles.edit.post');
        Route::get('delete/{id}', [UserRoleController::class, 'destroy'])->name('roles.destroy');
    });

    Route::prefix('banners')->group(function () {
        Route::get('/', [BannerController::class, 'list'])->name('banners.list');
        Route::get('create', [BannerController::class, 'create'])->name('banners.create');
        Route::post('create', [BannerController::class, 'update'])->name('banners.create.post');
        Route::get('edit/{banners}', [BannerController::class, 'edit'])->name('banners.edit');
        Route::post('edit', [BannerController::class, 'update'])->name('banners.edit.post');
        Route::post('edit', [BannerController::class, 'update'])->name('banners.edit.post');
        Route::get('destroy/{banners}', [BannerController::class, 'destroy'])->name('banners.delete');

        Route::post('uploadImage', [BannerController::class, 'uploadImage'])->name('banners.uploadImage');
        Route::post('delete', [BannerController::class, 'removeImage'])->name('banners.removeImage');
    });

    Route::prefix('galleries')->group(function () {
        Route::get('/', [GalleryController::class, 'list'])->name('galleries.list');
        Route::get('create', [GalleryController::class, 'create'])->name('galleries.create');
        Route::post('create', [GalleryController::class, 'update'])->name('galleries.create.post');
        Route::get('edit/{galleries}', [GalleryController::class, 'edit'])->name('galleries.edit');
        Route::post('edit', [GalleryController::class, 'update'])->name('galleries.edit.post');
        Route::post('edit', [GalleryController::class, 'update'])->name('galleries.edit.post');
        Route::get('destroy/{galleries}', [GalleryController::class, 'destroy'])->name('galleries.delete');

        Route::post('uploadImage', [GalleryController::class, 'uploadImage'])->name('galleries.uploadImage');
        Route::post('addVideo', [GalleryController::class, 'addVideo'])->name('galleries.addVideo');
        Route::post('delete', [GalleryController::class, 'removeImage'])->name('galleries.removeImage');
    });

    Route::prefix('media')->group(function () {
        Route::get('/', [MediaController::class, 'list'])->name('media.library');
        Route::get('/ajax', [MediaController::class, 'ajax'])->name('media.list');
    });

    Route::prefix('ajax')->group(function () {
        Route::get('changeStatus', [AjaxController::class, 'changeStatus'])->name('ajax.changeStatus.get');
        Route::post('changeStatus', [AjaxController::class, 'changeStatus'])->name('ajax.changeStatus.post');
        Route::post('generatePassword', [AjaxController::class, 'generatePassword'])->name('ajax.generatePassword.post');
        Route::post('changeOrder', [AjaxController::class, 'changeOrder'])->name('ajax.changeOrder.get');
        Route::get('changeOrder', [AjaxController::class, 'changeOrder'])->name('ajax.changeOrder.post');
    });

    Route::prefix('filemanager')->group(function () {
        Route::get('/', [FileManagerController::class, 'list'])->name('filemanager.index');
        Route::get('files', [FileManagerController::class, 'files'])->name('filemanager.files');
        Route::post('create_folder', [FileManagerController::class, 'createDirectory'])->name('filemanager.create_directory');
        Route::post('upload', [FileManagerController::class, 'uploadFile'])->name('filemanager.upload_file');
        Route::post('delete', [FileManagerController::class, 'deleteFile'])->name('filemanager.destroy');
    });

    Route::prefix('posts')->group(function () {
        Route::get('/', [PostsController::class, 'list'])->name('posts.list');
        Route::get('create', [PostsController::class, 'create'])->name('posts.create');
        Route::post('create', [PostsController::class, 'store'])->name('posts.create.post');
        Route::get('edit/{id?}', [PostsController::class, 'edit'])->name('posts.edit');
        Route::post('edit/{id?}', [PostsController::class, 'update'])->name('posts.edit.post');
        Route::get('delete/{id}', [PostsController::class, 'delete'])->name('posts.delete');
        Route::get('delete', [PostsController::class, 'delete'])->name('posts.delete.post');

        Route::get('ajax', [PostsController::class, 'ajax'])->name('posts.ajax');
        Route::post('ajax', [PostsController::class, 'ajax'])->name('posts.ajax.post');
    });

    Route::prefix('group-types')->group(function () {
        Route::get('/', [GroupTypeController::class, 'list'])->name('group-types.list');
        Route::get('create', [GroupTypeController::class, 'create'])->name('group-types.create');
        Route::post('create/{id?}', [GroupTypeController::class, 'update'])->name('group-types.create.post');
        Route::get('edit/{id?}', [GroupTypeController::class, 'edit'])->name('group-types.edit');
        Route::post('edit/{id?}', [GroupTypeController::class, 'update'])->name('group-types.edit.post');
        Route::get('delete/{id}', [GroupTypeController::class, 'delete'])->name('group-types.destroy');
        Route::get('delete', [GroupTypeController::class, 'delete'])->name('group-types.destroy.post');
    });

    Route::prefix('groups')->group(function () {
        Route::get('/', [GroupsController::class, 'list'])->name('groups.list');
        Route::get('create', [GroupsController::class, 'create'])->name('groups.create');
        Route::post('create/{id?}', [GroupsController::class, 'update'])->name('groups.create.post');
        Route::get('edit/{id?}', [GroupsController::class, 'edit'])->name('groups.edit');
        Route::post('edit/{id?}', [GroupsController::class, 'update'])->name('groups.edit.post');
        Route::get('delete/{id}', [GroupsController::class, 'delete'])->name('groups.destroy');
        Route::get('delete', [GroupsController::class, 'delete'])->name('groups.destroy.post');
    });

//    Route::prefix('sectors')->group(function () {
//        Route::get('/', [SectorsController::class, 'list'])->name('sectors.list');
//        Route::get('create', [SectorsController::class, 'create'])->name('sectors.create');
//        Route::post('create/{id?}', [SectorsController::class, 'update'])->name('sectors.create.post');
//        Route::get('edit/{id?}', [SectorsController::class, 'edit'])->name('sectors.edit');
//        Route::post('edit/{id?}', [SectorsController::class, 'update'])->name('sectors.edit.post');
//        Route::get('delete/{id}', [SectorsController::class, 'delete'])->name('sectors.destroy');
//        Route::get('delete', [SectorsController::class, 'delete'])->name('sectors.destroy.post');
//    });

    Route::prefix('sectors')->group(function () {
        Route::get('/', [SectorsController::class, 'list'])->name('sectors.list');
        Route::get('create', [SectorsController::class, 'create'])->name('sectors.create');
        Route::post('create/{id?}', [SectorsController::class, 'update'])->name('sectors.create.post');
        Route::get('edit/{id?}', [SectorsController::class, 'edit'])->name('sectors.edit');
        Route::post('edit/{id?}', [SectorsController::class, 'update'])->name('sectors.edit.post');
        Route::get('delete/{id}', [SectorsController::class, 'delete'])->name('sectors.destroy');
        Route::get('delete', [SectorsController::class, 'delete'])->name('sectors.destroy.post');
    });

    Route::prefix('teams')->group(function () {
        Route::get('/', [TeamsController::class, 'list'])->name('teams.list');
        Route::get('create', [TeamsController::class, 'create'])->name('teams.create');
        Route::post('create', [TeamsController::class, 'store'])->name('teams.create.post');
        Route::get('edit/{id}', [TeamsController::class, 'edit'])->name('teams.edit');
        Route::post('edit/{id}', [TeamsController::class, 'update'])->name('teams.edit.post');
        Route::get('delete/{id}', [TeamsController::class, 'delete'])->name('teams.delete');
        Route::get('delete', [TeamsController::class, 'delete'])->name('teams.delete.post');

        Route::get('ajax', [TeamsController::class, 'ajax'])->name('teams.ajax');
        Route::post('ajax', [TeamsController::class, 'ajax'])->name('teams.ajax.post');
    });

    Route::prefix('documents')->group(function () {
        Route::get('/', [DocumentController::class, 'list'])->name('documents.list');
        Route::get('create/{id?}', [DocumentController::class, 'edit'])->name('documents.create');
        Route::post('create/{id?}', [DocumentController::class, 'update'])->name('documents.create.post');
        Route::get('edit/{id?}', [DocumentController::class, 'edit'])->name('documents.edit');
        Route::post('edit/{id?}', [DocumentController::class, 'update'])->name('documents.edit.post');
        Route::get('delete/{id}', [DocumentController::class, 'delete'])->name('documents.destroy');
        Route::get('delete', [DocumentController::class, 'delete'])->name('documents.destroy.post');
    });

    Route::get('/update-migrations', function () {
        \Illuminate\Support\Facades\Artisan::call('migrate');

        return 'Migrations have been updated!';
    });

    Route::get('/update-seeders', function () {
        \Illuminate\Support\Facades\Artisan::call('db:seed');

        return 'Seeders have been updated!';
    });

    Route::get('/storage-link', function () {
        \Illuminate\Support\Facades\Artisan::call('storage:link');

        return 'Link have been updated!';
    });
});

require __DIR__.'/auth.php';
