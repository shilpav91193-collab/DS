function setCookie(key, value) {
    var expires = new Date();
    expires.setTime(expires.getTime() + (1 * 24 * 60 * 60 * 1000));
    document.cookie = key + '=' + value + ';expires=' + expires.toUTCString();
}
function getCookie(key) {
    var keyValue = document.cookie.match('(^|;) ?' + key + '=([^;]*)(;|$)');
    return keyValue ? keyValue[2] : null;
}


var fee = [0, 0];
$().ready(function () {

    $('select[name=faculty]').change(function () {
        var $new_courses = window.courses.filter(c => c.faculty_id == $(this).val());
        var $courses = '<option value=""></option>';
        $new_courses.forEach(course => {
            $courses += '<option value="' + course.id + '">' + course.name + '</option>';
        });
        $('select[name=course]').html($courses);
        $('select[name=course]').selectpicker('refresh');
        $('#majors_area').hide();
    });

    $('select[name=course]').change(function () {
        var $course = window.courses.find(c => c.id == $(this).val());
        var $majors = '';
        $course.majors.forEach(major => {
            $majors += '<option value="' + major.id + '">' + major.title + '</option>';
        });
        if (!$course.majors.length) {
            $('#majors_available').hide();
            $('#majors_not_available').show();
            $('#majors_available').selectpicker('hide');
            $('select[name="majors[]"]').prop('disabled', true);
            $('select[name="majors[]"]').selectpicker('refresh');
        } else {
            $('#majors_available').show();
            $('select[name="majors[]"]').html($majors);
            $('#majors_available').selectpicker('show');
            $('#majors_not_available').hide();
            $('select[name="majors[]"]').prop('disabled', false);
            $('select[name="majors[]"]').selectpicker('refresh');
        }
    });

    $('#postal_address').hide();
    $('input[name=posted]').change(function () {
        //console.log( $('input[name=posted]:checked').val() );
        if ($('input[name=posted]:checked').val() == 'posted_to_address') {
            $('#postal_address').show();
        } else if ($('input[name=posted]:checked').val() == 'held') {
            $('#postal_address').hide();
        }
    });
    $('select[name=posted]').trigger('change');

    $('select[name=country]').trigger('change');
    $('select[name=testamur]').trigger('change');

    $('select[name=employment_status]').change(function () {
        if ($(this).val() == 'Employed' || $(this).val() == 'Self-Employed') {
            $('#employment_details').show();
            $('#employment_details_other').hide();
        } else if ($(this).val() == 'Other') {
            $('#employment_details').hide();
            $('#employment_details_other').show();
        } else {
            $('#employment_details').hide();
            $('#employment_details_other').hide();
        }
    });

    //   $('#graduateregistrationform input[name=Submit]').click(function(){
    //      if($('#graduateregistrationform').valid()){
    //          $('#graduateregistrationform').submit();
    //      }
    //   });


    $.validator.addMethod("list_selected", function (value, element) {
        return (value != '');
    }, "Please select one from this list.");

    $.validator.addMethod('filesize', function (value, element, param) {
        return this.optional(element) || (element.files[0].size <= param * 1024 * 1024);
    }, 'File size must be less than {0} MB');

    $('#graduateregistrationform').validate({
        rules: {
            check_agree: { required: true },
            name: { required: true },
            //   rdoSolsName:{required:true},

            emirates_id: { required: true },
            faculty: { required: true },
            course: { required: true },
            'majors[]': { required: function () { return (window.courses.find(c => c.id == $('select[name=course]').val()) || { majors: [] }).majors.length > 1 } },
            email: { required: true, email: true },
            mobile: { required: true },
            nationality: { list_selected: true },
            //   rdoSolsNationality:{required:true},

            visa_sponser: { required: true },
            graduation_year: { required: true },
            last_semester: { required: true },

            testamur: { required: true },
            filePassport: { required: true, accept: 'jpg|png|pdf', filesize: 2 },
            fileEmiratesID: { required: true, accept: 'jpg|png|pdf', filesize: 2 },

            employment_status: { required: true },
            job_title: { required: function () { return ($('#employment_status').val() == 'Employed' || $('#employment_status').val() == 'Self-Employed'); } },
            company_name: { required: function () { return ($('#employment_status').val() == 'Employed' || $('#employment_status').val() == 'Self-Employed'); } },
            city: { required: function () { return ($('#employment_status').val() == 'Employed' || $('#employment_status').val() == 'Self-Employed'); } },
            industry: { required: function () { return ($('#employment_status').val() == 'Employed' || $('#employment_status').val() == 'Self-Employed'); } },
            work_email: { email: true, required: function () { return ($('#employment_status').val() == 'Employed' || $('#employment_status').val() == 'Self-Employed'); } },
            linkedin: { required: function () { return ($('#employment_status').val() == 'Employed' || $('#employment_status').val() == 'Self-Employed'); } },

            posted: { required: true },
            address: { required: "#posted_posted_to_address:checked" },
            street: { required: "#posted_posted_to_address:checked" },
            postal_code: { required: "#posted_posted_to_address:checked" },
            residence_city: { required: "#posted_posted_to_address:checked" },
            country: { required: "#posted_posted_to_address:checked" },
            phone: { required: "#posted_posted_to_address:checked" },
            check_agree2: { required: true }
        },
        messages: {
            check_agree: 'Please read the notes in order to proceed.',
            check_agree2: 'Please agree to the Terms &amp; Conditions in order to proceed.'
        },
        errorPlacement: function (error, element) {
            error.appendTo(element.closest('.reg-form-group'));
        },
        submitHandler: function (form) {
            form.submit();
        },
        meta: "validate"
    });

    $('select[name=faculty]').trigger('change');
    $('select[name=course]').val(window.oldData.course).trigger('change');
    $('select[name=majors]').val(window.oldData.majors).trigger('change');
    $('select[name=employment_status]').trigger('change');
    $('select[name=visa_sponsor]').trigger('change');
    $('select').trigger('change');
});
