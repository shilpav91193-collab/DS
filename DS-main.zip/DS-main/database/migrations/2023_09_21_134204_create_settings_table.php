<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('title')->nullable();
            $table->string('name')->nullable();
            $table->longText('value')->nullable();
            $table->enum('type',
                ['text', 'textarea', 'checkbox', 'radio', 'select', 'tokenfield', 'textEditor'])->nullable();
            $table->text('options')->nullable();
            $table->char('can_edit', 1)->default('Y')->nullable();
            $table->integer('sort_order')->nullable();
            $table->string('config_group')->nullable();
            $table->integer('row')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('settings');
    }
};
