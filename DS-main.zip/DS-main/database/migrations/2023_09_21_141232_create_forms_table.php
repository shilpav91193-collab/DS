<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('forms', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('dept_id')->nullable();
            $table->unsignedBigInteger('user_role')->nullable();
            $table->string('title')->nullable();
            $table->string('slug')->nullable();
            $table->text('description')->nullable();
            $table->string('version')->nullable();
            $table->string('code')->nullable();

            $table->char('status', 1)
                ->comment('Y, N')
                ->default('Y')
                ->nullable();

            $table->char('featured', 1)
                ->comment('Y, N')
                ->default('Y')
                ->nullable();

            $table->string('interactive')->nullable();
            $table->enum('form_type', ['document', 'url', 'webform'])->nullable();
            $table->string('webform_id')->nullable();
            $table->string('form_doc')->nullable();
            $table->string('form_url')->nullable();
            $table->integer('sort_order')->nullable();

            $table->timestamp('last_update')->nullable();
            $table->unsignedBigInteger('added_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();

            $table->timestamps();
            $table->softDeletes();

            $table->foreign('added_by')
                ->references('id')
                ->on('users')
                ->onDelete('cascade')
                ->onUpdate('cascade');

            $table->foreign('updated_by')
                ->references('id')
                ->on('users')
                ->onDelete('cascade')
                ->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('forms');
    }
};
