<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('modules', function (Blueprint $table) {
            $table->id();
            $table->string('name')->nullable();
            $table->longText('description')->nullable();
            $table->integer('display_order')->nullable();
            $table->string('icon')->nullable();
            $table->string('slug')->nullable();
            $table->string('link')->nullable();

            $table->char('requireSession', 1)
                ->comment('Y, N')
                ->nullable();

            $table->char('status', 1)
                ->comment('Y, N')
                ->nullable();

            $table->string('configValues')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('modules');
    }
};
