<?php

namespace Database\Seeders;

use App\Models\UserRole;
use Illuminate\Database\Seeder;

class UserRoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $access = [
            'module_access' => [
                'dashboard' => ['list', 'create', 'update', 'delete'],
                'page' => ['list', 'create', 'update', 'delete'],
                'news' => ['list', 'create', 'update', 'delete'],
                'group-types' => ['list', 'create', 'update', 'delete'],
                'groups' => ['list', 'create', 'update', 'delete'],
                'public_documents' => ['list', 'create', 'update', 'delete'],
                'galleries' => ['list', 'create', 'update', 'delete'],
                'banners' => ['list', 'create', 'update', 'delete'],
                'settings' => ['list', 'create', 'update', 'delete'],
                'users' => ['list', 'create', 'update', 'delete'],
                'roles' => ['list', 'create', 'update', 'delete'],
                'filemanager' => ['list', 'create', 'update', 'delete'],
                'contents' => ['list', 'create', 'update', 'delete', 'approve'],
            ],
        ];

        UserRole::updateOrCreate(
            ['name' => 'Super Admin'],
            ['status' => 'Y', 'access' => json_encode($access)]
        );
    }
}
