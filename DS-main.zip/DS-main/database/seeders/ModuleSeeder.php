<?php

namespace Database\Seeders;

use App\Models\Module;
use Illuminate\Database\Seeder;

class ModuleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $modules = [
            [
                'name' => 'System',
                'icon' => 'fa fa-cog',
                'slug' => 'settings',
                'link' => 'd-admin/settings/confic',
                'requireSession' => 'N',
                'status' => 'Y',
                'display_order' => 9,
            ],
            [
                'name' => 'My Dashboard',
                'icon' => 'fas fa-tachometer-alt',
                'slug' => 'dashboard',
                'link' => 'd-admin/dashboard',
                'requireSession' => 'N',
                'status' => 'N',
                'display_order' => 1,
            ],
            [
                'name' => 'Documents',
                'icon' => 'fas fa-file-pdf',
                'slug' => 'forms',
                'link' => '	d-admin/forms',
                'requireSession' => 'N',
                'status' => 'Y',
                'display_order' => 5,
            ],
            [
                'name' => 'Appearance',
                'icon' => 'fas fa-search-plus',
                'slug' => 'menus',
                'link' => 'd-admin/menus',
                'requireSession' => 'N',
                'status' => 'Y',
                'display_order' => 7,
            ],
            [
                'name' => 'Media Library',
                'icon' => 'fas fa-image',
                'slug' => 'medias',
                'link' => 'd-admin/galleries',
                'requireSession' => 'N',
                'status' => 'Y',
                'display_order' => 6,
            ],

            [
                'name' => 'Events',
                'icon' => 'fas fa-calendar',
                'slug' => 'events',
                'link' => 'd-admin/events',
                'requireSession' => 'N',
                'status' => 'Y',
                'display_order' => 3,
            ],
            [
                'name' => 'Collections',
                'icon' => 'fa fa-shopping-bag',
                'slug' => 'group-types',
                'link' => 'd-admin/group-types',
                'requireSession' => 'N',
                'status' => 'Y',
                'display_order' => 4,
            ],
            [
                'name' => 'Contents',
                'icon' => 'fa fa-folder-open',
                'slug' => 'page',
                'link' => 'd-admin/posts?post_type=page',
                'requireSession' => 'N',
                'status' => 'Y',
                'display_order' => 2,
            ],
            [
                'name' => 'Contact us',
                'icon' => 'fas fa-phone',
                'slug' => 'contact-us',
                'link' => 'd-admin/contact-us',
                'requireSession' => 'N',
                'status' => 'Y',
                'display_order' => 8,
            ],
        ];

        foreach ($modules as $module) {
            $slug = $module['slug'];
            Module::updateOrCreate(['slug' => $slug], $module);
        }
    }
}
