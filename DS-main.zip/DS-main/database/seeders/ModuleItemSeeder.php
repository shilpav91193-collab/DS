<?php

namespace Database\Seeders;

use App\Models\Module;
use App\Models\ModuleItem;
use Illuminate\Database\Seeder;

class ModuleItemSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $modules = [
            [
                'name' => 'Users',
                'icon' => 'fas fa-users',
                'slug' => 'users',
                'link' => 'd-admin/users',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'System')->first()->id,
            ],
            [
                'name' => 'Roles',
                'icon' => 'fas fa-user-lock',
                'slug' => 'roles',
                'link' => 'd-admin/roles',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'System')->first()->id,
            ],
            [
                'name' => 'Settings',
                'icon' => 'fas fa-cogs',
                'slug' => 'settings',
                'link' => 'd-admin/settings/config',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'System')->first()->id,
            ],
            [
                'name' => 'Forms',
                'icon' => 'fas fa-cogs',
                'slug' => 'forms',
                'link' => 'd-admin/forms',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'Documents')->first()->id,
            ],
            [
                'name' => 'File manager',
                'icon' => 'fa fa-upload',
                'slug' => 'filemanager',
                'link' => 'd-admin/files',
                'requireSession' => 'N',
                'status' => 'N',
                'module_id' => Module::where('name', 'System')->first()->id,
            ],
            [
                'name' => 'Galleries',
                'icon' => 'far fa-image',
                'slug' => 'galleries',
                'link' => 'd-admin/galleries',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'Media Library')->first()->id,
            ],
            [
                'name' => 'Banners',
                'icon' => 'far fa-image',
                'slug' => 'banners',
                'link' => 'd-admin/banners',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'Media Library')->first()->id,
            ],
            [
                'name' => 'General documents',
                'icon' => 'far fa-circle',
                'slug' => 'general_documents',
                'link' => 'd-admin/general_documents',
                'requireSession' => 'N',
                'status' => 'N',
                'module_id' => Module::where('name', 'Documents')->first()->id,
            ],
            [
                'name' => 'Public Documents',
                'icon' => 'far fa-circle',
                'slug' => 'public_documents',
                'link' => 'd-admin/filemanager',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'Documents')->first()->id,
            ],
            [
                'name' => 'Navigation menu',
                'icon' => 'far fa-circle',
                'slug' => 'menus',
                'link' => 'd-admin/menus/create',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'Appearance')->first()->id,
            ],
            [
                'name' => 'Enquiry Form',
                'icon' => 'fa fa-question-circle',
                'slug' => 'enquiry_form',
                'link' => 'd-admin/enquiry_form',
                'requireSession' => 'N',
                'status' => 'N',
                'module_id' => Module::where('name', 'Contact us')->first()->id,
            ],
            [
                'name' => 'Pages',
                'icon' => 'fas fa-file',
                'slug' => 'page',
                'link' => 'd-admin/posts?post_type=page',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'Contents')->first()->id,
            ],
            [
                'name' => 'News',
                'icon' => 'fas fa-file',
                'slug' => 'news',
                'link' => 'd-admin/posts?post_type=news',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'Contents')->first()->id,
            ],
            [
                'name' => 'Sectors',
                'icon' => 'fas fa-file',
                'slug' => 'sectors',
                'link' => 'd-admin/posts?post_type=sectors',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'Contents')->first()->id,
            ],
            [
                'name' => 'Districts',
                'icon' => 'fas fa-file',
                'slug' => 'districts',
                'link' => 'd-admin/posts?post_type=districts',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'Contents')->first()->id,
            ],
            [
                'name' => 'Airports',
                'icon' => 'fas fa-file',
                'slug' => 'airports',
                'link' => 'd-admin/posts?post_type=airports',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'Contents')->first()->id,
            ],
            [
                'name' => 'Articles',
                'icon' => 'fas fa-file',
                'slug' => 'article',
                'link' => 'd-admin/posts?post_type=article',
                'requireSession' => 'N',
                'status' => 'N',
                'module_id' => Module::where('name', 'Contents')->first()->id,
            ],
            [
                'name' => 'Article Categories',
                'icon' => 'fa fa-th',
                'slug' => 'term_article',
                'link' => 'd-admin/taxonomies?term=article',
                'requireSession' => 'N',
                'status' => 'N',
                'module_id' => Module::where('name', 'Contents')->first()->id,
            ],
            [
                'name' => 'Tables',
                'icon' => 'fa fa-table',
                'slug' => 'tables',
                'link' => 'd-admin/tables',
                'requireSession' => 'N',
                'status' => 'N',
                'module_id' => Module::where('name', 'Collections')->first()->id,
            ],
            [
                'name' => 'Teams',
                'icon' => 'fa fa-users',
                'slug' => 'teams',
                'link' => 'd-admin/teams',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'Collections')->first()->id,
            ],
            [
                'name' => 'Documents',
                'icon' => 'fas fa-file-pdf',
                'slug' => 'documents',
                'link' => 'd-admin/documents',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'Collections')->first()->id,
            ],
            [
                'name' => 'Events',
                'icon' => 'fas fa-calendar',
                'slug' => 'events',
                'link' => 'd-admin/events',
                'requireSession' => 'N',
                'status' => 'N',
                'module_id' => Module::where('name', 'Events')->first()->id,
            ],
            [
                'name' => 'Event Category',
                'icon' => 'fas fa-list',
                'slug' => 'events-category',
                'link' => 'd-admin/events/events-category',
                'requireSession' => 'N',
                'status' => 'N',
                'module_id' => Module::where('name', 'Events')->first()->id,
            ],
            [
                'name' => 'Group Types',
                'icon' => 'far fa-chart-bar',
                'slug' => 'group-types',
                'link' => 'd-admin/group-types',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'Collections')->first()->id,
            ],
            [
                'name' => 'Groups',
                'icon' => 'far fa-chart-bar',
                'slug' => 'groups',
                'link' => 'd-admin/groups',
                'requireSession' => 'N',
                'status' => 'Y',
                'module_id' => Module::where('name', 'Collections')->first()->id,
            ],
            //            [
            //                'name' => 'Sectors',
            //                'icon' => 'far fa-chart-bar',
            //                'slug' => 'sectors',
            //                'link' => 'd-admin/sectors',
            //                'requireSession' => 'N',
            //                'status' => 'Y',
            //                'module_id' => Module::where('name', 'Collections')->first()->id,
            //            ],
        ];

        foreach ($modules as $module) {
            $slug = $module['slug'];
            ModuleItem::updateOrCreate(['slug' => $slug], $module);
        }
    }
}
