<?php

namespace Database\Seeders;

use App\Models\UserRole;
use Illuminate\Database\Seeder;
use Illuminate\Foundation\Auth\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::updateOrCreate(
            ['email' => 'admin@timesworld.com'],
            [
                'name' => 'Admin',
                'password' => Hash::make('U!X5b)Xc'),
                'status' => 'Y',
                'roleid' => UserRole::first()->id,
            ]
        );
    }
}
