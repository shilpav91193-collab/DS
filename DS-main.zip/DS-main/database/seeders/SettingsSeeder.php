<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

class SettingsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $settings = [
            [
                'title' => 'Site name',
                'name' => 'site_name',
                'value' => 'Dubai Aviation City Corporation',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'General',
                'row' => '2',
            ],
            [
                'title' => 'Site Keywords',
                'name' => 'site_keywords',
                'type' => 'textarea',
                'can_edit' => 'Y',
                'config_group' => 'General',
                'row' => '2',
            ],
            [
                'title' => 'Site description',
                'name' => 'site_description',
                'type' => 'textarea',
                'can_edit' => 'Y',
                'config_group' => 'General',
                'row' => '2',
            ],
            [
                'title' => 'Contact us To',
                'name' => 'contactus_email_to',
                'value' => 'maillogs.timesworld@gmail.com',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'General',
                'row' => '2',
            ],
            [
                'title' => 'Contact us To',
                'name' => 'contactus_email_to',
                'value' => 'maillogs.timesworld@gmail.com',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'Email',
                'row' => '2',
            ],
            [
                'title' => 'Contact email address',
                'name' => 'contact_email_address',
                'value' => 'maillogs.timesworld@gmail.com',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'General',
                'row' => '2',
            ],
            [
                'title' => 'contact phone number',
                'name' => 'contact_phone_number',
                'value' => '0552545474',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'General',
                'row' => '2',
            ],
            [
                'title' => 'Version',
                'name' => '_version',
                'value' => '1.2',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'General',
                'row' => '2',
            ],
            [
                'title' => 'google_recaptcha_key',
                'name' => 'google_recaptcha_key',
                'value' => '6LdIPuYjAAAAALXQsGYpkhqMsHuFZnYyjXWzE1lR',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'General',
                'row' => '2',
            ],
            [
                'title' => 'google_recaptcha_secret',
                'name' => 'google_recaptcha_secret',
                'value' => '6LdIPuYjAAAAAMTOTr9k_XgSWn9d9Bgh-AohUiaY',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'General',
                'row' => '2',
            ],
            [
                'title' => 'Timezone',
                'name' => '_timezone',
                'value' => 'Asia/Kolkata',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'General',
                'row' => '2',
            ],
            [
                'title' => 'Non-editable values',
                'name' => '_not_editable_post_slug',
                'value' => 'home',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'General',
                'row' => '2',
            ],
            [
                'title' => 'Pagination Limit',
                'name' => 'pagination_limit',
                'value' => '10',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'General',
                'row' => '2',
            ],
            [
                'title' => 'Footer Text',
                'name' => '_footer_text',
                'value' => 'About DACC',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'Footer',
                'row' => '2',
            ],
            [
                'title' => 'Footer Text Content',
                'name' => '_footer_text_content',
                'value' => 'Welcome to DACC(Dubai Aviation City Corporation), a dynamic organization that has been entrusted with achieving strategic objectives and playing key roles in supporting the economic growth of Dubai.',
                'type' => 'textarea',
                'can_edit' => 'Y',
                'config_group' => 'Footer',
                'row' => '2',
            ],
            [
                'title' => 'Website',
                'name' => '_website',
                'value' => 'https://amityuniversity.ae/',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'General',
                'row' => '2',
            ],
            [
                'title' => 'Top scroll text',
                'name' => 'top_scroll_text',
                'value' => 'Texst sample',
                'type' => 'textarea',
                'can_edit' => 'Y',
                'config_group' => 'Header',
                'row' => '2',
            ],
            [
                'title' => 'User Email Content - (Enquiry Form)',
                'name' => '_enquiry_user_email_content',
                'value' => '<p>jhjhjh</p>',
                'type' => 'textEditor',
                'can_edit' => 'Y',
                'config_group' => 'Email',
                'row' => '2',
            ],
            [
                'title' => 'Google Map',
                'name' => '_google_map',
                'value' => 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2151.654932510982!2d55.117788107908794!3d24.910337211357565!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f0ca11145b885%3A0x4ce897a92c258fd7!2sDubai%20South%20Office%20Headquarters!5e0!3m2!1sen!2sae!4v1693220825605!5m2!1sen!2sae',
                'type' => 'textarea',
                'can_edit' => 'Y',
                'config_group' => 'Footer',
                'row' => '2',
            ],
            [
                'title' => 'Twitter',
                'name' => '_twitter',
                'value' => '',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'Footer',
                'row' => '2',
            ],
            [
                'title' => 'Instagram',
                'name' => '_instagram',
                'value' => '',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'Footer',
                'row' => '2',
            ],
            [
                'title' => 'LinkedIn',
                'name' => '_linkedin',
                'value' => '',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'Footer',
                'row' => '2',
            ],
            [
                'title' => 'YouTube',
                'name' => '_youtube',
                'value' => '',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'Footer',
                'row' => '2',
            ],
            [
                'title' => 'Facebook',
                'name' => '_face_book',
                'value' => '',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'Footer',
                'row' => '2',
            ],
            [
                'title' => 'Address Text',
                'name' => '_address',
                'value' => 'Office Address',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'Footer',
                'row' => '2',
            ],
            [
                'title' => 'Address Text Content',
                'name' => '_address_content',
                'value' => '<p class="mt-2">Dubai Aviation City Corporation(DACC)<br>
                        P.O Box 282228, Dubai, UAE<br>
                        Landline Number | Fax Number<br>
                        Email: <a href="mailto:info@dacc.gov.ae">info@dacc.gov.ae</a></p>',
                'type' => 'textEditor',
                'can_edit' => 'Y',
                'config_group' => 'Footer',
                'row' => '2',
            ],
            [
                'title' => 'Office Hours Text',
                'name' => '_office_hours_text',
                'value' => 'Office Hours',
                'type' => 'text',
                'can_edit' => 'Y',
                'config_group' => 'Footer',
                'row' => '2',
            ],
            [
                'title' => 'Office Hours Content',
                'name' => '_office_hours_content',
                'value' => '<p class="mt-2">7:30am - 3:30pm GST (GMT + 4 Hrs)<br>Monday to Friday</p>',
                'type' => 'textEditor',
                'can_edit' => 'Y',
                'config_group' => 'Footer',
                'row' => '2',
            ],
            [
                'title' => 'Body Script',
                'name' => '_body_script',
                'value' => '',
                'type' => 'textarea',
                'can_edit' => 'Y',
                'config_group' => 'General',
                'row' => '2',
            ],
            [
                'title' => 'Header Script',
                'name' => '_header_script',
                'value' => '',
                'type' => 'textarea',
                'can_edit' => 'Y',
                'config_group' => 'Header',
                'row' => '2',
            ],
            [
                'title' => 'User Email Content - (Consulation Form)',
                'name' => '_consultation_user_email_content',
                'value' => '',
                'type' => 'textEditor',
                'can_edit' => 'Y',
                'config_group' => 'Email',
                'row' => '2',
            ],
        ];

        Setting::truncate();

        foreach ($settings as $setting) {
            $name = $setting['name'];
            Setting::updateOrCreate(['name' => $name], $setting);
        }
    }
}
